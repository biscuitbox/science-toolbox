"""
ESP32-CAM (AI-Thinker, 27 x 40.5 mm) 각도 조절 마운트
- cam_base   : 상판 격자에 M3 볼트 2개(간격 40mm)로 고정, 귀 2개
- cam_holder : 보드 뒷면을 양면 폼테이프로 붙이고 아래 모서리를 턱에 올림.
               M3x16 볼트 + 나일론 너트로 귀에 끼우고, 너트를 조이면 각도가 고정됨
보드 앞면 부품 위치(렌즈·SD 슬롯)는 제조사마다 조금씩 달라서 앞면은 전혀 건드리지 않고,
뒷면 가운데(양쪽 핀 줄 사이)와 아래 모서리로만 잡습니다.
좌표: base 바닥 z=0, X=앞, 회전축 (0, 0, PIVOT_H)
"""
import cadquery as cq
from params import M3_HOLE

PIVOT_H = 18.0
EAR_T = 3.0
EAR_IN = 4.4            # 귀 안쪽면 y
HUB_W = 4.2             # 홀더 허브 반폭 (귀 사이)
HUB_R = 6.0
EAR_R = 5.0
PLATE_X0, PLATE_X1 = 6.0, 8.5     # 홀더 등판 (앞면 x=8.5 에 보드 뒷면이 붙음)
PLATE_W = 10.0          # 등판 반폭 (핀 줄 y=±12.2 보다 안쪽)
PLATE_TOP = 50.0
SHELF_TOP = 6.0         # 보드 아래 모서리가 놓이는 높이 (회전축 기준)
FRONT_X0 = 7.5
SHELF_X1 = 10.3         # 기판 두께 1.6 + 여유

CAM_W, CAM_L, CAM_PCB = 27.0, 40.5, 1.6


def _box(x0, x1, y0, y1, z0, z1):
    return cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0, centered=False).translate((x0, y0, z0))


BASE_HOLES = [(0, 20), (0, -20)]   # 상판 격자 구멍 2개 (y 간격 40mm)


def cam_base():
    t = 3.0
    # 뒤쪽은 ESP32 받침과 겹치지 않게 짧게 (x -7.5 ~ +9.5)
    body = cq.Workplane("XY").center(1, 0).rect(17, 50).extrude(t).edges("|Z").fillet(3)
    for sy in (1, -1):
        ya, yb = sorted((sy * EAR_IN, sy * (EAR_IN + EAR_T)))
        ear = (cq.Workplane("XZ").workplane(offset=-yb).center(0, PIVOT_H).circle(EAR_R).extrude(EAR_T))
        ear = ear.union(_box(-EAR_R, EAR_R, ya, yb, t - 0.01, PIVOT_H))
        body = body.union(ear)
        # 귀 앞뒤 보강
        for sx in (1, -1):
            rib = (cq.Workplane("XZ").workplane(offset=-yb)
                   .polyline([(sx * EAR_R - sx * 0.01, t - 0.01), (sx * EAR_R + (4 if sx > 0 else -2.4), t - 0.01),
                              (sx * EAR_R - sx * 0.01, t + 9)])
                   .close().extrude(EAR_T))
            body = body.union(rib)
    body = body.cut(cq.Workplane("XZ").workplane(offset=-20).center(0, PIVOT_H).circle(M3_HOLE / 2).extrude(40))
    body = body.cut(cq.Workplane("XY").workplane(offset=-1).pushPoints(BASE_HOLES)
                    .circle(M3_HOLE / 2).extrude(t + 2))
    return body


def cam_holder(tilt_deg=0.0):
    """회전축 기준 좌표로 만든 뒤 base 위치로 옮김. tilt_deg>0 이면 위를 봄."""
    hub = (cq.Workplane("XZ").workplane(offset=-HUB_W).circle(HUB_R).extrude(2 * HUB_W))
    hub = hub.union(_box(0, FRONT_X0 + 0.01, -HUB_W, HUB_W, -HUB_R, HUB_R))
    front = _box(FRONT_X0, SHELF_X1, -PLATE_W, PLATE_W, -HUB_R, SHELF_TOP)
    plate = _box(PLATE_X0, PLATE_X1, -PLATE_W, PLATE_W, -HUB_R + 2, PLATE_TOP)
    # 등판과 허브 사이 보강
    web = (cq.Workplane("XZ").workplane(offset=-HUB_W)
           .polyline([(2, HUB_R - 0.5), (PLATE_X0 + 0.01, HUB_R - 0.5), (PLATE_X0 + 0.01, HUB_R + 10)]).close()
           .extrude(2 * HUB_W))
    body = hub.union(front).union(plate).union(web)
    body = body.edges("|X and >Z").fillet(2.0)
    body = body.cut(cq.Workplane("XZ").workplane(offset=-20).circle(M3_HOLE / 2).extrude(40))
    # 케이블타이 구멍 (테이프가 약할 때 보조, 핀 줄 사이로 지나감)
    body = body.cut(_box(PLATE_X0 - 1, PLATE_X1 + 1, -8.5, -5.5, 40, 42.5))
    body = body.cut(_box(PLATE_X0 - 1, PLATE_X1 + 1, 5.5, 8.5, 40, 42.5))
    if tilt_deg:
        body = body.rotate((0, 0, 0), (0, 1, 0), -tilt_deg)
    return body.translate((0, 0, PIVOT_H))


def mock_esp32cam(tilt_deg=0.0):
    """조립 확인용 ESP32-CAM 모형 (회전축 기준 → base 위치)"""
    x0 = PLATE_X1
    pcb = _box(x0, x0 + CAM_PCB, -CAM_W / 2, CAM_W / 2, SHELF_TOP, SHELF_TOP + CAM_L)
    module = _box(x0 + CAM_PCB, x0 + CAM_PCB + 3.2, -9, 9, SHELF_TOP + 14, SHELF_TOP + CAM_L - 1)
    camera = _box(x0 + CAM_PCB + 3.2, x0 + CAM_PCB + 5.2, -4.25, 4.25, SHELF_TOP + 24, SHELF_TOP + 32.5)
    lens = (cq.Workplane("YZ").workplane(offset=x0 + CAM_PCB + 5.2).center(0, SHELF_TOP + 28.25)
            .circle(3.5).extrude(3.5))
    pins = None
    for sy in (1, -1):
        p = _box(x0 - 16, x0, sy * 12.2 - 1.27, sy * 12.2 + 1.27, SHELF_TOP + 1, SHELF_TOP + 21.5)
        pins = p if pins is None else pins.union(p)
    body = pcb.union(module).union(camera).union(lens).union(pins)
    if tilt_deg:
        body = body.rotate((0, 0, 0), (0, 1, 0), -tilt_deg)
    return body.translate((0, 0, PIVOT_H))
