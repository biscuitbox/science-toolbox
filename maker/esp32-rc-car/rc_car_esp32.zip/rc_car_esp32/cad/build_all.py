"""
모든 부품을 만들어 STL(출력 방향 정렬) + STEP 으로 내보내고, 조립 간섭을 검사합니다.
    python build_all.py
"""
import os
import cadquery as cq
import car
import controller as ctl
import camera_mount as cm
from params import *

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "models")
STL = os.path.join(OUT, "stl")
STEP = os.path.join(OUT, "step")
os.makedirs(STL, exist_ok=True)
os.makedirs(STEP, exist_ok=True)

H2S_BED = (340, 320, 340)   # 뱀부랩 H2S 단일 노즐 출력 영역(여유 있게)


def to_bed(shape, rot=None):
    s = shape
    if rot:
        axis, ang = rot
        s = s.rotate((0, 0, 0), axis, ang)
    bb = s.val().BoundingBox()
    return s.translate((-(bb.xmin + bb.xmax) / 2, -(bb.ymin + bb.ymax) / 2, -bb.zmin))


def place(shape, x=0, y=0, z=0):
    return shape.translate((x, y, z))


# --------------------------------------------------------------- 부품 생성
print("부품 생성 중...")
P = {}
P["car_01_chassis_bottom"] = (car.chassis_bottom(), None, 1)
P["car_02_deck_top"] = (car.deck_top(), None, 1)
P["car_03_bumper_front"] = (car.bumper(), ((0, 1, 0), 90), 1)          # 앞면을 바닥에
P["car_04_line_sensor_bracket"] = (car.line_bracket(), ((1, 0, 0), 180), 1)
P["car_05_esp32_riser"] = (car.esp32_riser(), None, 1)
P["car_06_l298n_riser"] = (car.l298n_riser(), None, 1)
P["car_07_servo_mount_sg90"] = (car.servo_mount(), None, 1)
P["car_08_sonar_bracket"] = (car.sonar_bracket(), None, 1)
P["car_09_module_plate"] = (car.module_plate(), None, 2)
P["car_10_cam_base"] = (cm.cam_base(), None, 1)
P["car_11_cam_holder"] = (cm.cam_holder(), None, 1)
P["car_12_charge_port"] = (car.charge_port(), None, 1)
ctop, cbot = ctl.build()
P["ctrl_01_top_shell"] = (ctop, ((1, 0, 0), 180), 1)                  # 윗면을 바닥에
P["ctrl_02_bottom_shell"] = (cbot, None, 1)

# --------------------------------------------------------------- 내보내기
report = []
for name, (shape, rot, qty) in P.items():
    assert shape.val().isValid(), name
    assert len(shape.solids().vals()) == 1, f"{name}: 조각이 {len(shape.solids().vals())}개"
    bedded = to_bed(shape, rot)
    bb = bedded.val().BoundingBox()
    fits = bb.xlen <= H2S_BED[0] and bb.ylen <= H2S_BED[1] and bb.zlen <= H2S_BED[2]
    cq.exporters.export(bedded, os.path.join(STL, name + ".stl"), tolerance=0.05, angularTolerance=0.2)
    cq.exporters.export(shape, os.path.join(STEP, name + ".step"))
    report.append((name, qty, round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1),
                   round(shape.val().Volume() / 1000, 1), fits))

# --------------------------------------------------------------- 조립체
DZ = car.DECK_Z
L298N_AT = (-25, 0)
ESP32_AT = (55, 0)
SONAR_BOARD_X = 93.4
CAM_AT = (95, 0)        # 카메라 받침 위치 (상판 격자 x=95, y=±20 구멍)

asm_print = {
    "chassis": car.chassis_bottom(),
    "deck": place(car.deck_top(), z=DZ),
    "bumper": car.bumper(),
    "line": car.line_bracket(),
    "l298n_riser": place(car.l298n_riser(), *L298N_AT, DZ + PLATE_T),
    "esp32_riser": place(car.esp32_riser(), *ESP32_AT, DZ + PLATE_T),
    "cam_base": place(cm.cam_base(), *CAM_AT, DZ + PLATE_T),
    "cam_holder": place(cm.cam_holder(), *CAM_AT, DZ + PLATE_T),
    "charge_port": car.charge_port(),
}
mock = {}
for sx in (1, -1):
    for sy in (1, -1):
        mock[f"motor{sx}{sy}"] = car.mock_motor(sx, sy)
        mock[f"wheel{sx}{sy}"] = car.mock_wheel(sx, sy)
mock["esp32cam"] = place(cm.mock_esp32cam(), *CAM_AT, DZ + PLATE_T)
mock["battery"] = car.mock_pack()
mock["charger"] = car.mock_charger()
mock["rocker"] = car.box(-85 - 6.5, -85 + 6.5, -9.6, 9.6, DZ - 12, DZ)
lz = DZ + PLATE_T + 3 + 6
mock["l298n"] = car.box(L298N_AT[0] - 21.75, L298N_AT[0] + 21.75, -21.75, 21.75, lz, lz + 1.6).union(
    car.box(L298N_AT[0] - 8, L298N_AT[0] + 8, -12, 12, lz + 1.6, lz + 26))
ez = DZ + PLATE_T + 3 + 22
mock["esp32"] = car.box(ESP32_AT[0] - ESP32_L / 2, ESP32_AT[0] + ESP32_L / 2, -ESP32_W / 2, ESP32_W / 2, ez, ez + 1.6).union(
    car.box(ESP32_AT[0] - 19, ESP32_AT[0] + 19, -14.2, -11.2, ez - 16.5, ez)).union(
    car.box(ESP32_AT[0] - 19, ESP32_AT[0] + 19, 11.2, 14.2, ez - 16.5, ez))
sz = car.SONAR_Z
mock["hcsr04"] = car.box(SONAR_BOARD_X, SONAR_BOARD_X + 1.6, -22.5, 22.5, sz - 10, sz + 10).union(
    cq.Workplane("YZ").workplane(offset=SONAR_BOARD_X + 1.6).pushPoints([(13, sz), (-13, sz)])
    .circle(8).extrude(12))
for i, y in enumerate(car.LINE_SENSOR_Y):
    mock[f"ir{i}"] = car.box(98, 130, y - 7, y + 7, -5.6, -4).union(car.box(124, 130, y - 5, y + 5, -13.6, -5.6))

print("간섭 검사 중...")
clashes = []
names = list(asm_print) + list(mock)
allp = {**asm_print, **mock}
for i, a in enumerate(names):
    for b in names[i + 1:]:
        if a in mock and b in mock:
            continue
        r = allp[a].intersect(allp[b])
        v = sum(s.Volume() for s in r.solids().vals())
        if v > 1.0:
            clashes.append((a, b, round(v, 1)))
ground = car.GROUND_Z
low = min(s.val().BoundingBox().zmin for s in list(asm_print.values()) + [mock[k] for k in mock if k.startswith("ir")])

cmk = ctl.mocks()
for name, m in cmk:
    for pn, s in (("ctrl_top", ctop), ("ctrl_bot", cbot)):
        r = s.intersect(m)
        v = sum(x.Volume() for x in r.solids().vals())
        if v > 1.0:
            clashes.append((name, pn, round(v, 1)))

# 조립 STEP (출력 부품 + 구매품 모형)
a = cq.Assembly(name="rc_car")
for k, v in asm_print.items():
    a.add(v, name=k, color=cq.Color(0.95, 0.55, 0.1))
for k, v in mock.items():
    col = cq.Color(1, 0.85, 0.1) if "motor" in k else cq.Color(0.15, 0.15, 0.15) if "wheel" in k else cq.Color(0.2, 0.5, 0.9)
    a.add(v, name=k, color=col)
a.export(os.path.join(STEP, "ASSEMBLY_car.step"))
b = cq.Assembly(name="controller")
b.add(ctop, name="top", color=cq.Color(0.2, 0.6, 0.9))
b.add(cbot, name="bottom", color=cq.Color(0.15, 0.15, 0.2))
for i, (name, m) in enumerate(cmk):
    b.add(m, name=f"{name}_{i}", color=cq.Color(0.9, 0.7, 0.2))
b.export(os.path.join(STEP, "ASSEMBLY_controller.step"))

print("\n부품               수량  X     Y     Z    부피cm3  H2S")
for r in report:
    print(f"{r[0]:30s} {r[1]}  {r[2]:6} {r[3]:6} {r[4]:6} {r[5]:6}  {'OK' if r[6] else 'TOO BIG'}")
print("\n지상고(차체 최저점-지면):", round(low - ground, 1), "mm")
print("간섭:", clashes if clashes else "없음")
