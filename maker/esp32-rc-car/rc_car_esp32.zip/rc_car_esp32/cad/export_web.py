"""
웹 3D 조립 설명서용 모델 데이터(model.json) 만들기
    python export_web.py <출력 경로>
부품마다 단계(step), 날아 들어오는 방향(from), 색, 이름을 붙이고
메시를 Int16(0.01mm 단위)으로 줄여 base64로 저장합니다.
좌표 변환 (three.js, y가 위)
  차량:   x = Y(왼쪽+), y = Z - 지면, z = X(앞+)
  조종기: x = X(오른쪽+), y = Z, z = -(Y - 9) (사용자 쪽이 +z)
"""
import sys, json, base64, math
import numpy as np
import cadquery as cq
import car
import controller as ctl
import camera_mount as cm
from params import *

Q = 0.01
DZ = car.DECK_Z
GZ = car.GROUND_Z
L298N_AT = (-25.0, 0.0)
ESP32_AT = (55.0, 0.0)
CAM_AT = (95.0, 0.0)
BUCK_AT = (-72.0, 34.0)

# ---------------------------------------------------------------- 공통
def car_xf(p):
    x, y, z = p
    return (y, z - GZ, x)


def ctl_xf(p):
    x, y, z = p
    return (x, z, -(y - 9.0))


def mesh(shape, xf, tol=0.2, ang=0.35):
    verts, faces = [], []
    for s in shape.solids().vals():
        v, f = s.tessellate(tol, ang)
        base = len(verts)
        verts += [xf((p.x, p.y, p.z)) for p in v]
        faces += [(a + base, b + base, c + base) for a, b, c in f]
    V = np.round(np.array(verts) / Q).astype(np.int16)
    F = np.array(faces, dtype=np.uint32).ravel()
    i32 = len(verts) > 65535
    idx = F.astype(np.uint32 if i32 else np.uint16)
    out = {"pos": base64.b64encode(V.tobytes()).decode(), "idx": base64.b64encode(idx.tobytes()).decode()}
    if i32:
        out["i32"] = 1
    return out, len(faces)


def box(x0, x1, y0, y1, z0, z1):
    return car.box(x0, x1, y0, y1, z0, z1)


def cyl_axis(p0, p1, d):
    """p0→p1 방향 원기둥"""
    v = cq.Vector(*p1) - cq.Vector(*p0)
    return cq.Workplane(cq.Plane(origin=p0, xDir=_perp(v), normal=v)).circle(d / 2).extrude(v.Length)


def _perp(v):
    a = cq.Vector(1, 0, 0) if abs(v.normalized().x) < 0.9 else cq.Vector(0, 1, 0)
    return v.cross(a).normalized()


def bolt(p_head, p_tip, d=3.0, head_d=5.5, head_l=2.6):
    v = (cq.Vector(*p_tip) - cq.Vector(*p_head)).normalized()
    h1 = cq.Vector(*p_head) - v * head_l
    return cyl_axis(tuple(h1), p_head, head_d).union(cyl_axis(p_head, p_tip, d))


PARTS = {"car": [], "ctrl": []}
WIRES = {"car": [], "ctrl": []}
TRIS = {"car": 0, "ctrl": 0}


def add(model, pid, label, color, step, shape, frm=(0, 0, 0), tol=0.2, ghost=None):
    xf = car_xf if model == "car" else ctl_xf
    m, n = mesh(shape, xf, tol)
    f = xf(frm)
    if model == "car":            # 방향 벡터라 지면 이동은 빼기
        f = (frm[1], frm[2], frm[0])
    else:
        f = (frm[0], frm[2], -frm[1])
    d = {"id": pid, "label": label, "color": color, "step": step, "from": [round(c, 2) for c in f]}
    if ghost is not None:
        d["ghost"] = ghost
    d.update(m)
    PARTS[model].append(d)
    TRIS[model] += n


def wire(model, pts, color, step, label, r=0.9):
    xf = car_xf if model == "car" else ctl_xf
    WIRES[model].append({"pts": [[round(c, 2) for c in xf(p)] for p in pts], "color": color, "r": r,
                         "step": step, "label": label})


# ---------------------------------------------------------------- 색
C_PRINT = "#E8833A"; C_DECK = "#F0A35E"; C_BUMP = "#D96C2C"; C_BRK = "#C95F22"; C_RISER = "#E39B4F"
C_CAMP = "#DB7A3A"; C_MOTOR = "#F2C230"; C_WHEEL = "#2B2F33"; C_BATT = "#3E4A57"; C_CELL = "#5B8DD6"
C_L298 = "#C7352B"; C_SINK = "#2F3338"; C_ESP = "#1F3B70"; C_SONAR = "#2F7BD8"; C_IR = "#2E6B4E"
C_BOLT = "#9AA3AD"; C_SW = "#1E1E1E"; C_TERM = "#2E7DCF"; C_LED = "#F4F1E8"; C_BUCK = "#1D6F42"
RED, BLACK, YELLOW, BLUE, GREEN, ORANGE, WHITE, PURPLE, GRAY = (
    "#D9443A", "#2A2D31", "#E8B923", "#2F72D8", "#3BA55D", "#E6812E", "#E9E9E4", "#8E5BD0", "#8C96A0")

# ================================================================ 차량
print("차량 부품...")
# 1 하판 + 모터
add("car", "chassis", "하판", C_PRINT, 1, car.chassis_bottom(), tol=0.25)
for sx in (1, -1):
    for sy in (1, -1):
        side = ("앞" if sx > 0 else "뒤") + ("왼쪽" if sy > 0 else "오른쪽")
        add("car", f"motor_{sx}{sy}", f"TT 모터 ({side})", C_MOTOR, 1, car.mock_motor(sx, sy), frm=(0, sy * 70, 0))
        for d in (TT_HOLE_D1, TT_HOLE_D2):
            x = sx * (AXLE_X - d)
            y_out = sy * (PLATE_W / 2)
            y_tip = sy * (car.MOTOR_IN_Y - TAB_T - 4)
            add("car", f"bolt_m_{sx}{sy}_{int(d)}", "M3×30 볼트 + 너트", C_BOLT, 1,
                bolt((x, y_out, car.AXLE_Z), (x, y_tip, car.AXLE_Z)), frm=(0, sy * 45, 0), tol=0.15)
# 2 바퀴
for sx in (1, -1):
    for sy in (1, -1):
        add("car", f"wheel_{sx}{sy}", "바퀴 65mm", C_WHEEL, 2, car.mock_wheel(sx, sy), frm=(0, sy * 50, 0), tol=0.3)
# 3 배터리
bz0, bz1 = PLATE_T, PLATE_T + 20.5
holder = box(-38.5, 38.5, -20.5, 20.5, bz0, bz0 + 3).union(box(-38.5, -35.5, -20.5, 20.5, bz0, bz1)).union(
    box(35.5, 38.5, -20.5, 20.5, bz0, bz1))
add("car", "batt_holder", "18650 2구 홀더", C_BATT, 3, holder, frm=(0, 0, 45))
for i, y in enumerate((-10.2, 10.2)):
    cell = cyl_axis((-34.5, y, bz0 + 3 + 9.3), (34.5, y, bz0 + 3 + 9.3), 18.4)
    add("car", f"cell{i}", "18650 배터리", C_CELL, 3, cell, frm=(0, 0, 60))
for i, x in enumerate((25, -25)):
    strap = box(x - 10, x + 10, -22.6, 22.6, bz1 + 0.5, bz1 + 1.5).union(
        box(x - 10, x + 10, -22.6, -21.4, -0.8, bz1 + 1.5)).union(box(x - 10, x + 10, 21.4, 22.6, -0.8, bz1 + 1.5)).union(
        box(x - 10, x + 10, -22.6, 22.6, -1.8, -0.8))
    add("car", f"strap{i}", "벨크로 끈", "#4A4F57", 3, strap, frm=(0, 0, 25))
# 4 범퍼·센서
add("car", "bumper", "앞범퍼", C_BUMP, 4, car.bumper(), frm=(25, 0, 25))
add("car", "line", "라인센서 브래킷 (선택)", C_BRK, 4, car.line_bracket(), frm=(0, 0, -30))
sz = car.SONAR_Z
sonar = box(93.4, 95.0, -22.5, 22.5, sz - 10, sz + 10).union(
    cq.Workplane("YZ").workplane(offset=95.0).pushPoints([(13, sz), (-13, sz)]).circle(8).extrude(12))
add("car", "sonar", "HC-SR04 초음파 센서", C_SONAR, 4, sonar, frm=(-30, 0, 0))
for i, y in enumerate(car.LINE_SENSOR_Y):
    ir = box(98, 130, y - 7, y + 7, -5.6, -4).union(box(124, 130, y - 5, y + 5, -13.6, -5.6))
    add("car", f"ir{i}", "TCRT5000 라인센서 (선택)", C_IR, 4, ir, frm=(0, 0, -25))
for i, y in enumerate((35, -35)):
    led = cyl_axis((100.0, y, sz), (108.0, y, sz), 5.0)
    add("car", f"led{i}", "전조등 LED 5mm", C_LED, 4, led, frm=(-25, 0, 0), tol=0.15)
for (x, y) in ((95, 20), (95, -20)):
    add("car", f"bolt_b_{y}", "M3×16 볼트 (범퍼+하판+브래킷)", C_BOLT, 4,
        bolt((x, y, PLATE_T + 3), (x, y, -8)), frm=(0, 0, 30), tol=0.15)
for (x, y) in ((85, 20), (85, -20)):
    add("car", f"bolt_l_{y}", "M3×10 볼트 (브래킷)", C_BOLT, 4,
        bolt((x, y, -4), (x, y, PLATE_T + 2)), frm=(0, 0, -25), tol=0.15)
# 5 상판·스위치
add("car", "deck", "상판", C_DECK, 5, car.deck_top().translate((0, 0, DZ)), frm=(0, 0, 50), tol=0.25)
for i, (x, y) in enumerate(PILLARS):
    add("car", f"bolt_d{i}", "M3×8 볼트 (상판)", C_BOLT, 5,
        bolt((x, y, DZ + PLATE_T), (x, y, DZ - 4)), frm=(0, 0, 60), tol=0.15)
rx, ry = car.ROCKER_POS
rocker = box(rx - 6.5, rx + 6.5, ry - 9.6, ry + 9.6, DZ - 12, DZ).union(
    box(rx - 7.5, rx + 7.5, ry - 10.6, ry + 10.6, DZ + PLATE_T, DZ + PLATE_T + 2)).union(
    box(rx - 5, rx + 5, ry - 1, ry + 8, DZ + PLATE_T + 2, DZ + PLATE_T + 5))
add("car", "rocker", "전원 스위치 (로커)", C_SW, 5, rocker, frm=(0, 0, 30))
# 6 L298N
lx, ly = L298N_AT
add("car", "l298n_riser", "L298N 받침", C_RISER, 6, car.l298n_riser().translate((lx, ly, DZ + PLATE_T)), frm=(0, 0, 35))
lz = DZ + PLATE_T + 3 + 6
l298 = box(lx - 21.75, lx + 21.75, -21.75, 21.75, lz, lz + 1.6)
add("car", "l298n", "L298N 모터 드라이버", C_L298, 6, l298, frm=(0, 0, 45))
sink = box(lx - 8, lx + 8, -11, 11, lz + 1.6, lz + 24)
for k in range(-2, 3):
    sink = sink.cut(box(lx - 9, lx + 9, k * 4.4 - 0.8, k * 4.4 + 0.8, lz + 8, lz + 25))
add("car", "l298n_sink", "L298N 방열판", C_SINK, 6, sink, frm=(0, 0, 45))
term = box(lx - 21.5, lx - 13.5, -10, 10, lz + 1.6, lz + 11)
term = term.union(box(lx - 8, lx + 8, 13.5, 21.5, lz + 1.6, lz + 11)).union(box(lx - 8, lx + 8, -21.5, -13.5, lz + 1.6, lz + 11))
add("car", "l298n_term", "L298N 단자대 (뒤: 12V·GND·5V / 양옆: 모터)", C_TERM, 6, term, frm=(0, 0, 45))
hdr = box(lx + 15, lx + 18, -9, 9, lz + 1.6, lz + 10)
add("car", "l298n_hdr", "L298N 신호 핀 (ENA·IN1~4·ENB)", "#111111", 6, hdr, frm=(0, 0, 45))
for i, (x, y) in enumerate(((lx - 23.25, 23.25), (lx - 23.25, -23.25), (lx + 23.25, 23.25), (lx + 23.25, -23.25))):
    add("car", f"bolt_l298_{i}", "M3×6 볼트 + 와셔", C_BOLT, 6,
        bolt((x, y, lz + 2.4), (x, y, lz - 4)), frm=(0, 0, 55), tol=0.15)
# 7 ESP32
ex, ey = ESP32_AT
add("car", "esp32_riser", "ESP32 받침", C_RISER, 7, car.esp32_riser().translate((ex, ey, DZ + PLATE_T)), frm=(0, 0, 35))
ez = DZ + PLATE_T + 3 + 22
esp = box(ex - ESP32_L / 2, ex + ESP32_L / 2, -ESP32_W / 2, ESP32_W / 2, ez, ez + 1.6).union(
    box(ex - 19, ex + 19, -14.2, -11.2, ez - 8.5, ez)).union(box(ex - 19, ex + 19, 11.2, 14.2, ez - 8.5, ez)).union(
    box(ex - 6, ex + 12, -9, 9, ez + 1.6, ez + 4.8)).union(box(ex + 19, ex + 25.75, -9, 9, ez + 1.6, ez + 2.4)).union(
    box(ex - ESP32_L / 2 - 1, ex - ESP32_L / 2 + 5, -4, 4, ez + 1.6, ez + 4.6))
add("car", "esp32", "ESP32 DevKit (USB가 뒤로)", C_ESP, 7, esp, frm=(0, 0, 45))
for i, (x, y) in enumerate(((ex - 27.25, 15.65), (ex - 27.25, -15.65), (ex + 27.25, 15.65), (ex + 27.25, -15.65))):
    add("car", f"bolt_esp_{i}", "M3×6 볼트 + 와셔", C_BOLT, 7,
        bolt((x, y, ez + 2.4), (x, y, ez - 4)), frm=(0, 0, 55), tol=0.15)
# 9 카메라
cx, cy = CAM_AT
add("car", "cam_base", "카메라 받침", C_CAMP, 9, cm.cam_base().translate((cx, cy, DZ + PLATE_T)), frm=(0, 0, 35))
add("car", "cam_holder", "카메라 홀더", C_CAMP, 9, cm.cam_holder(10).translate((cx, cy, DZ + PLATE_T)), frm=(0, 0, 50))
add("car", "esp32cam", "ESP32-CAM", "#30353C", 9, cm.mock_esp32cam(10).translate((cx, cy, DZ + PLATE_T)), frm=(30, 0, 20))
add("car", "cam_axle", "M3×16 볼트 + 나일론 너트 (각도 축)", C_BOLT, 9,
    bolt((cx, 9.4, DZ + PLATE_T + cm.PIVOT_H), (cx, -9.4, DZ + PLATE_T + cm.PIVOT_H)), frm=(0, 30, 0), tol=0.15)
bx, by = BUCK_AT
buck = box(bx - 11, bx + 11, by - 8.5, by + 8.5, DZ + PLATE_T, DZ + PLATE_T + 1.6).union(
    box(bx - 3, bx + 4, by - 3, by + 4, DZ + PLATE_T + 1.6, DZ + PLATE_T + 5))
add("car", "buck", "5V 강압 모듈 (카메라 전원)", C_BUCK, 9, buck, frm=(0, 0, 35))

# ---------------------------------------------------------------- 차량 배선 (8단계)
TZ = lz + 9          # 단자대 높이
wire("car", [(-38.5, 6, 14), (-52, 7, 20), (-72, 4, 26), (-85, 4, 28)], RED, 8, "배터리 + → 전원 스위치", 1.3)
wire("car", [(-85, -4, 28), (-72, -4, 30), (-58, -2, 34), (-55, -2, 42), (-50, -6, TZ)], RED, 8, "스위치 → L298N 12V", 1.3)
wire("car", [(-38.5, -6, 14), (-54, -3, 24), (-56, 1, 34), (-55, 1, 42), (-50, 0, TZ)], BLACK, 8, "배터리 − → L298N GND", 1.3)
for sx in (1, -1):
    for sy in (1, -1):
        for k, col in ((0, RED), (1, BLACK)):
            off = (k - 0.5) * 2.4
            x_end = lx + (-3 if sx < 0 else 3) + off * 2
            wire("car", [(sx * 11, sy * (38.75 + off), 12), (sx * 14, sy * (36 + off), 24),
                         (sx * 18 + off, sy * 36, 34), (sx * 18 + off, sy * 36, 42),
                         ((sx * 18 + x_end) / 2, sy * 30, TZ + 4), (x_end, sy * 19, TZ)],
                 col, 8, ("왼쪽" if sy > 0 else "오른쪽") + " 모터 → L298N " + ("OUT1·2" if sy > 0 else "OUT3·4"))
sig = [("ENA → 25", YELLOW), ("IN1 → 26", ORANGE), ("IN2 → 27", BLUE), ("IN3 → 33", GREEN),
       ("IN4 → 32", PURPLE), ("ENB → 13", WHITE)]
for i, (lbl, col) in enumerate(sig):
    y = -7.5 + i * 3
    wire("car", [(lx + 17, y, lz + 10), (lx + 26, y, lz + 16), (12, y * 1.4, lz + 14),
                 (ex - 17 + i * 2.5, -9, ez - 12), (ex - 17 + i * 2.5, -12.7, ez - 8.5)], col, 8, "L298N " + lbl)
wire("car", [(lx - 20, 6, TZ), (lx - 26, 8, TZ + 6), (0, 14, lz + 18), (ex - 22, 13, ez - 12), (ex - 19, 12.7, ez - 8.5)],
     RED, 8, "L298N 5V → ESP32 VIN", 1.0)
wire("car", [(lx - 20, 0, TZ), (lx - 27, 2, TZ + 8), (0, 17, lz + 20), (ex - 20, 15, ez - 12), (ex - 16.5, 12.7, ez - 8.5)],
     BLACK, 8, "L298N GND → ESP32 GND", 1.0)
for i, (lbl, col) in enumerate((("HC-SR04 VCC → 5V", RED), ("TRIG → 18", YELLOW), ("ECHO → 분압 → 19", GREEN), ("GND", BLACK))):
    y = -4.5 + i * 3
    wire("car", [(93, y, sz + 10), (86, y, sz + 12), (55, y * 0.6, 31), (28, y * 0.6, 32), (25, y * 0.6, 42),
                 (ex + 8 + i * 2.5, -9, ez - 12), (ex + 8 + i * 2.5, -12.7, ez - 8.5)], col, 8, lbl)
# 카메라 전원 (9단계)
wire("car", [(bx + 11, by - 2, DZ + PLATE_T + 1), (-30, 34, DZ + 16), (40, 30, DZ + 22), (cx - 6, 14, DZ + PLATE_T + 30),
             (cx - 4, 12.2, DZ + PLATE_T + 32)], RED, 9, "강압 모듈 5V → ESP32-CAM 5V", 1.0)
wire("car", [(bx + 11, by + 2, DZ + PLATE_T + 1), (-30, 38, DZ + 18), (40, 34, DZ + 24), (cx - 6, 16, DZ + PLATE_T + 33),
             (cx - 4, 12.2, DZ + PLATE_T + 35)], BLACK, 9, "강압 모듈 GND → ESP32-CAM GND", 1.0)

# ================================================================ 조종기
print("조종기 부품...")
top, bot = ctl.build()
mk = ctl.mocks()
add("ctrl", "bot", "아래 케이스", "#2F3A47", 1, bot, tol=0.25)
named = {}
for name, s in mk:
    named.setdefault(name, []).append(s)
add("ctrl", "esp32", "ESP32 DevKit (USB가 뒤쪽 구멍으로)", C_ESP, 1, named["esp32"][0], frm=(0, 0, 40))
for i, (px, py) in enumerate([(sx * (ESP32_W / 2 + 1.5), ctl.ESP32_CY + sy * (ESP32_L / 2 + 1.5)) for sx in (1, -1) for sy in (1, -1)]):
    z = ctl.FLOOR_T + ctl.ESP32_RISER_H
    add("ctrl", f"bolt_e{i}", "M3×6 볼트 + 와셔", C_BOLT, 1, bolt((px, py, z + 2.4), (px, py, z - 5)), frm=(0, 0, 40), tol=0.15)
add("ctrl", "battery", "18650 1구 홀더 + 배터리", C_BATT, 2, named["battery"][0], frm=(0, 0, 40))
add("ctrl", "tp4056", "TP4056 충전 모듈 (USB-C가 뒤쪽 구멍으로)", "#2E4FA8", 2, named["tp4056"][0], frm=(0, 0, 35))
add("ctrl", "mt3608", "MT3608 승압 모듈 (5V로 조정)", C_BUCK, 2, named["mt3608"][0], frm=(0, 0, 35))
add("ctrl", "rocker", "전원 스위치 (로커)", C_SW, 2, named["rocker"][0], frm=(0, 30, 0))
for i, s in enumerate(named["joystick"]):
    add("ctrl", f"joy{i}", "KY-023 조이스틱 " + ("오른쪽" if i == 0 else "왼쪽"), "#1C1F24", 3, s, frm=(0, 0, -35))
for i, s in enumerate(named["button"]):
    add("ctrl", f"btn{i}", "푸시버튼 " + ("B (속도)" if i == 1 else "A (모드)"), "#C23B30", 3, s, frm=(0, 0, -25))
add("ctrl", "led", "LED + 220Ω", "#F4E04D", 3, named["led"][0], frm=(0, 0, -25))
add("ctrl", "top", "위 케이스", "#2F86D6", 5, top, frm=(0, 0, 45), tol=0.25, ghost=3)
for i, (x, y) in enumerate(ctl.BOSSES):
    add("ctrl", f"bolt_c{i}", "M3×30 볼트 (케이스)", C_BOLT, 5, bolt((x, y, 0.2), (x, y, 30)), frm=(0, 0, -30), tol=0.15)

# 조종기 배선 (4단계)
ECY = ctl.ESP32_CY
pin_z = ctl.FLOOR_T + ctl.ESP32_RISER_H - 8.5
for i, sx in enumerate((1, -1)):
    hx, hy, hz = sx * 50, -14, ctl.JOY_PCB_TOP_Z - 0.5
    for k, col in enumerate((RED, BLACK, YELLOW, GREEN)):
        o = (k - 1.5) * 2.4
        px = sx * 12.7
        wire("ctrl", [(hx + o, hy - 6, hz), (hx + o, hy - 10, hz - 4), (sx * 30 + o, -4, 16), (px, ECY - 14 + k * 2.6, pin_z - 2),
                      (px, ECY - 14 + k * 2.6, pin_z)], col, 4,
             ("오른쪽" if sx > 0 else "왼쪽") + " 조이스틱 " + ["3.3V", "GND", "VRx/VRy", "SW"][k])
for i, (bxp, byp) in enumerate(ctl.BUTTONS):
    wire("ctrl", [(bxp, byp, ctl.H - 14.5), (bxp * 0.8, byp + 6, 20), (bxp * 0.6, 4, 16), (12.7 if bxp > 0 else -12.7, ECY - 2 + i, pin_z)],
         ORANGE if i == 0 else BLUE, 4, "버튼 " + ("A → 27" if i == 0 else "B → 14"))
lx2, ly2 = ctl.LED_POS
wire("ctrl", [(lx2, ly2, ctl.H - 10), (lx2, ly2 + 8, 24), (-4, 6, 18), (-12.7, ECY + 4, pin_z)], WHITE, 4, "LED → 4")
tpx = ctl.TP4056["x"]; mtx = ctl.MT3608["x"]
wire("ctrl", [(-38.5, -20, 12), (-40, 0, 8), (tpx - 4, 30, 9.5)], RED, 4, "배터리 + → TP4056 B+", 1.2)
wire("ctrl", [(-38.5, -26, 12), (-42, -2, 6), (tpx + 4, 30, 9.5)], BLACK, 4, "배터리 − → TP4056 B−", 1.2)
wire("ctrl", [(tpx + 4, 44, 9.5), (0, 47, 12), (40, 47, 14), (ctl.ROCKER_X - 4, 46.6, ctl.ROCKER_Z - 4)], RED, 4, "TP4056 OUT+ → 스위치", 1.2)
wire("ctrl", [(ctl.ROCKER_X - 4, 46.6, ctl.ROCKER_Z + 2), (42, 40, 12), (mtx + 4, 32, 9.5)], RED, 4, "스위치 → MT3608 IN+", 1.2)
wire("ctrl", [(tpx - 4, 44, 9.5), (-10, 20, 4.5), (mtx - 4, 20, 9.5)], BLACK, 4, "TP4056 OUT− → MT3608 IN−", 1.2)
wire("ctrl", [(mtx - 4, 40, 9.5), (20, 40, 14), (12.7, ECY + 18, pin_z)], RED, 4, "MT3608 OUT+ (5V) → ESP32 VIN", 1.0)
wire("ctrl", [(mtx + 4, 40, 9.5), (22, 44, 12), (12.7, ECY + 15.5, pin_z)], BLACK, 4, "MT3608 OUT− → ESP32 GND", 1.0)

data = {"q": Q, "models": {k: {"parts": PARTS[k], "wires": WIRES[k]} for k in PARTS}}
out = sys.argv[1] if len(sys.argv) > 1 else "model.json"
s = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
open(out, "w", encoding="utf-8").write(s)
print("삼각형:", TRIS, "부품:", {k: len(v) for k, v in PARTS.items()}, "배선:", {k: len(v) for k, v in WIRES.items()},
      "크기:", round(len(s) / 1024), "KB")
