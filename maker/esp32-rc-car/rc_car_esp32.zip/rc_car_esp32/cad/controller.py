"""
ESP32 RC카 조종기 케이스 (위/아래 2분할) - CadQuery
좌표: X=좌우(+오른쪽), Y=앞뒤(+먼쪽, USB 쪽), Z=위. 바닥 외면 z=0.
"""
import cadquery as cq
from params import M3_HOLE, M3_TAP, ROCKER_W, ROCKER_H, ESP32_L, ESP32_W

WALL = 2.4
FLOOR_T = 2.5
TOP_T = 2.5
INNER_H = 34.0
H = FLOOR_T + INNER_H + TOP_T          # 39
Z_IN_TOP = H - TOP_T                   # 36.5
SPLIT_Z = 26.0                         # 위/아래 분할 높이

# 조이스틱 KY-023 (PCB 26 x 34, 헤더는 사용자 쪽 -Y)
JOY_X = 50.0
JOY_Y = 12.0
JOY_HOLE = 30.0
JOY_PCB_X, JOY_PCB_Y = 26.0, 34.0
JOY_PCB_SHIFT = -3.0                   # 스틱 중심 대비 PCB 중심 (헤더 쪽으로)
JOY_PCB_TOP_Z = H - 16.0               # 패널 윗면에서 16mm 아래에 PCB 윗면

BTN_D = 7.2                            # PBS-110 7mm 푸시버튼
BUTTONS = [(-18, -14), (18, -14)]
LED_POS = (0, -16)
LED_D = 5.2

ESP32_CY = 53.6 - 3.0 - ESP32_L / 2    # USB 쪽 끝이 뒷벽에서 3mm
ESP32_RISER_H = 22.0
BATT_Y = -23.0
TP4056 = dict(x=-30, w=17.5, l=26.5)   # USB-C 뒷벽
MT3608 = dict(x=30, w=17.5, l=36.5)
ROCKER_X = 52.0
ROCKER_Z = 16.5
BOSSES = [(76, 42), (-76, 42), (62, -44), (-62, -44)]


def outline_wire():
    s = cq.Workplane("XY").center(0, 9).rect(176, 94).extrude(1).edges("|Z").fillet(24)
    s = s.union(cq.Workplane("XY").pushPoints([(60, -34), (-60, -34)]).circle(30).extrude(1))
    face = s.faces("<Z").val()
    w = face.outerWire()
    w = w.offset2D(10, "arc")[0].offset2D(-10, "arc")[0]   # 오목 모서리 라운드
    return w


def prism(wire, z0, z1):
    f = cq.Face.makeFromWires(wire.translate((0, 0, z0)))
    return cq.Workplane("XY").add(cq.Solid.extrudeLinear(f, cq.Vector(0, 0, z1 - z0)))


def zbox(x, y, w, l, z0, z1):
    return cq.Workplane("XY").box(w, l, z1 - z0, centered=(True, True, False)).translate((x, y, z0))


def cyl(x, y, d, z0, z1):
    return cq.Workplane("XY").workplane(offset=z0).center(x, y).circle(d / 2).extrude(z1 - z0)


def build():
    ow = outline_wire()
    iw = ow.offset2D(-WALL, "arc")[0]
    outer = prism(ow, 0, H)
    outer = outer.edges(">Z").fillet(4.0)
    outer = outer.edges("<Z").fillet(2.0)
    inner = prism(iw, FLOOR_T, Z_IN_TOP)
    shell = outer.cut(inner)

    # ---- 윗면 구멍
    for sx in (1, -1):
        shell = shell.cut(cyl(sx * JOY_X, JOY_Y, JOY_HOLE, Z_IN_TOP - 1, H + 1))
        cham = (cq.Workplane("XY").workplane(offset=H - 1.5).center(sx * JOY_X, JOY_Y)
                .circle(JOY_HOLE / 2).workplane(offset=1.6).circle(JOY_HOLE / 2 + 1.6).loft())
        shell = shell.cut(cham)
    for (x, y) in BUTTONS:
        shell = shell.cut(cyl(x, y, BTN_D, Z_IN_TOP - 1, H + 1))
    shell = shell.cut(cyl(LED_POS[0], LED_POS[1], LED_D, Z_IN_TOP - 1, H + 1))

    # ---- 뒷벽 구멍 (ESP32 USB, TP4056 USB-C, 전원 로커)
    yb = 56.0
    usb_z = FLOOR_T + ESP32_RISER_H + 1.6 + 1.6
    shell = shell.cut(cq.Workplane("XZ").workplane(offset=-(yb + 2)).center(0, usb_z)
                      .rect(12, 8).extrude(6))
    shell = shell.cut(cq.Workplane("XZ").workplane(offset=-(yb + 2)).center(TP4056["x"], FLOOR_T + 1.6 + 1.6)
                      .slot2D(10, 4.6, 0).extrude(6))
    shell = shell.cut(cq.Workplane("XZ").workplane(offset=-(yb + 2)).center(ROCKER_X, ROCKER_Z)
                      .rect(ROCKER_W, ROCKER_H).extrude(6))

    top_cut = zbox(0, 0, 400, 400, SPLIT_Z, H + 5)
    bot_cut = zbox(0, 0, 400, 400, -5, SPLIT_Z)
    top = shell.intersect(top_cut)
    bot = shell.intersect(bot_cut)

    # ---- 위 케이스: 조이스틱 모서리 클램프 기둥 + 결합 보스
    for sx in (1, -1):
        bcx, bcy = sx * JOY_X, JOY_Y + JOY_PCB_SHIFT
        for px in (1, -1):
            for py in (1, -1):
                x = bcx + px * (JOY_PCB_X / 2 + 1.5)
                y = bcy + py * (JOY_PCB_Y / 2 + 1.5)
                post = cyl(x, y, 7.0, JOY_PCB_TOP_Z, Z_IN_TOP + 0.5)
                post = post.cut(cyl(x, y, M3_TAP, JOY_PCB_TOP_Z - 1, JOY_PCB_TOP_Z + 9))
                top = top.union(post)
    for (x, y) in BOSSES:
        b = cyl(x, y, 8.0, SPLIT_Z, Z_IN_TOP + 0.5).cut(cyl(x, y, M3_TAP, SPLIT_Z - 1, Z_IN_TOP - 1))
        top = top.union(b)

    # ---- 아래 케이스
    # 맞춤 턱 (위 케이스 안쪽으로 2mm 들어감)
    lip_o = iw.offset2D(-0.25, "arc")[0]
    lip_i = iw.offset2D(-1.6, "arc")[0]
    lip_root = iw.offset2D(0.6, "arc")[0]
    lip = (prism(lip_o, SPLIT_Z - 0.01, SPLIT_Z + 2.0).union(prism(lip_root, SPLIT_Z - 3, SPLIT_Z))
           .cut(prism(lip_i, SPLIT_Z - 4, SPLIT_Z + 3)))
    bot = bot.union(lip)
    for (x, y) in BOSSES:
        b = cyl(x, y, 8.0, FLOOR_T - 0.5, SPLIT_Z)
        bot = bot.union(b)
        bot = bot.cut(cyl(x, y, M3_HOLE, -1, SPLIT_Z + 1))
        bot = bot.cut(cyl(x, y, 6.4, -1, 3.2))           # 나사머리 카운터보어
    # ESP32 모서리 클램프 기둥 (핀 아래 방향, 듀폰 공간 22mm)
    for px in (1, -1):
        for py in (1, -1):
            x = px * (ESP32_W / 2 + 1.5)
            y = ESP32_CY + py * (ESP32_L / 2 + 1.5)
            p = cyl(x, y, 7.0, FLOOR_T - 0.5, FLOOR_T + ESP32_RISER_H)
            p = p.cut(cyl(x, y, M3_TAP, FLOOR_T + ESP32_RISER_H - 10, FLOOR_T + ESP32_RISER_H + 1))
            bot = bot.union(p)
    # TP4056 / MT3608 포켓 (뒷벽에 붙임)
    for m in (TP4056, MT3608):
        y1 = 53.6
        y0 = y1 - m["l"]
        cy = (y0 + y1) / 2
        ring = (zbox(m["x"], cy - 0.8, m["w"] + 3.2, m["l"] + 1.6, FLOOR_T - 0.5, FLOOR_T + 3)
                .cut(zbox(m["x"], cy + 1, m["w"], m["l"] + 2, FLOOR_T - 1, FLOOR_T + 4)))
        bot = bot.union(ring)
    # 18650 홀더 받침 + 케이블타이 구멍
    for sy in (1, -1):
        bot = bot.union(zbox(0, BATT_Y + sy * (21.6 / 2 + 0.8), 60, 1.6, FLOOR_T - 0.5, FLOOR_T + 6))
    for sx in (1, -1):
        for sy in (1, -1):
            bot = bot.cut(zbox(sx * 20, BATT_Y + sy * 13.5, 4.2, 2.4, -1, FLOOR_T + 1))
    return top, bot


# ---------------------------------------------------------------- 모형
def mocks():
    m = []
    for sx in (1, -1):
        bcx, bcy = sx * JOY_X, JOY_Y + JOY_PCB_SHIFT
        pcb = zbox(bcx, bcy, JOY_PCB_X, JOY_PCB_Y, JOY_PCB_TOP_Z - 1.6, JOY_PCB_TOP_Z)
        mech = zbox(sx * JOY_X, JOY_Y, 22, 22, JOY_PCB_TOP_Z, JOY_PCB_TOP_Z + 11)
        stick = cyl(sx * JOY_X, JOY_Y, 18, JOY_PCB_TOP_Z + 11, H + 2).union(
            cyl(sx * JOY_X, JOY_Y, 24, H + 4, H + 14))
        hdr = zbox(bcx, bcy - JOY_PCB_Y / 2 - 6, 13, 12, JOY_PCB_TOP_Z - 1.6, JOY_PCB_TOP_Z + 1)
        m += [("joystick", pcb.union(mech).union(stick).union(hdr))]
    esp = zbox(0, ESP32_CY, ESP32_W, ESP32_L, FLOOR_T + ESP32_RISER_H, FLOOR_T + ESP32_RISER_H + 1.6)
    esp = esp.union(zbox(0, ESP32_CY - 4, 18, 25.5, FLOOR_T + ESP32_RISER_H + 1.6, FLOOR_T + ESP32_RISER_H + 4.8))
    for sx in (1, -1):
        esp = esp.union(zbox(sx * 12.7, ESP32_CY, 2.5, 38, FLOOR_T + ESP32_RISER_H - 16.5, FLOOR_T + ESP32_RISER_H))
    m.append(("esp32", esp))
    m.append(("battery", zbox(0, BATT_Y, 77, 21, FLOOR_T, FLOOR_T + 19.5)))
    for name, d in (("tp4056", TP4056), ("mt3608", MT3608)):
        m.append((name, zbox(d["x"], 53.6 - d["l"] / 2 + 0.5, d["w"] - 0.5, d["l"] - 1, FLOOR_T, FLOOR_T + 7)))
    m.append(("rocker", zbox(ROCKER_X, 53.6 - 7, 19, 14, ROCKER_Z - 6.5, ROCKER_Z + 6.5)))
    for (x, y) in BUTTONS:
        m.append(("button", cyl(x, y, 9, H - 14.5, Z_IN_TOP)))
    m.append(("led", cyl(LED_POS[0], LED_POS[1], 5, H - 10, Z_IN_TOP)))
    return m
