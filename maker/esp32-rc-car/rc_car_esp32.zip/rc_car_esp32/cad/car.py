"""
ESP32 TT모터 4WD RC카 - 출력 부품 모델 (CadQuery)
좌표: X=앞(+), Y=왼쪽(+), Z=위. 하판 바닥면이 z=0, 지면은 z = 축높이 - 바퀴반지름.
"""
import math
import cadquery as cq
from params import *

PLATE_L = PLATE_X_MAX - PLATE_X_MIN
PLATE_CX = (PLATE_X_MAX + PLATE_X_MIN) / 2
AXLE_Z = PLATE_T + TT_HEIGHT / 2           # 모터가 하판 위에 올라앉음
GROUND_Z = AXLE_Z - WHEEL_D / 2
DECK_Z = PLATE_T + PILLAR_H                 # 상판 바닥면 높이
MOTOR_IN_Y = PLATE_W / 2 - TT_THICK         # 모터 안쪽면 y


# ------------------------------------------------------------------ helpers
def plate_outline(t):
    return (cq.Workplane("XY").center(PLATE_CX, 0).rect(PLATE_L, PLATE_W)
            .extrude(t).edges("|Z").fillet(PLATE_R))


def lattice(xmin, xmax, ymin, ymax):
    pts = []
    i0 = math.ceil((xmin - GRID_X0) / GRID)
    i1 = math.floor((xmax - GRID_X0) / GRID)
    j0 = math.ceil((ymin - GRID_Y0) / GRID)
    j1 = math.floor((ymax - GRID_Y0) / GRID)
    for i in range(i0, i1 + 1):
        for j in range(j0, j1 + 1):
            pts.append((GRID_X0 + i * GRID, GRID_Y0 + j * GRID))
    return pts


def near_rect(p, cx, cy, w, h, m):
    return abs(p[0] - cx) < w / 2 + m and abs(p[1] - cy) < h / 2 + m


def near_pillar(p, m=7.5):
    return any(math.hypot(p[0] - x, p[1] - y) < m for x, y in PILLARS)


def holes(wp_solid, pts, d, z_top):
    """z_top 면에서 아래로 관통 구멍"""
    if not pts:
        return wp_solid
    cutter = (cq.Workplane("XY").workplane(offset=z_top - 50).pushPoints(pts)
              .circle(d / 2).extrude(100))
    return wp_solid.cut(cutter)


def box(x0, x1, y0, y1, z0, z1):
    return (cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0, centered=False)
            .translate((x0, y0, z0)))


GRID_MARGIN = 6.0
ALL_LATTICE = lattice(PLATE_X_MIN + GRID_MARGIN, PLATE_X_MAX - GRID_MARGIN,
                      -PLATE_W / 2 + GRID_MARGIN, PLATE_W / 2 - GRID_MARGIN)

# 배터리 고정용 벨크로 슬롯 (x, y, 길이X, 폭Y)
VELCRO = [(sx * 25, sy * 22.0, 20.0, 2.4) for sx in (1, -1) for sy in (1, -1)]


# ------------------------------------------------------------------ 하판
def chassis_bottom():
    body = plate_outline(PLATE_T)

    # 모터 고정 벽 + 보강 리브
    for sx in (1, -1):
        for sy in (1, -1):
            xa = sx * (AXLE_X - 12.0)
            xb = sx * (AXLE_X - 55.0)
            y_in = sy * MOTOR_IN_Y
            y_tab = y_in - sy * TAB_T
            tab = box(min(xa, xb), max(xa, xb), min(y_in, y_tab), max(y_in, y_tab),
                      PLATE_T - 0.01, PLATE_T + TT_HEIGHT)
            body = body.union(tab)
            # 리브 (두 장공 사이)
            xr = sx * (AXLE_X - (TT_HOLE_D1 + TT_HOLE_D2) / 2)
            y1 = y_tab
            y2 = y_tab - sy * 5.5
            rib = (cq.Workplane("YZ").workplane(offset=xr - 1.5)
                   .polyline([(y1, PLATE_T), (y1, PLATE_T + TT_HEIGHT - 3), (y2, PLATE_T)]).close()
                   .extrude(3.0))
            body = body.union(rib)
            # 모터 관통볼트용 장공 (축 방향 = Y)
            for d in (TT_HOLE_D1, TT_HOLE_D2):
                xs = sx * (AXLE_X - d)
                slot = (cq.Workplane("XZ").workplane(offset=-(PLATE_W / 2 + 5))
                        .center(xs, AXLE_Z).slot2D(TT_SLOT_LEN + M3_HOLE, M3_HOLE, 0)
                        .extrude(-(PLATE_W + 10)))
                body = body.cut(slot)

    # 상판 지지 기둥
    for (x, y) in PILLARS:
        p = (cq.Workplane("XY").workplane(offset=PLATE_T - 0.01).center(x, y)
             .circle(PILLAR_D / 2).extrude(PILLAR_H + 0.01))
        p = p.cut(cq.Workplane("XY").workplane(offset=PLATE_T + PILLAR_H - 14)
                  .center(x, y).circle(M3_TAP / 2).extrude(15))
        body = body.union(p)
        # 기둥 밑동 보강 (원뿔형)
        fil = (cq.Workplane("XY").workplane(offset=PLATE_T - 0.01).center(x, y)
               .circle(PILLAR_D / 2 + 1.5).workplane(offset=5).circle(PILLAR_D / 2).loft())
        body = body.union(fil)

    # 확장용 M3 격자
    def ok(p):
        if 8 < abs(p[0]) < 84 and abs(p[1]) > 21:      # 모터 구역
            return False
        if near_pillar(p, 9.5):
            return False
        for (vx, vy, vl, vw) in VELCRO:
            if near_rect(p, vx, vy, vl, vw, 2.5):
                return False
        return True
    pts = [p for p in ALL_LATTICE if ok(p)]
    body = holes(body, pts, M3_HOLE, PLATE_T)

    # 벨크로 슬롯
    for (vx, vy, vl, vw) in VELCRO:
        body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(vx, vy)
                        .rect(vl, vw).extrude(PLATE_T + 2))
    return body


# ------------------------------------------------------------------ 상판
DECK_SLOTS = [(sx * 18, sy * 36, 12, 7) for sx in (1, -1) for sy in (1, -1)] + \
             [(-55, 0, 24, 8), (25, 0, 24, 8)]
ROCKER_POS = (-85, 0)


def deck_top():
    body = plate_outline(PLATE_T)
    for (x, y) in PILLARS:
        body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(x, y)
                        .circle(M3_HOLE / 2).extrude(PLATE_T + 2))
    for (x, y, l, w) in DECK_SLOTS:
        body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(x, y)
                        .slot2D(l, w, 0).extrude(PLATE_T + 2))
    # 로커 스위치: 관통 + 아래쪽 포켓으로 두께 2mm 확보 (스냅 걸림)
    rx, ry = ROCKER_POS
    body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(rx, ry)
                    .rect(ROCKER_H, ROCKER_W).extrude(PLATE_T + 2))
    body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(rx, ry)
                    .rect(ROCKER_H + 6, ROCKER_W + 6).extrude(1 + PLATE_T - 2.0))

    def ok(p):
        if near_pillar(p, 7.5):
            return False
        for (x, y, l, w) in DECK_SLOTS:
            if near_rect(p, x, y, l, w, 2.5):
                return False
        if near_rect(p, rx, ry, ROCKER_H + 6, ROCKER_W + 6, 2.0):
            return False
        return True
    pts = [p for p in ALL_LATTICE if ok(p)]
    body = holes(body, pts, M3_HOLE, PLATE_T)
    return body


# ------------------------------------------------------------------ 앞범퍼 (초음파 + 전조등)
BUMPER_FACE_X = PLATE_X_MAX - 3.5
BUMPER_H = 30.0
SONAR_Z = PLATE_T + 15.0   # 하판 기준 높이


def bumper():
    """하판 코 부분 위에 볼트로 고정. 모델 좌표는 조립 위치 그대로."""
    z0 = PLATE_T
    flange = box(82, BUMPER_FACE_X + 0.01, -30, 30, z0, z0 + 3)
    face = box(BUMPER_FACE_X, PLATE_X_MAX, -45, 45, z0, z0 + BUMPER_H)
    body = flange.union(face)
    for sy in (1, -1):
        g = (cq.Workplane("XZ").workplane(offset=-(sy * 28) - 1.5)
             .polyline([(BUMPER_FACE_X, z0 + 3), (BUMPER_FACE_X, z0 + 20), (90, z0 + 3)]).close()
             .extrude(3))
        body = body.union(g)
    face_cut = cq.Workplane("YZ").workplane(offset=BUMPER_FACE_X - 5)
    body = body.cut(face_cut.pushPoints([(13, SONAR_Z), (-13, SONAR_Z)])
                    .circle(HCSR04_HOLE / 2).extrude(15))
    body = body.cut(face_cut.pushPoints([(35, SONAR_Z), (-35, SONAR_Z)])
                    .circle(5.3 / 2).extrude(15))
    # 앞면 아래쪽 M3 구멍 줄 (추가 센서·LED 바 고정용)
    body = body.cut(face_cut.pushPoints([(y, z0 + 25.5) for y in (-40, -30, 30, 40)] +
                                        [(y, z0 + 6) for y in (-40, -30, 30, 40)])
                    .circle(M3_HOLE / 2).extrude(15))
    pts = [p for p in ALL_LATTICE if 82 + 4 < p[0] < BUMPER_FACE_X - 3 and abs(p[1]) <= 25]
    body = holes(body, pts, M3_HOLE, z0 + 3)
    return body


# ------------------------------------------------------------------ 라인센서 브래킷 (하판 코 밑)
LINE_SENSOR_Y = (-25, 0, 25)


def line_bracket():
    t = 4.0
    bar = box(85 - 6, 122, -35, 35, -t, 0)
    # 보강 리브 (밑면 가장자리)
    for sy in (1, -1):
        bar = bar.union(box(85 - 6, 104, sy * 35 - (3 if sy > 0 else 0), sy * 35 + (0 if sy > 0 else 3), -t - 4, -t + 0.01))
    bolt = [(85, 20), (85, -20), (95, 20), (95, -20)]
    bar = holes(bar, bolt, M3_HOLE, 0)
    slots = (cq.Workplane("XY").workplane(offset=-t - 1)
             .pushPoints([(113, y) for y in LINE_SENSOR_Y]).slot2D(12, M3_HOLE, 0).extrude(t + 2))
    bar = bar.cut(slots)
    return bar


# ------------------------------------------------------------------ 보드 받침 (모서리 클램프식)
def board_riser(L, W, h, mount_pts, post_d=7.0, off=1.5, base_t=3.0, extra=8.0):
    """보드 네 모서리를 기둥 위에 올리고 와셔+M3 나사로 눌러 고정.
    구멍 간격이 제각각인 모듈도 크기만 맞으면 고정됨."""
    px, py = L / 2 + off, W / 2 + off
    ox, oy = px + post_d / 2 + 1, py + post_d / 2 + 1
    ox = max(ox, max(abs(p[0]) for p in mount_pts) + 5)
    oy = max(oy, max(abs(p[1]) for p in mount_pts) + 5)
    base = cq.Workplane("XY").rect(2 * ox, 2 * oy).extrude(base_t).edges("|Z").fillet(3)
    ix, iy = px - post_d / 2 - 2, py - post_d / 2 - 2
    ix = min(ix, min(abs(p[0]) for p in mount_pts) - 5) if any(abs(p[1]) < iy + 3 for p in mount_pts) else ix
    base = base.cut(cq.Workplane("XY").workplane(offset=-1).rect(2 * ix, 2 * iy).extrude(base_t + 2))
    # 바닥 고정 구멍이 있는 테두리가 끊기지 않게 마운트 지점 보강
    for (x, y) in mount_pts:
        base = base.union(cq.Workplane("XY").center(x, y).circle(4.5).extrude(base_t))
    for sx in (1, -1):
        for sy in (1, -1):
            post = (cq.Workplane("XY").workplane(offset=base_t - 0.01).center(sx * px, sy * py)
                    .circle(post_d / 2).extrude(h + 0.01))
            post = post.cut(cq.Workplane("XY").workplane(offset=base_t + h - 10)
                            .center(sx * px, sy * py).circle(M3_TAP / 2).extrude(11))
            base = base.union(post)
    base = holes(base, mount_pts, M3_HOLE, base_t)
    return base


def esp32_riser():
    # 핀이 아래로 향한 DevKit + 듀폰 커넥터 공간 22mm
    return board_riser(ESP32_L, ESP32_W, 22.0, [(-10, 20), (10, 20), (-10, -20), (10, -20)])


def l298n_riser():
    return board_riser(L298N_L, L298N_W, 6.0, [(-30, 10), (-30, -10), (30, 10), (30, -10)])


# ------------------------------------------------------------------ SG90 서보 마운트
def servo_mount():
    bt = 3.0
    top_z = bt + SG90_EAR_H + 0.5
    base = cq.Workplane("XY").rect(60, 22).extrude(bt).edges("|Z").fillet(3)
    base = holes(base, [(-25, 0), (25, 0)], M3_HOLE, bt)
    wall_y = SG90_W / 2 + 0.3
    for sy in (1, -1):
        base = base.union(box(-20, 20, min(sy * wall_y, sy * (wall_y + 3)),
                              max(sy * wall_y, sy * (wall_y + 3)), bt - 0.01, top_z))
    plat = box(-20, 20, -(wall_y + 3), wall_y + 3, top_z - 2.5, top_z)
    plat = plat.cut(cq.Workplane("XY").workplane(offset=top_z - 5)
                    .rect(SG90_L + 0.6, SG90_W + 0.6).extrude(10))
    plat = plat.cut(cq.Workplane("XY").workplane(offset=top_z - 5)
                    .pushPoints([(SG90_EAR_PITCH / 2, 0), (-SG90_EAR_PITCH / 2, 0)])
                    .slot2D(4.0, M2_TAP, 0).extrude(10))
    return base.union(plat)


# ------------------------------------------------------------------ 초음파 브래킷 (상판 또는 서보 혼 위)
def sonar_bracket():
    bt = 4.0
    base = box(-8, 12, -25, 25, 0, bt)
    face = box(12, 15, -25, 25, 0, 26 + bt)
    body = base.union(face)
    for sy in (1, -1):
        g = (cq.Workplane("XZ").workplane(offset=-(sy * 20) - 1.5)
             .polyline([(12, bt), (12, bt + 14), (0, bt)]).close().extrude(3))
        body = body.union(g)
    body = body.cut(cq.Workplane("YZ").workplane(offset=5)
                    .pushPoints([(13, bt + 13), (-13, bt + 13)]).circle(HCSR04_HOLE / 2).extrude(15))
    # 상판 격자용 구멍 (간격 30)
    body = holes(body, [(2, 15), (2, -15)], M3_HOLE, bt)
    # 서보 혼(십자/일자) 홈 + 가운데 나사 구멍
    body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(2, 0).rect(7.2, 36).extrude(1 + 2.0))
    body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(2, 0).rect(36, 7.2).extrude(1 + 2.0))
    body = body.cut(cq.Workplane("XY").workplane(offset=-1).center(2, 0).circle(3.2).extrude(bt + 2))
    return body


# ------------------------------------------------------------------ 범용 모듈판
def module_plate():
    t = 3.0
    body = cq.Workplane("XY").rect(60, 40).extrude(t).edges("|Z").fillet(3)
    body = holes(body, [(sx * 25, sy * 15) for sx in (1, -1) for sy in (1, -1)], M3_HOLE, t)
    body = body.cut(cq.Workplane("XY").workplane(offset=-1)
                    .pushPoints([(0, -8), (0, 0), (0, 8)]).slot2D(36, M3_HOLE, 0).extrude(t + 2))
    body = body.cut(cq.Workplane("XY").workplane(offset=-1)
                    .pushPoints([(-25, 0), (25, 0)]).slot2D(14, M3_HOLE, 90).extrude(t + 2))
    return body


# ------------------------------------------------------------------ 충전 포트 받침 (하판 뒤 가운데)
CHG_X0 = PLATE_X_MIN            # 뒤쪽 벽 바깥면 = 하판 뒤끝
CHG_HOLES = [(-55, 10), (-55, -10)]
CHG_BASE_T = 3.0
CHG_WALL_TOP = 16.0             # 받침 바닥에서 뒷벽 위까지


def charge_port():
    """USB-C 충전 모듈을 넣는 포켓. 뒷벽의 U자 홈으로 케이블을 꽂고, 홈 위로 충전 표시 LED가 보임.
    모듈은 양면 폼테이프로 바닥에 붙임. 모델 좌표 = 조립 위치(하판 윗면 z=PLATE_T 위)."""
    z0 = PLATE_T
    x_back = CHG_X0
    x_pf = x_back + 3 + CHG_POCKET_L          # 포켓 앞쪽 끝
    base = box(x_back, -48, -17, 17, z0, z0 + CHG_BASE_T)
    base = base.edges("|Z and >X").fillet(3)
    wall_r = box(x_back, x_back + 3, -17, 17, z0, z0 + CHG_WALL_TOP)
    sides = box(x_back, x_pf + 2, -CHG_POCKET_W / 2 - 2, -CHG_POCKET_W / 2, z0, z0 + 10).union(
        box(x_back, x_pf + 2, CHG_POCKET_W / 2, CHG_POCKET_W / 2 + 2, z0, z0 + 10))
    front = box(x_pf, x_pf + 2, -CHG_POCKET_W / 2 - 2, CHG_POCKET_W / 2 + 2, z0, z0 + 10)
    body = base.union(wall_r).union(sides).union(front)
    # 뒷벽 U자 홈 (USB-C 플러그 + LED 보이는 창)
    body = body.cut(box(x_back - 1, x_back + 4, -7.0, 7.0, z0 + CHG_BASE_T + 0.6, z0 + CHG_WALL_TOP + 1))
    # 전선 나가는 홈 (앞벽)
    body = body.cut(box(x_pf - 1, x_pf + 3, -6, 6, z0 + CHG_BASE_T + 1.5, z0 + 11))
    body = holes(body, CHG_HOLES, M3_HOLE, z0 + CHG_BASE_T)
    return body


def mock_pack():
    z0 = PLATE_T
    body = box(-PACK_L / 2, PACK_L / 2, -PACK_W / 2, PACK_W / 2, z0, z0 + PACK_H).edges("|X").fillet(8)
    return body


def mock_charger():
    z = PLATE_T + CHG_BASE_T + 1.0          # 폼테이프 1mm
    x_back = CHG_X0 + 3.4
    pcb = box(x_back, x_back + 25, -9, 9, z, z + 1.6)
    usb = box(x_back - 0.4, x_back + 7.5, -4.5, 4.5, z + 1.6, z + 4.8)
    return pcb.union(usb)


# ------------------------------------------------------------------ 구매품 모형 (조립 확인·렌더용)
def mock_motor(sx, sy):
    xa = sx * AXLE_X
    x_front = xa + sx * TT_AXLE_FROM_END
    x_back = xa - sx * (TT_TOTAL_LEN - TT_AXLE_FROM_END)
    y_out = sy * PLATE_W / 2
    y_in = sy * MOTOR_IN_Y
    gear_len = 42.0
    xg = xa - sx * (gear_len - TT_AXLE_FROM_END)
    g = box(min(x_front, xg), max(x_front, xg), min(y_in, y_out), max(y_in, y_out),
            PLATE_T, PLATE_T + TT_HEIGHT)
    can = (cq.Workplane("YZ").workplane(offset=min(xg, x_back)).center(sy * (PLATE_W / 2 - TT_THICK / 2), AXLE_Z)
           .circle(9.2).extrude(abs(xg - x_back)))
    return g.union(can)


def mock_wheel(sx, sy):
    y0 = sy * (PLATE_W / 2 + 4)
    return (cq.Workplane("XZ").workplane(offset=-y0).center(sx * AXLE_X, AXLE_Z)
            .circle(WHEEL_D / 2).circle(10).extrude(-sy * 26))
