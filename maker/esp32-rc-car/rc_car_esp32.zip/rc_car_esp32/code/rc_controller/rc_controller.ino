// ====================================================================
//  ESP32 RC카 조종기 코드
//  조이스틱 2개 + 버튼 2개 값을 ESP-NOW 방송으로 초당 50번 보냅니다.
//  MAC 주소를 적을 필요 없이 CAR_ID 가 같은 차량만 반응합니다.
//  켤 때 스틱에서 손을 떼고 있어야 가운데 값이 맞춰집니다.
// ====================================================================
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_arduino_version.h>
#include "config.h"
#include "protocol.h"

static const uint8_t BCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

static int centerY = 2048, centerX = 2048;
static ControlPacket pkt = {};

static volatile uint32_t lastTeleMs = 0;
static volatile bool     teleNew = false;
static TelemetryPacket   teleBuf, tele = {};
static portMUX_TYPE      teleMux = portMUX_INITIALIZER_UNLOCKED;

// ---------------------------------------------------------- 버튼 (디바운스 + 눌린 순간 감지)
struct Button {
  uint8_t pin; bool stable; bool last; uint32_t t;
};
static Button btnA{PIN_BTN_A, false, false, 0}, btnB{PIN_BTN_B, false, false, 0};
static Button swL{PIN_L_SW, false, false, 0},  swR{PIN_R_SW, false, false, 0};

static bool pressedEdge(Button &b) {         // 방금 눌렸으면 true
  bool raw = digitalRead(b.pin) == LOW;
  if (raw != b.last) { b.last = raw; b.t = millis(); }
  if (millis() - b.t > 25 && raw != b.stable) {
    b.stable = raw;
    return raw;
  }
  return false;
}

// ---------------------------------------------------------- LED 패턴 (논블로킹)
static uint8_t  blinksLeft = 0;
static uint32_t blinkT = 0;
static bool     blinkOn = false;
static void blink(uint8_t n) { blinksLeft = n; blinkOn = false; blinkT = millis(); }

static void updateLed(bool linked, bool lowBatt) {
  uint32_t now = millis();
  if (blinksLeft) {                          // 알림 깜빡임 우선
    if (now - blinkT >= (blinkOn ? 120u : 160u)) {
      blinkT = now; blinkOn = !blinkOn;
      if (!blinkOn) blinksLeft--;
    }
    digitalWrite(PIN_LED, blinkOn);
    return;
  }
  if (!linked)       digitalWrite(PIN_LED, (now / 120) % 2);           // 빠르게 깜빡: 차량 없음
  else if (lowBatt)  digitalWrite(PIN_LED, (now % 1000) > 150);         // 짧게 꺼짐: 배터리 부족
  else               digitalWrite(PIN_LED, HIGH);
}

// ---------------------------------------------------------- 조이스틱
static int readAvg(uint8_t pin, uint8_t n = 4) {
  uint32_t s = 0;
  for (uint8_t i = 0; i < n; i++) s += analogRead(pin);
  return s / n;
}

static int axis(int raw, int center, bool invert) {
  int v = raw - center;
  int out;
  if (abs(v) < DEADZONE) out = 0;
  else if (v > 0) out = (long)(v - DEADZONE) * 255 / max(1, 4095 - center - DEADZONE);
  else            out = (long)(v + DEADZONE) * 255 / max(1, center - DEADZONE);
  out = constrain(out, -255, 255);
  return invert ? -out : out;
}

static void calibrate() {
  long sy = 0, sx = 0;
  for (int i = 0; i < 64; i++) { sy += analogRead(PIN_L_Y); sx += analogRead(PIN_R_X); delay(3); }
  centerY = sy / 64; centerX = sx / 64;
  // 한쪽으로 쏠려 있으면 (스틱을 잡고 켰을 때) 기본값 사용
  if (abs(centerY - 2048) > 700) centerY = 1900;
  if (abs(centerX - 2048) > 700) centerX = 1900;
  Serial.printf("가운데 값  Y=%d  X=%d\n", centerY, centerX);
}

// ---------------------------------------------------------- ESP-NOW
#if ESP_ARDUINO_VERSION_MAJOR >= 3
static void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  (void)info;
#else
static void onRecv(const uint8_t *mac, const uint8_t *data, int len) {
  (void)mac;
#endif
  if (len != sizeof(TelemetryPacket)) return;
  const TelemetryPacket *p = (const TelemetryPacket *)data;
  if (p->magic != RC_MAGIC || p->type != PKT_TELEMETRY || p->carId != CAR_ID) return;
  portENTER_CRITICAL_ISR(&teleMux);
  memcpy(&teleBuf, data, sizeof(TelemetryPacket));
  teleNew = true;
  lastTeleMs = millis();
  portEXIT_CRITICAL_ISR(&teleMux);
}

static void radioBegin() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);
  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW 초기화 실패 → 재부팅");
    delay(1000); ESP.restart();
  }
  esp_now_register_recv_cb(onRecv);
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BCAST, 6);
  peer.channel = WIFI_CHANNEL;
  peer.ifidx = WIFI_IF_STA;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
}

// ---------------------------------------------------------- setup / loop
void setup() {
  Serial.begin(115200);
  pinMode(PIN_BTN_A, INPUT_PULLUP);
  pinMode(PIN_BTN_B, INPUT_PULLUP);
  pinMode(PIN_L_SW, INPUT_PULLUP);
  pinMode(PIN_R_SW, INPUT_PULLUP);
  pinMode(PIN_LED, OUTPUT);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  digitalWrite(PIN_LED, HIGH);
  delay(200);                                 // 스틱 손 떼기 대기
  calibrate();
  digitalWrite(PIN_LED, LOW);

  radioBegin();
  pkt.magic = RC_MAGIC;
  pkt.type = PKT_CONTROL;
  pkt.carId = CAR_ID;
  pkt.speedLevel = 2;
  Serial.printf("조종기 준비 완료  CAR_ID=%d  채널=%d  MAC=%s\n", CAR_ID, WIFI_CHANNEL, WiFi.macAddress().c_str());
  blink(pkt.speedLevel);
}

void loop() {
  uint32_t now = millis();

  if (pressedEdge(btnA)) { pkt.modeCount++; }
  if (pressedEdge(btnB)) { pkt.speedLevel = pkt.speedLevel >= 3 ? 1 : pkt.speedLevel + 1; blink(pkt.speedLevel); }
  if (pressedEdge(swR))  { pkt.lightCount++; }
  pressedEdge(swL);                            // 경적은 누르고 있는 동안

  if (teleNew) {
    portENTER_CRITICAL(&teleMux);
    uint8_t oldMode = tele.mode;
    tele = teleBuf; teleNew = false;
    portEXIT_CRITICAL(&teleMux);
    if (tele.mode != oldMode) blink(tele.mode + 1);
  }

  static uint32_t tSend = 0;
  if (now - tSend >= SEND_INTERVAL_MS) {
    tSend = now;
    int t = axis(readAvg(PIN_L_Y), centerY, INVERT_THROTTLE);
    int s = axis(readAvg(PIN_R_X), centerX, INVERT_STEER);
    pkt.throttle = t;
    pkt.steer = (int)(s * STEER_RATE);
    pkt.buttons = swL.stable ? BTN_HORN : 0;
    pkt.seq++;
    esp_now_send(BCAST, (const uint8_t *)&pkt, sizeof(pkt));
  }

  bool linked = (now - lastTeleMs) < LINK_TIMEOUT_MS;
  bool lowBatt = false;
#if USE_BATTERY_MON
  static uint32_t tB = 0; static uint16_t battMv = 4200;
  if (now - tB > 1000) { tB = now; battMv = analogReadMilliVolts(PIN_BATTERY) * BATTERY_DIVIDER; }
  lowBatt = battMv < LOW_BATTERY_MV;
#endif
  updateLed(linked, lowBatt);

  static uint32_t tLog = 0;
  if (now - tLog > 500) {
    tLog = now;
    Serial.printf("전진 %4d  방향 %4d  속도%d | %s  모드 %d  거리 %3dcm  라인 %d%d%d%s\n",
                  pkt.throttle, pkt.steer, pkt.speedLevel,
                  linked ? "연결" : "끊김", tele.mode, tele.distanceCm,
                  (tele.lineBits >> 2) & 1, (tele.lineBits >> 1) & 1, tele.lineBits & 1,
                  (tele.flags & 1) ? "  [앞 막힘]" : "");
  }
}
