// ====================================================================
//  config.h  —  조종기 설정
// ====================================================================
#pragma once

#define CAR_ID          1      // 차량 config.h 와 같은 번호
#define WIFI_CHANNEL    1

// ---------- 조이스틱 (KY-023, 반드시 3.3V 로 전원 연결!) ----------
// ADC1 핀만 사용 (ADC2 핀은 무선과 같이 못 씀)
#define PIN_L_Y         34     // 왼쪽 스틱 위아래 → 전진/후진
#define PIN_R_X         32     // 오른쪽 스틱 좌우 → 방향
#define PIN_L_SW        25     // 왼쪽 스틱 누르기 → 경적 (누르는 동안)
#define PIN_R_SW        26     // 오른쪽 스틱 누르기 → 전조등 켜기/끄기

#define INVERT_THROTTLE 1      // 스틱을 위로 밀었는데 후진하면 0/1 바꾸기
#define INVERT_STEER    0      // 오른쪽으로 밀었는데 왼쪽으로 돌면 0/1 바꾸기
#define DEADZONE        180    // 가운데 흔들림 무시 범위 (0~4095 중)
#define STEER_RATE      0.75f  // 방향 감도 (1.0 = 최대)

// ---------- 버튼 (PBS-110 등 푸시버튼, 한쪽은 GND) ----------
#define PIN_BTN_A       27     // 모드 전환 (수동 → 회피 → 라인)
#define PIN_BTN_B       14     // 속도 단계 1 → 2 → 3

// ---------- 표시 LED ----------
#define PIN_LED         4      // 220Ω 저항 거쳐 LED
// 켜짐: 연결됨 / 빠르게 깜빡: 차량 신호 없음 / N번 깜빡: 속도 단계·모드 표시

// ---------- 배터리 측정 (선택) ----------
#define USE_BATTERY_MON 0      // 18650+ ─ 100kΩ ─ (36) ─ 100kΩ ─ GND
#define PIN_BATTERY     36
#define BATTERY_DIVIDER 2.0f
#define LOW_BATTERY_MV  3400

#define SEND_INTERVAL_MS 20    // 초당 50번 전송
#define LINK_TIMEOUT_MS  500
