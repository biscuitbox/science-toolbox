// ====================================================================
//  ESP32-CAM (AI-Thinker) — RC카 실시간 카메라
//  차량이 연 와이파이 "RC-CAR-번호"에 자동 접속해서 영상을 보냅니다.
//    영상   http://192.168.4.200:81/stream   (폰 조종 화면이 자동으로 띄움)
//    설정   http://192.168.4.200/set?q=0~2&flip=0/1&mirror=0/1&led=0/1
//  보드 설정: "AI Thinker ESP32-CAM", PSRAM Enabled
//  업로드: ESP32-CAM-MB(USB 보드)에 꽂아서 업로드
// ====================================================================
#include <WiFi.h>
#include <esp_camera.h>
#include <esp_http_server.h>
#include <esp_arduino_version.h>
#include <soc/soc.h>
#include <soc/rtc_cntl_reg.h>
#include "config.h"

// ---------- AI-Thinker ESP32-CAM 카메라 핀 ----------
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22
#define FLASH_GPIO_NUM     4
#define RED_LED_GPIO      33   // 보드 뒷면 빨간 LED (LOW = 켜짐)

static httpd_handle_t ctrlServer = nullptr;
static httpd_handle_t streamServer = nullptr;
static int quality = START_QUALITY;
static bool flashOn = false;
static volatile uint32_t frames = 0;

// 화질 단계: 크기, JPEG 압축(숫자가 작을수록 선명·용량 큼)
static const framesize_t Q_SIZE[3] = {FRAMESIZE_QVGA, FRAMESIZE_HVGA, FRAMESIZE_VGA};
static const int         Q_JPEG[3] = {14, 14, 16};
static const char       *Q_NAME[3] = {"320x240", "480x320", "640x480"};

// ---------------------------------------------------------- 플래시 LED (코어 2.x / 3.x)
static void flashBegin() {
  // 채널 7 (타이머 3) 사용: 카메라가 쓰는 채널 0·타이머 0과 겹치지 않게
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttachChannel(FLASH_GPIO_NUM, 5000, 8, 7);
#else
  ledcSetup(7, 5000, 8);
  ledcAttachPin(FLASH_GPIO_NUM, 7);
#endif
}
static void flashWrite(uint8_t v) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(FLASH_GPIO_NUM, v);
#else
  ledcWrite(7, v);
#endif
}

// ---------------------------------------------------------- 카메라
static void applyQuality(int q) {
  quality = constrain(q, 0, 2);
  sensor_t *s = esp_camera_sensor_get();
  if (!s) return;
  s->set_framesize(s, Q_SIZE[quality]);
  s->set_quality(s, Q_JPEG[quality]);
}

static bool cameraBegin() {
  camera_config_t c = {};
  c.ledc_channel = LEDC_CHANNEL_0;
  c.ledc_timer = LEDC_TIMER_0;
  c.pin_d0 = Y2_GPIO_NUM; c.pin_d1 = Y3_GPIO_NUM; c.pin_d2 = Y4_GPIO_NUM; c.pin_d3 = Y5_GPIO_NUM;
  c.pin_d4 = Y6_GPIO_NUM; c.pin_d5 = Y7_GPIO_NUM; c.pin_d6 = Y8_GPIO_NUM; c.pin_d7 = Y9_GPIO_NUM;
  c.pin_xclk = XCLK_GPIO_NUM; c.pin_pclk = PCLK_GPIO_NUM;
  c.pin_vsync = VSYNC_GPIO_NUM; c.pin_href = HREF_GPIO_NUM;
  c.pin_sccb_sda = SIOD_GPIO_NUM; c.pin_sccb_scl = SIOC_GPIO_NUM;
  c.pin_pwdn = PWDN_GPIO_NUM; c.pin_reset = RESET_GPIO_NUM;
  c.xclk_freq_hz = 20000000;
  c.pixel_format = PIXFORMAT_JPEG;
  c.grab_mode = CAMERA_GRAB_LATEST;             // 항상 가장 최신 장면 (지연 줄이기)
  if (psramFound()) {
    c.frame_size = FRAMESIZE_VGA;               // 버퍼는 가장 큰 화질 기준
    c.jpeg_quality = 12;
    c.fb_count = 2;
    c.fb_location = CAMERA_FB_IN_PSRAM;
  } else {
    c.frame_size = FRAMESIZE_QVGA;
    c.jpeg_quality = 14;
    c.fb_count = 1;
    c.fb_location = CAMERA_FB_IN_DRAM;
  }
  esp_err_t err = esp_camera_init(&c);
  if (err != ESP_OK) {
    Serial.printf("카메라 초기화 실패 0x%x — 리본 케이블 연결 확인\n", err);
    return false;
  }
  sensor_t *s = esp_camera_sensor_get();
  s->set_vflip(s, FLIP_VERTICAL);
  s->set_hmirror(s, MIRROR);
  applyQuality(psramFound() ? START_QUALITY : 0);
  return true;
}

// ---------------------------------------------------------- 영상 스트림 (MJPEG)
#define BOUNDARY "rcframe"
static esp_err_t streamHandler(httpd_req_t *req) {
  httpd_resp_set_type(req, "multipart/x-mixed-replace;boundary=" BOUNDARY);
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  char head[80];
  esp_err_t r = ESP_OK;
  Serial.println("[CAM] 영상 보내기 시작");
  while (r == ESP_OK) {
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) { Serial.println("[CAM] 프레임 실패"); delay(30); continue; }
    int n = snprintf(head, sizeof(head),
                     "\r\n--" BOUNDARY "\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n", fb->len);
    r = httpd_resp_send_chunk(req, head, n);
    if (r == ESP_OK) r = httpd_resp_send_chunk(req, (const char *)fb->buf, fb->len);
    esp_camera_fb_return(fb);
    frames = frames + 1;
  }
  Serial.println("[CAM] 영상 연결 끊김");
  return r;
}

static esp_err_t captureHandler(httpd_req_t *req) {   // 사진 한 장
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) { httpd_resp_send_500(req); return ESP_FAIL; }
  httpd_resp_set_type(req, "image/jpeg");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  httpd_resp_set_hdr(req, "Content-Disposition", "inline; filename=rc_car.jpg");
  esp_err_t r = httpd_resp_send(req, (const char *)fb->buf, fb->len);
  esp_camera_fb_return(fb);
  return r;
}

// ---------------------------------------------------------- 설정 / 상태
static bool queryInt(const char *q, const char *key, int &out) {
  char v[8];
  if (httpd_query_key_value(q, key, v, sizeof(v)) != ESP_OK) return false;
  out = atoi(v);
  return true;
}

static esp_err_t setHandler(httpd_req_t *req) {
  char q[96] = "";
  httpd_req_get_url_query_str(req, q, sizeof(q));
  sensor_t *s = esp_camera_sensor_get();
  int v;
  if (queryInt(q, "q", v)) applyQuality(psramFound() ? v : 0);
  if (s && queryInt(q, "flip", v)) s->set_vflip(s, v ? 1 : 0);
  if (s && queryInt(q, "mirror", v)) s->set_hmirror(s, v ? 1 : 0);
  if (queryInt(q, "led", v)) { flashOn = v != 0; flashWrite(flashOn ? FLASH_MAX : 0); }
  char out[96];
  snprintf(out, sizeof(out), "{\"q\":%d,\"size\":\"%s\",\"led\":%d}", quality, Q_NAME[quality], flashOn ? 1 : 0);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_sendstr(req, out);
}

static esp_err_t indexHandler(httpd_req_t *req) {
  char html[400];
  snprintf(html, sizeof(html),
           "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width'>"
           "<body style='margin:0;background:#000;color:#ccc;font-family:sans-serif'>"
           "<p style='padding:8px'>RC-CAR-%d 카메라 · %s · 조종은 http://192.168.4.1</p>"
           "<img style='width:100%%' src='http://%s:81/stream'>",
           CAR_ID, Q_NAME[quality], WiFi.localIP().toString().c_str());
  httpd_resp_set_type(req, "text/html; charset=utf-8");
  return httpd_resp_sendstr(req, html);
}

static void serversBegin() {
  httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
  cfg.server_port = 80;
  cfg.ctrl_port = 32768;
  cfg.max_open_sockets = 4;
  cfg.lru_purge_enable = true;
  if (httpd_start(&ctrlServer, &cfg) == ESP_OK) {
    httpd_uri_t u = {};
    u.method = HTTP_GET;
    u.uri = "/";        u.handler = indexHandler;   httpd_register_uri_handler(ctrlServer, &u);
    u.uri = "/set";     u.handler = setHandler;     httpd_register_uri_handler(ctrlServer, &u);
    u.uri = "/capture"; u.handler = captureHandler; httpd_register_uri_handler(ctrlServer, &u);
  }
  // 영상은 따로 (영상 보내는 동안에도 설정 요청을 받을 수 있게)
  cfg.server_port = 81;
  cfg.ctrl_port = 32769;
  cfg.max_open_sockets = 3;
  if (httpd_start(&streamServer, &cfg) == ESP_OK) {
    httpd_uri_t u = {};
    u.method = HTTP_GET; u.uri = "/stream"; u.handler = streamHandler;
    httpd_register_uri_handler(streamServer, &u);
  }
}

// ---------------------------------------------------------- 와이파이
static String ssid() { return String(CAR_SSID_PREFIX) + CAR_ID; }

static void wifiBegin() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);                         // 절전 끄기 (영상 끊김 방지)
  WiFi.config(IPAddress(CAM_IP), IPAddress(192, 168, 4, 1), IPAddress(255, 255, 255, 0));
  WiFi.setAutoReconnect(true);
  WiFi.begin(ssid().c_str(), CAR_PASSWORD);
  Serial.printf("차량 와이파이 \"%s\" 접속 중", ssid().c_str());
  for (int i = 0; i < 40 && WiFi.status() != WL_CONNECTED; i++) { delay(250); Serial.print('.'); }
  Serial.println();
}

// ---------------------------------------------------------- setup / loop
void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);    // 순간 전압 강하로 재부팅되는 것 방지
  Serial.begin(115200);
  pinMode(RED_LED_GPIO, OUTPUT);
  digitalWrite(RED_LED_GPIO, HIGH);
  flashBegin();
  flashWrite(0);

  Serial.printf("\nRC카 카메라  CAR_ID=%d  PSRAM=%s\n", CAR_ID, psramFound() ? "있음" : "없음(320x240만)");
  if (!cameraBegin()) {
    for (;;) { digitalWrite(RED_LED_GPIO, !digitalRead(RED_LED_GPIO)); delay(100); }  // 빠른 깜빡임 = 카메라 오류
  }
  wifiBegin();
  serversBegin();
  Serial.printf("영상 주소  http://%s:81/stream\n", IPAddress(CAM_IP).toString().c_str());
}

void loop() {
  static uint32_t tLog = 0, tLed = 0, tRetry = 0, lastFrames = 0;
  uint32_t now = millis();
  bool ok = WiFi.status() == WL_CONNECTED;

  // 빨간 LED: 켜짐 = 차량 연결됨 / 천천히 깜빡 = 차량 찾는 중
  if (now - tLed > 500) { tLed = now; digitalWrite(RED_LED_GPIO, ok ? LOW : !digitalRead(RED_LED_GPIO)); }

  if (!ok && now - tRetry > 5000) {             // 차량이 늦게 켜져도 다시 접속
    tRetry = now;
    WiFi.disconnect();
    WiFi.begin(ssid().c_str(), CAR_PASSWORD);
  }
  if (now - tLog > 2000) {
    uint32_t f = frames;
    Serial.printf("[CAM] %s  %s  %.1f fps\n", ok ? "연결" : "끊김", Q_NAME[quality], (f - lastFrames) / 2.0f);
    lastFrames = f; tLog = now;
  }
  delay(20);
}
