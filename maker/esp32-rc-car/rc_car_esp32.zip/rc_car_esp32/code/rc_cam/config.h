// ====================================================================
//  config.h  —  ESP32-CAM (AI-Thinker) 카메라 설정
// ====================================================================
#pragma once

// ---------- 접속할 차량 ----------
// 차량 config.h 의 CAR_ID, PHONE_SSID_PREFIX, PHONE_PASSWORD 와 같게
#define CAR_ID          1
#define CAR_SSID_PREFIX "RC-CAR-"
#define CAR_PASSWORD    "12345678"

// 카메라 주소 (차량 config.h 의 CAM_IP 와 같게). 폰이 이 주소로 영상을 받습니다.
#define CAM_IP          192, 168, 4, 200

// ---------- 영상 ----------
// 시작 화질: 0 빠르게(320x240) / 1 보통(480x320) / 2 선명하게(640x480)
// 폰 설정 메뉴에서 바꿀 수 있습니다.
#define START_QUALITY   1
#define FLIP_VERTICAL   0      // 카메라를 거꾸로 달았으면 1
#define MIRROR          0      // 좌우가 바뀌어 보이면 1

// ---------- 플래시 LED (GPIO4, 매우 밝음) ----------
#define FLASH_MAX       60     // 폰에서 켰을 때 밝기 (0~255, 너무 밝으면 줄이기)
