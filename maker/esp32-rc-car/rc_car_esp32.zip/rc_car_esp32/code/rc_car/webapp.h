// 자동 생성 파일 — web/index.html 을 고친 뒤 web/make_webapp_h.py 실행
#pragma once
static const char WEBAPP_HTML[] = R"WEBAPP(<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#0d1014">
<title>RC카 조종</title>
<style>
:root{
  --bg:#0d1014; --panel:#171c22; --panel2:#202730; --line:#2c3540;
  --text:#eef2f6; --dim:#7f8a98; --accent:#f08a24; --accent2:#ffb867;
  --ok:#3ccf7a; --warn:#ffcc33; --bad:#ff5a52; --blue:#4aa3ff;
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
html,body{margin:0;height:100%;color:var(--text);overflow:hidden;touch-action:none;overscroll-behavior:none;
  font-family:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Malgun Gothic","Noto Sans KR",sans-serif;
  background:radial-gradient(120% 90% at 50% 110%,#1a2029 0%,var(--bg) 60%) fixed,var(--bg)}
button{font:inherit;color:inherit;border:0;background:none;cursor:pointer;padding:0}

#app{position:fixed;inset:0;display:grid;gap:8px;z-index:2;
  padding:max(8px,env(safe-area-inset-top)) max(12px,env(safe-area-inset-right)) max(8px,env(safe-area-inset-bottom)) max(12px,env(safe-area-inset-left));
  grid-template-rows:auto 1fr;
  grid-template-columns:1fr auto 1fr;
  grid-template-areas:"hud hud hud" "L mid R"}
#app.one{grid-template-columns:1.25fr 1fr;grid-template-areas:"hud hud" "L mid"}
#app.two.swap{grid-template-areas:"hud hud hud" "R mid L"}
#app.one.swap{grid-template-columns:1fr 1.25fr;grid-template-areas:"hud hud" "mid L"}
#app.one #zoneR{display:none}

/* ---------- 카메라 영상 (FPV) ---------- */
#cam{position:fixed;inset:0;width:100%;height:100%;object-fit:contain;background:#000;z-index:0;display:none}
#camShade{position:fixed;inset:0;z-index:1;pointer-events:none;display:none;
  background:linear-gradient(#000a,#0000 90px),linear-gradient(0deg,#0007,#0000 120px)}
body.fpv{background:#000}
body.fpv #cam,body.fpv #camShade{display:block}
body.fpv.fill #cam{object-fit:cover}
body.fpv.flip #cam{transform:rotate(180deg)}
#camMsg{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:1;display:none;pointer-events:none;
  color:#cfd6de;font-size:14px;text-align:center;line-height:1.6}
body.fpv:not(.live) #camMsg{display:block}
body.fpv .base{background:radial-gradient(circle,#0000002e 0 45%,#00000059 46% 100%);border-color:#ffffffa0}
body.fpv .zone:not(.active) .stick{opacity:.7}
body.fpv .rb{background:#0b0e12b3;border-color:#ffffff40;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}
body.fpv .zone .tag{color:#fffd;text-shadow:0 1px 3px #000}
body.fpv .chip,body.fpv .iconBtn{background:#0b0e12b3;border-color:#ffffff30}
#camBtn{display:none}
body.hascam #camBtn{display:grid}
#camBtn.on{border-color:var(--accent);color:var(--accent)}

/* ---------- HUD ---------- */
#hud{grid-area:hud;display:flex;align-items:center;gap:6px;flex-wrap:wrap;position:relative;z-index:5}
.chip{display:flex;align-items:center;gap:6px;background:#171c22d9;border:1px solid var(--line);
  border-radius:999px;padding:6px 11px;font-size:13px;white-space:nowrap;line-height:1}
.chip b{font-weight:700}
.dot{width:9px;height:9px;border-radius:50%;background:var(--dim);flex:none}
#link.ok .dot{background:var(--ok);box-shadow:0 0 8px var(--ok)}
#link.wait .dot{background:var(--warn);animation:blink 1s infinite}
#link.bad .dot{background:var(--bad)}
@keyframes blink{50%{opacity:.25}}
#owner.ctrl{border-color:var(--blue);color:var(--blue)}
#distBar{width:52px;height:6px;border-radius:3px;background:var(--panel2);overflow:hidden}
#distFill{height:100%;width:0;background:var(--ok);transition:width .15s}
#blockTag{display:none;color:var(--bad);border-color:var(--bad)}
#app.blocked #blockTag{display:flex}
#demo{display:none;color:var(--warn);border-color:var(--warn)}
#demo.show{display:flex}
.spacer{flex:1}
.iconBtn{width:36px;height:36px;border-radius:50%;background:#171c22d9;border:1px solid var(--line);display:grid;place-items:center}
.iconBtn svg{width:18px;height:18px}

/* ---------- 조이스틱 영역 ---------- */
.zone{position:relative;min-height:0;border-radius:24px}
#zoneL{grid-area:L} #zoneR{grid-area:R}
.zone .tag{position:absolute;left:50%;bottom:6px;transform:translateX(-50%);font-size:12px;color:var(--dim);
  white-space:nowrap;pointer-events:none;transition:opacity .2s}
.zone.active .tag{opacity:0}
.stick{position:absolute;left:0;top:0;width:var(--d);height:var(--d);margin:calc(var(--d)/-2) 0 0 calc(var(--d)/-2);
  pointer-events:none;opacity:.55;transition:opacity .15s, transform .18s ease-out;will-change:transform}
.zone.active .stick{opacity:1;transition:opacity .1s}
.base{position:absolute;inset:0;border-radius:50%;
  background:radial-gradient(circle at 50% 50%,#ffffff08 0 45%,#ffffff12 46% 100%);
  border:2px solid #ffffff2a;box-shadow:inset 0 0 30px #0008,0 8px 30px #0006}
.base::before{content:"";position:absolute;inset:22%;border-radius:50%;border:1px dashed #ffffff1c}
.aim{position:absolute;inset:-6px;border-radius:50%;opacity:0;
  background:conic-gradient(from -28deg,var(--accent) 0 56deg,transparent 56deg 360deg);
  -webkit-mask:radial-gradient(circle closest-side,transparent calc(100% - 8px),#000 calc(100% - 7px),#000 calc(100% - 1px),transparent 100%);
          mask:radial-gradient(circle closest-side,transparent calc(100% - 8px),#000 calc(100% - 7px),#000 calc(100% - 1px),transparent 100%);
  filter:drop-shadow(0 0 6px var(--accent))}
.chev{position:absolute;width:0;height:0;border:7px solid transparent;opacity:.5;transition:opacity .1s,border-color .1s}
.chev.u{left:50%;top:9%;margin-left:-7px;border-bottom:10px solid var(--dim);border-top:0}
.chev.d{left:50%;bottom:9%;margin-left:-7px;border-top:10px solid var(--dim);border-bottom:0}
.chev.l{top:50%;left:9%;margin-top:-7px;border-right:10px solid var(--dim);border-left:0}
.chev.r{top:50%;right:9%;margin-top:-7px;border-left:10px solid var(--dim);border-right:0}
.chev.on{opacity:1}
.chev.u.on{border-bottom-color:var(--accent)} .chev.d.on{border-top-color:var(--accent)}
.chev.l.on{border-right-color:var(--accent)} .chev.r.on{border-left-color:var(--accent)}
.stick.v .chev.l,.stick.v .chev.r,.stick.h .chev.u,.stick.h .chev.d{display:none}
.thumb{position:absolute;left:50%;top:50%;width:44%;height:44%;margin:-22% 0 0 -22%;border-radius:50%;
  background:radial-gradient(circle at 35% 30%,#ffd09a,var(--accent2) 25%,var(--accent) 62%,#b25a0c);
  box-shadow:0 6px 16px #000a,inset 0 -4px 8px #0004,inset 0 2px 3px #fff5;
  transition:transform .15s ease-out;will-change:transform}
.zone.active .thumb{transition:none}
.stick .val{position:absolute;left:50%;top:calc(100% + 6px);transform:translateX(-50%);font-size:12px;
  color:var(--dim);font-variant-numeric:tabular-nums;opacity:0}
.zone.active .stick .val{opacity:1}
#app.blocked #zoneL .base{border-color:var(--bad);box-shadow:inset 0 0 30px #0008,0 0 0 4px #ff5a5233}

/* ---------- 둥근 게임 버튼 ---------- */
#mid{grid-area:mid;position:relative;min-height:0;display:grid;align-content:center;justify-items:center;
  grid-template-columns:repeat(2,auto);gap:12px 14px;padding:0 4px}
.rb{position:relative;width:68px;height:68px;border-radius:50%;display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:2px;font-size:11px;font-weight:600;color:#d7dde4;
  background:radial-gradient(circle at 50% 30%,#2b333e,#1a2028 70%);
  border:2px solid #ffffff1f;box-shadow:0 6px 14px #0008,inset 0 2px 2px #ffffff14;transition:transform .08s}
.rb svg{width:24px;height:24px}
.rb:active,.rb.press{transform:scale(.92)}
.rb .big{font-size:24px;font-weight:800;line-height:1;color:var(--accent2)}
.rb.on{border-color:var(--warn);color:var(--warn);box-shadow:0 0 16px #ffcc3355,inset 0 2px 2px #ffffff14}
#hornBtn{border-color:#ff5a5266}
#hornBtn.on{border-color:var(--bad);color:#fff;background:radial-gradient(circle at 50% 30%,#ff7a6e,#c9352d 75%);box-shadow:0 0 20px #ff5a5288}
#modeBtn .mname{font-size:13px;font-weight:800;color:var(--text)}
#lineView{grid-column:1/-1;display:none;gap:6px}
#lineView.show{display:flex}
#lineView i{width:14px;height:14px;border-radius:50%;background:var(--panel2);border:1px solid var(--line)}
#lineView i.on{background:var(--text)}

/* 스틱 1개: 오른쪽은 게임 액션 버튼 배치 */
#app.one #mid{display:block}
#app.one .rb{position:absolute}
#app.one #hornBtn{width:112px;height:112px;right:8%;bottom:12%;font-size:13px}
#app.one #hornBtn svg{width:36px;height:36px}
#app.one #lightBtn{right:calc(8% + 128px);bottom:8%}
#app.one #speedBtn{right:calc(8% + 112px);bottom:calc(12% + 92px)}
#app.one #modeBtn{right:calc(8% + 20px);bottom:calc(12% + 128px);width:78px;height:78px}
#app.one #lineView{position:absolute;right:calc(8% + 110px);bottom:calc(12% + 200px)}
#app.one.swap #hornBtn{right:auto;left:8%}
#app.one.swap #lightBtn{right:auto;left:calc(8% + 128px)}
#app.one.swap #speedBtn{right:auto;left:calc(8% + 112px)}
#app.one.swap #modeBtn{right:auto;left:calc(8% + 20px)}
#app.one.swap #lineView{right:auto;left:calc(8% + 110px)}

/* ---------- 설정 메뉴 ---------- */
#menu{position:fixed;top:54px;right:max(12px,env(safe-area-inset-right));z-index:20;width:250px;
  max-height:calc(100% - 64px);overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;
  background:#171c22;border:1px solid var(--line);border-radius:16px;padding:12px;box-shadow:0 12px 40px #000a;
  display:none}
#menu.show{display:block}
#menu h4{margin:2px 2px 8px;font-size:12px;color:var(--dim);font-weight:600}
.seg{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:12px}
.seg button{padding:9px 0;border-radius:10px;background:var(--panel2);border:1px solid var(--line);font-size:13px;font-weight:600}
.seg button.on{background:var(--accent);border-color:var(--accent);color:#1a0f02}
.seg.three{grid-template-columns:1fr 1fr 1fr}
#camMenu{display:none}
body.hascam #camMenu{display:block}
#snapLink{display:block;text-align:center;padding:9px 0;border-radius:10px;background:var(--panel2);border:1px solid var(--line);
  color:var(--text);text-decoration:none;font-size:13px;font-weight:600}

#toast{position:fixed;left:50%;top:56px;transform:translate(-50%,-16px);opacity:0;pointer-events:none;z-index:30;
  background:#000d;border:1px solid var(--line);padding:9px 16px;border-radius:999px;font-size:14px;transition:.2s;
  white-space:nowrap;max-width:92vw;overflow:hidden;text-overflow:ellipsis}
#toast.show{opacity:1;transform:translate(-50%,0)}

/* ---------- 세로 화면 ---------- */
@media (orientation:portrait){
  #app.two,#app.one{grid-template-columns:1fr 1fr;grid-template-rows:auto auto 1fr}
  #app.two{grid-template-areas:"hud hud" "mid mid" "L R"}
  #app.two.swap{grid-template-areas:"hud hud" "mid mid" "R L"}
  #app.one,#app.one.swap{grid-template-areas:"hud hud" "mid mid" "L L"}
  #mid,#app.one #mid{display:flex;flex-wrap:wrap;justify-content:center;gap:12px;padding:6px 0}
  #app.one .rb,#app.one.swap .rb{position:relative;left:auto;right:auto;bottom:auto;width:68px;height:68px}
  #app.one #hornBtn svg{width:24px;height:24px}
  #lineView,#app.one #lineView{position:static;width:100%;justify-content:center}
  #toast{top:40%}
}
@media (orientation:landscape) and (max-height:360px){
  .rb{width:58px;height:58px} .rb svg{width:20px;height:20px}
  #app.one #hornBtn{width:96px;height:96px}
  .chip{padding:5px 9px;font-size:12px}
}
</style>
</head>
<body>
<img id="cam" alt="">
<div id="camShade"></div>
<div id="camMsg">카메라 연결 중…</div>
<div id="app" class="two">
  <header id="hud">
    <div class="chip" id="link"><span class="dot"></span><b id="carName">RC카</b><span id="linkTxt">연결 중…</span></div>
    <div class="chip" id="owner">대기</div>
    <div class="chip" id="distWrap">거리 <div id="distBar"><div id="distFill"></div></div><b id="distTxt">--</b></div>
    <div class="chip" id="battChip" style="display:none">배터리 <b id="battTxt">--</b></div>
    <div class="chip" id="blockTag">앞에 장애물</div>
    <div class="chip" id="demo">미리보기 (차량 연결 없음)</div>
    <div class="spacer"></div>
    <button class="iconBtn" id="camBtn" aria-label="카메라"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8a2 2 0 0 1 2-2h2l1.5-2h7L17 6h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="12.5" r="3.5"/></svg></button>
    <button class="iconBtn" id="gearBtn" aria-label="설정"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button>
    <button class="iconBtn" id="fsBtn" aria-label="전체 화면"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg></button>
  </header>

  <section class="zone" id="zoneL">
    <div class="stick v" id="stickL"><div class="aim"></div><div class="base"><i class="chev u"></i><i class="chev d"></i><i class="chev l"></i><i class="chev r"></i></div><div class="thumb"></div><span class="val"></span></div>
    <div class="tag" id="tagL">엄지를 대고 위·아래로 · 전진/후진</div>
  </section>

  <section id="mid">
    <button class="rb" id="modeBtn"><span class="mname" id="modeTxt">수동</span><span>모드</span></button>
    <button class="rb" id="speedBtn"><span class="big" id="speedTxt">2</span><span>속도</span></button>
    <button class="rb" id="lightBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z"/></svg><span>전조등</span></button>
    <button class="rb" id="hornBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10v4h4l5 4V6L8 10H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg><span>경적</span></button>
    <div id="lineView"><i id="l0"></i><i id="l1"></i><i id="l2"></i></div>
  </section>

  <section class="zone" id="zoneR">
    <div class="stick h" id="stickR"><div class="aim"></div><div class="base"><i class="chev u"></i><i class="chev d"></i><i class="chev l"></i><i class="chev r"></i></div><div class="thumb"></div><span class="val"></span></div>
    <div class="tag">엄지를 대고 좌·우로 · 방향</div>
  </section>
</div>

<div id="menu">
  <h4>조이스틱</h4>
  <div class="seg" id="segSticks"><button data-v="2">2개 (양손)</button><button data-v="1">1개 (한 손)</button></div>
  <h4>조이스틱 위치</h4>
  <div class="seg" id="segSide"><button data-v="0">기본</button><button data-v="1">좌우 바꾸기</button></div>
  <h4>조이스틱 나타나는 곳</h4>
  <div class="seg" id="segFloat"><button data-v="1">엄지 댄 곳</button><button data-v="0">제자리 고정</button></div>
  <div id="camMenu">
    <h4>카메라 화질</h4>
    <div class="seg three" id="segCamQ"><button data-v="0">빠르게</button><button data-v="1">보통</button><button data-v="2">선명</button></div>
    <h4>카메라 화면</h4>
    <div class="seg" id="segCamFit"><button data-v="1">꽉 채우기</button><button data-v="0">전체 보기</button></div>
    <div class="seg" id="segCamFlip"><button data-v="0">기본</button><button data-v="1">위아래 뒤집기</button></div>
    <a id="snapLink" target="_blank" rel="noopener">사진 찍기 (새 창)</a>
  </div>
</div>
<div id="toast"></div>

<script>
(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const MODE_NAMES = ["수동 주행", "장애물 회피", "라인트레이싱"];
  const MODE_SHORT = ["수동", "회피", "라인"];
  const SEND_MS = 50;

  const st = {
    t: 0, s: 0, horn: false, speed: 2, modeCount: 0, lightCount: 0,
    oneStick: false, swapped: false, floating: true, tele: null, lastTele: 0
  };
  const load = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
  st.oneStick = load("rc_oneStick", "0") === "1";
  st.swapped = load("rc_swapped", "0") === "1";
  st.floating = load("rc_floating", "1") === "1";
  st.speed = Math.min(3, Math.max(1, +load("rc_speed", "2") || 2));

  const buzz = ms => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} };
  let toastTimer = 0;
  function toast(msg) {
    const el = $("toast"); el.textContent = msg; el.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 1400);
  }

  // ---------------------------------------------------------- 원형 조이스틱
  // 엄지를 댄 곳에 조이스틱이 나타나고(플로팅), 손을 떼면 제자리로 돌아감
  function makeStick(zone, stick, getAxis, onMove) {
    const thumb = stick.querySelector(".thumb"), aim = stick.querySelector(".aim"), val = stick.querySelector(".val");
    const chev = {}; ["u", "d", "l", "r"].forEach(k => chev[k] = stick.querySelector(".chev." + k));
    let pid = null, cx = 0, cy = 0, D = 160;

    function size() {
      const r = zone.getBoundingClientRect();
      D = Math.round(Math.max(120, Math.min(210, Math.min(r.width * 0.75, r.height * 0.62))));
      stick.style.setProperty("--d", D + "px");
      return r;
    }
    function rest() {                         // 손 뗀 상태의 위치
      const r = size();
      cx = r.width / 2; cy = r.height * 0.56;
      stick.style.transform = `translate(${cx}px,${cy}px)`;
    }
    function draw(nx, ny) {                   // nx, ny: -1~1 (화면 기준, 아래가 +)
      const R = D * 0.36;
      thumb.style.transform = `translate(${nx * R}px,${ny * R}px)`;
      const m = Math.min(1, Math.hypot(nx, ny));
      aim.style.opacity = m > 0.08 ? (0.35 + 0.65 * m).toFixed(2) : 0;
      aim.style.transform = `rotate(${Math.atan2(nx, -ny)}rad)`;
      chev.u.classList.toggle("on", ny < -0.2); chev.d.classList.toggle("on", ny > 0.2);
      chev.l.classList.toggle("on", nx < -0.2); chev.r.classList.toggle("on", nx > 0.2);
    }
    function update(px, py) {
      const r = zone.getBoundingClientRect();
      const axis = getAxis();
      const R = D * 0.36;
      let dx = px - r.left - cx, dy = py - r.top - cy;
      if (axis === "v") dx = 0;
      if (axis === "h") dy = 0;
      let nx = dx / R, ny = dy / R;
      const m = Math.hypot(nx, ny);
      if (m > 1) { nx /= m; ny /= m; }
      draw(nx, ny);
      const out = onMove(nx, -ny);
      val.textContent = out;
    }
    function release() {
      pid = null; zone.classList.remove("active");
      draw(0, 0); rest(); onMove(0, 0);
    }
    zone.addEventListener("pointerdown", e => {
      if (pid !== null) return;
      pid = e.pointerId; zone.setPointerCapture(pid); zone.classList.add("active");
      const r = size();
      if (st.floating) {                        // 엄지 댄 곳으로 이동
        const m = D * 0.3;
        cx = Math.max(m, Math.min(r.width - m, e.clientX - r.left));
        cy = Math.max(m, Math.min(r.height - m, e.clientY - r.top));
        stick.style.transform = `translate(${cx}px,${cy}px)`;
      }
      update(e.clientX, e.clientY); buzz(8); e.preventDefault();
    });
    zone.addEventListener("pointermove", e => { if (e.pointerId === pid) update(e.clientX, e.clientY); });
    ["pointerup", "pointercancel", "lostpointercapture"].forEach(ev =>
      zone.addEventListener(ev, e => { if (e.pointerId === pid) release(); }));
    return { release, rest, setAxis: a => { stick.classList.remove("v", "h", "xy"); stick.classList.add(a); } };
  }

  // 가운데는 0, 바깥으로 갈수록 부드럽게 커지는 곡선
  const shape = v => {
    const dz = 0.1, a = Math.abs(v);
    if (a < dz) return 0;
    const n = (a - dz) / (1 - dz);
    return Math.sign(v) * Math.round(255 * Math.min(1, 0.35 * n + 0.65 * n * n));
  };

  // ---------------------------------------------------------- 카메라 (ESP32-CAM 영상)
  const cam = {
    host: "", want: load("rc_cam", "1") === "1", q: +load("rc_camQ", "1"),
    fill: load("rc_camFill", "1") === "1", flip: load("rc_camFlip", "0") === "1",
    live: false, timer: 0, tries: 0, led: -1
  };
  const camImg = $("cam");
  function camMsg(t) { $("camMsg").innerHTML = t; }
  function camStart() {
    clearInterval(cam.timer);
    if (!cam.host || !cam.want) return;
    cam.live = false; document.body.classList.remove("live");
    camMsg("카메라 연결 중…");
    camImg.src = `http://${cam.host}:81/stream?t=${Date.now()}`;
    cam.tries = 0;
    cam.timer = setInterval(() => {
      if (camImg.naturalWidth > 0) {
        if (!cam.live) { cam.live = true; document.body.classList.add("live"); camSet("q=" + cam.q); }
      } else if (++cam.tries > 10) {
        camMsg("카메라 응답 없음<br><small>ESP32-CAM 전원·와이파이 확인 · 다시 시도 중</small>");
        camStart();
      }
    }, 500);
  }
  function camStop() {
    clearInterval(cam.timer); cam.live = false;
    document.body.classList.remove("live");
    camImg.removeAttribute("src");
  }
  function camApply() {
    const on = !!cam.host && cam.want;
    document.body.classList.toggle("hascam", !!cam.host);
    document.body.classList.toggle("fpv", on);
    $("camBtn").classList.toggle("on", on);
    if (on && !camImg.getAttribute("src")) camStart();
    if (!on && camImg.getAttribute("src")) camStop();
    requestAnimationFrame(() => { L.rest(); R.rest(); });
  }
  function camSet(query) {
    if (!cam.host) return;
    fetch(`http://${cam.host}/set?${query}`, { mode: "no-cors", cache: "no-store" }).catch(() => {});
  }
  camImg.addEventListener("error", () => {
    if (!cam.want || !camImg.getAttribute("src")) return;
    cam.live = false; document.body.classList.remove("live");
    camMsg("카메라 연결 끊김 · 다시 연결 중…");
    clearInterval(cam.timer); cam.timer = setTimeout(camStart, 1500);
  });
  $("camBtn").addEventListener("click", () => {
    cam.want = !cam.want; save("rc_cam", cam.want ? "1" : "0"); buzz(10);
    if (cam.want) camImg.removeAttribute("src");
    camApply(); toast(cam.want ? "카메라 켜기" : "카메라 끄기");
  });

  const L = makeStick($("zoneL"), $("stickL"), () => st.oneStick ? "xy" : "v",
    (x, y) => { st.t = shape(y); if (st.oneStick) st.s = shape(x); sendNow(); return st.oneStick ? `${st.t} / ${st.s}` : st.t; });
  const R = makeStick($("zoneR"), $("stickR"), () => "h",
    (x) => { if (!st.oneStick) st.s = shape(x); sendNow(); return st.s; });

  function applyLayout() {
    const app = $("app");
    app.classList.toggle("one", st.oneStick); app.classList.toggle("two", !st.oneStick);
    app.classList.toggle("swap", st.swapped);
    L.setAxis(st.oneStick ? "xy" : "v");
    $("tagL").textContent = st.oneStick ? "엄지를 대고 원하는 방향으로 · 주행" : "엄지를 대고 위·아래로 · 전진/후진";
    segOn("segSticks", st.oneStick ? "1" : "2");
    segOn("segSide", st.swapped ? "1" : "0");
    segOn("segFloat", st.floating ? "1" : "0");
    segOn("segCamQ", String(cam.q)); segOn("segCamFit", cam.fill ? "1" : "0"); segOn("segCamFlip", cam.flip ? "1" : "0");
    document.body.classList.toggle("fill", cam.fill); document.body.classList.toggle("flip", cam.flip);
    requestAnimationFrame(() => { L.release(); R.release(); });
  }
  function segOn(id, v) { $(id).querySelectorAll("button").forEach(b => b.classList.toggle("on", b.dataset.v === v)); }
  addEventListener("resize", () => { L.rest(); R.rest(); });

  // ---------------------------------------------------------- 버튼
  const tapBtn = (id, fn) => $(id).addEventListener("click", () => { fn(); buzz(12); sendNow(); });
  tapBtn("modeBtn", () => { st.modeCount = (st.modeCount + 1) & 255; });
  tapBtn("lightBtn", () => { st.lightCount = (st.lightCount + 1) & 255; });
  tapBtn("speedBtn", () => { st.speed = st.speed >= 3 ? 1 : st.speed + 1; save("rc_speed", st.speed); renderSpeed(); toast("속도 " + st.speed + "단계"); });
  function renderSpeed() { $("speedTxt").textContent = st.speed; }

  const horn = $("hornBtn");
  const hornOff = () => { if (!st.horn) return; st.horn = false; horn.classList.remove("on"); sendNow(); };
  horn.addEventListener("pointerdown", e => { horn.setPointerCapture(e.pointerId); e.preventDefault();
    st.horn = true; horn.classList.add("on"); buzz(25); sendNow(); });
  ["pointerup", "pointercancel", "lostpointercapture"].forEach(ev => horn.addEventListener(ev, hornOff));

  // 설정 메뉴
  $("gearBtn").addEventListener("click", e => { e.stopPropagation(); $("menu").classList.toggle("show"); });
  document.addEventListener("pointerdown", e => {
    if (!$("menu").contains(e.target) && e.target.closest("#gearBtn") === null) $("menu").classList.remove("show");
  });
  function segClick(id, fn) {
    $(id).addEventListener("click", e => { const b = e.target.closest("button"); if (b) { fn(b.dataset.v); applyLayout(); buzz(8); } });
  }
  segClick("segSticks", v => { st.oneStick = v === "1"; save("rc_oneStick", v); toast(st.oneStick ? "스틱 1개 — 한 손으로 전진·방향" : "스틱 2개 — 왼손 전후, 오른손 방향"); });
  segClick("segSide", v => { st.swapped = v === "1"; save("rc_swapped", v); });
  segClick("segFloat", v => { st.floating = v === "1"; save("rc_floating", v); });
  segClick("segCamQ", v => { cam.q = +v; save("rc_camQ", v); camSet("q=" + v); toast(["빠르게 320×240", "보통 480×320", "선명하게 640×480"][cam.q]); });
  segClick("segCamFit", v => { cam.fill = v === "1"; save("rc_camFill", v); });
  segClick("segCamFlip", v => { cam.flip = v === "1"; save("rc_camFlip", v); });

  $("fsBtn").addEventListener("click", () => {
    const d = document, el = d.documentElement;
    if (!d.fullscreenElement && el.requestFullscreen) {
      el.requestFullscreen().then(() => { try { screen.orientation.lock("landscape"); } catch (e) {} }).catch(() => {});
    } else if (d.exitFullscreen) d.exitFullscreen().catch(() => {});
  });
  document.addEventListener("gesturestart", e => e.preventDefault());
  document.addEventListener("contextmenu", e => e.preventDefault());

  // ---------------------------------------------------------- 통신 (WebSocket)
  const demo = !/^https?:$/.test(location.protocol) || location.hostname === "";
  let ws = null, retry = 0;
  function connect() {
    if (demo) { $("demo").classList.add("show"); setLink("bad", "미리보기"); return; }
    setLink("wait", "연결 중…");
    try { ws = new WebSocket(`ws://${location.host}/ws`); } catch (e) { scheduleRetry(); return; }
    ws.onopen = () => { retry = 0; setLink("wait", "차량 응답 대기"); sendNow(); if (cam.host && cam.want && !cam.live) camStart(); };
    ws.onmessage = ev => { try { st.tele = JSON.parse(ev.data); st.lastTele = performance.now(); renderTele(); } catch (e) {} };
    ws.onclose = () => { ws = null; setLink("bad", "끊김 · 다시 연결"); scheduleRetry(); };
    ws.onerror = () => { try { ws.close(); } catch (e) {} };
  }
  function scheduleRetry() { setTimeout(connect, Math.min(3000, 500 + retry++ * 500)); }

  // C,전진,방향,경적,속도,모드카운트,전조등카운트
  const packet = () => `C,${st.t},${st.s},${st.horn ? 1 : 0},${st.speed},${st.modeCount},${st.lightCount}`;
  let lastSent = 0;
  function sendNow() {
    if (!ws || ws.readyState !== 1 || ws.bufferedAmount > 256) return;
    ws.send(packet()); lastSent = performance.now();
  }
  setInterval(() => { if (performance.now() - lastSent >= SEND_MS - 5) sendNow(); }, SEND_MS);

  document.addEventListener("visibilitychange", () => {       // 화면을 벗어나면 바로 멈춤
    if (document.hidden) { st.t = 0; st.s = 0; st.horn = false; L.release(); R.release(); sendNow(); }
  });

  function setLink(cls, txt) { $("link").className = "chip " + cls; $("linkTxt").textContent = txt; }

  let lastMode = -1;
  function renderTele() {
    const t = st.tele; if (!t) return;
    setLink("ok", "연결됨");
    if (t.id !== undefined) $("carName").textContent = "RC-CAR-" + t.id;
    if (t.m !== lastMode) {
      $("modeTxt").textContent = MODE_SHORT[t.m] || t.m;
      if (lastMode !== -1) { toast(MODE_NAMES[t.m] + " 모드"); buzz([15, 40, 15]); }
      lastMode = t.m;
    }
    const hasUS = (t.am & 2) !== 0;
    $("distWrap").style.display = hasUS ? "" : "none";
    if (hasUS) {
      const d = t.d || 0;
      $("distFill").style.width = Math.max(0, Math.min(100, (1 - Math.min(d, 100) / 100) * 100)) + "%";
      $("distFill").style.background = d < 15 ? "var(--bad)" : d < 35 ? "var(--warn)" : "var(--ok)";
      $("distTxt").textContent = d >= 400 ? "멀리" : d + "cm";
    }
    if (t.b) { $("battChip").style.display = ""; $("battTxt").textContent = (t.b / 1000).toFixed(1) + "V"; }
    $("app").classList.toggle("blocked", !!(t.f & 1));
    $("lightBtn").classList.toggle("on", !!t.lt);
    if (typeof t.cam === "string" && t.cam !== cam.host) {
      cam.host = t.cam; $("snapLink").href = cam.host ? `http://${cam.host}/capture` : "#";
      camImg.removeAttribute("src"); camApply();
    }
    if (cam.host && cam.led !== (t.lt ? 1 : 0)) { cam.led = t.lt ? 1 : 0; camSet("led=" + cam.led); }   // 전조등 = 카메라 플래시도
    $("lineView").classList.toggle("show", t.m === 2);
    for (let i = 0; i < 3; i++) $("l" + i).classList.toggle("on", !!(t.l & (4 >> i)));
    const own = $("owner");
    if (t.o === 1) { own.textContent = "조종기가 조종 중"; own.className = "chip ctrl"; }
    else if (t.o === 2) { own.textContent = "폰으로 조종 중"; own.className = "chip"; }
    else { own.textContent = "대기"; own.className = "chip"; }
  }
  setInterval(() => {
    if (!demo && ws && ws.readyState === 1 && performance.now() - st.lastTele > 800) setLink("wait", "차량 응답 없음");
  }, 300);

  renderSpeed(); applyLayout(); connect();
})();
</script>
</body>
</html>
)WEBAPP";
