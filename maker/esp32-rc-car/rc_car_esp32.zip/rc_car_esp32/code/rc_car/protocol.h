// ====================================================================
//  protocol.h  —  차량과 조종기가 주고받는 데이터 (두 폴더에 똑같은 파일)
// ====================================================================
#pragma once
#include <Arduino.h>

#define RC_MAGIC        0xA7
#define PKT_CONTROL     1     // 조종기 -> 차량
#define PKT_TELEMETRY   2     // 차량  -> 조종기

// 버튼 비트 (계속 누르고 있는 상태)
#define BTN_HORN        0x01  // 왼쪽 스틱 누름: 경적
#define BTN_BRAKE       0x02  // (예비)

typedef struct __attribute__((packed)) {
  uint8_t  magic;      // RC_MAGIC
  uint8_t  type;       // PKT_CONTROL
  uint8_t  carId;      // 같은 번호끼리만 통신
  uint8_t  seq;
  int16_t  throttle;   // -255(후진) ~ 255(전진)
  int16_t  steer;      // -255(왼쪽) ~ 255(오른쪽)
  uint8_t  buttons;    // BTN_* 비트
  uint8_t  speedLevel; // 1~3
  uint8_t  modeCount;  // A버튼 누른 횟수 (바뀌면 차량이 모드 전환)
  uint8_t  lightCount; // 오른쪽 스틱 누른 횟수 (바뀌면 전조등 켜기/끄기)
} ControlPacket;

typedef struct __attribute__((packed)) {
  uint8_t  magic;
  uint8_t  type;       // PKT_TELEMETRY
  uint8_t  carId;
  uint8_t  mode;       // 0 수동, 1 장애물 회피, 2 라인트레이싱
  uint16_t distanceCm; // 초음파 거리 (없으면 0)
  uint16_t batteryMv;  // 차량 배터리 (없으면 0)
  uint8_t  lineBits;   // 라인센서 L C R (bit2 bit1 bit0)
  uint8_t  flags;      // bit0: 장애물 때문에 전진 막힘, bit1: 배터리 충전 필요, bit2: 배터리 부족으로 정지
} TelemetryPacket;
