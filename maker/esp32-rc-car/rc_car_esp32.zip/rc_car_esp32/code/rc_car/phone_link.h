// ====================================================================
//  phone_link.h  —  스마트폰 웹앱 연결 (와이파이 AP + 웹서버 + 웹소켓)
//  차량이 "RC-CAR-<번호>" 와이파이를 열고, 폰 브라우저에 조종 화면을 보냅니다.
//  ESP32 코어에 들어 있는 esp_http_server 를 쓰므로 라이브러리 설치가 필요 없습니다.
// ====================================================================
#pragma once
#include <WiFi.h>
#include <DNSServer.h>
#include <esp_http_server.h>
#include "config.h"
#include "protocol.h"
#include "webapp.h"

namespace phone {

static httpd_handle_t server = nullptr;
static DNSServer      dns;

static portMUX_TYPE   mux = portMUX_INITIALIZER_UNLOCKED;
static ControlPacket  rx;
static volatile bool  rxNew = false;

static char           teleJson[200] = "{}";
static size_t         teleLen = 2;

// ---------------------------------------------------------- 웹 페이지
static esp_err_t pageHandler(httpd_req_t *req) {
  httpd_resp_set_type(req, "text/html; charset=utf-8");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  return httpd_resp_send(req, WEBAPP_HTML, HTTPD_RESP_USE_STRLEN);
}

// 모르는 주소는 전부 조종 화면으로 (폰이 와이파이에 붙으면 화면이 자동으로 뜨게)
static esp_err_t notFound(httpd_req_t *req, httpd_err_code_t err) {
  (void)err;
#if PHONE_CAPTIVE_PORTAL
  httpd_resp_set_status(req, "302 Found");
  httpd_resp_set_hdr(req, "Location", "http://192.168.4.1/");
  return httpd_resp_send(req, "", 0);
#else
  httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Not found");
  return ESP_FAIL;
#endif
}

// ---------------------------------------------------------- 웹소켓
// 폰 → 차량: "C,전진,방향,경적,속도,모드카운트,전조등카운트"
static void parse(const char *s) {
  int t, st, h, sp, mc, lc;
  if (sscanf(s, "C,%d,%d,%d,%d,%d,%d", &t, &st, &h, &sp, &mc, &lc) != 6) return;
  ControlPacket p = {};
  p.magic = RC_MAGIC; p.type = PKT_CONTROL; p.carId = CAR_ID;
  p.throttle = constrain(t, -255, 255);
  p.steer = constrain(st, -255, 255);
  p.buttons = h ? BTN_HORN : 0;
  p.speedLevel = constrain(sp, 1, 3);
  p.modeCount = (uint8_t)mc;
  p.lightCount = (uint8_t)lc;
  portENTER_CRITICAL(&mux);
  rx = p; rxNew = true;
  portEXIT_CRITICAL(&mux);
}

static esp_err_t wsHandler(httpd_req_t *req) {
  if (req->method == HTTP_GET) {               // 처음 연결(핸드셰이크)
    Serial.println("[PHONE] 폰 연결됨");
    return ESP_OK;
  }
  httpd_ws_frame_t f = {};
  f.type = HTTPD_WS_TYPE_TEXT;
  esp_err_t r = httpd_ws_recv_frame(req, &f, 0);   // 길이만 먼저
  if (r != ESP_OK) return r;
  if (f.len == 0) return ESP_OK;
  if (f.len > 96) return ESP_FAIL;                 // 이상한 데이터 → 연결 끊기
  uint8_t buf[100];
  f.payload = buf;
  r = httpd_ws_recv_frame(req, &f, f.len);
  if (r != ESP_OK) return r;
  buf[f.len] = 0;
  if (f.type == HTTPD_WS_TYPE_TEXT) parse((const char *)buf);
  return ESP_OK;
}

// 웹서버 작업 순서 안에서 모든 폰에 상태 보내기
static void teleWork(void *arg) {
  (void)arg;
  char json[sizeof(teleJson)];
  size_t n;
  portENTER_CRITICAL(&mux);
  n = teleLen; memcpy(json, teleJson, n);
  portEXIT_CRITICAL(&mux);

  size_t count = 8;
  int fds[8];
  if (httpd_get_client_list(server, &count, fds) != ESP_OK) return;
  httpd_ws_frame_t f = {};
  f.type = HTTPD_WS_TYPE_TEXT;
  f.final = true;
  f.payload = (uint8_t *)json;
  f.len = n;
  for (size_t i = 0; i < count; i++) {
    if (httpd_ws_get_fd_info(server, fds[i]) == HTTPD_WS_CLIENT_WEBSOCKET)
      httpd_ws_send_frame_async(server, fds[i], &f);
  }
}

// ---------------------------------------------------------- 외부에서 쓰는 함수
static String ssid() { return String(PHONE_SSID_PREFIX) + CAR_ID; }

static void begin() {
  WiFi.softAPConfig(IPAddress(192, 168, 4, 1), IPAddress(192, 168, 4, 1), IPAddress(255, 255, 255, 0));
  WiFi.softAP(ssid().c_str(), PHONE_PASSWORD, WIFI_CHANNEL, 0, 4);

  httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
  cfg.max_open_sockets = 7;
  cfg.lru_purge_enable = true;                  // 오래된 연결은 자동 정리
  cfg.stack_size = 6144;
  if (httpd_start(&server, &cfg) != ESP_OK) {
    Serial.println("[PHONE] 웹서버 시작 실패");
    return;
  }
  httpd_uri_t page = {};
  page.uri = "/"; page.method = HTTP_GET; page.handler = pageHandler;
  httpd_register_uri_handler(server, &page);

  httpd_uri_t ws = {};
  ws.uri = "/ws"; ws.method = HTTP_GET; ws.handler = wsHandler; ws.is_websocket = true;
  httpd_register_uri_handler(server, &ws);

  httpd_register_err_handler(server, HTTPD_404_NOT_FOUND, notFound);

#if PHONE_CAPTIVE_PORTAL
  dns.start(53, "*", WiFi.softAPIP());
#endif
  Serial.printf("[PHONE] 와이파이 \"%s\" (비밀번호 %s) → http://192.168.4.1\n", ssid().c_str(), PHONE_PASSWORD);
}

static void loop() {
#if PHONE_CAPTIVE_PORTAL
  dns.processNextRequest();
#endif
}

// 새 조종 값이 있으면 out 에 넣고 true
static bool take(ControlPacket &out) {
  if (!rxNew) return false;
  portENTER_CRITICAL(&mux);
  out = rx; rxNew = false;
  portEXIT_CRITICAL(&mux);
  return true;
}

static void sendTelemetry(const char *json) {
  if (!server) return;
  size_t n = strlen(json);
  if (n > sizeof(teleJson) - 1) n = sizeof(teleJson) - 1;
  portENTER_CRITICAL(&mux);
  memcpy(teleJson, json, n); teleLen = n;
  portEXIT_CRITICAL(&mux);
  httpd_queue_work(server, teleWork, nullptr);
}

}  // namespace phone
