// ====================================================================
//  ESP32 TT모터 4WD RC카 — 차량 코드
//  ESP-NOW로 조종기 신호를 받아 L298N으로 좌우 바퀴를 구동합니다.
//  스마트폰: 차량이 와이파이 "RC-CAR-번호"를 열고 브라우저 조종 화면 제공
//           (USE_PHONE, 앱 설치·라이브러리 설치 필요 없음)
//  모드: 0 수동 / 1 장애물 회피(초음파) / 2 라인트레이싱(IR 3개)
//  조종기 A버튼(또는 폰 모드 버튼)으로 모드 전환, 신호가 끊기면 자동 정지.
//  ESP32 Arduino core 2.x / 3.x 모두 컴파일됩니다.
// ====================================================================
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_arduino_version.h>
#include "config.h"
#include "protocol.h"
#if USE_PHONE
#include "phone_link.h"
#endif

// 함수보다 먼저 선언해야 하는 타입 (Arduino IDE 자동 프로토타입 때문)
enum Mode : uint8_t { MODE_MANUAL = 0, MODE_AVOID = 1, MODE_LINE = 2 };
enum AvoidState { AV_FORWARD, AV_BACK, AV_LOOK_L, AV_LOOK_R, AV_TURN };

// 조종 신호가 들어오는 곳 (0 = 조종기, 1 = 스마트폰)
struct Source {
  const char   *name;
  ControlPacket pkt;
  uint32_t      lastRx;      // 마지막으로 신호 받은 시각
  uint32_t      lastActive;  // 마지막으로 스틱을 움직인 시각
  bool          linked;
  uint8_t       modeCnt, lightCnt;
};
#define SRC_CTRL   0
#define SRC_PHONE  1

#ifndef LED_BUILTIN
#define LED_BUILTIN 2
#endif

// ---------------------------------------------------------- PWM (코어 2.x / 3.x 호환)
#define CH_LEFT   0
#define CH_RIGHT  1
#define CH_SERVO  4

static void pwmAttach(uint8_t pin, uint8_t ch, uint32_t freq, uint8_t bits) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttachChannel(pin, freq, bits, ch);
#else
  ledcSetup(ch, freq, bits);
  ledcAttachPin(pin, ch);
#endif
}
static void pwmWrite(uint8_t pin, uint8_t ch, uint32_t duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  (void)ch; ledcWrite(pin, duty);
#else
  (void)pin; ledcWrite(ch, duty);
#endif
}

// ---------------------------------------------------------- 상태
static Mode mode = MODE_MANUAL;

static volatile bool    rxNew = false;
static ControlPacket    rxBuf;
static portMUX_TYPE     rxMux = portMUX_INITIALIZER_UNLOCKED;

static Source src[2] = {
  {"조종기", {}, 0, 0, false, 0, 0},
  {"스마트폰", {}, 0, 0, false, 0, 0},
};
static int  owner = -1;                // 지금 운전하는 쪽 (-1 없음)
static ControlPacket ctrl = {};        // 운전하는 쪽의 마지막 신호
static bool lightsOn = false;

static int targetL = 0, targetR = 0;   // -255 ~ 255
static int curL = 0, curR = 0;

static uint16_t distanceCm = 0;        // 0 = 측정 안 함/없음
static uint8_t  lineBits = 0;
static uint16_t batteryMv = 0;
static bool     forwardBlocked = false;

static const uint8_t BCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// ---------------------------------------------------------- 부저 (논블로킹)
static uint8_t  beepsLeft = 0;
static uint32_t beepT = 0;
static bool     beepOn = false;
static void beep(uint8_t n) { beepsLeft = n; beepOn = false; beepT = 0; }

static void updateBuzzer(bool horn) {
#if USE_BUZZER
  uint32_t now = millis();
  if (horn) { digitalWrite(PIN_BUZZER, HIGH); return; }
  if (beepsLeft == 0) { digitalWrite(PIN_BUZZER, LOW); return; }
  if (now - beepT >= (beepOn ? 80u : 120u)) {
    beepT = now;
    beepOn = !beepOn;
    digitalWrite(PIN_BUZZER, beepOn ? HIGH : LOW);
    if (!beepOn) beepsLeft--;
  }
#else
  (void)horn;
#endif
}

// ---------------------------------------------------------- 모터
static void driveOne(int v, uint8_t pinA, uint8_t pinB, uint8_t pinEn, uint8_t ch, bool rev) {
  if (rev) v = -v;
  int mag = abs(v);
  if (mag < 4) {                         // 정지: 양쪽 LOW (자유 회전)
    digitalWrite(pinA, LOW); digitalWrite(pinB, LOW);
    pwmWrite(pinEn, ch, 0);
    return;
  }
  digitalWrite(pinA, v > 0 ? HIGH : LOW);
  digitalWrite(pinB, v > 0 ? LOW : HIGH);
  int duty = map(mag, 0, 255, MOTOR_MIN_PWM, 255);
  pwmWrite(pinEn, ch, constrain(duty, 0, 255));
}

static int rampTo(int cur, int target) {
  if (target > cur) return min(cur + RAMP_STEP, target);
  if (target < cur) return max(cur - RAMP_STEP, target);
  return cur;
}

static void updateMotors() {
  static uint32_t t = 0;
  if (millis() - t < 5) return;
  t = millis();
  // 방향이 바뀔 때는 0을 거쳐 가도록 (전류 튐 방지)
  curL = rampTo(curL, targetL);
  curR = rampTo(curR, targetR);
  driveOne(curL, PIN_IN1, PIN_IN2, PIN_ENA, CH_LEFT, LEFT_REVERSE);
  driveOne(curR, PIN_IN3, PIN_IN4, PIN_ENB, CH_RIGHT, RIGHT_REVERSE);
}

static void setDrive(int l, int r) {
  targetL = constrain(l, -255, 255);
  targetR = constrain(r, -255, 255);
}

// ---------------------------------------------------------- 서보
static void servoWrite(int deg) {
#if USE_SERVO_SCAN
  deg = constrain(deg, 0, 180);
  uint32_t us = map(deg, 0, 180, 500, 2400);
  pwmWrite(PIN_SERVO, CH_SERVO, (uint32_t)((us * 65535UL) / 20000UL));
#else
  (void)deg;
#endif
}

// ---------------------------------------------------------- 센서
static uint16_t measureCm() {
#if USE_ULTRASONIC
  digitalWrite(PIN_TRIG, LOW);  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  unsigned long us = pulseIn(PIN_ECHO, HIGH, 25000UL);   // 최대 약 4m
  if (us == 0) return 400;                                  // 응답 없음 = 앞이 비어 있음
  return (uint16_t)constrain(us / 58UL, 2UL, 400UL);
#else
  return 0;
#endif
}

static void updateSensors() {
  uint32_t now = millis();
#if USE_ULTRASONIC
  static uint32_t tU = 0;
  if (now - tU >= 60) { tU = now; distanceCm = measureCm(); }
#endif
#if USE_LINE_SENSOR
  lineBits = ((digitalRead(PIN_LINE_L) == LINE_BLACK) << 2) |
             ((digitalRead(PIN_LINE_C) == LINE_BLACK) << 1) |
             ((digitalRead(PIN_LINE_R) == LINE_BLACK) << 0);
#endif
#if USE_BATTERY_MON
  static uint32_t tB = 0;
  if (now - tB >= 500) { tB = now; batteryMv = (uint16_t)(analogReadMilliVolts(PIN_BATTERY) * BATTERY_DIVIDER); }
#endif
  (void)now;
}

// ---------------------------------------------------------- 모드 전환
static bool modeAvailable(Mode m) {
  if (m == MODE_MANUAL) return true;
  if (m == MODE_AVOID)  return USE_ULTRASONIC;
  if (m == MODE_LINE)   return USE_LINE_SENSOR;
  return false;
}

static void nextMode() {
  Mode m = mode;
  do { m = (Mode)((m + 1) % 3); } while (!modeAvailable(m));
  mode = m;
  servoWrite(SERVO_CENTER);
  beep(mode + 1);                      // 수동 1번, 회피 2번, 라인 3번 삐
  Serial.printf("[MODE] %s\n", mode == MODE_MANUAL ? "수동" : mode == MODE_AVOID ? "장애물 회피" : "라인트레이싱");
}

// ---------------------------------------------------------- 주행 로직
static float speedScale(uint8_t lv) {
  return lv >= 3 ? SPEED_L3 : lv == 2 ? SPEED_L2 : SPEED_L1;
}

static void runManual() {
  int t = ctrl.throttle;
  int s = ctrl.steer;
  bool wasBlocked = forwardBlocked;
  forwardBlocked = false;
#if USE_ULTRASONIC
  if (SAFETY_STOP_CM > 0 && t > 0 && distanceCm > 0 && distanceCm < SAFETY_STOP_CM) {
    t = 0;                               // 전진만 막고 후진·제자리 회전은 허용
    forwardBlocked = true;
    if (!wasBlocked) beep(1);
  }
#endif
  float k = speedScale(ctrl.speedLevel);
  int l = t + s;
  int r = t - s;
  int m = max(abs(l), abs(r));
  if (m > 255) { l = l * 255 / m; r = r * 255 / m; }
  setDrive((int)(l * k), (int)(r * k));
}

// 장애물 회피 상태머신
static AvoidState av = AV_FORWARD;
static uint32_t avT = 0;
static int avTurnDir = 1;
static uint16_t distL = 0, distR = 0;

static void runAvoid() {
  uint32_t now = millis();
  switch (av) {
    case AV_FORWARD:
      setDrive(AUTO_SPEED, AUTO_SPEED);
      if (distanceCm > 0 && distanceCm < AVOID_CM) { av = AV_BACK; avT = now; beep(1); }
      break;
    case AV_BACK:
      setDrive(-AUTO_SPEED, -AUTO_SPEED);
      if (now - avT > 350) {
        setDrive(0, 0);
#if USE_SERVO_SCAN
        servoWrite(SERVO_LEFT); av = AV_LOOK_L; avT = now;
#else
        avTurnDir = -avTurnDir; av = AV_TURN; avT = now;   // 서보가 없으면 번갈아 회전
#endif
      }
      break;
    case AV_LOOK_L:
      setDrive(0, 0);
      if (now - avT > 400) { distL = measureCm(); servoWrite(SERVO_RIGHT); av = AV_LOOK_R; avT = now; }
      break;
    case AV_LOOK_R:
      setDrive(0, 0);
      if (now - avT > 500) {
        distR = measureCm(); servoWrite(SERVO_CENTER);
        avTurnDir = (distL >= distR) ? -1 : 1;              // 더 넓은 쪽으로
        av = AV_TURN; avT = now;
      }
      break;
    case AV_TURN:
      // avTurnDir -1 = 왼쪽(반시계), 1 = 오른쪽
      setDrive(avTurnDir * AUTO_TURN, -avTurnDir * AUTO_TURN);
      if (now - avT > 380) { av = AV_FORWARD; }
      break;
  }
}

static int lineLastDir = 0;   // -1 왼쪽, 1 오른쪽
static void runLine() {
  bool L = lineBits & 0b100, C = lineBits & 0b010, R = lineBits & 0b001;
  if (L && C && R)      setDrive(LINE_SPEED, LINE_SPEED);            // 교차로: 직진
  else if (C && !L && !R) setDrive(LINE_SPEED, LINE_SPEED);
  else if (L)           { setDrive(-LINE_TURN / 3, LINE_TURN); lineLastDir = -1; }
  else if (R)           { setDrive(LINE_TURN, -LINE_TURN / 3); lineLastDir = 1; }
  else {                                                           // 선을 놓침: 마지막 방향으로 찾기
    if (lineLastDir < 0) setDrive(-LINE_TURN / 2, LINE_TURN / 2 + 30);
    else if (lineLastDir > 0) setDrive(LINE_TURN / 2 + 30, -LINE_TURN / 2);
    else setDrive(0, 0);
  }
}

// ---------------------------------------------------------- ESP-NOW
#if ESP_ARDUINO_VERSION_MAJOR >= 3
static void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  (void)info;
#else
static void onRecv(const uint8_t *mac, const uint8_t *data, int len) {
  (void)mac;
#endif
  if (len != sizeof(ControlPacket)) return;
  const ControlPacket *p = (const ControlPacket *)data;
  if (p->magic != RC_MAGIC || p->type != PKT_CONTROL || p->carId != CAR_ID) return;
  portENTER_CRITICAL_ISR(&rxMux);
  memcpy(&rxBuf, data, sizeof(ControlPacket));
  rxNew = true;
  portEXIT_CRITICAL_ISR(&rxMux);
}

static void radioBegin() {
#if USE_PHONE
  // 와이파이 공유기(AP)와 ESP-NOW를 같은 채널에서 함께 사용
  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect();
  phone::begin();
#else
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);
#endif
  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW 초기화 실패 → 재부팅");
    delay(1000); ESP.restart();
  }
  esp_now_register_recv_cb(onRecv);
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BCAST, 6);
  peer.channel = WIFI_CHANNEL;
#if USE_PHONE
  peer.ifidx = WIFI_IF_AP;
#else
  peer.ifidx = WIFI_IF_STA;
#endif
  peer.encrypt = false;
  esp_now_add_peer(&peer);
}

static void sendTelemetry() {
  static uint32_t t = 0;
  if (millis() - t < 100) return;
  t = millis();
  TelemetryPacket tp = {};
  tp.magic = RC_MAGIC; tp.type = PKT_TELEMETRY; tp.carId = CAR_ID;
  tp.mode = mode; tp.distanceCm = distanceCm; tp.batteryMv = batteryMv;
  tp.lineBits = lineBits; tp.flags = forwardBlocked ? 1 : 0;
  esp_now_send(BCAST, (const uint8_t *)&tp, sizeof(tp));
#if USE_PHONE
  uint8_t avail = 1 | (USE_ULTRASONIC ? 2 : 0) | (USE_LINE_SENSOR ? 4 : 0);
  char json[180];
  snprintf(json, sizeof(json),
           "{\"id\":%d,\"m\":%d,\"d\":%u,\"b\":%u,\"l\":%u,\"f\":%u,\"am\":%u,\"o\":%d,\"lt\":%d,\"cam\":\"%s\"}",
           CAR_ID, mode, distanceCm, batteryMv, lineBits, tp.flags, avail, owner + 1, lightsOn ? 1 : 0,
           USE_CAMERA ? CAM_IP : "");
  phone::sendTelemetry(json);
#endif
}

// ---------------------------------------------------------- 조종 신호 처리 (조종기·폰 공통)
static void handlePacket(int i, const ControlPacket &p, uint32_t now) {
  Source &s = src[i];
  bool fresh = !s.linked;
  s.pkt = p;
  s.lastRx = now;
  if (p.throttle != 0 || p.steer != 0) s.lastActive = now;
  if (fresh) {
    // 처음(또는 끊겼다가 다시) 연결: 카운터만 맞추고 모드·전조등은 그대로
    s.modeCnt = p.modeCount;
    s.lightCnt = p.lightCount;
    s.linked = true;
    beep(2);
    Serial.printf("[LINK] %s 연결됨\n", s.name);
    return;
  }
  if (p.modeCount != s.modeCnt) { s.modeCnt = p.modeCount; nextMode(); }
  if (p.lightCount != s.lightCnt) {
    s.lightCnt = p.lightCount;
    lightsOn = !lightsOn;
#if USE_HEADLIGHT
    digitalWrite(PIN_HEADLIGHT, lightsOn ? HIGH : LOW);
#endif
  }
}

// 둘 다 연결됐을 때: 지금 운전하는 쪽이 OWNER_IDLE_MS 동안 스틱을 놓고 있으면
// 스틱을 움직이는 다른 쪽이 운전을 넘겨받음
static void updateOwner(uint32_t now) {
  for (int i = 0; i < 2; i++) {
    if (src[i].linked && now - src[i].lastRx >= FAILSAFE_MS) {
      src[i].linked = false;
      Serial.printf("[LINK] %s 신호 끊김\n", src[i].name);
      if (owner == i) { owner = -1; beep(3); }
    }
  }
  auto busy = [&](int i) { return src[i].linked && now - src[i].lastActive < OWNER_IDLE_MS; };
  for (int i = 0; i < 2; i++) {
    if (i != owner && busy(i) && (owner < 0 || !busy(owner))) {
      owner = i;
      Serial.printf("[LINK] %s(으)로 운전\n", src[i].name);
    }
  }
  if (owner < 0) {
    for (int i = 0; i < 2; i++) if (src[i].linked) { owner = i; break; }
  }
}

// ---------------------------------------------------------- setup / loop
void setup() {
  Serial.begin(115200);
  pinMode(PIN_IN1, OUTPUT); pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_IN3, OUTPUT); pinMode(PIN_IN4, OUTPUT);
  digitalWrite(PIN_IN1, LOW); digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, LOW); digitalWrite(PIN_IN4, LOW);
  pwmAttach(PIN_ENA, CH_LEFT, PWM_FREQ, 8);
  pwmAttach(PIN_ENB, CH_RIGHT, PWM_FREQ, 8);
  pwmWrite(PIN_ENA, CH_LEFT, 0);
  pwmWrite(PIN_ENB, CH_RIGHT, 0);

#if USE_ULTRASONIC
  pinMode(PIN_TRIG, OUTPUT); pinMode(PIN_ECHO, INPUT);
#endif
#if USE_SERVO_SCAN
  pwmAttach(PIN_SERVO, CH_SERVO, 50, 16);
  servoWrite(SERVO_CENTER);
#endif
#if USE_LINE_SENSOR
  pinMode(PIN_LINE_L, INPUT); pinMode(PIN_LINE_C, INPUT); pinMode(PIN_LINE_R, INPUT);
#endif
#if USE_BUZZER
  pinMode(PIN_BUZZER, OUTPUT); digitalWrite(PIN_BUZZER, LOW);
#endif
#if USE_HEADLIGHT
  pinMode(PIN_HEADLIGHT, OUTPUT); digitalWrite(PIN_HEADLIGHT, LOW);
#endif
  pinMode(LED_BUILTIN, OUTPUT);

  radioBegin();
  Serial.printf("\nRC카 준비 완료  CAR_ID=%d  채널=%d  MAC=%s\n", CAR_ID, WIFI_CHANNEL, WiFi.macAddress().c_str());
  beep(1);
}

void loop() {
  uint32_t now = millis();

  // 조종기(ESP-NOW) 신호
  if (rxNew) {
    ControlPacket p;
    portENTER_CRITICAL(&rxMux);
    p = rxBuf;
    rxNew = false;
    portEXIT_CRITICAL(&rxMux);
    handlePacket(SRC_CTRL, p, now);
  }
#if USE_PHONE
  // 스마트폰(웹소켓) 신호
  phone::loop();
  {
    ControlPacket p;
    if (phone::take(p)) handlePacket(SRC_PHONE, p, now);
  }
#endif

  updateOwner(now);
  bool linked = owner >= 0;
  if (linked) ctrl = src[owner].pkt;
  bool horn = (src[0].linked && (src[0].pkt.buttons & BTN_HORN)) ||
              (src[1].linked && (src[1].pkt.buttons & BTN_HORN));

  updateSensors();

  if (!linked) {
    setDrive(0, 0);                      // 신호 끊김 → 정지 (모든 모드)
    av = AV_FORWARD;
  } else {
    switch (mode) {
      case MODE_MANUAL: runManual(); break;
      case MODE_AVOID:  runAvoid();  break;
      case MODE_LINE:   runLine();   break;
    }
  }

  updateMotors();
  updateBuzzer(horn);
  digitalWrite(LED_BUILTIN, linked ? HIGH : ((now / 250) % 2));
  sendTelemetry();
}
