"""차량별 와이파이 연결 QR 라벨 (A4 PDF) 만들기
    pip install "qrcode[pil]"
    python make_qr_labels.py            → 1~10번
    python make_qr_labels.py 1 20       → 1~20번 (10개씩 한 장)
비밀번호·이름 앞글자를 바꿨다면 아래 두 값도 config.h 와 같게 바꾸세요."""
import os, sys
import qrcode
from PIL import Image, ImageDraw, ImageFont

SSID_PREFIX = "RC-CAR-"
PASSWORD = "12345678"
URL = "http://192.168.4.1"

DPI = 200
MM = DPI / 25.4
PAGE = (int(210 * MM), int(297 * MM))
COLS, ROWS = 2, 5
MARGIN_X, MARGIN_Y = 10 * MM, 12 * MM
GAP = 4 * MM


def font(size, bold=False):
    cands = ["/usr/share/fonts/opentype/noto/NotoSansCJK-%s.ttc" % ("Bold" if bold else "Regular"),
             "C:/Windows/Fonts/malgun%s.ttf" % ("bd" if bold else ""),
             "/System/Library/Fonts/AppleSDGothicNeo.ttc"]
    for p in cands:
        if os.path.exists(p):
            return ImageFont.truetype(p, int(size), index=1 if p.endswith("CJK-Regular.ttc") or p.endswith("CJK-Bold.ttc") else 0)
    return ImageFont.load_default()


def qr(data, px):
    q = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, border=1, box_size=10)
    q.add_data(data); q.make(fit=True)
    return q.make_image(fill_color="black", back_color="white").convert("RGB").resize((px, px), Image.NEAREST)


def label(draw, page, x, y, w, h, car_id):
    ssid = f"{SSID_PREFIX}{car_id}"
    draw.rounded_rectangle([x, y, x + w, y + h], radius=3 * MM, outline=(160, 160, 160), width=2)
    draw.rectangle([x + 2, y + 2, x + w - 2, y + 11 * MM], fill=(240, 138, 36))
    draw.text((x + 5 * MM, y + 1.6 * MM), ssid, font=font(7 * MM, True), fill="white")
    draw.text((x + w - 5 * MM, y + 3.0 * MM), f"비밀번호 {PASSWORD}", font=font(3.6 * MM, True), fill="white", anchor="ra")
    qs = int(min(h - 27 * MM, (w - 15 * MM) / 2))
    cy = y + 13 * MM
    for i, (data, cap) in enumerate([
        (f"WIFI:T:WPA;S:{ssid};P:{PASSWORD};;", "① 와이파이 연결"),
        (URL, "② 조종 화면 열기"),
    ]):
        qx = int(x + 5 * MM + i * (qs + 5 * MM))
        page.paste(qr(data, qs), (qx, int(cy)))
        draw.text((qx + qs / 2, cy + qs + 1.2 * MM), cap, font=font(3.4 * MM, True), fill="black", anchor="ma")
    draw.text((x + w / 2, y + h - 4.2 * MM), f"화면이 안 뜨면 브라우저에 {URL.replace('http://', '')}",
              font=font(2.9 * MM), fill=(90, 90, 90), anchor="ma")


def main():
    a = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    b = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    ids = list(range(a, b + 1))
    pages = []
    w = (PAGE[0] - 2 * MARGIN_X - (COLS - 1) * GAP) / COLS
    h = (PAGE[1] - 2 * MARGIN_Y - (ROWS - 1) * GAP) / ROWS
    for start in range(0, len(ids), COLS * ROWS):
        page = Image.new("RGB", PAGE, "white")
        d = ImageDraw.Draw(page)
        for k, cid in enumerate(ids[start:start + COLS * ROWS]):
            r, c = divmod(k, COLS)
            label(d, page, MARGIN_X + c * (w + GAP), MARGIN_Y + r * (h + GAP), w, h, cid)
        pages.append(page)
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "qr_labels.pdf")
    pages[0].save(out, save_all=True, append_images=pages[1:], resolution=DPI)
    print("저장:", out)


if __name__ == "__main__":
    main()
