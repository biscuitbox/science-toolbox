"""web/index.html 을 고친 뒤 실행하면 ../webapp.h 를 다시 만듭니다.
    python make_webapp_h.py
(파이썬이 없으면 webapp.h 안의 HTML을 직접 고쳐도 됩니다.)"""
import os
here = os.path.dirname(os.path.abspath(__file__))
html = open(os.path.join(here, "index.html"), encoding="utf-8").read()
assert ')WEBAPP"' not in html
out = ("// 자동 생성 파일 — web/index.html 을 고친 뒤 web/make_webapp_h.py 실행\n"
       "#pragma once\n"
       "static const char WEBAPP_HTML[] = R\"WEBAPP(" + html + ")WEBAPP\";\n")
open(os.path.join(here, "..", "webapp.h"), "w", encoding="utf-8").write(out)
print("webapp.h 생성:", len(html.encode()), "bytes")
