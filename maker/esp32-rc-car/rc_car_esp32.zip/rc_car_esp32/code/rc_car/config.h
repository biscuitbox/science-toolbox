// ====================================================================
//  config.h  —  차량 설정 (핀 번호, 모듈 사용 여부, 속도 값)
//  달아 둔 모듈만 1로 바꾸면 해당 기능이 켜집니다.
// ====================================================================
#pragma once

// ---------- 페어링 ----------
// 조종기 config.h 의 CAR_ID 와 같은 번호여야 합니다. (반 전체가 쓸 때 차마다 다르게)
#define CAR_ID          1
#define WIFI_CHANNEL    1      // 1~13, 조종기와 같게 (여러 대를 쓸 땐 1, 6, 11 처럼 나눠도 됨)

// ---------- 스마트폰 조종 ----------
// 차량이 와이파이 "RC-CAR-1" 을 엽니다. 폰에서 연결 → 조종 화면이 뜸 (안 뜨면 http://192.168.4.1)
#define USE_PHONE            1
#define PHONE_SSID_PREFIX    "RC-CAR-"     // 와이파이 이름 = 이 글자 + CAR_ID
#define PHONE_PASSWORD       "12345678"    // 8자 이상
#define PHONE_CAPTIVE_PORTAL 1             // 1: 와이파이 연결하면 조종 화면이 자동으로 뜸
#define OWNER_IDLE_MS        1000          // 조종기·폰 둘 다 켜져 있을 때, 운전 중인 쪽이
                                           // 이 시간(ms) 동안 스틱을 놓으면 다른 쪽이 넘겨받음

// ---------- 카메라 (ESP32-CAM, 선택) ----------
// ESP32-CAM 이 이 차량 와이파이에 접속해서 영상을 보내면, 폰 조종 화면 뒤에 실시간 영상이 깔립니다.
#define USE_CAMERA           1
#define CAM_IP               "192.168.4.200"   // rc_cam/config.h 의 CAM_IP 와 같게

// ---------- 확장 모듈 ON/OFF ----------
#define USE_ULTRASONIC  1      // HC-SR04 (앞범퍼)          → 장애물 회피 모드, 충돌 방지
#define USE_SERVO_SCAN  0      // SG90 위에 초음파 올렸을 때 → 회피할 때 좌우를 둘러봄
#define USE_LINE_SENSOR 0      // TCRT5000 3개 (라인 브래킷) → 라인트레이싱 모드
#define USE_BUZZER      1      // 능동 부저                → 경적, 모드 알림
#define USE_HEADLIGHT   1      // 범퍼 5mm LED 2개          → 오른쪽 스틱 누르면 켜기/끄기
#define USE_BATTERY_MON 0      // 전압 분배 저항으로 배터리 측정

// ---------- L298N 모터 드라이버 ----------
// ENA, ENB 점퍼는 반드시 빼고 ESP32 핀에 연결하세요.
#define PIN_ENA   25   // 왼쪽 바퀴 속도 (PWM)
#define PIN_IN1   26
#define PIN_IN2   27
#define PIN_IN3   33
#define PIN_IN4   32
#define PIN_ENB   13   // 오른쪽 바퀴 속도 (PWM)

// 앞으로 밀었는데 한쪽이 거꾸로 돌면 그쪽을 1로 (선을 바꿔 끼워도 됨)
#define LEFT_REVERSE    0
#define RIGHT_REVERSE   0

// ---------- 확장 모듈 핀 ----------
#define PIN_TRIG        18
#define PIN_ECHO        19     // HC-SR04 ECHO는 5V! 저항 1k+2k 분배로 3.3V로 낮춰 연결
#define PIN_SERVO       23
#define PIN_LINE_L      34     // 34·35·39 는 입력 전용 핀
#define PIN_LINE_C      35
#define PIN_LINE_R      39
#define PIN_BUZZER      4
#define PIN_HEADLIGHT   17     // LED 마다 220Ω 저항
#define PIN_BATTERY     36     // 배터리+ ─ 100kΩ ─ (36) ─ 33kΩ ─ GND
#define BATTERY_DIVIDER ((100.0f + 33.0f) / 33.0f)

// ---------- 주행 값 ----------
#define PWM_FREQ        5000
#define MOTOR_MIN_PWM   90     // 이 값 아래로는 모터가 안 돌아서 바로 이 값부터 시작
#define RAMP_STEP       12     // 5ms마다 바뀌는 최대 PWM (클수록 반응 빠름, 작을수록 부드러움)
#define FAILSAFE_MS     500    // 이 시간 동안 신호가 없으면 정지

// 수동 주행 속도 단계 (B버튼으로 1→2→3)
#define SPEED_L1        0.45f
#define SPEED_L2        0.70f
#define SPEED_L3        1.00f

// 초음파
#define SAFETY_STOP_CM  15     // 수동 주행 중 이 거리 안에 물체가 있으면 전진만 막음 (0이면 끔)
#define AVOID_CM        25     // 회피 모드에서 피하기 시작하는 거리
#define AUTO_SPEED      170    // 회피 모드 전진 속도
#define AUTO_TURN       190    // 회피 모드 회전 속도

// 라인트레이싱
#define LINE_BLACK      HIGH   // 검은 선 위에서 센서 출력 (대부분 HIGH, 반대면 LOW)
#define LINE_SPEED      150
#define LINE_TURN       180

// 서보 (회피 모드 둘러보기)
#define SERVO_CENTER    90
#define SERVO_LEFT      155
#define SERVO_RIGHT     25
