# 교탁 도우미 (ClassHelper)

2.8인치 ESP32-S3 터치 보드(LCDwiki **ES3C28P**)로 만드는 교탁용 기기입니다.
지뢰찾기 · 소음 신호등 · PPT 프레젠터 · 날씨 탁상시계를 첫 화면에서 골라 씁니다.

**자세한 설명서(사진 대신 단계별 안내, 문제 해결 포함)**
https://biscuitbox.github.io/science-toolbox/maker/classhelper/

## 폴더

| 폴더 | 내용 |
|------|------|
| `code/ClassHelper/` | 아두이노 스케치. **`ClassHelper.ino`** 를 아두이노 IDE로 엽니다 |
| `models/` | 케이스 3D 출력 파일: `01_뒤판_back_shell.stl`, `02_앞베젤_front_bezel.stl` |

## 빠른 순서 (자세한 건 설명서)

1. 아두이노 IDE 2 설치
2. 파일 → 기본 설정 → 추가 보드 관리자 URL에
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. 보드 매니저에서 **esp32 by Espressif Systems 3.3.x** 설치
4. 라이브러리 매니저에서 **LovyanGFX** 설치
5. `code/ClassHelper/ClassHelper.ino` 열기 → `config.h` 맨 위에서 이름·블루투스 이름 바꾸기
6. 도구(Tools) 메뉴를 아래처럼 맞추고 업로드

| 항목 | 값 |
|------|-----|
| Board | ESP32S3 Dev Module |
| Flash Size | 16MB (128Mb) |
| Flash Mode | QIO 80MHz |
| PSRAM | OPI PSRAM |
| Partition Scheme | **Custom** (같은 폴더의 `partitions.csv` 사용) |
| USB CDC On Boot | Enabled |

> `ClassHelper` 폴더 이름과 `ClassHelper.ino` 파일 이름은 같아야 합니다. 폴더 이름을 바꾸지 마세요.
> 배터리(선택)는 **리튬폴리머 803035 3.7V 800mAh**, 단자는 **JST PH1.25mm 2핀**이어야 합니다 (PH2.0은 안 맞음). 꽂기 전에 보드의 +/− 표시와 빨강(+)·검정(−) 선 방향이 맞는지 꼭 확인하세요.
> 케이스는 **M3×12 렌치볼트(육각 홈 볼트) 4개**로 조립합니다. 뒤판 바깥 네 귀퉁이 구멍에 넣어 앞 베젤 기둥에 조여요.
> 케이스를 만들 때 보드 뒷면 **BOOT 버튼이 눌리지 않게** 해 주세요. 눌린 채로 켜지면 화면이 켜지지 않습니다.

## 외부 자료

- 화면: [LovyanGFX](https://github.com/lovyan03/LovyanGFX) (FreeBSD) — 한글 글꼴 efont 포함
- 날씨·미세먼지: [Open-Meteo](https://open-meteo.com/) (CC BY 4.0, 비상업 무료)
- 위치: [beaconDB](https://beacondb.net/), [ip-api.com](https://ip-api.com/) (비상업 무료)
