// =====================================================================
//  net.h  —  🌐 와이파이로 시간·날씨·미세먼지 받아 오기 + 위치 찾기
//
//  와이파이는 [설정 → 와이파이] 화면에서 넣습니다 (3개까지 저장, 보드 안에 기억).
//  켤 때 한 번 + 30분마다 한 번 잠깐 와이파이에 붙어서
//    ① 인터넷 시간으로 시계를 맞추고 (NTP · 막혀 있으면 날씨 서버의 시각으로)
//    ② 지금 있는 곳을 찾고 (위치가 '자동'일 때)
//         - 먼저 주변 와이파이 목록으로 (beaconDB — 무료·공개, 열쇠 필요 없음)
//         - 안 되면 인터넷 주소(IP)로 (ip-api.com — 대략, 통신사 위치가 나올 수 있음)
//    ③ 그곳의 날씨·온도·습도, 미세먼지(PM10)·초미세먼지(PM2.5)를 받고 (Open-Meteo)
//    ④ 곧바로 와이파이를 끕니다 (블루투스 프레젠터와 배터리를 위해).
//
//  - 이 일은 '뒤에서 따로' 돌아서, 연결이 오래 걸려도 화면·터치·시계가 멈추지 않아요.
//  - 인터넷이 끊기면: 시계는 보드 안 시계로 그대로 가고, 날씨는 마지막 값이 남아요.
//    실패하면 2분 → 4분 → … → 10분 간격으로 다시 해 봅니다.
//  - 프레젠터 화면에 있는 동안은 새로 연결하지 않아요 (블루투스 키 입력이 끊기지 않게).
//  - 위치는 하루에 한 번, 또는 다른 와이파이에 붙었을 때 다시 찾습니다.
//  - 미세먼지는 모델로 계산한 값이라 에어코리아 측정소 값과 조금 다를 수 있어요.
//
//  📁 이 파일은 고치지 않아도 됩니다.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include "config.h"
#include "clock_time.h"

// 예전 config.h 를 써도 되도록 기본값
#ifndef CLOCK_WIFI
  #define CLOCK_WIFI 0
#endif
#ifndef WIFI_SSID
  #define WIFI_SSID ""
  #define WIFI_PASS ""
#endif
#ifndef WIFI_SSID2
  #define WIFI_SSID2 ""
  #define WIFI_PASS2 ""
#endif
#ifndef WEATHER_ON
  #define WEATHER_ON 1
#endif
#ifndef WEATHER_LAT
  #define WEATHER_LAT 35.1796
  #define WEATHER_LON 129.0756
#endif
#ifndef NET_REFRESH_MIN
  #define NET_REFRESH_MIN 30
#endif

#if CLOCK_WIFI
  #include <WiFi.h>
  #include <HTTPClient.h>
  #include <WiFiClientSecure.h>
  #include "esp_sntp.h"
#endif

namespace Net {

enum State : uint8_t { N_OFF, N_WAIT, N_BUSY, N_OK, N_FAIL };

struct Weather {
  bool     has;          // 한 번이라도 받았는지
  float    temp;         // 기온 (℃)
  int      hum;          // 습도 % (-1 = 모름)
  int      code;         // 날씨 번호 (WMO, -1 = 모름)
  bool     day;          // 낮이면 true (해 / 달 그림)
  float    pm10, pm25;   // 미세먼지·초미세먼지 ㎍/㎥ (-1 = 모름)
  uint32_t atMs;         // 받은 시각 (millis)
};
struct Cred     { char ssid[33]; char pass[65]; };
struct ScanItem { char ssid[33]; int8_t rssi; bool open; };
struct Place    { const char* name; float lat, lon; };

// 위치를 직접 고를 때의 도시 (시청 근처 좌표). 자동으로 찾은 곳의 이름도 가장 가까운 도시로 붙여요.
static const int CITY_N = 17;
static const Place CITIES[CITY_N] = {
  {"서울", 37.5665f, 126.9780f}, {"인천", 37.4563f, 126.7052f}, {"수원", 37.2636f, 127.0286f},
  {"춘천", 37.8813f, 127.7298f}, {"강릉", 37.7519f, 128.8761f}, {"청주", 36.6424f, 127.4890f},
  {"대전", 36.3504f, 127.3845f}, {"천안", 36.8151f, 127.1139f}, {"전주", 35.8242f, 127.1480f},
  {"광주", 35.1595f, 126.8526f}, {"목포", 34.8118f, 126.3922f}, {"대구", 35.8714f, 128.6014f},
  {"포항", 36.0190f, 129.3435f}, {"울산", 35.5384f, 129.3114f}, {"부산", 35.1796f, 129.0756f},
  {"창원", 35.2280f, 128.6811f}, {"제주", 33.4996f, 126.5312f},
};
static const int MAX_CRED = 3;

// ------------------------------ 상태 ------------------------------
static volatile State    state     = N_OFF;
static volatile uint32_t ver       = 0;      // 뭔가 바뀔 때마다 +1 (화면 다시 그리기용)
static const char* volatile msg    = "";     // 마지막 실패 이유 (화면에 보임)
static volatile uint32_t lastOkMs  = 0;
static volatile bool     allowed   = true;   // false = 지금은 연결하지 말기 (프레젠터 중)
static volatile bool     wantNow   = false;  // '지금 연결' · '인터넷 시간' 버튼
static volatile bool     wantScan  = false;  // 설정 화면의 '주변 와이파이 찾기'
static Weather           wx        = {false, 0, -1, -1, true, -1, -1, 0};
static portMUX_TYPE      mux       = portMUX_INITIALIZER_UNLOCKED;

static Cred              creds[MAX_CRED];
static volatile uint8_t  nCred     = 0;
static char              lastSsid[33] = "";  // 마지막으로 붙은 와이파이
static ScanItem          scanList[8];
static volatile uint8_t  scanN     = 0;
static volatile uint8_t  scanState = 0;      // 0 아직 / 1 찾는 중 / 2 끝

static volatile uint8_t  locMode   = 0;      // 0 = 자동, 1~17 = CITIES 번호+1
static volatile bool     autoFound = false;  // 자동으로 찾은 위치가 있는지
static float             autoLat = 0, autoLon = 0;
static uint8_t           autoSrc   = 0;      // 1 = 주변 와이파이로, 2 = 인터넷 주소로
static char              autoSsid[33] = "";  // 그때 붙어 있던 와이파이
static uint32_t          autoAtMs  = 0;      // 0 = 이번에 켠 뒤로 아직 안 찾음

static void bump() { ver = ver + 1; }
static void setMsg(const char* m) { msg = m; bump(); }

static int  credCount()  { return nCred; }
static bool ready()      { return CLOCK_WIFI && nCred > 0; }   // 와이파이를 하나라도 넣었는지
static bool weatherOn()  { return ready() && WEATHER_ON; }
static bool busy()       { return state == N_BUSY; }
static const char* lastMsg() { return msg; }
static uint32_t refreshMs() {
  int m = NET_REFRESH_MIN;
  if (m < 10) m = 10;
  if (m > 120) m = 120;
  return (uint32_t)m * 60000UL;
}
// 최근에 성공했는지 (못 받은 지 오래면 false → 화면 점이 회색)
static bool fresh() { return lastOkMs != 0 && millis() - lastOkMs < refreshMs() * 2 + 60000UL; }

static Weather weather() {                       // 다른 작업이 쓰는 중일 수 있어 통째로 복사
  portENTER_CRITICAL(&mux);
  Weather w = wx;
  portEXIT_CRITICAL(&mux);
  return w;
}
static void requestNow()     { wantNow = true; }
static void requestScan()    { scanState = 1; wantScan = true; bump(); }
static void poll(bool allow) { allowed = allow; }   // loop() 에서 계속 부름

// ------------------------------ 저장 (보드 안) ------------------------------
static void saveCreds() {
  Cred c[MAX_CRED]; int n;
  portENTER_CRITICAL(&mux);
  n = nCred; memcpy(c, creds, sizeof(creds));
  portEXIT_CRITICAL(&mux);
  Preferences p; p.begin("netcfg", false);
  p.putUChar("n", n);
  for (int i = 0; i < MAX_CRED; i++) {
    char ks[4] = {'s', (char)('0' + i), 0}, kp[4] = {'p', (char)('0' + i), 0};
    if (i < n) { p.putString(ks, c[i].ssid); p.putString(kp, c[i].pass); }
    else       { p.remove(ks); p.remove(kp); }
  }
  p.end();
}
static void saveLoc() {
  Preferences p; p.begin("netcfg", false);
  p.putUChar("loc", locMode);
  p.putBool("af", autoFound);
  p.putFloat("alat", autoLat);
  p.putFloat("alon", autoLon);
  p.putUChar("asrc", autoSrc);
  p.end();
}

static bool getCred(int i, Cred& out) {
  bool ok = false;
  portENTER_CRITICAL(&mux);
  if (i >= 0 && i < nCred) { out = creds[i]; ok = true; }
  portEXIT_CRITICAL(&mux);
  return ok;
}
static bool isSaved(const char* ssid) {
  bool f = false;
  portENTER_CRITICAL(&mux);
  for (int i = 0; i < nCred; i++) if (strcmp(creds[i].ssid, ssid) == 0) f = true;
  portEXIT_CRITICAL(&mux);
  return f;
}
// 새로 넣은 와이파이는 맨 위로. 같은 이름이 있으면 비밀번호만 바꿈. 4개째면 맨 아래 것이 빠짐.
static void addCred(const char* ssid, const char* pass) {
  if (!ssid || !ssid[0]) return;
  Cred c = {};
  strlcpy(c.ssid, ssid, sizeof(c.ssid));
  strlcpy(c.pass, pass ? pass : "", sizeof(c.pass));
  portENTER_CRITICAL(&mux);
  Cred t[MAX_CRED]; int k = 0;
  t[k++] = c;
  for (int i = 0; i < nCred && k < MAX_CRED; i++) if (strcmp(creds[i].ssid, ssid) != 0) t[k++] = creds[i];
  memcpy(creds, t, sizeof(Cred) * k);
  nCred = k;
  portEXIT_CRITICAL(&mux);
  saveCreds();
  wantNow = true;
  bump();
}
static void removeCred(int idx) {
  portENTER_CRITICAL(&mux);
  if (idx >= 0 && idx < nCred) {
    for (int i = idx; i < nCred - 1; i++) creds[i] = creds[i + 1];
    nCred = nCred - 1;
  }
  portEXIT_CRITICAL(&mux);
  saveCreds();
  bump();
}

static int  scanCount() { return scanN; }
static bool getScan(int i, ScanItem& out) {
  bool ok = false;
  portENTER_CRITICAL(&mux);
  if (i >= 0 && i < scanN) { out = scanList[i]; ok = true; }
  portEXIT_CRITICAL(&mux);
  return ok;
}

// ------------------------------ 위치 ------------------------------
static void currentLoc(float& lat, float& lon) {
  uint8_t m = locMode;
  if (m >= 1 && m <= CITY_N) { lat = CITIES[m - 1].lat; lon = CITIES[m - 1].lon; return; }
  if (autoFound)             { lat = autoLat; lon = autoLon; return; }
  lat = WEATHER_LAT; lon = WEATHER_LON;          // 아직 못 찾았으면 config.h 의 기본 위치
}
static int nearestCity(float lat, float lon, float& km) {
  int best = 0; float bd = 1e9f;
  for (int i = 0; i < CITY_N; i++) {
    float dy = (lat - CITIES[i].lat) * 111.0f;
    float dx = (lon - CITIES[i].lon) * 111.0f * cosf(lat * DEG_TO_RAD);
    float d = sqrtf(dx * dx + dy * dy);
    if (d < bd) { bd = d; best = i; }
  }
  km = bd;
  return best;
}
// 위치 이름: "부산" / "부산 근처" (shortName = true 면 '근처' 없이)
static void placeName(char* out, size_t n, bool shortName = false) {
  uint8_t m = locMode;
  if (m >= 1 && m <= CITY_N) { strlcpy(out, CITIES[m - 1].name, n); return; }
  float lat, lon, km;
  currentLoc(lat, lon);
  int i = nearestCity(lat, lon, km);
  if (km < 30 || (shortName && km < 100)) strlcpy(out, CITIES[i].name, n);
  else if (km < 100) snprintf(out, n, "%s 근처", CITIES[i].name);
  else strlcpy(out, "현재 위치", n);
}
// 설정 화면에 보일 설명
static const char* locDetail() {
  if (locMode >= 1) return "직접 고른 곳";
  if (!autoFound)   return busy() ? "찾는 중..." : "아직 못 찾음 · 기본 위치";
  return autoSrc == 1 ? "주변 와이파이로 찾음" : "인터넷 주소로 찾음(대략)";
}
static void setLocMode(uint8_t m) {
  if (m > CITY_N) m = 0;
  locMode = m;
  if (m == 0) autoAtMs = 0;                      // 자동 → 바로 다시 찾기
  portENTER_CRITICAL(&mux);
  wx.has = false;                                // 다른 곳 날씨가 남아 있지 않게
  portEXIT_CRITICAL(&mux);
  saveLoc();
  wantNow = true;
  bump();
}

#if CLOCK_WIFI
// =====================================================================
//                      뒤에서 도는 부분 (따로 된 작업)
// =====================================================================
static volatile bool ntpDone = false;
static void onNtp(struct timeval*) { ntpDone = true; }
static time_t   httpTime   = 0;                  // 날씨 서버가 알려 준 시각 (NTP 가 막혔을 때 씀)
static uint32_t httpTimeMs = 0;

struct Ap { uint8_t mac[6]; int8_t rssi; };      // 위치 찾기에 쓰는 주변 공유기
static Ap       aps[12];
static int      nAps = 0;
static ScanItem seen[16];                        // 이번 검색에서 본 와이파이 (이름별 가장 센 것)
static int      nSeen = 0;

// "Thu, 26 Nov 2026 07:17:00 GMT" → 1970년부터 센 초
static time_t parseHttpDate(const char* s) {
  const char* c = strchr(s, ',');
  if (!c) return 0;
  char mon[4] = {0};
  int d, y, h, mi, se;
  if (sscanf(c + 1, " %d %3s %d %d:%d:%d", &d, mon, &y, &h, &mi, &se) != 6) return 0;
  static const char* M = "JanFebMarAprMayJunJulAugSepOctNovDec";
  const char* p = strstr(M, mon);
  if (!p) return 0;
  int m = (int)(p - M) / 3 + 1;
  y -= (m <= 2);                                 // 날짜 → 일 수 (그레고리력)
  long era = (y >= 0 ? y : y - 399) / 400;
  long yoe = y - era * 400;
  long doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  long days = era * 146097L + doe - 719468L;
  return (time_t)days * 86400 + h * 3600 + mi * 60 + se;
}

// 주변 와이파이 찾기 → seen(이름 목록) · aps(위치용) · scanList(설정 화면용)
static void doScan() {
  int n = WiFi.scanNetworks(false, true);
  if (n < 0) n = 0;
  nAps = 0; nSeen = 0;
  for (int i = 0; i < n; i++) {
    String s = WiFi.SSID(i);
    int r = WiFi.RSSI(i);
    if (nAps < 12 && !s.endsWith("_nomap")) {    // '_nomap' 은 위치 찾기에 쓰지 말라는 표시
      memcpy(aps[nAps].mac, WiFi.BSSID(i), 6);
      aps[nAps].rssi = (int8_t)r;
      nAps++;
    }
    if (!s.length()) continue;                   // 숨긴 와이파이
    int k = -1;
    for (int j = 0; j < nSeen; j++) if (strcmp(seen[j].ssid, s.c_str()) == 0) k = j;
    if (k >= 0) { if (r > seen[k].rssi) seen[k].rssi = (int8_t)r; continue; }
    if (nSeen >= 16) continue;
    strlcpy(seen[nSeen].ssid, s.c_str(), sizeof(seen[0].ssid));
    seen[nSeen].rssi = (int8_t)r;
    seen[nSeen].open = (WiFi.encryptionType(i) == WIFI_AUTH_OPEN);
    nSeen++;
  }
  WiFi.scanDelete();
  for (int i = 1; i < nSeen; i++)                // 센 것부터
    for (int j = i; j > 0 && seen[j].rssi > seen[j - 1].rssi; j--) { ScanItem t = seen[j]; seen[j] = seen[j - 1]; seen[j - 1] = t; }
  portENTER_CRITICAL(&mux);
  int m = nSeen < 8 ? nSeen : 8;
  memcpy(scanList, seen, sizeof(ScanItem) * m);
  scanN = m;
  portEXIT_CRITICAL(&mux);
  scanState = 2;
  wantScan = false;
  bump();
  Serial.printf("[인터넷] 와이파이 %d개 찾음\n", nSeen);
}

static bool connectTo(const char* ssid, const char* pass, uint32_t waitMs) {
  if (!ssid || !ssid[0]) return false;
  Serial.printf("[인터넷] 와이파이 '%s' 연결 중\n", ssid);
  WiFi.begin(ssid, pass);
  uint32_t t0 = millis();
  wl_status_t s = WL_IDLE_STATUS;
  while (millis() - t0 < waitMs) {
    s = WiFi.status();
    if (s == WL_CONNECTED) {
      Serial.printf("[인터넷] 연결됨 (%s)\n", WiFi.localIP().toString().c_str());
      return true;
    }
    if (s == WL_CONNECT_FAILED && millis() - t0 > 3000) break;
    vTaskDelay(pdMS_TO_TICKS(200));
  }
  setMsg(s == WL_NO_SSID_AVAIL   ? "와이파이를 못 찾았어요" :
         s == WL_CONNECT_FAILED  ? "와이파이 비밀번호 확인" : "와이파이 연결 안 됨");
  Serial.printf("[인터넷] '%s' 연결 실패 (상태 %d)\n", ssid, (int)s);
  WiFi.disconnect();
  vTaskDelay(pdMS_TO_TICKS(300));
  return false;
}

// 저장된 와이파이 중 주변에 보이는 것을 신호 센 순서로, 안 보이는 것(숨긴 와이파이)은 맨 뒤에
static bool connectBest() {
  Cred c[MAX_CRED]; int n;
  portENTER_CRITICAL(&mux);
  n = nCred; memcpy(c, creds, sizeof(creds));
  portEXIT_CRITICAL(&mux);
  int order[MAX_CRED], rs[MAX_CRED];
  bool anySeen = false;
  for (int i = 0; i < n; i++) {
    order[i] = i; rs[i] = -127;
    for (int j = 0; j < nSeen; j++) if (strcmp(seen[j].ssid, c[i].ssid) == 0) rs[i] = seen[j].rssi;
    if (rs[i] > -127) anySeen = true;
  }
  for (int i = 1; i < n; i++)
    for (int j = i; j > 0 && rs[order[j]] > rs[order[j - 1]]; j--) { int t = order[j]; order[j] = order[j - 1]; order[j - 1] = t; }
  for (int k = 0; k < n; k++) {
    int i = order[k];
    if (connectTo(c[i].ssid, c[i].pass, rs[i] > -127 ? 15000 : 8000)) {
      portENTER_CRITICAL(&mux);
      strlcpy(lastSsid, c[i].ssid, sizeof(lastSsid));
      portEXIT_CRITICAL(&mux);
      return true;
    }
  }
  if (!anySeen && n > 0) setMsg("저장된 와이파이가 안 보여요");
  return false;
}

// 주소로 받아 오기: http 먼저, 안 되면 https
static bool httpGet(const char* hostPath, String& body) {
  static const char* KEYS[] = {"Date"};
  for (int i = 0; i < 2; i++) {
    WiFiClient       plain;
    WiFiClientSecure secure;
    HTTPClient       http;
    String url = String(i == 0 ? "http://" : "https://") + hostPath;
    bool begun;
    if (i == 0) begun = http.begin(plain, url);
    else { secure.setInsecure(); begun = http.begin(secure, url); }   // 날씨라서 인증서 검사는 생략
    if (!begun) continue;
    http.setConnectTimeout(8000);
    http.setTimeout(8000);
    http.collectHeaders(KEYS, 1);
    int code = http.GET();
    if (code == 200) {
      body = http.getString();
      String d = http.header("Date");
      if (d.length()) {
        time_t t = parseHttpDate(d.c_str());
        if (t > 1735657200) { httpTime = t; httpTimeMs = millis(); }
      }
      http.end();
      if (body.length() > 0) return true;
      continue;
    }
    Serial.printf("[인터넷] %s → %d\n", url.c_str(), code);
    http.end();
  }
  return false;
}

// 받은 글(JSON)에서 "key": 숫자 찾기. section 을 주면 "section":{ ... } 안에서만. 없거나 null 이면 false
static bool findNum(const String& b, const char* section, const char* key, float& out) {
  int s = 0, e = -1;
  if (section) {
    s = b.indexOf(String("\"") + section + "\":");
    if (s < 0) return false;
    e = b.indexOf('}', s);
  }
  String k = String("\"") + key + "\":";
  int p = b.indexOf(k, s);
  if (p < 0 || (e > 0 && p > e)) return false;
  const char* c = b.c_str() + p + k.length();
  while (*c == ' ') c++;
  if (!(*c == '-' || *c == '.' || (*c >= '0' && *c <= '9'))) return false;
  out = atof(c);
  return true;
}

// ① 주변 와이파이로 위치 찾기 (beaconDB). 공유기 주소(MAC)와 신호 세기만 보냄
static bool locateWifi(float& lat, float& lon, float& acc) {
  if (nAps < 2) return false;
  String body;
  body.reserve(48 + nAps * 64);
  body = "{\"considerIp\":true,\"wifiAccessPoints\":[";
  char e[80];
  for (int i = 0; i < nAps; i++) {
    const uint8_t* m = aps[i].mac;
    snprintf(e, sizeof(e), "%s{\"macAddress\":\"%02x:%02x:%02x:%02x:%02x:%02x\",\"signalStrength\":%d}",
             i ? "," : "", m[0], m[1], m[2], m[3], m[4], m[5], aps[i].rssi);
    body += e;
  }
  body += "]}";
  WiFiClientSecure sc;
  sc.setInsecure();
  HTTPClient http;
  if (!http.begin(sc, "https://api.beacondb.net/v1/geolocate")) return false;
  http.setConnectTimeout(8000);
  http.setTimeout(8000);
  http.setUserAgent("ClassHelper/1.0 (ESP32 classroom clock)");
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  String r = (code == 200) ? http.getString() : String();
  http.end();
  if (code != 200) { Serial.printf("[위치] beaconDB → %d\n", code); return false; }
  if (!findNum(r, nullptr, "lat", lat) || !findNum(r, nullptr, "lng", lon)) return false;
  if (!findNum(r, nullptr, "accuracy", acc)) acc = 99999;
  return lat > -90 && lat < 90 && lon > -180 && lon < 180;
}
// ② 인터넷 주소로 대략 찾기 (ip-api.com, 비상업 무료)
static bool locateIp(float& lat, float& lon) {
  String b;
  if (!httpGet("ip-api.com/json/?fields=status,lat,lon", b)) return false;
  if (b.indexOf("success") < 0) return false;
  return findNum(b, nullptr, "lat", lat) && findNum(b, nullptr, "lon", lon);
}
static void maybeLocate() {
  if (locMode != 0) return;
  char ss[33];
  portENTER_CRITICAL(&mux); strlcpy(ss, lastSsid, sizeof(ss)); portEXIT_CRITICAL(&mux);
  bool need = !autoFound || autoAtMs == 0 || strcmp(ss, autoSsid) != 0 || millis() - autoAtMs > 24UL * 3600 * 1000;
  if (!need) return;
  float wl = 0, wo = 0, acc = 0, il = 0, io = 0;
  bool wOk = locateWifi(wl, wo, acc);
  bool good = wOk && acc <= 20000;               // 20km 안쪽으로 맞으면 와이파이 위치를 믿음
  uint8_t src = 1;
  float lat = wl, lon = wo;
  if (!good) {
    if (locateIp(il, io)) { lat = il; lon = io; src = 2; good = true; }
    else if (wOk)         { src = 2; good = true; }   // 와이파이 쪽이 IP 로 대략 답한 것
  }
  if (!good) { Serial.println("[위치] 못 찾음 → 지난 위치/기본 위치 사용"); return; }
  autoLat = lat; autoLon = lon; autoSrc = src; autoFound = true;
  autoAtMs = millis(); if (!autoAtMs) autoAtMs = 1;
  strlcpy(autoSsid, ss, sizeof(autoSsid));
  saveLoc();
  bump();
  char nm[24]; placeName(nm, sizeof(nm));
  Serial.printf("[위치] %.4f, %.4f (%s, 정확도 %.0fm) → %s\n", lat, lon, src == 1 ? "와이파이" : "IP", acc, nm);
}

static bool fetchWeather() {
  float la, lo;
  currentLoc(la, lo);
  char path[240];
  String b;
  snprintf(path, sizeof(path),
           "api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
           "&current=temperature_2m,relative_humidity_2m,weather_code,is_day&timezone=Asia%%2FSeoul",
           (double)la, (double)lo);
  if (!httpGet(path, b)) return false;
  float t, h, c, d;
  if (!findNum(b, "current", "temperature_2m", t)) { Serial.println("[날씨] 기온을 못 읽음"); return false; }
  Weather w = weather();
  if (!w.has) { w.pm10 = -1; w.pm25 = -1; }
  w.temp = t;
  w.hum  = findNum(b, "current", "relative_humidity_2m", h) ? (int)(h + 0.5f) : -1;
  w.code = findNum(b, "current", "weather_code", c) ? (int)c : -1;
  w.day  = findNum(b, "current", "is_day", d) ? (d > 0.5f) : true;

  snprintf(path, sizeof(path),
           "air-quality-api.open-meteo.com/v1/air-quality?latitude=%.4f&longitude=%.4f"
           "&current=pm10,pm2_5&timezone=Asia%%2FSeoul",
           (double)la, (double)lo);
  if (httpGet(path, b)) {
    float p10, p25;
    w.pm10 = findNum(b, "current", "pm10", p10) ? p10 : -1;
    w.pm25 = findNum(b, "current", "pm2_5", p25) ? p25 : -1;
  }                                              // 미세먼지만 실패하면 지난 값을 그대로 둠
  w.has = true;
  w.atMs = millis();
  portENTER_CRITICAL(&mux);
  wx = w;
  portEXIT_CRITICAL(&mux);
  Serial.printf("[날씨] %.1f℃ 습도 %d%% 날씨 %d · 미세 %.0f 초미세 %.0f\n", w.temp, w.hum, w.code, w.pm10, w.pm25);
  return true;
}

// 날씨를 안 쓸 때 NTP 가 막혀 있으면: 아주 작은 요청으로 서버 시각만 얻기
static void fetchTimeOnly() {
  String b;
  httpGet("api.open-meteo.com/v1/forecast?latitude=35.18&longitude=129.08&current=is_day", b);
}

// 설정 화면의 '주변 와이파이 찾기'만
static void scanOnly() {
  WiFi.mode(WIFI_STA);
  doScan();
  WiFi.mode(WIFI_OFF);
}

// 한 번: 찾기 → 연결 → 시간 → 위치 → 날씨 → 와이파이 끄기
static bool runOnce() {
  state = N_BUSY; msg = ""; bump();
  WiFi.persistent(false);                        // 와이파이 정보를 매번 저장공간에 쓰지 않게
  WiFi.mode(WIFI_STA);
  doScan();
  bool conn = connectBest();
  bool timeOk = false, wxOk = !weatherOn();
  if (conn) {
    msg = "";
    httpTime = 0;
    ntpDone = false;
    configTzTime("KST-9", "time.kriss.re.kr", "pool.ntp.org", "time.google.com");
    uint32_t t0 = millis();
    while (!ntpDone && millis() - t0 < 8000) vTaskDelay(pdMS_TO_TICKS(100));
    timeOk = ntpDone;
    if (timeOk) Serial.println("[인터넷] 인터넷 시간(NTP)으로 맞춤");
    if (allowed) {
      if (weatherOn()) { maybeLocate(); wxOk = fetchWeather(); }
      else if (!timeOk) fetchTimeOnly();
    }
    if (!timeOk && httpTime) {                   // 학교망에서 NTP 가 막혔을 때
      ClockTime::setSystem(httpTime + (time_t)((millis() - httpTimeMs) / 1000));
      timeOk = true;
      Serial.println("[인터넷] 날씨 서버 시각으로 맞춤");
    }
    if (timeOk) ClockTime::markSynced();         // 시계 모듈·저장공간에 적기는 loop() 쪽에서
    if (!timeOk && !wxOk) { msg = "인터넷 응답 없음"; Serial.println("[인터넷] 연결은 됐는데 인터넷이 안 됨 (로그인 화면이 뜨는 와이파이?)"); }
    else if (!wxOk)       msg = "날씨 서버 응답 없음";
  }
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);                           // 다 받으면 바로 끔
  bool ok = conn && timeOk && wxOk;
  if (ok) lastOkMs = millis();
  state = ok ? N_OK : N_FAIL;
  bump();
  return ok;
}

static void task(void*) {
  uint32_t nextAt = millis() + 3000;             // 켜고 3초 뒤 처음
  uint8_t  fails = 0;
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(300));
    if (wantScan) { scanOnly(); continue; }
    if (nCred == 0) { if (state != N_OFF) { state = N_OFF; bump(); } wantNow = false; continue; }
    if (state == N_OFF) { state = N_WAIT; bump(); }
    if (!allowed) continue;
    if (wantNow) { wantNow = false; fails = 0; }
    else if ((int32_t)(millis() - nextAt) < 0) continue;
    if (runOnce()) { fails = 0; nextAt = millis() + refreshMs(); }
    else { if (fails < 5) fails++; nextAt = millis() + fails * 120000UL; }   // 2·4·6·8·10분 뒤 다시
  }
}
#endif

// setup() 에서 한 번: 저장해 둔 와이파이·위치를 읽고, 뒤에서 도는 작업 시작
static void begin() {
  Preferences p;
  bool has = false;
  if (p.begin("netcfg", true)) {
    has = p.isKey("n");
    int n = p.getUChar("n", 0);
    if (n > MAX_CRED) n = MAX_CRED;
    int k = 0;
    for (int i = 0; i < n; i++) {
      char ks[4] = {'s', (char)('0' + i), 0}, kp[4] = {'p', (char)('0' + i), 0};
      Cred c = {};
      p.getString(ks, c.ssid, sizeof(c.ssid));
      p.getString(kp, c.pass, sizeof(c.pass));
      if (c.ssid[0]) creds[k++] = c;
    }
    nCred = k;
    locMode   = p.getUChar("loc", 0);
    autoFound = p.getBool("af", false);
    autoLat   = p.getFloat("alat", 0);
    autoLon   = p.getFloat("alon", 0);
    autoSrc   = p.getUChar("asrc", 0);
    p.end();
  }
  if (locMode > CITY_N) locMode = 0;
  if (!has) {                                    // 처음 켤 때만: config.h 에 적어 둔 와이파이를 옮겨 옴
    if (strlen(WIFI_SSID2) > 0) addCred(WIFI_SSID2, WIFI_PASS2);
    if (strlen(WIFI_SSID)  > 0) addCred(WIFI_SSID,  WIFI_PASS);
    saveCreds();
  }
  state = nCred ? N_WAIT : N_OFF;
#if CLOCK_WIFI
  sntp_set_time_sync_notification_cb(onNtp);
  xTaskCreatePinnedToCore(task, "net", 12288, nullptr, 1, nullptr, 1);
#endif
}

}  // namespace Net
