// =====================================================================
//  config.h  —  보드 핀 & 기기 설정
//  보드: LCDwiki ES3C28P (ESP32-S3 N16R8, 2.8" IPS 240x320,
//        ILI9341V + FT6336G 정전식 터치 + ES8311 코덱 + FM8002E 앰프)
//
//  ✏️ 선생님이 바꿔도 되는 곳은 맨 위 "기기 이름" 세 줄과 시계 와이파이 세 줄뿐입니다.
//     나머지는 보드 배선이라 건드리지 마세요.
// =====================================================================
#pragma once

// ---------- ✏️ 기기 이름 — 마음대로 바꿔도 돼요 (큰따옴표 " " 안만) ----------
// 글자가 길면 화면에서 저절로 작게 써요. 한글 OK, 이모지는 화면에 안 나와요.
#define DEVICE_TITLE   "교탁 도우미"        // 첫 화면 큰 제목 — 한글 12자까지 (8자 안쪽이 크게 보여요)
#define DEVICE_OWNER   "우리 반"         // 첫 화면·시계에 작게 — 한글 18자까지 (반 이름, 선생님 이름 등)
#define BT_NAME        "ClassHelper-01"     // 블루투스 이름 — 영어·숫자·- 로 16자까지, 옆 사람과 겹치지 않게!
// 글자 수 검사 (한글 1자 = 3칸, 영어·숫자·띄어쓰기 1자 = 1칸으로 셈)
static_assert(sizeof(DEVICE_TITLE) <= 37, "config.h: DEVICE_TITLE 은 한글 12자(영어 36자)까지만 써 주세요");
static_assert(sizeof(DEVICE_OWNER) <= 55, "config.h: DEVICE_OWNER 는 한글 18자(영어 54자)까지만 써 주세요");
// 사용설명서 웹 주소 — 설정 → [도움말] 화면의 QR 코드가 이 주소로 열려요
#define HELP_URL       "https://biscuitbox.github.io/science-toolbox/maker/classhelper/#usage"
static_assert(sizeof(BT_NAME) <= 17, "config.h: BT_NAME 은 영어·숫자 16자까지만 써 주세요 (길면 PC 목록에 안 보여요)");

// ---------- ✏️ 탁상시계: 인터넷으로 시간·날씨 받기 ----------
// 와이파이와 날씨 위치는 이제 보드 화면에서 넣어요: 첫 화면 → [설정 · 점검] → [와이파이]
//   · 와이파이 3개까지 저장 (학교 · 집 · 휴대폰 핫스팟 등) → 주변에 있는 것 중 신호 센 것에 붙음
//   · 날씨 위치: [자동] (주변 와이파이 · 인터넷 주소로 찾음) 또는 도시 고르기
// 켤 때 + 30분마다 잠깐 연결해서 시간을 맞추고 날씨·미세먼지를 받은 뒤 바로 끊습니다.
// 인터넷이 끊겨도 시계는 보드 안 시계로 계속 가요 (날씨만 마지막 값으로 남음).
//  · 2.4GHz 와이파이만 됩니다 (5GHz 전용은 안 보여요).
//  · 로그인 화면이 뜨는 와이파이, 아이디를 넣는 와이파이(학교 업무망 등)는 안 됩니다.
#define CLOCK_WIFI     1                 // 0 = 인터넷 기능을 아예 빼기

// (안 써도 됨) 처음 켤 때 한 번만 보드에 옮겨 담을 와이파이. 그 뒤로는 화면에서 바꿔요.
#define WIFI_SSID      ""
#define WIFI_PASS      ""
#define WIFI_SSID2     ""
#define WIFI_PASS2     ""

#define WEATHER_ON       1               // 0 = 날씨는 안 보이고 시간만 맞춤
// 기본 위치: [자동]인데 아직 위치를 못 찾았을 때 쓰는 곳 (위도, 경도). 지금은 부산시청.
#define WEATHER_LAT      35.1796
#define WEATHER_LON      129.0756
#define NET_REFRESH_MIN  30              // 몇 분마다 새로 받을지 (10 ~ 120)

// ---------- LCD (SPI, ILI9341V) ----------
#define PIN_LCD_SCK    12
#define PIN_LCD_MOSI   11
#define PIN_LCD_MISO   13
#define PIN_LCD_CS     10
#define PIN_LCD_DC     46
#define PIN_LCD_BL     45     // HIGH = 백라이트 켜짐
// LCD 리셋은 ESP32 EN(리셋)과 공용이라 따로 핀이 없음

// 화면이 좌우로 뒤집혀(거울처럼) 보이면 0 -> 6 으로 바꾸세요.
#define LCD_OFFSET_ROTATION  0

// ---------- 터치 (I2C, FT6336G) ----------
#define PIN_I2C_SDA    16     // 터치·코덱·확장 I2C 공용 버스
#define PIN_I2C_SCL    15
#define PIN_TP_INT     17
#define PIN_TP_RST     18

// 터치 위치가 화면과 어긋날 때만 바꾸세요 (설정 → 점검 화면에서 확인)
#define TOUCH_SWAP_XY   0
#define TOUCH_MIRROR_X  1
#define TOUCH_MIRROR_Y  1
#define TOUCH_Y_OFFSET  0     // 손가락이 살짝 아래를 누른다면 -3 ~ -5

// ---------- 오디오 (I2S, ES8311 + FM8002E) ----------
#define PIN_I2S_MCLK    4
#define PIN_I2S_BCLK    5
#define PIN_I2S_LRCK    7
#define PIN_I2S_DOUT    8     // ESP32 -> 코덱 (스피커)
#define PIN_I2S_DIN     6     // 코덱 -> ESP32 (마이크)
#define PIN_AMP_EN      1
#define AMP_ON_LEVEL    LOW   // 제조사 문서: Low = 앰프 켜짐. 소리가 안 나면 HIGH 로 바꿔 보세요.
#define AUDIO_SAMPLE_RATE 22050

// ---------- 기타 ----------
#define PIN_WS2812     42     // 보드 뒷면 RGB LED (1개 내장)
#define PIN_BAT_ADC     9     // 배터리 전압 (1/2 분압) — 뒷면 1.25mm 2핀에 3.7V 리튬 배터리
#define BAT_DIVIDER   2.0f
#define PIN_BOOT_BTN    0     // 뒷면 BOOT 버튼 (앱마다 쓰임이 다름)
// ✏️ BOOT 버튼을 쓸지: 0 = 안 씀 (케이스 안에 숨김 — 실수로 눌려도 절전·깨어남이 일어나지 않음)
//                     1 = 씀 (짧게 = 프레젠터 다음 장·시계 모양 / 1초 길게 = 절전 / 절전에서 깨우기)
#define USE_BOOT_BUTTON 0

// ---------- 공통 조작 ----------
#define LONG_PRESS_MS  380    // 길게 누르기 판정 시간 (지뢰찾기 깃발)
#define HOME_HOLD_MS   700    // 왼쪽 위 🏠 를 이만큼 누르고 있으면 첫 화면으로
