// =====================================================================
//  wifi_setup.h  —  설정 → [와이파이] 화면 (인터넷 · 날씨 위치)
//
//   ① 저장된 와이파이 3개까지 보기 / 지우기 (지우기는 두 번 눌러야 지워짐)
//   ② [+ 주변 와이파이 찾아서 추가] → 목록에서 고르기 → 화면 키보드로 비밀번호
//      · 목록에 없는 숨긴 와이파이는 [직접 입력] 으로 이름부터 씀
//   ③ 날씨 위치: [자동] (주변 와이파이 / 인터넷 주소로 찾음) 또는 도시 17곳 중 고르기
//   ④ [지금 연결해 보기] 로 바로 시험
//
//  저장된 와이파이 중 주변에 보이는 것을 신호가 센 순서로 붙습니다 (net.h).
//  📁 이 파일은 고치지 않아도 됩니다.
// =====================================================================
#pragma once
#include "helper.h"
#include "sfx.h"
#include "net.h"

namespace NetSetup {

enum : uint8_t { P_MAIN, P_SCAN, P_KEY, P_LOC };
static uint8_t  page = P_MAIN;
static uint32_t lastVer = 0;
static uint8_t  lastScanState = 0;
static int      delArmed = -1;                // 지우기를 한 번 누른 줄
static uint32_t delAt = 0;

static const lgfx::IFont* const F14_12[] = {&fonts::efontKR_14, &fonts::efontKR_12};
static const lgfx::IFont* const F16_14[] = {&fonts::efontKR_16_b, &fonts::efontKR_14};

// ------------------------------ 키보드 ------------------------------
static char    kbuf[65];
static int     klen = 0;
static uint8_t layer = 0;                     // 0 소문자 / 1 대문자·기호 / 2 기호
static bool    forSsid = false;               // true = 와이파이 이름을 쓰는 중
static char    pickSsid[33] = "";
static uint8_t keyFrom = P_SCAN;              // 키보드 [취소] 로 돌아갈 곳

enum : uint8_t { K_SHIFT = 1, K_BACK = 2, K_LAYER = 3, K_OK = 4 };
struct KeyDef { int16_t x, y, w, h; uint8_t code; };
static KeyDef keys[44];
static int    nKeys = 0;
static int    pressedKey = -1;

static const char* ROWS[3][4] = {
  {"1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"},
  {"!@#$%^&*()", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"},
  {"1234567890", "-_=+[]{}\\|", ";:'\",.<>/", "?`~.-_@"},
};

static void addKey(int x, int y, int w, int h, uint8_t code) {
  if (nKeys < 44) keys[nKeys++] = {(int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h, code};
}
static void buildKeys() {
  nKeys = 0;
  for (int r = 0; r < 4; r++) {
    const char* s = ROWS[layer][r];
    int len = strlen(s), y = 92 + r * 44;
    int x0 = (r == 2) ? 12 : (r == 3 ? 36 : 0);
    if (r == 3) addKey(0, y, 36, 40, K_SHIFT);
    for (int i = 0; i < len; i++) addKey(x0 + i * 24, y, 24, 40, (uint8_t)s[i]);
    if (r == 3) addKey(204, y, 36, 40, K_BACK);
  }
  addKey(0,   270, 58,  46, K_LAYER);
  addKey(58,  270, 116, 46, ' ');
  addKey(174, 270, 66,  46, K_OK);
}

static void drawKey(int i, bool down) {
  if (i < 0 || i >= nKeys) return;
  const KeyDef& k = keys[i];
  bool special = (k.code < 32 || k.code == ' ');
  uint16_t face = down ? C_ACCENT : (k.code == K_OK ? C_ACCENT : (special ? 0xBDF7 : C_WHITE));
  uint16_t ink  = (down || k.code == K_OK) ? C_WHITE : C_BLACK;
  lcd.fillRect(k.x, k.y, k.w, k.h, C_GRAY);
  lcd.fillRoundRect(k.x + 1, k.y + 1, k.w - 2, k.h - 2, 5, face);
  int cx = k.x + k.w / 2, cy = k.y + k.h / 2;
  switch (k.code) {
    case K_SHIFT: text(layer == 0 ? "대문자" : (layer == 1 ? "소문자" : "abc"), cx, cy + 1,
                       layer == 2 ? (const lgfx::IFont*)&fonts::FreeSansBold9pt7b : &fonts::efontKR_12, ink); break;
    case K_BACK:  text("지움", cx, cy + 1, &fonts::efontKR_12, ink); break;
    case K_LAYER: text(layer == 2 ? "abc" : "#+=", cx, cy, &fonts::FreeSansBold9pt7b, ink); break;
    case ' ':     text("띄어쓰기", cx, cy + 1, &fonts::efontKR_14, ink); break;
    case K_OK:    text("확인", cx, cy + 1, &fonts::efontKR_16_b, ink); break;
    default: { char s[2] = {(char)k.code, 0}; text(s, cx, cy, &fonts::FreeSansBold9pt7b, ink); }
  }
}
static void drawKeys() {
  lcd.startWrite();
  lcd.fillRect(0, 90, 240, 230, C_GRAY);
  for (int i = 0; i < nKeys; i++) drawKey(i, false);
  lcd.endWrite();
}
static int keyAt(int x, int y) {
  for (int i = 0; i < nKeys; i++) if (inside(x, y, keys[i].x, keys[i].y, keys[i].w, keys[i].h)) return i;
  return -1;
}

static void drawField() {
  lcd.startWrite();
  lcd.fillRect(0, 30, 240, 60, C_GRAY);
  char lab[64];
  if (forSsid) strcpy(lab, "와이파이 이름 (대소문자 그대로)");
  else snprintf(lab, sizeof(lab), "%s 의 비밀번호", pickSsid);
  fitText(lab, 120, 41, 228, C_BAR, F14_12, 2);
  lcd.fillRoundRect(4, 52, 232, 34, 6, C_WHITE);
  lcd.setFont(&fonts::FreeMonoBold9pt7b);
  lcd.setTextSize(1);
  const char* show = kbuf;
  while (*show && lcd.textWidth(show) > 196) show++;   // 길면 끝부분만
  if (show != kbuf) text("<", 8, 69, &fonts::FreeMonoBold9pt7b, C_DARK, textdatum_t::middle_left);
  text(show, 18, 69, &fonts::FreeMonoBold9pt7b, C_BLACK, textdatum_t::middle_left);
  lcd.setFont(&fonts::FreeMonoBold9pt7b);
  int w = lcd.textWidth(show);
  lcd.fillRect(18 + w + 1, 60, 2, 18, C_ACCENT);       // 커서
  char cnt[8]; snprintf(cnt, sizeof(cnt), "%d", klen);
  text(cnt, 232, 79, &fonts::Font0, C_DARK, textdatum_t::bottom_right);
  lcd.endWrite();
}

// ------------------------------ 그리기 ------------------------------
static void drawTitle() {
  if (page == P_KEY) {
    drawTitleBar(forSsid ? "와이파이 이름" : "비밀번호");
    button(176, 3, 60, 24, "취소", false, &fonts::efontKR_14, 0x4A69, C_WHITE);
  } else {
    static const char* T[4] = {"인터넷 · 날씨 위치", "와이파이 고르기", "", "날씨 위치 고르기"};
    drawTitleBar(T[page]);
  }
}

static void drawStatus() {
  lcd.fillRect(0, 30, 240, 26, C_GRAY);
  uint16_t dot = 0x8410;
  char b[64];
  const char* m;
  if (!CLOCK_WIFI)                        { m = "config.h 에서 CLOCK_WIFI 를 1 로"; }
  else if (Net::credCount() == 0)         { m = "와이파이를 추가해 주세요"; }
  else if (Net::busy())                   { dot = C_YELLOW; m = "연결해 보는 중..."; }
  else if (Net::state == Net::N_OK)       { dot = C_GO; snprintf(b, sizeof(b), "연결 잘 됨 · %s", Net::lastSsid); m = b; }
  else if (Net::state == Net::N_FAIL)     { dot = C_STOP; m = Net::lastMsg()[0] ? Net::lastMsg() : "연결 안 됨"; }
  else                                    { m = "곧 연결해요"; }
  lcd.fillCircle(12, 43, 5, dot);
  fitText(m, 126, 43, 210, C_BAR, F14_12, 2);
}

static void drawCredRows() {
  for (int i = 0; i < Net::MAX_CRED; i++) {
    int y = 72 + i * 34;
    lcd.fillRect(0, y, 240, 32, C_GRAY);
    Net::Cred c;
    if (Net::getCred(i, c)) {
      lcd.fillRoundRect(4, y, 232, 30, 6, C_WHITE);
      fitText(c.ssid, 92, y + 15, 160, C_BLACK, F14_12, 2);
      bool armed = (delArmed == i);
      button(180, y + 3, 52, 24, armed ? "정말?" : "지우기", false, &fonts::efontKR_12,
             armed ? C_STOP : 0xDEFB, armed ? C_WHITE : C_BLACK);
    } else {
      lcd.drawRoundRect(4, y, 232, 30, 6, C_DARK);
      text("비어 있음", 120, y + 15, &fonts::efontKR_12, C_DARK);
    }
  }
}

static void drawLocBox() {
  lcd.fillRect(0, 216, 240, 62, C_GRAY);
  text("날씨 위치", 6, 222, &fonts::efontKR_12, C_BAR, textdatum_t::middle_left);
  lcd.fillRoundRect(4, 230, 232, 48, 6, C_WHITE);
  char nm[24], line[40];
  Net::placeName(nm, sizeof(nm));
  if (Net::locMode == 0) snprintf(line, sizeof(line), "자동 · %s", nm);
  else strlcpy(line, nm, sizeof(line));
  fitText(line, 92, 244, 164, C_BLACK, F16_14, 2);
  fitText(Net::locDetail(), 92, 265, 164, C_DARK, F14_12, 2);
  button(178, 238, 54, 32, "바꾸기", false, &fonts::efontKR_14);
}

static void drawMain() {
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  drawTitle();
  drawStatus();
  text("저장된 와이파이 (3개까지)", 6, 64, &fonts::efontKR_12, C_BAR, textdatum_t::middle_left);
  drawCredRows();
  button(4, 176, 232, 32, "+ 주변 와이파이 찾아서 추가", false, &fonts::efontKR_14);
  drawLocBox();
  button(4,   286, 112, 30, "지금 연결해 보기", false, &fonts::efontKR_14);
  button(124, 286, 112, 30, "돌아가기", true, &fonts::efontKR_14);
  lcd.endWrite();
}

static void drawBars(int x, int y, int rssi) {      // 신호 막대 4칸 (x,y = 왼쪽 아래)
  int lv = rssi >= -55 ? 4 : rssi >= -65 ? 3 : rssi >= -75 ? 2 : 1;
  for (int i = 0; i < 4; i++) {
    int h = 4 + i * 3;
    lcd.fillRect(x + i * 5, y - h, 3, h, i < lv ? C_BAR : 0xC618);
  }
}
static void drawLock(int x, int y) {                 // 자물쇠 (x,y = 왼쪽 위)
  lcd.drawRoundRect(x + 2, y, 6, 8, 2, C_DARK);
  lcd.fillRoundRect(x, y + 5, 10, 8, 1, C_DARK);
}

static void drawScan() {
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  drawTitle();
  if (Net::scanState != 2) {
    text("주변 와이파이를 찾는 중...", 120, 130, &fonts::efontKR_16, C_BAR);
    text("몇 초 걸려요", 120, 154, &fonts::efontKR_12, C_DARK);
  } else {
    int n = Net::scanCount();
    if (n == 0) text("찾은 와이파이가 없어요", 120, 130, &fonts::efontKR_16, C_BAR);
    for (int i = 0; i < n && i < 6; i++) {
      Net::ScanItem s;
      if (!Net::getScan(i, s)) continue;
      int y = 36 + i * 36;
      lcd.fillRoundRect(4, y, 232, 32, 6, C_WHITE);
      fitText(s.ssid, 88, y + 16, 156, C_BLACK, F14_12, 2);
      if (Net::isSaved(s.ssid)) text("저장됨", 186, y + 16, &fonts::efontKR_12, C_ACCENT, textdatum_t::middle_right);
      if (!s.open) drawLock(190, y + 9);
      drawBars(208, y + 24, s.rssi);
    }
  }
  text("숨긴 와이파이는 [직접 입력]", 120, 261, &fonts::efontKR_12, C_BAR);
  text("5GHz 전용 와이파이는 쓸 수 없어요", 120, 275, &fonts::efontKR_12, C_DARK);
  button(4,   284, 74, 32, "다시 찾기", false, &fonts::efontKR_14);
  button(82,  284, 76, 32, "직접 입력", false, &fonts::efontKR_14);
  button(162, 284, 74, 32, "취소", false, &fonts::efontKR_14);
  lcd.endWrite();
}

static void openKeyboard(bool ssidMode, uint8_t from) {
  forSsid = ssidMode; keyFrom = from;
  kbuf[0] = 0; klen = 0; layer = 0; pressedKey = -1;
  page = P_KEY;
  buildKeys();
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  drawTitle();
  lcd.endWrite();
  drawField();
  drawKeys();
}

static void drawLoc() {
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  drawTitle();
  uint8_t m = Net::locMode;
  for (int i = 0; i <= Net::CITY_N; i++) {
    int c = i % 3, r = i / 3;
    button(4 + c * 78, 34 + r * 40, 74, 36, i == 0 ? "자동" : Net::CITIES[i - 1].name, i == m, &fonts::efontKR_16);
  }
  text("자동: 와이파이·인터넷 주소로 찾기", 120, 279, &fonts::efontKR_12, C_BAR);
  button(4, 290, 232, 28, "돌아가기", true, &fonts::efontKR_14);
  lcd.endWrite();
}

// ------------------------------ 바깥에서 부르는 것 ------------------------------
static void start() {
  page = P_MAIN; delArmed = -1; pressedKey = -1;
  lastVer = Net::ver;
  drawMain();
}

static void update() {
  if (delArmed >= 0 && millis() - delAt > 3000) { delArmed = -1; if (page == P_MAIN) { lcd.startWrite(); drawCredRows(); lcd.endWrite(); } }
  if (Net::ver == lastVer) return;
  lastVer = Net::ver;
  if (page == P_MAIN) { lcd.startWrite(); drawStatus(); drawLocBox(); lcd.endWrite(); }
  else if (page == P_SCAN && Net::scanState != lastScanState) { lastScanState = Net::scanState; drawScan(); }
}

static void down(int x, int y) {
  if (page != P_KEY) return;
  pressedKey = keyAt(x, y);
  lcd.startWrite(); drawKey(pressedKey, true); lcd.endWrite();
}
static void move(int x, int y) {
  if (page != P_KEY || pressedKey < 0) return;
  int k = keyAt(x, y);
  if (k == pressedKey) return;
  lcd.startWrite(); drawKey(pressedKey, false); drawKey(k, true); lcd.endWrite();
  pressedKey = k;
}

static void pressKey(uint8_t code) {
  switch (code) {
    case K_SHIFT: layer = (layer == 0) ? 1 : 0; buildKeys(); drawKeys(); Sfx::play(SFX_TAP); return;
    case K_LAYER: layer = (layer == 2) ? 0 : 2; buildKeys(); drawKeys(); Sfx::play(SFX_TAP); return;
    case K_BACK:
      if (klen > 0) kbuf[--klen] = 0;
      Sfx::play(SFX_KEY); drawField(); return;
    case K_OK:
      if (forSsid) {
        if (klen == 0) { Sfx::play(SFX_ERROR); return; }
        strlcpy(pickSsid, kbuf, sizeof(pickSsid));
        Sfx::play(SFX_TAP);
        openKeyboard(false, P_SCAN);             // 이름 다음은 비밀번호 (없으면 그냥 확인)
        return;
      }
      if (klen > 0 && klen < 8) {                // WPA 비밀번호는 8자 이상
        Sfx::play(SFX_ERROR);
        toast("비밀번호는 8자 이상이에요", C_STOP);
        delay(900);
        lcd.startWrite(); lcd.fillScreen(C_GRAY); drawTitle(); lcd.endWrite();
        drawField(); drawKeys();
        return;
      }
      Net::addCred(pickSsid, kbuf);              // 저장하고 바로 연결해 봄
      memset(kbuf, 0, sizeof(kbuf)); klen = 0;
      Sfx::play(SFX_FLAG);
      page = P_MAIN; drawMain();
      return;
    default: {
      int maxLen = forSsid ? 32 : 63;
      if (klen < maxLen && code >= 32 && code < 127) { kbuf[klen++] = (char)code; kbuf[klen] = 0; Sfx::play(SFX_KEY); }
      else Sfx::play(SFX_ERROR);
      drawField();
    }
  }
}

// 손가락을 뗄 때. true 를 돌려주면 '돌아가기' (설정 화면으로)
static bool up(int x, int y) {
  switch (page) {
    case P_MAIN: {
      for (int i = 0; i < Net::MAX_CRED; i++) {   // 지우기 (두 번)
        int ry = 72 + i * 34;
        if (i < Net::credCount() && inside(x, y, 176, ry, 64, 32)) {
          if (delArmed == i && millis() - delAt < 3000) {
            Net::removeCred(i); delArmed = -1; Sfx::play(SFX_UNFLAG);
          } else { delArmed = i; delAt = millis(); Sfx::play(SFX_TAP); }
          lcd.startWrite(); drawCredRows(); drawStatus(); lcd.endWrite();
          return false;
        }
      }
      if (inside(x, y, 0, 172, 240, 40)) {         // + 추가
        Sfx::play(SFX_TAP);
        page = P_SCAN; Net::requestScan(); lastScanState = Net::scanState; drawScan();
      } else if (inside(x, y, 0, 228, 240, 52)) {  // 위치 바꾸기
        Sfx::play(SFX_TAP); page = P_LOC; drawLoc();
      } else if (y >= 282 && x < 120) {            // 지금 연결
        if (Net::credCount() == 0) { Sfx::play(SFX_ERROR); return false; }
        Sfx::play(SFX_TAP); Net::requestNow();
      } else if (y >= 282) {
        Sfx::play(SFX_TAP); return true;
      }
      return false;
    }

    case P_SCAN: {
      if (y >= 280) {
        Sfx::play(SFX_TAP);
        if (x < 80)       { Net::requestScan(); lastScanState = Net::scanState; drawScan(); }
        else if (x < 160) { openKeyboard(true, P_SCAN); }
        else              { page = P_MAIN; drawMain(); }
        return false;
      }
      if (Net::scanState != 2 || y < 36) return false;
      int i = (y - 36) / 36;
      Net::ScanItem s;
      if (i < 0 || i >= 6 || !Net::getScan(i, s)) return false;
      Sfx::play(SFX_TAP);
      strlcpy(pickSsid, s.ssid, sizeof(pickSsid));
      if (s.open) { Net::addCred(pickSsid, ""); page = P_MAIN; drawMain(); }   // 비밀번호 없는 와이파이
      else openKeyboard(false, P_SCAN);
      return false;
    }

    case P_KEY: {
      int k = pressedKey;
      pressedKey = -1;
      if (y < 30) {                                // 제목줄 [취소]
        if (x >= 170) {
          Sfx::play(SFX_TAP);
          memset(kbuf, 0, sizeof(kbuf)); klen = 0;
          if (keyFrom == P_SCAN) { page = P_SCAN; lastScanState = Net::scanState; drawScan(); }
          else { page = P_MAIN; drawMain(); }
        }
        return false;
      }
      if (k >= 0) { lcd.startWrite(); drawKey(k, false); lcd.endWrite(); pressKey(keys[k].code); }
      return false;
    }

    case P_LOC: {
      if (y >= 288) { Sfx::play(SFX_TAP); page = P_MAIN; drawMain(); return false; }
      if (y < 34) return false;
      int c = constrain(x / 80, 0, 2), r = (y - 34) / 40, i = r * 3 + c;
      if (r < 0 || r > 5 || i > Net::CITY_N) return false;
      Sfx::play(SFX_FLAG);
      Net::setLocMode(i);
      page = P_MAIN; drawMain();
      return false;
    }
  }
  return false;
}

}  // namespace NetSetup
