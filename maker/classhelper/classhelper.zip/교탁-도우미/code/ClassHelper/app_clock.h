// =====================================================================
//  app_clock.h  —  🕰 탁상시계 (아날로그) + 날씨·미세먼지
//
//  평소에는 교탁 위 탁상시계로 씁니다.
//   - 설정 → [와이파이] 에서 와이파이를 넣으면 시간이 저절로 맞고, 날씨·기온·습도·
//     미세먼지·초미세먼지가 시계 아래(가로일 때는 오른쪽)에 나옵니다. (net.h)
//     · 위쪽 날짜 옆 = 날씨 위치 (자동으로 찾은 곳 또는 직접 고른 도시)
//     · 위쪽 작은 점: 초록 = 최근에 받음 / 노랑 = 받는 중 / 회색 = 인터넷 끊김
//     · 인터넷이 끊겨도 시계는 그대로 가고, 날씨는 마지막 값이 남아요.
//       3시간이 넘으면 "○시간 전" 으로 흐리게, 12시간이 넘으면 숨깁니다.
//   - 화면을 한 번 누르면 메뉴: [시간 맞추기] [방향 바꾸기] [모양] [초침]
//   - 와이파이가 없을 때 꺼졌다 켜지면 마지막으로 적어 둔 시간부터 가고 "시간 확인"이 뜹니다
//     → 누르면 바로 맞추기 (시계 모듈 DS3231 을 꽂으면 꺼져도 시간이 그대로 — clock_time.h)
//   - 방향 바꾸기: 충전선이 나오는 쪽(바닥 쪽) 가장자리를 누르면 그쪽이 아래가 됩니다.
//   - 보드 뒷면 BOOT 짧게 = 밝은 / 어두운 모양 바꾸기
//   - 이 화면에서는 자동 절전하지 않습니다 (충전선을 꽂아 두고 쓰세요).
//
//  ✏️ 바꿔 볼 만한 곳: THEMES (색), drawFace() (숫자·눈금 모양),
//                     DUST_NAME / DUST_COLOR (미세먼지 등급 색), wxName() (날씨 이름)
// =====================================================================
#pragma once
#include "helper.h"
#include "sfx.h"
#include "clock_time.h"
#include "net.h"

namespace AppClock {

// ---------------------------- 모양 (색) ----------------------------
struct Theme { const char* name; uint16_t bg, rim, face, tick, num, hand, sec, text, sub, card; };
static const Theme THEMES[2] = {
  // 이름     바탕    테두리  판      눈금    숫자    바늘    초침    큰 글자  작은 글자 날씨 칸
  {"밝게",  0x10A6, 0x7BEF, 0xFFFF, 0x2104, 0x18C3, 0x18C3, 0xE8E4, 0xFFFF, 0xAD55, 0x2149},
  {"어둡게", 0x0000, 0x4A69, 0x10A2, 0xC618, 0xE71C, 0xFFFF, 0xFD20, 0xE71C, 0x8410, 0x18C3},
};
static const char* WEEK[7] = {"일", "월", "화", "수", "목", "금", "토"};

// 미세먼지 등급 (환경부 기준) — 좋음 / 보통 / 나쁨 / 매우나쁨
static const char*    DUST_NAME[4]  = {"좋음", "보통", "나쁨", "매우나쁨"};
static const uint16_t DUST_COLOR[4] = {0x2C7F, 0x2DE8, 0xFC60, 0xE8E4};   // 파랑 초록 주황 빨강
static int dustGrade(float v, bool fine) {
  int n = (int)(v + 0.5f);
  if (fine) return n <= 15 ? 0 : n <= 35 ? 1 : n <= 75 ? 2 : 3;   // 초미세먼지 PM2.5
  return n <= 30 ? 0 : n <= 80 ? 1 : n <= 150 ? 2 : 3;            // 미세먼지 PM10
}

// ---------------------------- 상태 ----------------------------
enum Mode : uint8_t { M_CLOCK, M_MENU, M_SET, M_DIR };
static Mode     mode = M_CLOCK;
static uint8_t  rot = 0;            // 시계 화면 방향 (0~3)
static uint8_t  themeIdx = 0;
static bool     showSec = true;
static Preferences prefs;
static bool     loaded = false;
static int      lastSec = -1, lastMin = -1;
static uint32_t menuAt = 0;
static uint32_t lastNetVer = 0;     // 인터넷 쪽이 바뀌면 다시 그리기
static bool     lastValid = false;  // 시간이 처음 맞춰지면 전체 다시 그리기

static LGFX_Sprite faceSpr(&lcd);   // 시계판을 먼저 그려서 한 번에 보냄 (깜빡임 없음)
static bool     sprOk = false;
static int      sprS = 0;

// 화면 크기에 따른 배치 (날씨를 보일 때는 시계판을 조금 작게)
static int W() { return lcd.width(); }
static int H() { return lcd.height(); }
static bool landscape() { return W() > H(); }
static bool wxOn() { return Net::weatherOn(); }
static const int RMAX = 104;                       // 시계판 반지름 (세로, 날씨 없을 때)
static int R()      { if (landscape()) return wxOn() ? 92 : 98;   return wxOn() ? 94 : RMAX; }
static int faceCX() { if (landscape()) return wxOn() ? 112 : 122; return 120; }
static int faceCY() { if (landscape()) return wxOn() ? 134 : 136; return wxOn() ? 128 : 138; }

static const Theme& th() { return THEMES[themeIdx]; }

static void loadPrefs() {
  prefs.begin("clock", true);
  rot = prefs.getUChar("rot", 0) & 3;
  themeIdx = prefs.getUChar("theme", 0) % 2;
  showSec = prefs.getBool("sec", true);
  prefs.end();
}
static void savePrefs() {
  prefs.begin("clock", false);
  prefs.putUChar("rot", rot);
  prefs.putUChar("theme", themeIdx);
  prefs.putBool("sec", showSec);
  prefs.end();
}

// ---------------------------- 첫 화면 아이콘 ----------------------------
static void icon(int cx, int cy) {
  lcd.fillCircle(cx, cy, 17, 0x2104);
  lcd.fillCircle(cx, cy, 14, C_WHITE);
  lcd.drawWedgeLine(cx, cy, cx, cy - 10, 2, 1, 0x2104);          // 분침
  lcd.drawWedgeLine(cx, cy, cx + 7, cy + 3, 2.5f, 1.5f, 0x2104);  // 시침
  lcd.fillCircle(cx, cy, 2, 0xE8E4);
}

// ---------------------------- 시계판 ----------------------------
template <typename G>
static void drawFace(G& g, int cx, int cy, const struct tm& t, bool timeOk) {
  const Theme& c = th();
  const int R = AppClock::R();
  g.fillSmoothCircle(cx, cy, R, c.rim);
  g.fillSmoothCircle(cx, cy, R - 4, c.face);
  // 눈금 60개 (5분마다 굵게)
  for (int i = 0; i < 60; i++) {
    float a = i * 6 * DEG_TO_RAD, s = sinf(a), k = cosf(a);
    bool big = (i % 5 == 0);
    float r1 = R - (big ? 18 : 11), r2 = R - 8;
    g.drawWedgeLine(cx + s * r1, cy - k * r1, cx + s * r2, cy - k * r2,
                    big ? 1.6f : 0.6f, big ? 1.6f : 0.6f, c.tick);
  }
  // 숫자 1~12
  g.setFont(&fonts::FreeSansBold12pt7b);
  g.setTextSize(1);
  g.setTextDatum(textdatum_t::middle_center);
  g.setTextColor(c.num);
  for (int h = 1; h <= 12; h++) {
    float a = h * 30 * DEG_TO_RAD;
    char b[3]; snprintf(b, sizeof(b), "%d", h);
    g.drawString(b, cx + sinf(a) * (R - 33), cy - cosf(a) * (R - 33) + 1);
  }
  // 반 이름
  g.setFont(&fonts::efontKR_12);
  g.setTextColor(c.tick);
  if (g.textWidth(DEVICE_OWNER) <= R * 1.3f) g.drawString(DEVICE_OWNER, cx, cy + R * 0.42f);   // 너무 길면 판에는 안 씀
  if (!timeOk) { g.setTextColor(0xE8E4); g.drawString("시간을 맞춰 주세요", cx, cy + R * 0.24f); }

  // 바늘
  float sec = t.tm_sec, mn = t.tm_min + sec / 60.0f, hr = (t.tm_hour % 12) + mn / 60.0f;
  float ah = hr * 30 * DEG_TO_RAD, am = mn * 6 * DEG_TO_RAD, as = sec * 6 * DEG_TO_RAD;
  g.drawWedgeLine(cx - sinf(ah) * 10, cy + cosf(ah) * 10, cx + sinf(ah) * R * 0.52f, cy - cosf(ah) * R * 0.52f, 4.5f, 2.5f, c.hand);
  g.drawWedgeLine(cx - sinf(am) * 12, cy + cosf(am) * 12, cx + sinf(am) * R * 0.78f, cy - cosf(am) * R * 0.78f, 3.5f, 1.5f, c.hand);
  if (showSec) {
    g.drawWedgeLine(cx - sinf(as) * 18, cy + cosf(as) * 18, cx + sinf(as) * R * 0.86f, cy - cosf(as) * R * 0.86f, 1.2f, 0.8f, c.sec);
    g.fillSmoothCircle(cx, cy, 5, c.sec);
  } else {
    g.fillSmoothCircle(cx, cy, 5, c.hand);
  }
  g.fillSmoothCircle(cx, cy, 2, c.face);
}

// 시계판 크기가 바뀌면(방향·날씨) 그림판도 새 크기로
static void ensureSprite() {
  int s = R() * 2 + 4;
  if (sprOk && sprS == s) return;
  if (sprOk) faceSpr.deleteSprite();
  faceSpr.setColorDepth(16);
  faceSpr.setPsram(true);
  sprOk = faceSpr.createSprite(s, s) != nullptr;
  sprS = sprOk ? s : 0;
}

static void drawFaceNow(const struct tm& t, bool ok) {
  int cx = faceCX(), cy = faceCY();
  if (sprOk) {
    int s = sprS;
    faceSpr.fillScreen(th().bg);
    drawFace(faceSpr, s / 2, s / 2, t, ok);
    faceSpr.pushSprite(cx - s / 2, cy - s / 2);
  } else {
    drawFace(lcd, cx, cy, t, ok);
  }
}

// =====================================================================
//                         날씨 그림 (도형으로)
// =====================================================================
enum : uint8_t { WI_SUN, WI_PART, WI_CLOUD, WI_FOG, WI_RAIN, WI_SNOW, WI_STORM };
static uint8_t wxKind(int code) {                // 날씨 번호(WMO) → 그림 종류
  if (code <= 1) return WI_SUN;
  if (code == 2) return WI_PART;
  if (code == 3) return WI_CLOUD;
  if (code == 45 || code == 48) return WI_FOG;
  if ((code >= 71 && code <= 77) || code == 85 || code == 86) return WI_SNOW;
  if (code >= 95) return WI_STORM;
  return WI_RAIN;                                // 51~67 이슬비·비, 80~82 소나기
}
static const char* wxName(int code) {
  switch (code) {
    case 0: case 1:            return "맑음";
    case 2:                    return "구름 조금";
    case 3:                    return "흐림";
    case 45: case 48:          return "안개";
    case 51: case 53: case 55: return "이슬비";
    case 56: case 57:
    case 66: case 67:          return "어는 비";
    case 61: case 63: case 65: return "비";
    case 71: case 73: case 75: return "눈";
    case 77:                   return "싸락눈";
    case 80: case 81: case 82: return "소나기";
    case 85: case 86:          return "눈 소나기";
    case 95: case 96: case 99: return "뇌우";
  }
  return "";
}

static void drawSun(int x, int y, int r, uint16_t col) {
  for (int i = 0; i < 8; i++) {
    float a = i * 45 * DEG_TO_RAD, ca = cosf(a), sa = sinf(a);
    lcd.drawWedgeLine(x + ca * (r + 3), y + sa * (r + 3), x + ca * (r + 6), y + sa * (r + 6), 1.2f, 1.0f, col);
  }
  lcd.fillCircle(x, y, r, col);
}
static void drawMoon(int x, int y, int r, uint16_t col, uint16_t bg) {
  lcd.fillCircle(x, y, r, col);
  lcd.fillCircle(x + r * 2 / 3, y - r / 3, r * 4 / 5, bg);   // 초승달
}
static void drawCloud(int x, int y, int s, uint16_t col) {   // (x,y) 가운데, 폭 약 2s
  lcd.fillCircle(x - s / 2, y + s / 6, s / 2, col);
  lcd.fillCircle(x + s / 6, y - s / 5, s * 2 / 3, col);
  lcd.fillCircle(x + s * 2 / 3, y + s / 4, s * 2 / 5, col);
  lcd.fillRoundRect(x - s, y + s / 6, s * 2, s / 2, s / 4, col);
}
// 날씨 그림 (가운데 x,y · 크기 s 는 약 12 → 24px 쯤)
static void drawWxIcon(int x, int y, int s, int code, bool day, uint16_t bg) {
  const uint16_t SUN = 0xFE40, MOON = 0xFF7A, CLOUD = 0xC638, GREY = 0x9CF3,
                 RAIN = 0x5D7F, SNOW = 0xFFFF, BOLT = 0xFFE0;
  switch (wxKind(code)) {
    case WI_SUN:
      if (day) drawSun(x, y, s * 2 / 3, SUN); else drawMoon(x, y, s * 3 / 4, MOON, bg);
      break;
    case WI_PART:
      if (day) drawSun(x - s / 3, y - s / 3, s / 2, SUN); else drawMoon(x - s / 3, y - s / 3, s / 2, MOON, bg);
      drawCloud(x + s / 5, y + s / 4, s * 3 / 4, CLOUD);
      break;
    case WI_CLOUD:
      drawCloud(x, y, s, CLOUD);
      break;
    case WI_FOG:
      for (int i = 0; i < 3; i++) lcd.fillRoundRect(x - s + (i == 1 ? s / 3 : 0), y - s / 2 + i * s / 2, s * 2 - s / 3, 3, 1, CLOUD);
      break;
    case WI_RAIN:
      drawCloud(x, y - s / 4, s * 4 / 5, GREY);
      for (int i = -1; i <= 1; i++)
        lcd.drawWedgeLine(x + i * s / 2 + 2, y + s / 2, x + i * s / 2 - 1, y + s, 1.4f, 1.0f, RAIN);
      break;
    case WI_SNOW:
      drawCloud(x, y - s / 4, s * 4 / 5, CLOUD);
      for (int i = -1; i <= 1; i++) lcd.fillCircle(x + i * s / 2, y + s * 3 / 4 + (i == 0 ? 2 : 0), 2, SNOW);
      break;
    default:   // WI_STORM
      drawCloud(x, y - s / 4, s * 4 / 5, GREY);
      lcd.fillTriangle(x + 1, y + s / 4, x - s / 3, y + s * 3 / 4, x, y + s * 3 / 4, BOLT);
      lcd.fillTriangle(x - 1, y + s * 3 / 4 - 2, x + s / 3, y + s * 3 / 4 - 2, x - 2, y + s + 3, BOLT);
  }
}

// 기온: 숫자 + ° (FreeSans 글꼴에는 ° 가 없어서 동그라미로 그림). 그린 폭을 돌려줌
static int drawTemp(float temp, int x, int y, uint16_t ink) {
  char tb[8];
  snprintf(tb, sizeof(tb), "%d", (int)floorf(temp + 0.5f));
  lcd.setFont(&fonts::FreeSansBold12pt7b);
  lcd.setTextSize(1);
  lcd.setTextDatum(textdatum_t::middle_left);
  lcd.setTextColor(ink);
  lcd.drawString(tb, x, y + 1);
  int w = lcd.textWidth(tb);
  lcd.drawCircle(x + w + 4, y - 6, 3, ink);
  lcd.drawCircle(x + w + 4, y - 6, 2, ink);
  return w + 9;
}

// 미세먼지 한 줄: "미세 23 [좋음]". pillRight > 0 이면 등급 칸을 그 x 에 오른쪽 맞춤 (숫자는 생략)
static void drawDust(int x, int y, int maxW, const char* label, float v, bool fine, uint16_t ink, int pillRight = 0) {
  const Theme& c = th();
  text(label, x, y, &fonts::efontKR_12, c.sub, textdatum_t::middle_left);
  lcd.setFont(&fonts::efontKR_12);
  int lw = lcd.textWidth(label);
  int px = x + lw + 4;
  if (v < 0) {
    text("-", pillRight > 0 ? pillRight - 6 : px, y, &fonts::efontKR_12, ink, textdatum_t::middle_left);
    return;
  }
  int g = dustGrade(v, fine);
  char nb[8];
  snprintf(nb, sizeof(nb), "%d", (int)(v + 0.5f));
  lcd.setFont(&fonts::efontKR_12);
  int gw = lcd.textWidth(DUST_NAME[g]) + 10;
  lcd.setFont(&fonts::efontKR_12);
  int nw = lcd.textWidth(nb);
  if (pillRight > 0) px = pillRight - gw;
  else if (lw + 4 + nw + 4 + gw <= maxW) {       // 자리가 되면 숫자(㎍/㎥)도
    text(nb, px, y, &fonts::efontKR_12, ink, textdatum_t::middle_left);
    px += nw + 4;
  }
  lcd.fillRoundRect(px, y - 9, gw, 18, 9, DUST_COLOR[g]);
  text(DUST_NAME[g], px + gw / 2, y + 1, &fonts::efontKR_12, C_WHITE);
}

// 날씨 칸에 보일 것: 없음 / 오래됨 판단
static const uint32_t OLD_MS  = 3UL * 3600 * 1000;    // 3시간 넘으면 흐리게 + "○시간 전"
static const uint32_t HIDE_MS = 12UL * 3600 * 1000;   // 12시간 넘으면 숨김

// 세로: 시계 아래 넓은 칸 (x0,y0 부터 w×h)
static void drawWxPortrait(int x0, int y0, int w, int h) {
  const Theme& c = th();
  lcd.fillRoundRect(x0, y0, w, h, 8, c.card);
  Net::Weather wx = Net::weather();
  uint32_t age = millis() - wx.atMs;
  int cx = x0 + w / 2;
  if (!wx.has || age > HIDE_MS) {
    const char* m = Net::busy() ? "날씨를 받아 오는 중..." :
                    (Net::lastMsg()[0] ? Net::lastMsg() : (wx.has ? "인터넷 연결 안 됨" : "곧 날씨를 받아 와요"));
    text(m, cx, y0 + 18, &fonts::efontKR_14, c.text);
    text("인터넷이 끊겨도 시계는 계속 가요", cx, y0 + 40, &fonts::efontKR_12, c.sub);
    return;
  }
  bool old = age > OLD_MS;
  uint16_t ink = old ? c.sub : c.text;
  int y = y0 + 17;
  if (wx.code >= 0) drawWxIcon(x0 + 22, y, 12, wx.code, wx.day, c.card);
  int tx = x0 + 42;
  int tw = drawTemp(wx.temp, tx, y, ink);
  char ab[16];
  const char* desc = wxName(wx.code);
  if (old) { snprintf(ab, sizeof(ab), "%u시간 전", (unsigned)(age / 3600000UL)); desc = ab; }
  text(desc, tx + tw + 6, y + 1, &fonts::efontKR_14, ink, textdatum_t::middle_left);
  if (wx.hum >= 0) {
    char hb[16]; snprintf(hb, sizeof(hb), "습도 %d%%", wx.hum);
    text(hb, x0 + w - 8, y + 1, &fonts::efontKR_14, ink, textdatum_t::middle_right);
  }
  int y2 = y0 + 41, half = (w - 16) / 2;
  drawDust(x0 + 8,         y2, half - 4, "미세",   wx.pm10, false, ink);
  drawDust(x0 + 8 + half,  y2, half,     "초미세", wx.pm25, true,  ink);
}

// 가로: 오른쪽 세로로 긴 칸
static void drawWxLandscape(int x0, int y0, int w, int h) {
  const Theme& c = th();
  lcd.fillRoundRect(x0, y0, w, h, 8, c.card);
  Net::Weather wx = Net::weather();
  uint32_t age = millis() - wx.atMs;
  int cx = x0 + w / 2;
  if (!wx.has || age > HIDE_MS) {
    text("날씨", cx, y0 + 40, &fonts::efontKR_16_b, c.text);
    text(Net::busy() ? "받는 중..." : (wx.has ? "연결 안 됨" : "기다리는 중"), cx, y0 + 64, &fonts::efontKR_12, c.sub);
    text("시계는", cx, y0 + 100, &fonts::efontKR_12, c.sub);
    text("그대로 가요", cx, y0 + 118, &fonts::efontKR_12, c.sub);
    return;
  }
  bool old = age > OLD_MS;
  uint16_t ink = old ? c.sub : c.text;
  int y = y0 + 22;
  if (wx.code >= 0) drawWxIcon(x0 + 22, y, 11, wx.code, wx.day, c.card);
  drawTemp(wx.temp, x0 + 42, y, ink);
  char ab[16];
  const char* desc = wxName(wx.code);
  if (old) { snprintf(ab, sizeof(ab), "%u시간 전", (unsigned)(age / 3600000UL)); desc = ab; }
  text(desc, cx, y0 + 48, &fonts::efontKR_14, ink);
  if (wx.hum >= 0) {
    char hb[16]; snprintf(hb, sizeof(hb), "습도 %d%%", wx.hum);
    text(hb, cx, y0 + 70, &fonts::efontKR_14, ink);
  }
  drawDust(x0 + 5, y0 + 96,  w - 10, "미세",   wx.pm10, false, ink, x0 + w - 5);
  drawDust(x0 + 5, y0 + 122, w - 10, "초미세", wx.pm25, true,  ink, x0 + w - 5);
}

// =====================================================================
//                      날짜·디지털 시각·인터넷 상태
// =====================================================================
static void drawDigital(int cx, int cy, const struct tm& t, const lgfx::IFont* big) {   // "오후 4:17" 가운데
  const Theme& c = th();
  char hm[8];
  int h12 = t.tm_hour % 12; if (h12 == 0) h12 = 12;
  snprintf(hm, sizeof(hm), "%d:%02d", h12, t.tm_min);
  const char* ampm = t.tm_hour < 12 ? "오전" : "오후";
  lcd.setTextSize(1);
  lcd.setFont(&fonts::efontKR_16); int wa = lcd.textWidth(ampm);
  lcd.setFont(big);                int wt = lcd.textWidth(hm);
  int x0 = cx - (wa + 6 + wt) / 2;
  text(ampm, x0, cy, &fonts::efontKR_16, c.text, textdatum_t::middle_left);
  lcd.setFont(big); lcd.setTextDatum(textdatum_t::middle_left); lcd.setTextColor(c.text);
  lcd.drawString(hm, x0 + wa + 6, cy + 1);
}

// 날씨를 보일 때: 위쪽 줄 가운데에 날짜, 배터리 왼쪽에 인터넷 점
static void drawTopInfo(const struct tm& t, bool ok) {
  const Theme& c = th();
  int dotX = W() - 60;
  lcd.fillRect(46, 0, dotX + 6 - 46, 30, c.bg);
  uint16_t dc = Net::busy() ? C_YELLOW : (Net::fresh() ? 0x07E0 : 0x8410);
  lcd.fillCircle(dotX, 15, 4, dc);
  int cx = (46 + dotX - 8) / 2;
  if (ClockTime::needsCheck() || !ok) {
    const char* m = Net::busy() ? "시간 맞추는 중" : (ok ? "시간 확인 필요" : "");
    text(m, cx, 15, &fonts::efontKR_14, 0xFD20);
  } else {                                     // "11월 26일 목 · 부산" (좁으면 글자가 작아짐)
    char d[48], place[24];
    Net::placeName(place, sizeof(place), true);
    snprintf(d, sizeof(d), "%d월 %d일 %s · %s", t.tm_mon + 1, t.tm_mday, WEEK[t.tm_wday], place);
    static const lgfx::IFont* const F[] = {&fonts::efontKR_14, &fonts::efontKR_12};
    fitText(d, cx, 15, dotX - 8 - 50, c.sub, F, 2);
  }
}

// 날씨를 보일 때의 배치
static void drawInfoWx(const struct tm& t, bool ok) {
  const Theme& c = th();
  drawTopInfo(t, ok);
  if (!landscape()) {                          // 세로: 시계판 아래 디지털 시각 + 날씨 칸
    lcd.fillRect(0, 225, 240, 95, c.bg);
    if (ok) drawDigital(120, 242, t, &fonts::FreeSansBold18pt7b);
    else    text("화면을 누르면 시간을 맞출 수 있어요", 120, 242, &fonts::efontKR_12, c.sub);
    drawWxPortrait(6, 260, 228, 56);
  } else {                                     // 가로: 오른쪽에 시각 + 날씨 칸
    lcd.fillRect(208, 30, 112, 210, c.bg);
    if (ok) {
      char hm[8];
      int h12 = t.tm_hour % 12; if (h12 == 0) h12 = 12;
      snprintf(hm, sizeof(hm), "%d:%02d", h12, t.tm_min);
      text(t.tm_hour < 12 ? "오전" : "오후", 263, 46, &fonts::efontKR_14, c.text);
      lcd.setFont(&fonts::FreeSansBold18pt7b); lcd.setTextSize(1); lcd.setTextDatum(textdatum_t::middle_center);
      lcd.setTextColor(c.text); lcd.drawString(hm, 263, 72);
    } else {
      text("눌러서", 263, 50, &fonts::efontKR_12, c.sub);
      text("시간 맞추기", 263, 68, &fonts::efontKR_12, c.sub);
    }
    drawWxLandscape(210, 92, 106, 144);
  }
}

// 날씨를 안 보일 때의 배치 (예전 그대로)
static void drawInfoPlain(const struct tm& t, bool ok) {
  const Theme& c = th();
  char d[32], hm[8];
  snprintf(d, sizeof(d), "%d월 %d일 %s요일", t.tm_mon + 1, t.tm_mday, WEEK[t.tm_wday]);
  int h12 = t.tm_hour % 12; if (h12 == 0) h12 = 12;
  snprintf(hm, sizeof(hm), "%d:%02d", h12, t.tm_min);
  const char* ampm = t.tm_hour < 12 ? "오전" : "오후";

  if (!landscape()) {                          // 세로: 시계판 아래
    lcd.fillRect(0, 246, 240, 74, c.bg);
    if (ok && ClockTime::needsCheck()) {         // 꺼졌다 켜져서 저장해 둔 시간부터 가는 중
      text("시간 확인 필요 · 눌러서 맞추기", 120, 258, &fonts::efontKR_16, 0xFD20);
    } else if (ok) {
      text(d, 120, 258, &fonts::efontKR_16, c.sub);
    }
    if (ok) {
      text(ampm, 64, 292, &fonts::efontKR_16, c.text);
      lcd.setFont(&fonts::FreeSansBold24pt7b); lcd.setTextSize(1); lcd.setTextDatum(textdatum_t::middle_left);
      lcd.setTextColor(c.text); lcd.drawString(hm, 88, 293);
    } else {
      text("화면을 누르면 시간을 맞출 수 있어요", 120, 276, &fonts::efontKR_12, c.sub);
    }
  } else {                                     // 가로: 오른쪽
    lcd.fillRect(228, 30, 92, 210, c.bg);
    if (ok) {
      char md[12]; snprintf(md, sizeof(md), "%d월 %d일", t.tm_mon + 1, t.tm_mday);
      char wd[12]; snprintf(wd, sizeof(wd), "%s요일", WEEK[t.tm_wday]);
      if (ClockTime::needsCheck()) {
        text("시간 확인", 276, 70, &fonts::efontKR_16_b, 0xFD20);
        text("눌러서 맞추기", 276, 94, &fonts::efontKR_12, 0xFD20);
      } else {
        text(md, 276, 70, &fonts::efontKR_16, c.sub);
        text(wd, 276, 94, &fonts::efontKR_16, c.sub);
      }
      text(ampm, 276, 140, &fonts::efontKR_16, c.text);
      lcd.setFont(&fonts::FreeSansBold18pt7b); lcd.setTextSize(1); lcd.setTextDatum(textdatum_t::middle_center);
      lcd.setTextColor(c.text); lcd.drawString(hm, 276, 172);
    } else {
      text("눌러서", 276, 110, &fonts::efontKR_12, c.sub);
      text("시간 맞추기", 276, 128, &fonts::efontKR_12, c.sub);
    }
  }
  // 인터넷 시간 상태 (와이파이를 적었고 날씨는 끈 경우)
  if (Net::ready() && Net::state != Net::N_WAIT) {
    const char* m = Net::busy() ? "인터넷 시간 맞추는 중" :
                    Net::state == Net::N_OK ? "인터넷 시간" : "인터넷 연결 안 됨";
    if (landscape()) text(m, 276, 224, &fonts::efontKR_12, c.sub);
    else             text(m, 120, 313, &fonts::efontKR_12, c.sub);
  }
}

static void drawInfo(const struct tm& t, bool ok) {
  if (wxOn()) drawInfoWx(t, ok); else drawInfoPlain(t, ok);
}

static void drawTop() {
  const Theme& c = th();
  lcd.fillRect(0, 0, W(), 30, c.bg);
  drawHomeButton(c.bg, c.sub);
  drawBattery(W() - 52, 8, c.bg, c.sub);
}

static void drawClockScreen() {
  ensureSprite();
  struct tm t; ClockTime::local(ClockTime::now(), t);
  bool ok = ClockTime::valid();
  lastNetVer = Net::ver;
  lcd.startWrite();
  lcd.fillScreen(th().bg);
  drawTop();
  drawFaceNow(t, ok);
  drawInfo(t, ok);
  lcd.endWrite();
  lastSec = t.tm_sec; lastMin = t.tm_min; lastValid = ok;
}

// ---------------------------- 메뉴 ----------------------------
static int menuX() { return (W() - 216) / 2; }
static int menuY() { return (H() - 176) / 2 + 8; }
static void drawMenu() {
  int x = menuX(), y = menuY();
  lcd.startWrite();
  lcd.fillRoundRect(x, y, 216, 176, 12, 0x2124);
  lcd.drawRoundRect(x, y, 216, 176, 12, 0x6B4D);
  text("시계 설정", x + 108, y + 18, &fonts::efontKR_16_b, C_WHITE);
  button(x + 8,   y + 36,  96, 44, "시간 맞추기");
  button(x + 112, y + 36,  96, 44, "방향 바꾸기");
  char tb[32]; snprintf(tb, sizeof(tb), "모양: %s", th().name);
  button(x + 8,   y + 86,  96, 44, tb, false, &fonts::efontKR_14);
  button(x + 112, y + 86,  96, 44, showSec ? "초침: 켬" : "초침: 끔", false, &fonts::efontKR_14);
  button(x + 8,   y + 136, 200, 32, "닫기", true);
  lcd.endWrite();
  menuAt = millis();
}

// ---------------------------- 시간 맞추기 ----------------------------
static struct tm edit;                         // 맞추는 중인 시간
static int  holdField = -1, holdDir = 0;       // 길게 누르면 계속 바뀜
static uint32_t holdAt = 0;
static const char* FIELD[5] = {"년", "월", "일", "시", "분"};

static int rowH() { return (H() - 34 - 42) / 5; }
static int rowY(int i) { return 34 + i * rowH(); }
static int btnW() { return landscape() ? 60 : 50; }
static int minusX() { return landscape() ? 70 : 52; }
static int plusX() { return W() - btnW() - 8; }

static int fieldVal(int f) {
  switch (f) { case 0: return edit.tm_year + 1900; case 1: return edit.tm_mon + 1; case 2: return edit.tm_mday;
               case 3: return edit.tm_hour; default: return edit.tm_min; }
}
static void bump(int f, int d) {
  static const int DAYS[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  int y = edit.tm_year + 1900, m = edit.tm_mon;
  switch (f) {
    case 0: y = constrain(y + d, 2025, 2099); edit.tm_year = y - 1900; break;
    case 1: edit.tm_mon = (m + d + 12) % 12; break;
    case 2: edit.tm_mday += d; break;
    case 3: edit.tm_hour = (edit.tm_hour + d + 24) % 24; break;
    case 4: edit.tm_min = (edit.tm_min + d + 60) % 60; break;
  }
  y = edit.tm_year + 1900; m = edit.tm_mon;
  int dim = DAYS[m] + ((m == 1 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) ? 1 : 0);
  if (edit.tm_mday < 1) edit.tm_mday = dim;
  if (edit.tm_mday > dim) edit.tm_mday = (f == 2) ? 1 : dim;
}

static void drawField(int f) {
  int y = rowY(f), h = rowH() - 6, bw = btnW();
  lcd.fillRect(0, y, W(), rowH(), C_GRAY);
  text(FIELD[f], 10, y + h / 2 + 3, &fonts::efontKR_16_b, C_BAR, textdatum_t::middle_left);
  button(minusX(), y + 3, bw, h, "-", false, &fonts::FreeSansBold12pt7b);
  button(plusX(),  y + 3, bw, h, "+", false, &fonts::FreeSansBold12pt7b);
  int mid = (minusX() + bw + plusX()) / 2;
  if (f == 3) {                                // 시: 오전/오후 + 숫자
    char n[4]; snprintf(n, sizeof(n), "%d", (edit.tm_hour % 12) ? edit.tm_hour % 12 : 12);
    text(edit.tm_hour < 12 ? "오전" : "오후", mid - 3, y + h / 2 + 3, &fonts::efontKR_16_b, C_BAR, textdatum_t::middle_right);
    text(n, mid + 3, y + h / 2 + 4, &fonts::FreeSansBold12pt7b, C_BLACK, textdatum_t::middle_left);
  } else {
    char b[8]; snprintf(b, sizeof(b), f == 4 ? "%02d" : "%d", fieldVal(f));
    text(b, mid, y + h / 2 + 4, &fonts::FreeSansBold12pt7b, C_BLACK);
  }
}

static void drawSet() {
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  lcd.fillRect(0, 0, W(), 30, C_BAR);
  text("시간 맞추기", W() / 2, 15, &fonts::efontKR_16_b, C_WHITE);
  for (int f = 0; f < 5; f++) drawField(f);
  int y = H() - 38, n = Net::ready() ? 3 : 2, w = (W() - 8 - (n - 1) * 6) / n, x = 4;
  if (n == 3) { button(x, y, w, 34, "인터넷 시간", false, &fonts::efontKR_14); x += w + 6; }
  button(x, y, w, 34, "취소"); x += w + 6;
  button(x, y, w, 34, "저장", true);
  lcd.endWrite();
}

static void openSet() {
  time_t n = ClockTime::now();
  if (!ClockTime::valid()) {                   // 아직 모르면 2026-03-02 09:00 부터
    struct tm d = {}; d.tm_year = 126; d.tm_mon = 2; d.tm_mday = 2; d.tm_hour = 9;
    n = ClockTime::make(d);
  }
  ClockTime::local(n, edit);
  edit.tm_sec = 0;
  mode = M_SET;
  drawSet();
}

// ---------------------------- 방향 바꾸기 ----------------------------
static void drawDir() {
  lcd.startWrite();
  lcd.fillScreen(C_BG);
  int w = W(), h = H();
  lcd.fillRect(0, 0, w, 10, C_YELLOW);  lcd.fillRect(0, h - 10, w, 10, C_YELLOW);
  lcd.fillRect(0, 0, 10, h, C_YELLOW);  lcd.fillRect(w - 10, 0, 10, h, C_YELLOW);
  text("바닥으로 둘 쪽 가장자리를", w / 2, h / 2 - 40, &fonts::efontKR_16_b, C_WHITE);
  text("눌러 주세요", w / 2, h / 2 - 16, &fonts::efontKR_16_b, C_WHITE);
  text("(충전선이 나오는 쪽)", w / 2, h / 2 + 12, &fonts::efontKR_14, C_YELLOW);
  text("가운데를 누르면 취소", w / 2, h / 2 + 46, &fonts::efontKR_12, 0xAD55);
  lcd.endWrite();
}
// 누른 곳(지금 화면 좌표) → 그 가장자리가 아래로 가는 방향 번호. 가장자리가 아니면 -1
static int dirFromTap(int x, int y) {
  int w = W(), h = H(), m = 56;
  int dl = x, dr = w - 1 - x, dt = y, db = h - 1 - y;
  int best = min(min(dl, dr), min(dt, db));
  if (best > m) return -1;
  int lx = (best == dl) ? 0 : (best == dr) ? w - 1 : x;
  int ly = (best == dt) ? 0 : (best == db) ? h - 1 : y;
  if (best == dl || best == dr) ly = h / 2; else lx = w / 2;
  int rx, ry; screenToRaw(Sys::rot, lx, ly, rx, ry);           // 보드 기준 위치로
  for (int r = 0; r < 4; r++) {
    int sx, sy; rawToScreen(r, rx, ry, sx, sy);
    int hh = (r & 1) ? 240 : 320;
    if (sy >= hh - 2) return r;                                 // 이 방향에서 맨 아래
  }
  return -1;
}

// ---------------------------- 앱 규칙 4가지 ----------------------------
static void start() {
  if (!loaded) { loadPrefs(); loaded = true; }
  setScreenRot(rot);
  mode = M_CLOCK;
  drawClockScreen();                          // 그림판(시계판)도 여기서 만듦
}

static void stop() {
  setScreenRot(appRot());                     // 다른 기능은 원래 방향으로
  if (sprOk) { faceSpr.deleteSprite(); sprOk = false; sprS = 0; }
}

static void update() {
  if (mode == M_CLOCK) {
    bool ok = ClockTime::valid();
    if (ok != lastValid) { drawClockScreen(); return; }       // 인터넷으로 시간이 처음 맞춰짐
    struct tm t; ClockTime::local(ClockTime::now(), t);
    if (Net::ver != lastNetVer) {                             // 날씨·인터넷 상태가 바뀜
      lastNetVer = Net::ver;
      lcd.startWrite(); drawInfo(t, ok); lcd.endWrite();
    }
    if (t.tm_sec != lastSec) {
      lastSec = t.tm_sec;
      lcd.startWrite();
      drawFaceNow(t, ok);
      if (t.tm_min != lastMin) { lastMin = t.tm_min; drawInfo(t, ok); drawBattery(W() - 52, 8, th().bg, th().sub); }
      lcd.endWrite();
    }
  } else if (mode == M_MENU) {
    if (millis() - menuAt > 8000) { mode = M_CLOCK; drawClockScreen(); }
  } else if (mode == M_SET && holdField >= 0 && Sys::touching) {
    if (millis() - holdAt > 380) {                           // 길게 누르면 빠르게 바뀜
      holdAt = millis() - 300;
      bump(holdField, holdDir); drawField(holdField);
    }
  }
}

static void touch(uint8_t ev, int x, int y) {
  if (ev == TOUCH_DOWN && mode == M_SET) {
    holdField = -1;
    for (int f = 0; f < 5; f++) {
      int ry = rowY(f), h = rowH() - 6;
      if (y < ry || y >= ry + rowH()) continue;
      if (inside(x, y, minusX() - 6, ry, btnW() + 12, h + 6)) { holdField = f; holdDir = -1; }
      if (inside(x, y, plusX() - 6,  ry, btnW() + 12, h + 6)) { holdField = f; holdDir = +1; }
      if (holdField >= 0) { bump(holdField, holdDir); drawField(holdField); Sfx::play(SFX_TAP); holdAt = millis(); }
    }
    return;
  }
  if (ev != TOUCH_UP) return;

  switch (mode) {
    case M_CLOCK:
      Sfx::play(SFX_TAP);
      if (ClockTime::needsCheck() || !ClockTime::valid()) openSet();   // 시간 확인이 필요하면 바로 맞추기
      else { mode = M_MENU; drawMenu(); }
      break;

    case M_MENU: {
      int mx = x - menuX(), my = y - menuY();
      if (inside(mx, my, 8, 36, 96, 44))        { Sfx::play(SFX_TAP); openSet(); }
      else if (inside(mx, my, 112, 36, 96, 44)) { Sfx::play(SFX_TAP); mode = M_DIR; drawDir(); }
      else if (inside(mx, my, 8, 86, 96, 44))   { Sfx::play(SFX_TAP); themeIdx = (themeIdx + 1) % 2; savePrefs(); drawClockScreen(); drawMenu(); }
      else if (inside(mx, my, 112, 86, 96, 44)) { Sfx::play(SFX_TAP); showSec = !showSec; savePrefs(); drawClockScreen(); drawMenu(); }
      else { Sfx::play(SFX_TAP); mode = M_CLOCK; drawClockScreen(); }   // 닫기 · 바깥
      break;
    }

    case M_SET: {
      holdField = -1;
      if (y < H() - 42) return;
      int n = Net::ready() ? 3 : 2, w = (W() - 8 - (n - 1) * 6) / n;
      int i = constrain((x - 4) / (w + 6), 0, n - 1);
      if (n == 3 && i == 0) {                                   // 인터넷 시간 (지금 바로 받기)
        Sfx::play(SFX_TAP); Net::requestNow();
        mode = M_CLOCK; drawClockScreen(); return;
      }
      bool save = (i == n - 1);
      if (save) { ClockTime::set(ClockTime::make(edit)); Sfx::play(SFX_WIN); }
      else Sfx::play(SFX_TAP);
      mode = M_CLOCK; drawClockScreen();
      break;
    }

    case M_DIR: {
      int r = dirFromTap(x, y);
      if (r >= 0) { rot = r; savePrefs(); setScreenRot(rot); Sfx::play(SFX_FLAG); }
      else Sfx::play(SFX_TAP);
      mode = M_CLOCK; drawClockScreen();
      break;
    }
  }
}

static void bootButton() {                      // BOOT 짧게: 밝은 ↔ 어두운
  themeIdx = (themeIdx + 1) % 2; savePrefs();
  if (mode == M_CLOCK) drawClockScreen();
}

const App app = {
  "탁상시계", "시계 · 날씨 · 미세먼지", 0x0451, icon,
  start, update, touch, stop,
  bootButton,  // BOOT 버튼: 모양 바꾸기
  true,        // 자동 절전 안 함 (충전선 꽂아 두고 쓰기)
  true         // 완성!
};

}  // namespace AppClock
