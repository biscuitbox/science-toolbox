JGB37 밸런싱 로봇 - 출력 파일과 코드

0_D0_base_plate.stl           바닥판 1개 (평평한 밑면을 베드에)
1_side_plate_x2.stl           측판 2개
2_D1_uno_mpu_deck.stl         D1 데크 1개 (탭이 위로)
3_D2_battery_deck_top.stl     D2 배터리 데크 1개 (탭이 위로)
4_wheel_adapter_standard_x2   JGB37 6mm 축 → TT 바퀴 어댑터 2개 (헐거우면 tight)
balance_uno.ino               Arduino UNO 코드 (balance_uno 폴더에 넣어서 열기)

재료 PETG, 서포트 없음. 어댑터는 벽 6겹·채움 100%.
