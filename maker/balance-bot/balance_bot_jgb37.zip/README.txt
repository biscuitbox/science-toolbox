JGB37 밸런싱 로봇 - 출력 파일과 코드

0_D0_base_plate.stl           바닥판 1개 (평평한 밑면을 베드에)
1_side_plate_x2.stl           측판 2개
2_D1_uno_mpu_deck.stl         D1 데크 1개 (탭이 위로)
3_D2_battery_deck_top.stl     D2 배터리 데크 1개 (탭이 위로)
4_wheel_adapter_standard_x2   JGB37 6mm 축 → TT 바퀴 어댑터 2개 (헐거우면 tight)
balance_uno.ino               Arduino UNO 코드 (balance_uno 폴더에 넣어서 열기)

재료 PETG, 서포트 없음. 어댑터는 벽 6겹·채움 100%.

balance_uno_auto.ino (자동 튜닝판)
- 실로 로봇을 들어 바퀴를 띄운 채 a 를 보내면 최소 출력 m, 균형 각도 s, p·d 를 스스로 찾아 저장해요.
- 폰 웹앱 "밸런싱 봇 리모컨"(과학 도구상자 → 메이커)으로 블루투스 연결해 튜닝·값 조정·조이스틱 조종을 할 수 있어요.
- 코드 올릴 때는 HC-06을 UART 단자에서 뽑아 두세요.
