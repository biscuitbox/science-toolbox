// 밸런싱 로봇 - Arduino UNO + MOEBIUS UNO Motor&Servo 쉴드
// JGB37-520 엔코더 모터(330rpm) 2개 + MPU6050 + HC-05/06 블루투스
//
// 연결
//  - 왼쪽 모터: 쉴드 M1 커넥터 (PCA9685 6·7번, 엔코더 A=D3 B=D2)
//  - 오른쪽 모터: 쉴드 M2 커넥터 (PCA9685 4·5번, 엔코더 A=D6 B=D4)
//  - MPU6050: 쉴드 IIC 단자 (VCC GND SCL SDA). 보드는 납작하게, X축 화살표가 로봇 앞쪽
//  - HC-05/06: 쉴드 UART 단자. 코드를 올릴 때는 블루투스 모듈을 뽑아 두세요 (같은 시리얼 사용)
//
// 시리얼 모니터 / 블루투스 앱: 9600bps, 줄바꿈 전송
// 명령: p i d s m x (각도 제어)  v k (엔코더 속도·위치 제어, 0이면 꺼짐)  g t ?

#include <Wire.h>

// ===== 방향 보정 (t 명령으로 확인 후 필요하면 -1로) =====
int ANGLE_SIGN = 1;   // 앞으로 기울였을 때 angle이 +가 되도록
int LEFT_DIR   = 1;   // + 명령에 왼쪽 바퀴가 앞으로 돌도록
int RIGHT_DIR  = -1;  // 오른쪽 모터는 반대로 달리므로 보통 -1
int LEFT_ENC   = 1;   // 왼쪽 바퀴가 앞으로 돌 때 엔코더 값이 +가 되도록
int RIGHT_ENC  = -1;  // 오른쪽 엔코더도 보통 반대

// ===== 튜닝 값 (시리얼 명령으로 변경 가능) =====
float Kp = 12.0;
float Ki = 0.0;
float Kd = 0.3;
float setpoint = 0.0;   // 균형 각도 (도)
int minPwm = 30;        // 모터가 돌기 시작하는 최소 출력 (0~255)
int maxPwm = 255;       // 최대 출력 (0~255)
float Kv = 0.0;         // 속도 제어: 바퀴 속도 1회전/초당 기울일 각도 (도)
float Kx = 0.0;         // 위치 제어: 바퀴 1회전 밀렸을 때 기울일 각도 (도)

const float FALL_ANGLE   = 40.0;  // 넘어짐 판정 각도
const float RESUME_ANGLE = 5.0;   // 다시 세웠을 때 재시작 각도
const float SPEED_TILT_MAX = 8.0; // 속도·위치 제어가 바꿀 수 있는 최대 각도
const unsigned long LOOP_US = 5000;  // 제어 주기 5ms (200Hz)
const long BAUD = 9600;              // HC-05/06 기본 속도

// 엔코더: 모터축 11펄스 x 감속비 30 x 4체배 = 바퀴 1회전당 1320카운트
const float COUNTS_PER_REV = 11.0 * 30.0 * 4.0;

// ===== PCA9685 (쉴드의 모터 PWM 칩) =====
const uint8_t PCA_ADDR = 0x40;
// 채널 4: 오른쪽 IN1, 5: 오른쪽 IN2, 6: 왼쪽 IN1, 7: 왼쪽 IN2
const uint8_t PCA_FIRST_CH = 4;

// ===== MPU6050 =====
const uint8_t MPU_ADDR = 0x68;

// ===== 내부 변수 =====
float gyroOffsetY = 0;
float angle = 0, gyroRate = 0;
float integral = 0, output = 0;
bool fallen = true, enabled = true;
unsigned long lastMicros = 0, lastPrint = 0;

volatile long encL = 0, encR = 0;
volatile uint8_t prevPD = 0;
long lastEncL = 0, lastEncR = 0, posRef = 0;
float wheelSpeed = 0;   // 회전/초 (앞쪽 +)
float wheelPos = 0;     // 회전 (앞쪽 +)

char lineBuf[24];
uint8_t lineLen = 0;

// ---------- 엔코더 (D2, D3, D4, D6 모두 PORTD 핀 변화 인터럽트) ----------
const int8_t QDEC[16] = {0, 1, -1, 0, -1, 0, 0, 1, 1, 0, 0, -1, 0, -1, 1, 0};

ISR(PCINT2_vect) {
  uint8_t pd = PIND;
  uint8_t lp = (((prevPD >> 3) & 1) << 1) | ((prevPD >> 2) & 1);  // 왼쪽 A=D3, B=D2
  uint8_t ln = (((pd >> 3) & 1) << 1) | ((pd >> 2) & 1);
  uint8_t rp = (((prevPD >> 6) & 1) << 1) | ((prevPD >> 4) & 1);  // 오른쪽 A=D6, B=D4
  uint8_t rn = (((pd >> 6) & 1) << 1) | ((pd >> 4) & 1);
  encL += QDEC[(lp << 2) | ln];
  encR += QDEC[(rp << 2) | rn];
  prevPD = pd;
}

void initEncoders() {
  pinMode(2, INPUT_PULLUP);
  pinMode(3, INPUT_PULLUP);
  pinMode(4, INPUT_PULLUP);
  pinMode(6, INPUT_PULLUP);
  prevPD = PIND;
  PCMSK2 |= _BV(PCINT18) | _BV(PCINT19) | _BV(PCINT20) | _BV(PCINT22);  // D2 D3 D4 D6
  PCICR |= _BV(PCIE2);
}

void readEncoders(long &l, long &r) {
  noInterrupts();
  l = encL;
  r = encR;
  interrupts();
  l *= LEFT_ENC;
  r *= RIGHT_ENC;
}

// ---------- PCA9685 ----------
bool pcaWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(PCA_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return Wire.endTransmission() == 0;
}

bool initPCA() {
  if (!pcaWrite(0x00, 0x10)) return false;  // MODE1: 슬립 (주파수 설정용)
  pcaWrite(0xFE, 3);                        // 프리스케일 3 → 약 1.5kHz (최대)
  pcaWrite(0x01, 0x04);                     // MODE2: 토템폴 출력
  pcaWrite(0x00, 0x20);                     // MODE1: 깨우기 + 자동 주소 증가
  delay(2);
  pcaWrite(0x00, 0xA0);                     // 재시작
  pcaWrite(0xFD, 0x10);                     // 모든 채널 끄기
  return true;
}

void putChannel(uint16_t v) {  // 0~4095
  if (v == 0) {                // 완전히 끔
    Wire.write(0); Wire.write(0); Wire.write(0); Wire.write(0x10);
  } else if (v >= 4095) {      // 완전히 켬
    Wire.write(0); Wire.write(0x10); Wire.write(0); Wire.write(0);
  } else {
    Wire.write(0); Wire.write(0); Wire.write(v & 0xFF); Wire.write(v >> 8);
  }
}

// left, right: -255 ~ 255 (앞쪽 +)
void setMotors(int left, int right) {
  left = constrain(left, -maxPwm, maxPwm) * LEFT_DIR;
  right = constrain(right, -maxPwm, maxPwm) * RIGHT_DIR;
  uint16_t lv = (uint16_t)abs(left) * 16, rv = (uint16_t)abs(right) * 16;
  if (abs(left) >= 255) lv = 4095;
  if (abs(right) >= 255) rv = 4095;

  Wire.beginTransmission(PCA_ADDR);
  Wire.write(0x06 + 4 * PCA_FIRST_CH);   // 채널 4부터 4개 연속 기록
  putChannel(right > 0 ? rv : 0);        // ch4 오른쪽 IN1
  putChannel(right < 0 ? rv : 0);        // ch5 오른쪽 IN2
  putChannel(left > 0 ? lv : 0);         // ch6 왼쪽 IN1
  putChannel(left < 0 ? lv : 0);         // ch7 왼쪽 IN2
  Wire.endTransmission();
}

void drive(float out) {
  int pwm = 0;
  if (out > 0.5)       pwm = minPwm + (int)out;   // 데드존 보정
  else if (out < -0.5) pwm = -minPwm + (int)out;
  setMotors(pwm, pwm);
}

// ---------- MPU6050 ----------
void mpuWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

bool readMPU(float &ax, float &az, float &gy) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(MPU_ADDR, (uint8_t)14) != 14) return false;
  int16_t raw[7];
  for (int i = 0; i < 7; i++) {
    uint8_t hi = Wire.read();
    uint8_t lo = Wire.read();
    raw[i] = (int16_t)((hi << 8) | lo);
  }
  ax = raw[0] / 16384.0;
  az = raw[2] / 16384.0;
  gy = raw[5] / 131.0;
  return true;
}

float accelAngle(float ax, float az) {
  return atan2(-ax, az) * RAD_TO_DEG * ANGLE_SIGN;
}

void calibrateGyro() {
  float sum = 0, ax, az, gy;
  int n = 0;
  for (int i = 0; i < 500; i++) {
    if (readMPU(ax, az, gy)) { sum += gy; n++; }
    delay(2);
  }
  gyroOffsetY = (n > 0) ? sum / n : 0;
}

// ---------- 출력 ----------
void printValues() {
  Serial.print(F("Kp=")); Serial.print(Kp, 2);
  Serial.print(F(" Ki=")); Serial.print(Ki, 2);
  Serial.print(F(" Kd=")); Serial.print(Kd, 2);
  Serial.print(F(" s=")); Serial.print(setpoint, 2);
  Serial.print(F(" m=")); Serial.print(minPwm);
  Serial.print(F(" x=")); Serial.print(maxPwm);
  Serial.print(F(" v=")); Serial.print(Kv, 2);
  Serial.print(F(" k=")); Serial.print(Kx, 2);
  Serial.println(enabled ? F(" ON") : F(" OFF"));
}

void printHelp() {
  Serial.println(F("p i d : PID  s : 균형각도  m : 최소출력  x : 최대출력"));
  Serial.println(F("v : 속도제어  k : 위치제어 (0이면 꺼짐)"));
  Serial.println(F("g : 모터 켜기/끄기  t : 모터·엔코더 시험  ? : 현재 값"));
}

// ---------- 모터·엔코더 시험 (바퀴를 띄운 상태에서) ----------
void motorTest() {
  bool was = enabled;
  enabled = false;
  Serial.println(F("시험: 바퀴를 띄우세요. 왼쪽 → 오른쪽 순서로 1초씩 '앞으로' 돌립니다."));
  delay(1500);
  long l0, r0, l1, r1;

  readEncoders(l0, r0);
  setMotors(120, 0);
  delay(1000);
  setMotors(0, 0);
  delay(300);
  readEncoders(l1, r1);
  Serial.print(F("왼쪽 엔코더: ")); Serial.println(l1 - l0);

  readEncoders(l0, r0);
  setMotors(0, 120);
  delay(1000);
  setMotors(0, 0);
  delay(300);
  readEncoders(l1, r1);
  Serial.print(F("오른쪽 엔코더: ")); Serial.println(r1 - r0);

  Serial.println(F("바퀴가 앞으로 돌았고 두 값이 모두 + 이면 정상이에요."));
  Serial.println(F("바퀴가 뒤로 돌았으면 *_DIR, 바퀴는 앞인데 값이 - 이면 *_ENC 를 반대로."));
  enabled = was;
  lastMicros = micros();
}

// ---------- 명령 처리 ----------
void handleCommand(char *line) {
  char c = tolower(line[0]);
  float v = atof(line + 1);
  switch (c) {
    case 'p': Kp = v; break;
    case 'i': Ki = v; integral = 0; break;
    case 'd': Kd = v; break;
    case 's': setpoint = v; break;
    case 'm': minPwm = constrain((int)v, 0, 200); break;
    case 'x': maxPwm = constrain((int)v, 0, 255); break;
    case 'v': Kv = v; break;
    case 'k': Kx = v; break;
    case 'g': enabled = !enabled; integral = 0; break;
    case 't': motorTest(); return;
    case '?': break;
    default: printHelp(); return;
  }
  printValues();
}

void readSerial() {
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (lineLen > 0) {
        lineBuf[lineLen] = 0;
        handleCommand(lineBuf);
        lineLen = 0;
      }
    } else if (lineLen < sizeof(lineBuf) - 1) {
      lineBuf[lineLen++] = ch;
    }
  }
}

// ---------- 메인 ----------
void setup() {
  Serial.begin(BAUD);
  Wire.begin();
  Wire.setClock(400000);

  if (!initPCA()) {
    Serial.println(F("PCA9685(모터 칩)를 찾을 수 없어요. 쉴드가 제대로 끼워졌는지 확인하세요."));
    while (true) delay(1000);
  }
  setMotors(0, 0);
  initEncoders();

  mpuWrite(0x6B, 0x00);  // 슬립 해제
  mpuWrite(0x1A, 0x03);  // 저역통과 필터 약 44Hz
  mpuWrite(0x1B, 0x00);  // 자이로 ±250°/s
  mpuWrite(0x1C, 0x00);  // 가속도 ±2g
  delay(100);

  float ax, az, gy;
  if (!readMPU(ax, az, gy)) {
    Serial.println(F("MPU6050을 찾을 수 없어요. IIC 단자 배선을 확인하세요."));
    while (true) delay(1000);
  }

  Serial.println(F("자이로 보정 중... 로봇을 움직이지 마세요 (약 1초)"));
  calibrateGyro();
  readMPU(ax, az, gy);
  angle = accelAngle(ax, az);

  printHelp();
  printValues();
  lastMicros = micros();
}

void loop() {
  readSerial();

  unsigned long now = micros();
  if (now - lastMicros < LOOP_US) return;
  float dt = (now - lastMicros) / 1000000.0;
  lastMicros = now;

  float ax, az, gy;
  if (!readMPU(ax, az, gy)) { setMotors(0, 0); return; }

  // 상보필터
  gyroRate = (gy - gyroOffsetY) * ANGLE_SIGN;
  angle = 0.98 * (angle + gyroRate * dt) + 0.02 * accelAngle(ax, az);

  // 바퀴 속도와 위치 (두 바퀴 평균)
  long l, r;
  readEncoders(l, r);
  float spd = ((l - lastEncL) + (r - lastEncR)) * 0.5 / COUNTS_PER_REV / dt;
  lastEncL = l;
  lastEncR = r;
  wheelSpeed += (spd - wheelSpeed) * 0.2;   // 약 25ms 평균
  wheelPos = ((l + r) * 0.5 - posRef) / COUNTS_PER_REV;

  // 넘어짐 감지와 재시작
  float tilt = angle - setpoint;
  if (fabs(tilt) > FALL_ANGLE) fallen = true;
  if (fallen && fabs(tilt) < RESUME_ANGLE) {
    fallen = false;
    integral = 0;
    posRef = (l + r) / 2;   // 세운 자리를 기준 위치로
    wheelPos = 0;
  }

  if (!enabled || fallen) {
    output = 0;
    drive(0);
  } else {
    // 앞으로 움직이거나 밀려나 있으면 목표 각도를 뒤로 살짝 옮겨 되돌아오게 함
    float lean = constrain(Kv * wheelSpeed + Kx * wheelPos, -SPEED_TILT_MAX, SPEED_TILT_MAX);
    float err = angle - (setpoint - lean);
    integral += err * dt;
    integral = constrain(integral, -100, 100);
    output = Kp * err + Ki * integral + Kd * gyroRate;
    drive(output);
  }

  // 200ms마다 상태 출력 (9600bps에 맞춰 짧게)
  if (millis() - lastPrint > 200) {
    lastPrint = millis();
    Serial.print(F("angle:")); Serial.print(angle, 2);
    Serial.print(F(" out:")); Serial.print((int)output);
    Serial.print(F(" spd:")); Serial.println(wheelSpeed, 2);
  }
}
