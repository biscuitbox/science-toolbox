# 스터디패드 (StudyPad)

2.8인치 ESP32 터치 보드(LCDWiki **E32R28T**, ESP32-32E · ST7789 · 저항막 터치)로 만드는 공부 단말기입니다.
같은 코드가 **ES3C28P**(ESP32-S3, 교탁 도우미 보드)에서도 돌아가요 — 도구 메뉴에서 보드만 다르게 고르면 됩니다.
지뢰찾기 · 영어 단어(하루 10단어) · 상식 퀴즈 · 그림판 · 손글씨 메모 · 공부 타이머 · 계산기 · 주사위·뽑기 · 날씨 탁상시계가 들어 있어요.

- 교사용 정리: https://biscuitbox.github.io/science-toolbox/maker/studypad/
- 학생용 단계별 안내(그림 · 슬라이드): https://biscuitbox.github.io/studypad-board/

## 폴더

| 폴더 | 내용 |
|------|------|
| `code/StudyPad/` | 아두이노 스케치. **`StudyPad.ino`** 를 아두이노 IDE로 엽니다 (탭 23개) |
| `models/` | 케이스 3D 출력 파일(단색): 앞 베젤, 뒷 케이스 2종, BOOT 플런저 + 조립 안내 |

## 빠른 순서

1. 아두이노 IDE 2 설치 → 파일 → 기본 설정 → 언어: 한국어
2. 보드 매니저에서 **esp32 by Espressif Systems** 의 버전을 **3.3.13** 으로 골라 설치
   (2026-11-19에 나온 4.0.0 은 LovyanGFX 1.3.0 과 맞지 않아 컴파일 오류가 납니다)
3. 라이브러리 매니저에서 **LovyanGFX** 설치
4. `code/StudyPad/StudyPad.ino` 열기 → 도구 메뉴를 아래처럼 맞추고 업로드

| 항목 | E32R28T | ES3C28P |
|------|---------|---------|
| 보드 | ESP32 Dev Module | ESP32S3 Dev Module |
| Partition Scheme | **Huge APP (3MB No OTA/1MB SPIFFS)** | **Huge APP** (Custom이 남아 있으면 바꾸기) |
| USB CDC On Boot | - | Enabled |
| 포트 | 보드의 COM 번호 | 보드의 COM 번호 |

> `StudyPad` 폴더 이름과 `StudyPad.ino` 파일 이름은 같아야 합니다.
> E32R28T는 처음 켜면 터치 보정 화면이 나와요(ES3C28P는 정전식이라 보정 없음). 다시 보정하려면 시작 화면이 보일 때 BOOT 를 누르거나 설정 → 터치 보정.
> 와이파이는 보드 화면(설정 → 와이파이·날씨)에서 넣어요. 2.4GHz만, 로그인 화면이 뜨는 와이파이는 안 됩니다.

## 외부 자료

- 화면: [LovyanGFX](https://github.com/lovyan03/LovyanGFX) (FreeBSD) — 한글 글꼴 efont 포함
- 날씨·미세먼지: [Open-Meteo](https://open-meteo.com/) (CC BY 4.0, 비상업 무료)
- 위치: [beaconDB](https://beacondb.net/), [ip-api.com](https://ip-api.com/) (비상업 무료)
