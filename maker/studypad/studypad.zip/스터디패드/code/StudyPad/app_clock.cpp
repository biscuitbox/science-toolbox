// =====================================================================
//  탁상시계 — 아날로그 시계 + 날씨 · 기온 · 습도 · 미세먼지 · 초미세먼지
//  (교탁 도우미의 탁상시계를 스터디패드에 맞게 옮김)
//
//   - [설정 → 와이파이·날씨] 에서 와이파이를 넣으면 시간이 저절로 맞고,
//     시계 아래에 날씨가 나와요. (net.cpp)
//     · 위쪽 날짜 옆 = 날씨 위치,  작은 점: 초록 = 최근에 받음 / 노랑 = 받는 중 / 회색 = 끊김
//     · 인터넷이 끊겨도 시계는 그대로 가고, 날씨는 마지막 값이 남아요.
//       3시간이 넘으면 "○시간 전"으로 흐리게, 12시간이 넘으면 숨겨요.
//   - 화면을 누르면 메뉴: [시간 맞추기] [와이파이·날씨] [모양] [초침] [방향 바꾸기]
//   - 방향 바꾸기: 바닥으로 둘 쪽 가장자리를 누르면 그쪽이 아래가 돼요 (가로로 세우면 날씨가 오른쪽에)
//   - 와이파이 없이 꺼졌다 켜지면 저장해 둔 시간부터 가고 "시간 확인"이 떠요 → 누르면 맞추기
//   - 이 화면에서는 자동 절전하지 않아요 (충전선을 꽂아 두고 쓰세요).
//
//  ✏️ 바꿔 볼 만한 곳: THEMES (색), drawFace() (숫자·눈금 모양),
//                     DUST_NAME / DUST_COLOR (미세먼지 등급 색), wxName() (날씨 이름)
// =====================================================================
#include "apps.h"
#include "net.h"

namespace {

// ---------------------------- 모양 (색) ----------------------------
struct Theme { const char* name; uint16_t bg, rim, face, tick, num, hand, sec, text, sub, card; };
const Theme THEMES[2] = {
  // 이름     바탕    테두리  판      눈금    숫자    바늘    초침    큰 글자  작은 글자 날씨 칸
  {"밝게",  0x10A6, 0x7BEF, 0xFFFF, 0x2104, 0x18C3, 0x18C3, 0xE8E4, 0xFFFF, 0xAD55, 0x2149},
  {"어둡게", 0x0000, 0x4A69, 0x10A2, 0xC618, 0xE71C, 0xFFFF, 0xFD20, 0xE71C, 0x8410, 0x18C3},
};
const char* WEEK[7] = {"일", "월", "화", "수", "목", "금", "토"};
const uint16_t C_CHECK = 0xFD20;   // "시간 확인" 주황

// 미세먼지 등급 (환경부 기준) — 좋음 / 보통 / 나쁨 / 매우나쁨
const char*    DUST_NAME[4]  = {"좋음", "보통", "나쁨", "매우나쁨"};
const uint16_t DUST_COLOR[4] = {0x2C7F, 0x2DE8, 0xFC60, 0xE8E4};   // 파랑 초록 주황 빨강
int dustGrade(float v, bool fine) {
  int n = (int)(v + 0.5f);
  if (fine) return n <= 15 ? 0 : n <= 35 ? 1 : n <= 75 ? 2 : 3;   // 초미세먼지 PM2.5
  return n <= 30 ? 0 : n <= 80 ? 1 : n <= 150 ? 2 : 3;            // 미세먼지 PM10
}

// ---------------------------- 상태 ----------------------------
enum Mode : uint8_t { M_CLOCK, M_MENU, M_SET, M_DIR };
Mode     mode = M_CLOCK;
uint8_t  themeIdx = 0;
bool     showSec = true;
int      lastSec = -1, lastMin = -1;
uint32_t menuAt = 0;
uint32_t lastNetVer = 0;
bool     lastValid = false, lastReady = false;

LGFX_Sprite faceSpr(&lcd);          // 시계판을 먼저 그려서 한 번에 보냄 (깜빡임 없음)
bool     sprOk = false;
int      sprS = 0;

uint8_t  rot = 0;                   // 시계 화면 방향: 0 = 세로(원래), 1·3 = 가로, 2 = 거꾸로

int  W()      { return lcd.width(); }
int  H()      { return lcd.height(); }
bool land()   { return W() > H(); }
bool wxOn()   { return Net::ready(); }
int  R()      { if (land()) return wxOn() ? 92 : 98;   return wxOn() ? 94 : 104; }
int  faceCX() { if (land()) return wxOn() ? 112 : 122; return 120; }
int  faceCY() { if (land()) return wxOn() ? 134 : 136; return wxOn() ? 128 : 138; }

// 화면 방향: 설정의 '화면 뒤집기' 위에 시계 방향을 더함
void useClockRot() { lcd.setRotation((rot + (settings.flip ? 2 : 0)) & 3); }
void useBaseRot()  { lcd.setRotation(settings.flip ? 2 : 0); }
// 터치 좌표(세로 기준)를 지금 방향의 화면 좌표로 바꾸기
void rotXY(int16_t& x, int16_t& y) {
  int16_t px = x, py = y;
  switch (rot) {
    case 1: x = py;       y = 239 - px; break;
    case 2: x = 239 - px; y = 319 - py; break;
    case 3: x = 319 - py; y = px;       break;
  }
}
Touch rotTouch(Touch t) { if (rot) { rotXY(t.x, t.y); rotXY(t.sx, t.sy); } return t; }
const Theme& th() { return THEMES[themeIdx]; }

void loadPrefs() { themeIdx = kvGetInt("clkTheme", 0) % 2; showSec = kvGetInt("clkSec", 1); rot = kvGetInt("clkRot", 0) & 3; }
void savePrefs() { kvSetInt("clkTheme", themeIdx); kvSetInt("clkSec", showSec); kvSetInt("clkRot", rot); }

void text(const char* s, int x, int y, uint8_t px, uint16_t fg, uint16_t bg,
          lgfx::textdatum_t d = middle_center) {
  uiFont(px);
  lcd.setTextDatum(d);
  lcd.setTextColor(fg, bg);
  lcd.drawString(s, x, y);
}

// ---------------------------- 시계판 ----------------------------
template <typename G>
void drawFace(G& g, int cx, int cy, const struct tm& t, bool timeOk) {
  const Theme& c = th();
  const int R = ::R();
  g.fillSmoothCircle(cx, cy, R, c.rim);
  g.fillSmoothCircle(cx, cy, R - 4, c.face);
  for (int i = 0; i < 60; i++) {                 // 눈금 60개 (5분마다 굵게)
    float a = i * 6 * DEG_TO_RAD, s = sinf(a), k = cosf(a);
    bool big = (i % 5 == 0);
    float r1 = R - (big ? 18 : 11), r2 = R - 8;
    g.drawWedgeLine(cx + s * r1, cy - k * r1, cx + s * r2, cy - k * r2,
                    big ? 1.6f : 0.6f, big ? 1.6f : 0.6f, c.tick);
  }
  g.setFont(&fonts::FreeSansBold12pt7b);         // 숫자 1~12
  g.setTextSize(1);
  g.setTextDatum(middle_center);
  g.setTextColor(c.num);
  for (int h = 1; h <= 12; h++) {
    float a = h * 30 * DEG_TO_RAD;
    char b[3]; snprintf(b, sizeof(b), "%d", h);
    g.drawString(b, cx + sinf(a) * (R - 33), cy - cosf(a) * (R - 33) + 1);
  }
  g.setFont(&fonts::efontKR_12);
  g.setTextColor(c.tick);
  g.drawString("스터디패드", cx, cy + R * 0.42f);
  if (!timeOk) { g.setTextColor(0xE8E4); g.drawString("시간을 맞춰 주세요", cx, cy + R * 0.24f); }

  float sec = t.tm_sec, mn = t.tm_min + sec / 60.0f, hr = (t.tm_hour % 12) + mn / 60.0f;   // 바늘
  float ah = hr * 30 * DEG_TO_RAD, am = mn * 6 * DEG_TO_RAD, as = sec * 6 * DEG_TO_RAD;
  g.drawWedgeLine(cx - sinf(ah) * 10, cy + cosf(ah) * 10, cx + sinf(ah) * R * 0.52f, cy - cosf(ah) * R * 0.52f, 4.5f, 2.5f, c.hand);
  g.drawWedgeLine(cx - sinf(am) * 12, cy + cosf(am) * 12, cx + sinf(am) * R * 0.78f, cy - cosf(am) * R * 0.78f, 3.5f, 1.5f, c.hand);
  if (showSec) {
    g.drawWedgeLine(cx - sinf(as) * 18, cy + cosf(as) * 18, cx + sinf(as) * R * 0.86f, cy - cosf(as) * R * 0.86f, 1.2f, 0.8f, c.sec);
    g.fillSmoothCircle(cx, cy, 5, c.sec);
  } else {
    g.fillSmoothCircle(cx, cy, 5, c.hand);
  }
  g.fillSmoothCircle(cx, cy, 2, c.face);
}

// 시계판 그림판: 16비트 색 → 메모리가 모자라면 8비트 → 그래도 안 되면 화면에 바로
void ensureSprite() {
  int s = R() * 2 + 4;
  if (sprOk && sprS == s) return;
  if (sprOk) faceSpr.deleteSprite();
  sprOk = false;
  for (int depth : {16, 8}) {
    faceSpr.setColorDepth(depth);
    if (faceSpr.createSprite(s, s)) { sprOk = true; break; }
  }
  sprS = sprOk ? s : 0;
}

void drawFaceNow(const struct tm& t, bool ok) {
  int cx = faceCX(), cy = faceCY();
  if (sprOk) {
    faceSpr.fillScreen(th().bg);
    drawFace(faceSpr, sprS / 2, sprS / 2, t, ok);
    faceSpr.pushSprite(cx - sprS / 2, cy - sprS / 2);
  } else {
    drawFace(lcd, cx, cy, t, ok);
  }
}

// =====================================================================
//                         날씨 그림 (도형으로)
// =====================================================================
enum : uint8_t { WI_SUN, WI_PART, WI_CLOUD, WI_FOG, WI_RAIN, WI_SNOW, WI_STORM };
uint8_t wxKind(int code) {                       // 날씨 번호(WMO) → 그림 종류
  if (code <= 1) return WI_SUN;
  if (code == 2) return WI_PART;
  if (code == 3) return WI_CLOUD;
  if (code == 45 || code == 48) return WI_FOG;
  if ((code >= 71 && code <= 77) || code == 85 || code == 86) return WI_SNOW;
  if (code >= 95) return WI_STORM;
  return WI_RAIN;
}
const char* wxName(int code) {
  switch (code) {
    case 0: case 1:            return "맑음";
    case 2:                    return "구름 조금";
    case 3:                    return "흐림";
    case 45: case 48:          return "안개";
    case 51: case 53: case 55: return "이슬비";
    case 56: case 57:
    case 66: case 67:          return "어는 비";
    case 61: case 63: case 65: return "비";
    case 71: case 73: case 75: return "눈";
    case 77:                   return "싸락눈";
    case 80: case 81: case 82: return "소나기";
    case 85: case 86:          return "눈 소나기";
    case 95: case 96: case 99: return "뇌우";
  }
  return "";
}

void drawSun(int x, int y, int r, uint16_t col) {
  for (int i = 0; i < 8; i++) {
    float a = i * 45 * DEG_TO_RAD, ca = cosf(a), sa = sinf(a);
    lcd.drawWedgeLine(x + ca * (r + 3), y + sa * (r + 3), x + ca * (r + 6), y + sa * (r + 6), 1.2f, 1.0f, col);
  }
  lcd.fillCircle(x, y, r, col);
}
void drawMoon(int x, int y, int r, uint16_t col, uint16_t bg) {
  lcd.fillCircle(x, y, r, col);
  lcd.fillCircle(x + r * 2 / 3, y - r / 3, r * 4 / 5, bg);   // 초승달
}
void drawCloud(int x, int y, int s, uint16_t col) {
  lcd.fillCircle(x - s / 2, y + s / 6, s / 2, col);
  lcd.fillCircle(x + s / 6, y - s / 5, s * 2 / 3, col);
  lcd.fillCircle(x + s * 2 / 3, y + s / 4, s * 2 / 5, col);
  lcd.fillRoundRect(x - s, y + s / 6, s * 2, s / 2, s / 4, col);
}
void drawWxIcon(int x, int y, int s, int code, bool day, uint16_t bg) {
  const uint16_t SUN = 0xFE40, MOON = 0xFF7A, CLOUD = 0xC638, GREY = 0x9CF3,
                 RAIN = 0x5D7F, SNOW = 0xFFFF, BOLT = 0xFFE0;
  switch (wxKind(code)) {
    case WI_SUN:
      if (day) drawSun(x, y, s * 2 / 3, SUN); else drawMoon(x, y, s * 3 / 4, MOON, bg);
      break;
    case WI_PART:
      if (day) drawSun(x - s / 3, y - s / 3, s / 2, SUN); else drawMoon(x - s / 3, y - s / 3, s / 2, MOON, bg);
      drawCloud(x + s / 5, y + s / 4, s * 3 / 4, CLOUD);
      break;
    case WI_CLOUD: drawCloud(x, y, s, CLOUD); break;
    case WI_FOG:
      for (int i = 0; i < 3; i++) lcd.fillRoundRect(x - s + (i == 1 ? s / 3 : 0), y - s / 2 + i * s / 2, s * 2 - s / 3, 3, 1, CLOUD);
      break;
    case WI_RAIN:
      drawCloud(x, y - s / 4, s * 4 / 5, GREY);
      for (int i = -1; i <= 1; i++)
        lcd.drawWedgeLine(x + i * s / 2 + 2, y + s / 2, x + i * s / 2 - 1, y + s, 1.4f, 1.0f, RAIN);
      break;
    case WI_SNOW:
      drawCloud(x, y - s / 4, s * 4 / 5, CLOUD);
      for (int i = -1; i <= 1; i++) lcd.fillCircle(x + i * s / 2, y + s * 3 / 4 + (i == 0 ? 2 : 0), 2, SNOW);
      break;
    default:   // 뇌우
      drawCloud(x, y - s / 4, s * 4 / 5, GREY);
      lcd.fillTriangle(x + 1, y + s / 4, x - s / 3, y + s * 3 / 4, x, y + s * 3 / 4, BOLT);
      lcd.fillTriangle(x - 1, y + s * 3 / 4 - 2, x + s / 3, y + s * 3 / 4 - 2, x - 2, y + s + 3, BOLT);
  }
}

// 기온: 숫자 + ° (FreeSans 글꼴에는 ° 가 없어서 동그라미로 그림). 그린 폭을 돌려줌
int drawTemp(float temp, int x, int y, uint16_t ink, uint16_t bg) {
  char tb[8];
  snprintf(tb, sizeof(tb), "%d", (int)floorf(temp + 0.5f));
  lcd.setFont(&fonts::FreeSansBold12pt7b);
  lcd.setTextSize(1);
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(ink, bg);
  lcd.drawString(tb, x, y + 1);
  int w = lcd.textWidth(tb);
  lcd.drawCircle(x + w + 4, y - 6, 3, ink);
  lcd.drawCircle(x + w + 4, y - 6, 2, ink);
  return w + 9;
}

// 미세먼지 한 줄: "미세 23 [좋음]"
void drawDust(int x, int y, int maxW, const char* label, float v, bool fine, uint16_t ink, int pillRight = 0) {
  const Theme& c = th();
  text(label, x, y, 12, c.sub, c.card, middle_left);
  uiFont(12);
  int px = x + lcd.textWidth(label) + 4;
  if (v < 0) { text("-", pillRight > 0 ? pillRight - 6 : px, y, 12, ink, c.card, middle_left); return; }
  int g = dustGrade(v, fine);
  char nb[8];
  snprintf(nb, sizeof(nb), "%d", (int)(v + 0.5f));
  int gw = lcd.textWidth(DUST_NAME[g]) + 10, nw = lcd.textWidth(nb);
  if (pillRight > 0) px = pillRight - gw;          // 가로: 등급 칸을 오른쪽 끝에 맞춤
  else if (px - x + nw + 4 + gw <= maxW) {       // 자리가 되면 숫자(㎍/㎥)도
    text(nb, px, y, 12, ink, c.card, middle_left);
    px += nw + 4;
  }
  lcd.fillRoundRect(px, y - 9, gw, 18, 9, DUST_COLOR[g]);
  text(DUST_NAME[g], px + gw / 2, y + 1, 12, TFT_WHITE, DUST_COLOR[g]);
}

const uint32_t OLD_MS  = 3UL * 3600 * 1000;    // 3시간 넘으면 흐리게 + "○시간 전"
const uint32_t HIDE_MS = 12UL * 3600 * 1000;   // 12시간 넘으면 숨김

// 시계 아래 날씨 칸 (x0,y0 부터 w×h)
void drawWeather(int x0, int y0, int w, int h) {
  const Theme& c = th();
  lcd.fillRoundRect(x0, y0, w, h, 8, c.card);
  Net::Weather wx = Net::weather();
  uint32_t age = millis() - wx.atMs;
  int cx = x0 + w / 2;
  if (!wx.has || age > HIDE_MS) {
    const char* m = Net::busy() ? "날씨를 받아 오는 중..." :
                    (Net::lastMsg()[0] ? Net::lastMsg() : (wx.has ? "인터넷 연결 안 됨" : "곧 날씨를 받아 와요"));
    text(m, cx, y0 + 18, 16, c.text, c.card);
    text("인터넷이 끊겨도 시계는 계속 가요", cx, y0 + 40, 12, c.sub, c.card);
    return;
  }
  bool old = age > OLD_MS;
  uint16_t ink = old ? c.sub : c.text;
  int y = y0 + 17;
  if (wx.code >= 0) drawWxIcon(x0 + 22, y, 12, wx.code, wx.day, c.card);
  int tx = x0 + 42;
  int tw = drawTemp(wx.temp, tx, y, ink, c.card);
  char ab[16];
  const char* desc = wxName(wx.code);
  if (old) { snprintf(ab, sizeof(ab), "%u시간 전", (unsigned)(age / 3600000UL)); desc = ab; }
  text(desc, tx + tw + 6, y + 1, 16, ink, c.card, middle_left);
  if (wx.hum >= 0) {
    char hb[24]; snprintf(hb, sizeof(hb), "습도 %d%%", wx.hum);
    text(hb, x0 + w - 8, y + 1, 12, ink, c.card, middle_right);
  }
  int y2 = y0 + 41, half = (w - 16) / 2;
  drawDust(x0 + 8,        y2, half - 4, "미세",   wx.pm10, false, ink);
  drawDust(x0 + 8 + half, y2, half,     "초미세", wx.pm25, true,  ink);
}

// 가로일 때: 오른쪽 세로로 긴 날씨 칸
void drawWeatherSide(int x0, int y0, int w, int h) {
  const Theme& c = th();
  lcd.fillRoundRect(x0, y0, w, h, 8, c.card);
  Net::Weather wx = Net::weather();
  uint32_t age = millis() - wx.atMs;
  int cx = x0 + w / 2;
  if (!wx.has || age > HIDE_MS) {
    text("날씨", cx, y0 + 40, 16, c.text, c.card);
    text(Net::busy() ? "받는 중..." : (wx.has ? "연결 안 됨" : "기다리는 중"), cx, y0 + 64, 12, c.sub, c.card);
    text("시계는", cx, y0 + 100, 12, c.sub, c.card);
    text("그대로 가요", cx, y0 + 118, 12, c.sub, c.card);
    return;
  }
  bool old = age > OLD_MS;
  uint16_t ink = old ? c.sub : c.text;
  int y = y0 + 22;
  if (wx.code >= 0) drawWxIcon(x0 + 22, y, 11, wx.code, wx.day, c.card);
  drawTemp(wx.temp, x0 + 42, y, ink, c.card);
  char ab[16];
  const char* desc = wxName(wx.code);
  if (old) { snprintf(ab, sizeof(ab), "%u시간 전", (unsigned)(age / 3600000UL)); desc = ab; }
  text(desc, cx, y0 + 50, 16, ink, c.card);
  if (wx.hum >= 0) {
    char hb[24]; snprintf(hb, sizeof(hb), "습도 %d%%", wx.hum);
    text(hb, cx, y0 + 72, 12, ink, c.card);
  }
  drawDust(x0 + 5, y0 + 98,  w - 10, "미세",   wx.pm10, false, ink, x0 + w - 5);
  drawDust(x0 + 5, y0 + 124, w - 10, "초미세", wx.pm25, true,  ink, x0 + w - 5);
}

// =====================================================================
//                      날짜·디지털 시각·인터넷 상태
// =====================================================================
void drawDigital(int cx, int cy, const struct tm& t, const lgfx::IFont* big) {   // "오후 4:17"
  const Theme& c = th();
  char hm[8];
  int h12 = t.tm_hour % 12; if (h12 == 0) h12 = 12;
  snprintf(hm, sizeof(hm), "%d:%02d", h12, t.tm_min);
  const char* ampm = t.tm_hour < 12 ? "오전" : "오후";
  uiFont(16);     int wa = lcd.textWidth(ampm);
  lcd.setFont(big); int wt = lcd.textWidth(hm);
  int x0 = cx - (wa + 6 + wt) / 2;
  text(ampm, x0, cy, 16, c.text, c.bg, middle_left);
  lcd.setFont(big); lcd.setTextDatum(middle_left); lcd.setTextColor(c.text, c.bg);
  lcd.drawString(hm, x0 + wa + 6, cy + 1);
}

void drawTop(const struct tm& t, bool ok) {
  const Theme& c = th();
  lcd.fillRect(0, 0, W(), 30, c.bg);
  lcd.fillRoundRect(4, 4, 34, 22, 6, c.card);            // ◀ (홈)
  lcd.fillTriangle(13, 15, 25, 8, 25, 22, c.sub);
  uiBattery(W() - 50, 8, c.sub, c.bg);
  int dotX = W() - 60;
  if (wxOn()) {
    uint16_t dc = Net::busy() ? 0xFFE0 : (Net::fresh() ? 0x07E0 : 0x8410);
    lcd.fillCircle(dotX, 15, 4, dc);
  }
  int cx = (44 + dotX - 8) / 2;
  if (Clock::needsCheck() || !ok) {
    const char* m = (wxOn() && Net::busy()) ? "시간 맞추는 중" : (ok ? "시간 확인 필요" : "");
    text(m, cx, 15, 16, C_CHECK, c.bg);
  } else {                                     // "11월 27일 금 · 부산"
    char d[48];
    if (wxOn()) {
      char place[24];
      Net::placeName(place, sizeof(place), true);
      snprintf(d, sizeof(d), "%d월 %d일 %s · %s", t.tm_mon + 1, t.tm_mday, WEEK[t.tm_wday], place);
    } else {
      snprintf(d, sizeof(d), "%d월 %d일 %s요일", t.tm_mon + 1, t.tm_mday, WEEK[t.tm_wday]);
    }
    uiFitText(d, cx, 15, dotX - 8 - 46, c.sub, c.bg, middle_center);
  }
}

void drawInfo(const struct tm& t, bool ok) {
  const Theme& c = th();
  if (land()) {                                // 가로: 시계 오른쪽에 시각 (+ 날씨 칸)
    char hm[8];
    int h12 = t.tm_hour % 12; if (h12 == 0) h12 = 12;
    snprintf(hm, sizeof(hm), "%d:%02d", h12, t.tm_min);
    const char* ampm = t.tm_hour < 12 ? "오전" : "오후";
    int cx = wxOn() ? 263 : 276;
    lcd.fillRect(wxOn() ? 208 : 228, 30, W() - (wxOn() ? 208 : 228), H() - 30, c.bg);
    if (!ok) {
      text("눌러서", cx, wxOn() ? 50 : 110, 12, c.sub, c.bg);
      text("시간 맞추기", cx, wxOn() ? 68 : 128, 12, c.sub, c.bg);
    } else if (wxOn()) {
      text(ampm, cx, 46, 16, c.text, c.bg);
      lcd.setFont(&fonts::FreeSansBold18pt7b); lcd.setTextDatum(middle_center); lcd.setTextColor(c.text, c.bg);
      lcd.drawString(hm, cx, 74);
    } else {
      char md[16]; snprintf(md, sizeof(md), "%d월 %d일", t.tm_mon + 1, t.tm_mday);
      char wd[16]; snprintf(wd, sizeof(wd), "%s요일", WEEK[t.tm_wday]);
      if (Clock::needsCheck()) { text("시간 확인", cx, 70, 16, C_CHECK, c.bg); text("눌러서 맞추기", cx, 94, 12, C_CHECK, c.bg); }
      else { text(md, cx, 70, 16, c.sub, c.bg); text(wd, cx, 94, 16, c.sub, c.bg); }
      text(ampm, cx, 140, 16, c.text, c.bg);
      lcd.setFont(&fonts::FreeSansBold18pt7b); lcd.setTextDatum(middle_center); lcd.setTextColor(c.text, c.bg);
      lcd.drawString(hm, cx, 172);
    }
    if (wxOn()) drawWeatherSide(210, 92, 106, 144);
    return;
  }
  if (wxOn()) {                                // 시계판 아래: 디지털 시각 + 날씨 칸
    lcd.fillRect(0, 225, SCREEN_W, 95, c.bg);
    if (ok) drawDigital(120, 242, t, &fonts::FreeSansBold18pt7b);
    else    text("화면을 누르면 시간을 맞출 수 있어요", 120, 242, 12, c.sub, c.bg);
    drawWeather(6, 260, 228, 56);
  } else {                                     // 와이파이가 없을 때: 큰 디지털 시각
    lcd.fillRect(0, 246, SCREEN_W, 74, c.bg);
    if (ok && Clock::needsCheck()) text("눌러서 시간 맞추기", 120, 256, 16, C_CHECK, c.bg);
    if (ok) drawDigital(120, 286, t, &fonts::FreeSansBold24pt7b);
    else    text("화면을 누르면 시간을 맞출 수 있어요", 120, 272, 12, c.sub, c.bg);
    text("와이파이를 넣으면 날씨도 나와요 (메뉴)", 120, 311, 12, c.sub, c.bg);
  }
}

void drawClockScreen() {
  useClockRot();
  ensureSprite();
  struct tm t; Clock::local(Clock::now(), t);
  bool ok = Clock::valid();
  lastNetVer = Net::version();
  lastReady = wxOn();
  lcd.fillScreen(th().bg);
  drawTop(t, ok);
  drawFaceNow(t, ok);
  drawInfo(t, ok);
  lastSec = t.tm_sec; lastMin = t.tm_min; lastValid = ok;
}

// ---------------------------- 메뉴 ----------------------------
int MX() { return (W() - 216) / 2; }
int MY() { return (H() - 176) / 2 + 8; }
Btn mBtn(int dx, int dy, int w, int h) { Btn b = {(int16_t)(MX() + dx), (int16_t)(MY() + dy), (int16_t)w, (int16_t)h}; return b; }
Btn M_SETT()  { return mBtn(8,   36,  96, 44); }
Btn M_WIFI()  { return mBtn(112, 36,  96, 44); }
Btn M_LOOK()  { return mBtn(8,   86,  96, 44); }
Btn M_SECS()  { return mBtn(112, 86,  96, 44); }
Btn M_DIRB()  { return mBtn(8,   136, 96, 32); }
Btn M_CLOSE() { return mBtn(112, 136, 96, 32); }

void drawMenu() {
  const uint16_t BG = UI_RGB(36, 40, 52), BT = UI_RGB(70, 76, 92);
  lcd.fillRoundRect(MX(), MY(), 216, 176, 12, BG);
  lcd.drawRoundRect(MX(), MY(), 216, 176, 12, UI_RGB(110, 118, 140));
  text("시계 메뉴", MX() + 108, MY() + 18, 16, TFT_WHITE, BG);
  uiButton(M_SETT(), "시간 맞추기", BT, TFT_WHITE);
  uiButton(M_WIFI(), "와이파이·날씨", BT, TFT_WHITE, 12);
  char tb[32]; snprintf(tb, sizeof(tb), "모양: %s", th().name);
  uiButton(M_LOOK(), tb, BT, TFT_WHITE, 12);
  uiButton(M_SECS(), showSec ? "초침: 켬" : "초침: 끔", BT, TFT_WHITE, 12);
  uiButton(M_DIRB(), "방향 바꾸기", BT, TFT_WHITE, 12);
  uiButton(M_CLOSE(), "닫기", C_WORD);
  menuAt = millis();
}

// ---------------------------- 방향 바꾸기 ----------------------------
// 세로 화면에 노란 테두리 → 바닥으로 둘 쪽 가장자리를 누르면 그쪽이 아래가 됨
void drawDir() {
  useBaseRot();
  const uint16_t Y = 0xFE60;
  lcd.fillScreen(C_TEXT);
  lcd.fillRect(0, 0, 240, 12, Y);   lcd.fillRect(0, 308, 240, 12, Y);
  lcd.fillRect(0, 0, 12, 320, Y);   lcd.fillRect(228, 0, 12, 320, Y);
  text("바닥으로 둘 쪽", 120, 120, 16, TFT_WHITE, C_TEXT);
  text("가장자리를 눌러 주세요", 120, 144, 16, TFT_WHITE, C_TEXT);
  text("(충전선이 나오는 쪽을 아래로)", 120, 174, 12, Y, C_TEXT);
  text("가운데를 누르면 취소", 120, 210, 12, UI_RGB(170, 176, 196), C_TEXT);
}
// 세로 기준으로 누른 곳 → 방향 번호 (가장자리가 아니면 -1)
int dirFromTap(int x, int y) {
  int dl = x, dr = 239 - x, dt = y, db = 319 - y;
  int m = min(min(dl, dr), min(dt, db));
  if (m > 56) return -1;
  if (m == db) return 0;        // 아래 → 원래대로
  if (m == dl) return 1;        // 왼쪽이 아래로 (가로)
  if (m == dt) return 2;        // 위가 아래로 (거꾸로)
  return 3;                     // 오른쪽이 아래로 (가로)
}

// ---------------------------- 시간 맞추기 ----------------------------
struct tm edit;                                // 맞추는 중인 시간
int  holdField = -1, holdDir = 0;              // 꾹 누르면 계속 바뀜
uint32_t holdAt = 0;
const char* FIELD[5] = {"년", "월", "일", "시", "분"};
const int ROW_Y0 = 38, ROW_H = 48, BW = 50, MINUS_X = 52, PLUS_X = SCREEN_W - BW - 8;

int fieldVal(int f) {
  switch (f) { case 0: return edit.tm_year + 1900; case 1: return edit.tm_mon + 1; case 2: return edit.tm_mday;
               case 3: return edit.tm_hour; default: return edit.tm_min; }
}
void bumpField(int f, int d) {
  static const int DAYS[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  int y = edit.tm_year + 1900;
  switch (f) {
    case 0: y = constrain(y + d, 2025, 2099); edit.tm_year = y - 1900; break;
    case 1: edit.tm_mon = (edit.tm_mon + d + 12) % 12; break;
    case 2: edit.tm_mday += d; break;
    case 3: edit.tm_hour = (edit.tm_hour + d + 24) % 24; break;
    case 4: edit.tm_min = (edit.tm_min + d + 60) % 60; break;
  }
  y = edit.tm_year + 1900;
  int m = edit.tm_mon;
  int dim = DAYS[m] + ((m == 1 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) ? 1 : 0);
  if (edit.tm_mday < 1) edit.tm_mday = dim;
  if (edit.tm_mday > dim) edit.tm_mday = (f == 2) ? 1 : dim;
}
Btn minusBtn(int f) { Btn b = {MINUS_X, (int16_t)(ROW_Y0 + f * ROW_H + 3), BW, ROW_H - 6}; return b; }
Btn plusBtn(int f)  { Btn b = {PLUS_X,  (int16_t)(ROW_Y0 + f * ROW_H + 3), BW, ROW_H - 6}; return b; }

void drawField(int f) {
  int y = ROW_Y0 + f * ROW_H, cy = y + ROW_H / 2;
  lcd.fillRect(0, y, SCREEN_W, ROW_H, C_BG);
  text(FIELD[f], 14, cy, 16, C_TEXT, C_BG, middle_left);
  uiButton(minusBtn(f), "-", C_LINE, C_TEXT, 24);
  uiButton(plusBtn(f), "+", C_LINE, C_TEXT, 24);
  int mid = (MINUS_X + BW + PLUS_X) / 2;
  lcd.setFont(&fonts::FreeSansBold12pt7b);
  lcd.setTextColor(C_TEXT, C_BG);
  if (f == 3) {                                // 시: 오전/오후 + 숫자
    char n[4]; snprintf(n, sizeof(n), "%d", (edit.tm_hour % 12) ? edit.tm_hour % 12 : 12);
    text(edit.tm_hour < 12 ? "오전" : "오후", mid - 3, cy, 16, C_TEXT, C_BG, middle_right);
    lcd.setFont(&fonts::FreeSansBold12pt7b); lcd.setTextDatum(middle_left); lcd.setTextColor(C_TEXT, C_BG);
    lcd.drawString(n, mid + 3, cy + 1);
  } else {
    char b[8]; snprintf(b, sizeof(b), f == 4 ? "%02d" : "%d", fieldVal(f));
    lcd.setTextDatum(middle_center);
    lcd.drawString(b, mid, cy + 1);
  }
}

Btn setBtn(int i, int n) {
  int w = (SCREEN_W - 8 - (n - 1) * 6) / n;
  Btn b = {(int16_t)(4 + i * (w + 6)), 282, (int16_t)w, 34};
  return b;
}
int setBtnCount() { return Net::ready() ? 3 : 2; }

void drawSet() {
  useBaseRot();                                // 맞추기 화면은 늘 세로
  lcd.fillScreen(C_BG);
  uiTopBar("시간 맞추기", C_CLOCK);
  for (int f = 0; f < 5; f++) drawField(f);
  int n = setBtnCount(), i = 0;
  if (n == 3) uiButton(setBtn(i++, n), "인터넷 시간", C_LINE, C_TEXT, 12);
  uiButton(setBtn(i++, n), "취소", C_LINE, C_TEXT);
  uiButton(setBtn(i++, n), "저장", C_OK);
}

void openSet() {
  time_t n = Clock::now();
  if (!Clock::valid()) {                       // 아직 모르면 2026-03-02 09:00 부터
    struct tm d = {}; d.tm_year = 126; d.tm_mon = 2; d.tm_mday = 2; d.tm_hour = 9;
    n = Clock::make(d);
  }
  Clock::local(n, edit);
  edit.tm_sec = 0;
  holdField = -1;
  mode = M_SET;
  drawSet();
}

// 맞추기 화면에서 손가락 처리. 시계 화면으로 돌아가면 true
bool setTouch(const Touch& t) {
  if (t.type == T_DOWN) {
    holdField = -1;
    for (int f = 0; f < 5; f++) {
      if (minusBtn(f).in(t.x, t.y)) { holdField = f; holdDir = -1; }
      if (plusBtn(f).in(t.x, t.y))  { holdField = f; holdDir = +1; }
    }
    if (holdField >= 0) { bumpField(holdField, holdDir); drawField(holdField); sfx(SFX_TICK); holdAt = millis(); }
    return false;
  }
  if (t.type != T_UP) return false;
  holdField = -1;
  int n = setBtnCount();
  for (int i = 0; i < n; i++) {
    if (!setBtn(i, n).hit(t)) continue;
    int k = (n == 3) ? i : i + 1;              // 0 인터넷 시간 / 1 취소 / 2 저장
    sfx(SFX_CLICK);
    if (k == 0) { Net::requestNow(); uiToast("인터넷 시간을 받아 와요", C_NET); }
    if (k == 2) { Clock::set(Clock::make(edit)); uiToast("시간을 맞췄어요", C_OK); }
    return true;
  }
  return false;
}

}  // namespace

// =====================================================================
void appClock() {
  loadPrefs();
  mode = M_CLOCK;
  hwKeepAwake = true;                          // 시계 화면에서는 자동 절전 안 함
  drawClockScreen();
  while (true) {
    Touch t = readTouch();

    if (mode == M_CLOCK || mode == M_MENU) t = rotTouch(t);   // 가로·거꾸로일 때 터치 좌표 맞추기

    if (mode == M_CLOCK) {
      if (uiHitHome(t)) break;
      if (t.type == T_UP && t.tap) {
        sfx(SFX_CLICK);
        if (Clock::needsCheck() || !Clock::valid()) openSet();   // 시간 확인이 필요하면 바로 맞추기
        else { mode = M_MENU; drawMenu(); }
        continue;
      }
      bool ok = Clock::valid();
      if (ok != lastValid || wxOn() != lastReady) { drawClockScreen(); continue; }   // 시간이 처음 맞춰짐 등
      struct tm tt; Clock::local(Clock::now(), tt);
      if (Net::version() != lastNetVer) { lastNetVer = Net::version(); drawTop(tt, ok); drawInfo(tt, ok); }
      if (tt.tm_sec != lastSec) {
        lastSec = tt.tm_sec;
        drawFaceNow(tt, ok);
        if (tt.tm_min != lastMin) { lastMin = tt.tm_min; drawTop(tt, ok); drawInfo(tt, ok); }
      }
    }

    else if (mode == M_MENU) {
      if (M_SETT().hit(t))      { sfx(SFX_CLICK); openSet(); }
      else if (M_WIFI().hit(t)) {
        sfx(SFX_CLICK); waitRelease();
        useBaseRot();
        appWifi();
        mode = M_CLOCK; drawClockScreen();
      }
      else if (M_LOOK().hit(t)) { sfx(SFX_CLICK); themeIdx = (themeIdx + 1) % 2; savePrefs(); drawClockScreen(); drawMenu(); }
      else if (M_SECS().hit(t)) { sfx(SFX_CLICK); showSec = !showSec; savePrefs(); drawClockScreen(); drawMenu(); }
      else if (M_DIRB().hit(t)) { sfx(SFX_CLICK); mode = M_DIR; drawDir(); }
      else if (t.type == T_UP && t.tap) { sfx(SFX_CLICK); mode = M_CLOCK; drawClockScreen(); }   // 닫기 · 바깥
      else if (millis() - menuAt > 8000) { mode = M_CLOCK; drawClockScreen(); }
    }

    else if (mode == M_DIR) {
      if (t.type == T_UP && t.tap) {
        int r = dirFromTap(t.x, t.y);
        if (r >= 0) { rot = r; savePrefs(); sfx(SFX_OK); }
        else sfx(SFX_CLICK);
        mode = M_CLOCK; drawClockScreen();
      }
    }

    else if (mode == M_SET) {
      if (uiHitHome(t)) { holdField = -1; sfx(SFX_CLICK); mode = M_CLOCK; drawClockScreen(); continue; }
      if (setTouch(t)) { mode = M_CLOCK; drawClockScreen(); continue; }
      if (holdField >= 0 && millis() - holdAt > 380) {           // 꾹 누르면 빠르게 바뀜
        holdAt = millis() - 300;
        bumpField(holdField, holdDir); drawField(holdField);
      }
    }
    delay(5);
  }
  hwKeepAwake = false;
  if (sprOk) { faceSpr.deleteSprite(); sprOk = false; sprS = 0; }
  useBaseRot();                                // 다른 앱은 원래 방향으로
}
