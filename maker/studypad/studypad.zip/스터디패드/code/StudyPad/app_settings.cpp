// =====================================================================
//  설정 - 밝기, 소리, 화면 반전/회전, 터치 보정, 기록 초기화, 기기 정보
// =====================================================================
#include "apps.h"
#include "net.h"

namespace {

const int ROW_H = 31, ROW_Y = 35;

Btn rowMinus(int r) { Btn b = { 120, (int16_t)(ROW_Y + r * ROW_H + 2), 34, 27 }; return b; }
Btn rowPlus(int r)  { Btn b = { 198, (int16_t)(ROW_Y + r * ROW_H + 2), 34, 27 }; return b; }
Btn rowWide(int r)  { Btn b = { 120, (int16_t)(ROW_Y + r * ROW_H + 2), 112, 27 }; return b; }

void rowLabel(int r, const char* s) {
  int y = ROW_Y + r * ROW_H;
  lcd.fillRect(0, y, SCREEN_W, ROW_H, C_BG);
  lcd.drawFastHLine(8, y + ROW_H - 1, 224, C_LINE);
  uiFont(16);
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(C_TEXT, C_BG);
  lcd.drawString(s, 10, y + ROW_H / 2);
}

void stepper(int r, const char* label, int v, int vmax) {
  rowLabel(r, label);
  uiButton(rowMinus(r), "-", C_LINE, C_TEXT, 24);
  uiButton(rowPlus(r), "+", C_LINE, C_TEXT, 24);
  int y = ROW_Y + r * ROW_H + ROW_H / 2;
  for (int i = 0; i < vmax; i++)
    lcd.fillRoundRect(158 + i * (38 / vmax), y - 6, 38 / vmax - 2, 12, 2, i < v ? C_SET : C_LINE);
}

void toggle(int r, const char* label, bool on) {
  rowLabel(r, label);
  uiButton(rowWide(r), on ? "켜짐" : "꺼짐", on ? C_OK : C_LINE, on ? TFT_WHITE : C_TEXT);
}

void action(int r, const char* label, const char* btn, uint16_t color) {
  rowLabel(r, label);
  uiButton(rowWide(r), btn, color);
}

const char* sleepLabel() {
  static char s[16];
  if (settings.sleepIdx == 0) return "끄기";
  snprintf(s, sizeof(s), "%d분 뒤", SLEEP_MINUTES[settings.sleepIdx]);
  return s;
}

const char* wifiLabel() {
  if (Net::credCount() == 0) return "넣기";
  if (Net::busy()) return "연결 중...";
  return Net::state() == Net::N_OK ? "연결됨" : "확인 필요";
}
uint16_t wifiColor() {
  if (Net::credCount() == 0) return C_NET;
  return Net::state() == Net::N_OK ? C_OK : (Net::busy() ? C_WARN : C_BAD);
}

const Btn B_SLEEP = { 158, 4, 78, 24 };          // 제목줄 오른쪽: 지금 바로 절전

void drawInfo() {
  int y = ROW_Y + 8 * ROW_H + 4;
  lcd.fillRect(0, y, SCREEN_W, SCREEN_H - y, C_BG);
  char s[64];
  int mv = batteryMilliVolts();
  snprintf(s, sizeof(s), "배터리 %d.%02dV (약 %d%%)%s", mv / 1000, (mv % 1000) / 10, batteryPercent(),
           hwCharging ? " · 충전 중" : (hwLowBattery ? " 충전 필요!" : ""));
  uiFont(12);
  lcd.setTextDatum(top_left);
  lcd.setTextColor(hwCharging ? C_OK : (hwLowBattery ? C_BAD : C_SUB), C_BG);
  lcd.drawString(s, 10, y);
  lcd.setTextColor(C_SUB, C_BG);
#ifdef ARDUINO
  snprintf(s, sizeof(s), "스터디패드 v1.2.3 · 남은 메모리 %u KB", (unsigned)(ESP.getFreeHeap() / 1024));
#else
  snprintf(s, sizeof(s), "스터디패드 v1.2.3");
#endif
  lcd.drawString(s, 10, y + 16);
}

void drawAll() {
  lcd.fillScreen(C_BG);
  uiTopBar("설정", C_SET);
  uiButton(B_SLEEP, "지금 절전", UI_RGB(70, 80, 92), TFT_WHITE, 12);
  stepper(0, "화면 밝기", settings.brightness, 5);
  stepper(1, "소리 크기", settings.volume, 3);
  toggle(2, "색 반전", settings.invert);
  toggle(3, "화면 뒤집기", settings.flip);
  action(4, "자동 절전", sleepLabel(), C_SET);
  action(5, "와이파이·날씨", wifiLabel(), wifiColor());
  action(6, HW_TOUCH_CAL ? "터치 보정" : "터치 점검", "시작", C_WORD);
  action(7, "기록 지우기", "지우기", C_BAD);
  drawInfo();
}

}  // namespace

void appSettings() {
  drawAll();
  uint32_t lastInfo = millis();
  while (true) {
    Touch t = readTouch();
    if (uiHitHome(t)) { settingsSave(); return; }
    if (B_SLEEP.hit(t)) {                            // 지금 절전 → 화면이나 BOOT 를 누르면 다시 이 화면
      sfx(SFX_CLICK); settingsSave();
      hwSleepNow();
      drawAll();
      continue;
    }
    bool changed = false;
    if (rowMinus(0).hit(t) || rowPlus(0).hit(t)) {
      settings.brightness = constrain(settings.brightness + (rowPlus(0).hit(t) ? 1 : -1), 1, 5);
      settingsApply(); sfx(SFX_CLICK); changed = true;
      stepper(0, "화면 밝기", settings.brightness, 5);
    }
    if (rowMinus(1).hit(t) || rowPlus(1).hit(t)) {
      settings.volume = constrain(settings.volume + (rowPlus(1).hit(t) ? 1 : -1), 0, 3);
      sfx(SFX_OK); changed = true;
      stepper(1, "소리 크기", settings.volume, 3);
    }
    if (rowWide(2).hit(t)) { settings.invert ^= 1; settingsApply(); sfx(SFX_CLICK); changed = true; toggle(2, "색 반전", settings.invert); }
    if (rowWide(3).hit(t)) {
      settings.flip ^= 1; settingsApply(); sfx(SFX_CLICK); settingsSave();
      waitRelease();
      drawAll();
    }
    if (rowWide(4).hit(t)) {
      settings.sleepIdx = (settings.sleepIdx + 1) % 5;
      sfx(SFX_CLICK); changed = true;
      action(4, "자동 절전", sleepLabel(), C_SET);
    }
    if (changed) settingsSave();                     // 바뀌면 바로 저장
    if (rowWide(5).hit(t)) { sfx(SFX_CLICK); waitRelease(); appWifi(); drawAll(); }
    if (rowWide(6).hit(t)) { touchCalibrate(); drawAll(); }
    if (rowWide(7).hit(t)) {
      if (uiConfirm("기록, 오답 노트, 단어 진도를 모두 지울까요? (그림·메모는 남아요)")) {
        kvClearAll();
        uiToast("지웠어요", C_OK);
      }
      drawAll();
    }
    if (millis() - lastInfo > 3000) { lastInfo = millis(); drawInfo(); action(5, "와이파이·날씨", wifiLabel(), wifiColor()); }
    delay(5);
  }
}
