// =====================================================================
//  도움말 — 앱 사용법 페이지 주소를 QR 코드로 보여 줘요 (홈 2쪽)
//   휴대폰 카메라로 찍으면 스터디패드 앱 사용법 페이지가 열려요.
//   ✏️ 우리 반 사이트가 따로 있으면 아래 HELP_URL 주소를 바꾸면 돼요.
//      (주소가 짧을수록 QR 칸이 커져서 잘 찍혀요. GitHub Pages 는 .html 을 빼도 열려요)
// =====================================================================
#include "apps.h"

namespace {

const char* HELP_SITE = "biscuitbox.github.io";
const char* HELP_PATH = "/studypad-board/apps";
const uint16_t C_HELP = UI_RGB(0, 140, 130);
const int BOX_X = 15, BOX_Y = 64, BOX_W = 210, QR_W = 174;   // 29칸 × 6점 + 둘레 여백

void draw() {
  lcd.fillScreen(C_BG);
  uiTopBar("도움말", C_HELP);
  uiFitText("앱 사용법 · 휴대폰 카메라로 찍어요", 120, 48, 228, C_TEXT, C_BG, middle_center);
  char url[96];
  snprintf(url, sizeof(url), "https://%s%s", HELP_SITE, HELP_PATH);
  lcd.fillRoundRect(BOX_X, BOX_Y, BOX_W, BOX_W, 8, TFT_WHITE);   // QR 둘레 흰 여백
  lcd.qrcode(url, BOX_X + (BOX_W - QR_W) / 2, BOX_Y + (BOX_W - QR_W) / 2, QR_W, 1, false);
  lcd.setFont(&fonts::Font0);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(C_SUB, C_BG);
  lcd.drawString(HELP_SITE, 120, 290);
  lcd.drawString(HELP_PATH, 120, 302);
}

}  // namespace

void appHelp() {
  draw();
  while (true) {
    Touch t = readTouch();
    if (uiHitHome(t)) return;
    delay(5);
  }
}
