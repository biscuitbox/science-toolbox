// =====================================================================
//  hw.cpp  -  하드웨어 기능 구현
//  (학생들이 크게 고칠 일은 없는 파일이에요. 앱을 만들 때는 hw.h 만 보면 돼요.)
// =====================================================================
#include "hw.h"

LGFX lcd;
Settings settings = { 3, 2, 0, 0, 2 };
bool hwKeepAwake = false;
volatile bool hwNetBusy = false;
bool hwLowBattery = false;
static void (*saveHook)() = nullptr;
void hwSetSaveHook(void (*fn)()) { saveHook = fn; }
void hwSaveNow() { if (saveHook) saveHook(); }

// 플랫폼별 저수준 함수 (아래 #ifdef ARDUINO 부분 또는 PC 시뮬레이터에서 구현)
bool llTouchScreen(int16_t& x, int16_t& y);   // 보정된 화면 좌표
void llToneOn(uint16_t freq);
void llToneOff();
void llLed(bool r, bool g, bool b);
void llBegin();
void llSleep();        // 가벼운 절전 (깨어나면 이어서 실행)
void llDeepSleep();    // 깊은 절전 (BOOT 버튼으로 깨어나면 처음부터 다시 시작)
void llStorageBegin(); // 저장 공간(설정·기록·그림) 준비

// ---------------------------------------------------------------------
//  터치 이벤트 만들기 (DOWN / MOVE / UP / LONG)
// ---------------------------------------------------------------------
static bool     tPressed = false;
static bool     tLongSent = false;
static bool     tMoved = false;
static int16_t  tStartX, tStartY, tLastX, tLastY;
static uint32_t tStartMs = 0;
static uint8_t  tMissCount = 0;

bool touchRaw(int16_t& x, int16_t& y) { return llTouchScreen(x, y); }

// ---- 절전 / 배터리 상태 ----
static uint32_t lastActivity = 0;
static bool     dimmed = false;     // 절전 직전 화면을 어둡게 한 상태
static bool     swallow = false;    // 깨운 손가락은 버튼 누름으로 치지 않기
static bool     soundBusy = false;

static void enterSleep() {
  hwSaveNow();
  soundStop();
  llLed(false, false, false);
  llSleep();                         // 여기서 멈춰 있다가 깨어나면 다음 줄부터
  dimmed = false;
  settingsApply();
  swallow = true;
  tMissCount = 0;
  lastActivity = millis();
}

static void lowBatteryShutdown() {
  hwSaveNow();
  soundStop();
  lcd.setRotation(settings.flip ? 2 : 0);
  lcd.fillScreen(TFT_BLACK);
  lcd.setFont(&fonts::efontKR_16);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(TFT_WHITE, TFT_BLACK);
  lcd.drawString("배터리가 부족해요", 120, 140);
  lcd.drawString("기록은 저장했어요", 120, 164);
  lcd.setTextColor(0xFE60, TFT_BLACK);
  lcd.drawString(HW_E32R28T ? "충전한 뒤 BOOT 버튼을 누르세요" : "충전한 뒤 화면을 누르세요", 120, 196);
  for (int i = 0; i < 6; i++) { llLed(true, false, false); delay(250); llLed(false, false, false); delay(250); }
  llDeepSleep();
}

static void powerCheck(uint32_t ms) {
  // 배터리: 10초마다 재고, 30초 연속으로 낮을 때만 판단 (잠깐 떨어지는 것 무시)
  static uint32_t lastBatMs = 0;
  static uint8_t lowCnt = 0, critCnt = 0;
  static bool warned = false;
  if (ms - lastBatMs >= 10000) {
    lastBatMs = ms;
    int mv = batteryMilliVolts();
    bool plausible = mv > 2900 && mv < 4400;   // 측정값이 이상하면(배터리 없음 등) 판단하지 않음
    lowCnt  = (plausible && mv < 3450) ? lowCnt + 1 : 0;
    critCnt = (plausible && mv < 3300) ? critCnt + 1 : 0;
    if (lowCnt >= 3) {
      hwLowBattery = true;
      if (!warned) { warned = true; hwSaveNow(); }
      ledFlash(true, false, false, 150);
    } else if (lowCnt == 0) {
      hwLowBattery = false; warned = false;
    }
    if (critCnt >= 3) lowBatteryShutdown();
  }
  // 자동 절전
  uint8_t idx = settings.sleepIdx < 5 ? settings.sleepIdx : 0;
  if (!idx || hwKeepAwake || hwNetBusy || soundBusy || tPressed) { lastActivity = ms; return; }
  uint32_t limit = SLEEP_MINUTES[idx] * 60000UL;
  uint32_t idle = ms - lastActivity;
  if (idle >= limit) enterSleep();
  else if (!dimmed && idle + 15000 >= limit) { dimmed = true; lcd.setBrightness(8); }
}

Touch readTouch() {
  hwUpdate();
  Touch ev = { T_NONE, tLastX, tLastY, tStartX, tStartY, false, false };
  int16_t x, y;
  bool now = llTouchScreen(x, y);
  uint32_t ms = millis();
  if (now) lastActivity = ms;

  // 절전에서 깨운 손가락 / 어두운 화면을 밝힌 손가락은 뗄 때까지 무시
  if (swallow) {
    if (now) tMissCount = 0;
    else if (++tMissCount >= 2) { swallow = false; tPressed = false; tMissCount = 0; }
    return ev;
  }
  if (now && dimmed) {
    dimmed = false; settingsApply();
    swallow = true; tMissCount = 0;
    return ev;
  }
  if (!now) powerCheck(ms);

  if (now) {
    tMissCount = 0;
    if (!tPressed) {
      tPressed = true; tLongSent = false; tMoved = false;
      tStartX = tLastX = x; tStartY = tLastY = y; tStartMs = ms;
      ev.type = T_DOWN; ev.x = x; ev.y = y; ev.sx = x; ev.sy = y;
      return ev;
    }
    if (abs(x - tStartX) > 10 || abs(y - tStartY) > 10) tMoved = true;
    if (!tLongSent && !tMoved && ms - tStartMs > 450) {
      tLongSent = true;
      ev.type = T_LONG; ev.x = tStartX; ev.y = tStartY;
      return ev;
    }
    if (x != tLastX || y != tLastY) {
      tLastX = x; tLastY = y;
      ev.type = T_MOVE; ev.x = x; ev.y = y;
      return ev;
    }
    return ev;
  }

  // 저항막 터치는 순간적으로 끊겨 보일 때가 있어서 두 번 연속 '안 눌림'일 때 뗀 것으로 봄
  if (tPressed && ++tMissCount >= 2) {
    tPressed = false;
    ev.type = T_UP; ev.x = tLastX; ev.y = tLastY;
    ev.tap = !tMoved && !tLongSent;
    ev.longed = tLongSent;
    return ev;
  }
  return ev;
}

void waitRelease() {
  while (true) {
    Touch t = readTouch();
    if (!tPressed) break;
    (void)t;
    delay(5);
  }
}

// ---------------------------------------------------------------------
//  소리
// ---------------------------------------------------------------------
static uint16_t melody[64];
static int      melodyLen = 0, melodyPos = 0;
static uint32_t noteEndMs = 0;

static void startNote() {
  uint16_t f = melody[melodyPos * 2], d = melody[melodyPos * 2 + 1];
  if (f && settings.volume) llToneOn(f); else llToneOff();
  noteEndMs = millis() + d;
}

void playMelody(const uint16_t* notes, int count) {
  if (settings.volume == 0) return;
  if (count > 32) count = 32;
  for (int i = 0; i < count * 2; i++) melody[i] = notes[i];
  melodyLen = count; melodyPos = 0; soundBusy = true;
  startNote();
}

void beep(uint16_t freq, uint16_t ms) {
  uint16_t n[2] = { freq, ms };
  playMelody(n, 1);
}

void soundStop() { soundBusy = false; llToneOff(); }

void sfx(Sfx s) {
  static const uint16_t CLICK[] = { 1800, 15 };
  static const uint16_t OK[]    = { 1047, 70, 1568, 110 };
  static const uint16_t WRONG[] = { 330, 120, 0, 30, 247, 200 };
  static const uint16_t WIN[]   = { 523, 100, 659, 100, 784, 100, 1047, 250, 0, 60, 784, 100, 1047, 300 };
  static const uint16_t LOSE[]  = { 392, 150, 330, 150, 262, 150, 196, 400 };
  static const uint16_t FLAG[]  = { 1319, 40, 1760, 40 };
  static const uint16_t ALARM[] = { 1760, 150, 0, 80, 1760, 150, 0, 80, 1760, 150, 0, 400,
                                    1760, 150, 0, 80, 1760, 150, 0, 80, 1760, 150 };
  static const uint16_t TICK[]  = { 2400, 8 };
  switch (s) {
    case SFX_CLICK: playMelody(CLICK, 1); break;
    case SFX_OK:    playMelody(OK, 2); break;
    case SFX_WRONG: playMelody(WRONG, 3); break;
    case SFX_WIN:   playMelody(WIN, 7); break;
    case SFX_LOSE:  playMelody(LOSE, 4); break;
    case SFX_FLAG:  playMelody(FLAG, 2); break;
    case SFX_ALARM: playMelody(ALARM, 11); break;
    case SFX_TICK:  playMelody(TICK, 1); break;
  }
}

// ---------------------------------------------------------------------
//  LED
// ---------------------------------------------------------------------
static uint32_t ledOffMs = 0;
void led(bool r, bool g, bool b) { ledOffMs = 0; llLed(r, g, b); }
void ledFlash(bool r, bool g, bool b, uint16_t ms) { llLed(r, g, b); ledOffMs = millis() + ms; if (!ledOffMs) ledOffMs = 1; }

// ---------------------------------------------------------------------
void hwUpdate() {
  uint32_t now = millis();
  if (soundBusy && (int32_t)(now - noteEndMs) >= 0) {
    if (++melodyPos >= melodyLen) { soundBusy = false; llToneOff(); }
    else startNote();
  }
  if (ledOffMs && (int32_t)(now - ledOffMs) >= 0) { ledOffMs = 0; llLed(false, false, false); }
}

int batteryPercent() {
  int mv = batteryMilliVolts();
  // 리튬 폴리머 3.3V(0%) ~ 4.15V(100%) 정도로 대략 계산
  int p = (mv - 3300) * 100 / (4150 - 3300);
  if (p < 0) p = 0;
  if (p > 100) p = 100;
  return p;
}

void settingsSave() {
  kvSetInt("bright", settings.brightness);
  kvSetInt("volume", settings.volume);
  kvSetInt("invert", settings.invert);
  kvSetInt("flip", settings.flip);
  kvSetInt("sleep", settings.sleepIdx);
}

void settingsApply() {
  static const uint8_t LV[6] = { 0, 30, 70, 120, 180, 255 };
  if (settings.brightness < 1) settings.brightness = 1;
  if (settings.brightness > 5) settings.brightness = 5;
  lcd.setBrightness(LV[settings.brightness]);
  lcd.invertDisplay(settings.invert);
  lcd.setRotation(settings.flip ? 2 : 0);
}

static void settingsLoad() {
  settings.brightness = kvGetInt("bright", 3);
  settings.volume     = kvGetInt("volume", 2);
  settings.invert     = kvGetInt("invert", 0);
  settings.flip       = kvGetInt("flip", 0);
  settings.sleepIdx   = kvGetInt("sleep", 2);
}

void hwBegin() {
  llStorageBegin();
  llBegin();
  settingsLoad();
  lcd.init();
  settingsApply();
  lcd.fillScreen(TFT_BLACK);
  lastActivity = millis();
}

// =====================================================================
//  ↓↓↓ 여기부터는 ESP32 보드 공통: 저장 공간 (보드마다 다른 부분은 hw_e32r28t.cpp / hw_es3c28p.cpp) ↓↓↓
// =====================================================================
#ifdef ARDUINO
#include <Preferences.h>
#include <LittleFS.h>

static Preferences prefs;
static bool fsReady = false;

int32_t kvGetInt(const char* key, int32_t def) { return prefs.getInt(key, def); }
void    kvSetInt(const char* key, int32_t v)   { prefs.putInt(key, v); }
bool    kvGetBytes(const char* key, void* buf, size_t len) {
  if (prefs.getBytesLength(key) != len) return false;
  return prefs.getBytes(key, buf, len) == len;
}
void    kvSetBytes(const char* key, const void* buf, size_t len) { prefs.putBytes(key, buf, len); }
void    kvClearAll() {
  uint8_t keep[16]; size_t n = prefs.getBytesLength("tcal");   // 터치 보정값은 남김
  bool has = n > 0 && n <= sizeof(keep) && prefs.getBytes("tcal", keep, n) == n;
  prefs.clear();
  if (has) prefs.putBytes("tcal", keep, n);
  settingsSave();
}

// 저장 공간 준비 (hwBegin 에서 가장 먼저)
void llStorageBegin() {
  prefs.begin("studypad", false);
  fsReady = LittleFS.begin(true);       // 처음엔 자동 포맷
}
bool bootButtonDown() { return digitalRead(PIN_BOOT) == LOW; }

bool fileSave(const char* path, const void* buf, size_t len) {
  if (!fsReady) return false;
  File f = LittleFS.open(path, "w");
  if (!f) return false;
  size_t w = f.write((const uint8_t*)buf, len);
  f.close();
  return w == len;
}
bool fileLoad(const char* path, void* buf, size_t len) {
  if (!fsReady || !LittleFS.exists(path)) return false;
  File f = LittleFS.open(path, "r");
  if (!f) return false;
  size_t r = f.read((uint8_t*)buf, len);
  f.close();
  return r == len;
}
bool fileExists(const char* path) { return fsReady && LittleFS.exists(path); }
void fileRemove(const char* path) { if (fsReady && LittleFS.exists(path)) LittleFS.remove(path); }

#endif  // ARDUINO
