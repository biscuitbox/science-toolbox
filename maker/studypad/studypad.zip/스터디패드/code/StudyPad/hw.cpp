// =====================================================================
//  hw.cpp  -  하드웨어 기능 구현
//  (학생들이 크게 고칠 일은 없는 파일이에요. 앱을 만들 때는 hw.h 만 보면 돼요.)
// =====================================================================
#include "hw.h"

LGFX lcd;
Settings settings = { 3, 2, 0, 0, 2 };
bool hwKeepAwake = false;
volatile bool hwNetBusy = false;
bool hwLowBattery = false;
static void (*saveHook)() = nullptr;
void hwSetSaveHook(void (*fn)()) { saveHook = fn; }
void hwSaveNow() { if (saveHook) saveHook(); }

// 플랫폼별 저수준 함수 (아래 #ifdef ARDUINO 부분 또는 PC 시뮬레이터에서 구현)
bool llTouchScreen(int16_t& x, int16_t& y);   // 보정된 화면 좌표
void llToneOn(uint16_t freq);
void llToneOff();
void llLed(bool r, bool g, bool b);
void llBegin();
void llSleep();        // 가벼운 절전 (깨어나면 이어서 실행)
void llDeepSleep();    // 깊은 절전 (BOOT 버튼으로 깨어나면 처음부터 다시 시작)

// ---------------------------------------------------------------------
//  터치 이벤트 만들기 (DOWN / MOVE / UP / LONG)
// ---------------------------------------------------------------------
static bool     tPressed = false;
static bool     tLongSent = false;
static bool     tMoved = false;
static int16_t  tStartX, tStartY, tLastX, tLastY;
static uint32_t tStartMs = 0;
static uint8_t  tMissCount = 0;

bool touchRaw(int16_t& x, int16_t& y) { return llTouchScreen(x, y); }

// ---- 절전 / 배터리 상태 ----
static uint32_t lastActivity = 0;
static bool     dimmed = false;     // 절전 직전 화면을 어둡게 한 상태
static bool     swallow = false;    // 깨운 손가락은 버튼 누름으로 치지 않기
static bool     soundBusy = false;

static void enterSleep() {
  hwSaveNow();
  soundStop();
  llLed(false, false, false);
  llSleep();                         // 여기서 멈춰 있다가 깨어나면 다음 줄부터
  dimmed = false;
  settingsApply();
  swallow = true;
  tMissCount = 0;
  lastActivity = millis();
}

static void lowBatteryShutdown() {
  hwSaveNow();
  soundStop();
  lcd.setRotation(settings.flip ? 2 : 0);
  lcd.fillScreen(TFT_BLACK);
  lcd.setFont(&fonts::efontKR_16);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(TFT_WHITE, TFT_BLACK);
  lcd.drawString("배터리가 부족해요", 120, 140);
  lcd.drawString("기록은 저장했어요", 120, 164);
  lcd.setTextColor(0xFE60, TFT_BLACK);
  lcd.drawString("충전한 뒤 BOOT 버튼을 누르세요", 120, 196);
  for (int i = 0; i < 6; i++) { llLed(true, false, false); delay(250); llLed(false, false, false); delay(250); }
  llDeepSleep();
}

static void powerCheck(uint32_t ms) {
  // 배터리: 10초마다 재고, 30초 연속으로 낮을 때만 판단 (잠깐 떨어지는 것 무시)
  static uint32_t lastBatMs = 0;
  static uint8_t lowCnt = 0, critCnt = 0;
  static bool warned = false;
  if (ms - lastBatMs >= 10000) {
    lastBatMs = ms;
    int mv = batteryMilliVolts();
    bool plausible = mv > 2900 && mv < 4400;   // 측정값이 이상하면(배터리 없음 등) 판단하지 않음
    lowCnt  = (plausible && mv < 3450) ? lowCnt + 1 : 0;
    critCnt = (plausible && mv < 3300) ? critCnt + 1 : 0;
    if (lowCnt >= 3) {
      hwLowBattery = true;
      if (!warned) { warned = true; hwSaveNow(); }
      ledFlash(true, false, false, 150);
    } else if (lowCnt == 0) {
      hwLowBattery = false; warned = false;
    }
    if (critCnt >= 3) lowBatteryShutdown();
  }
  // 자동 절전
  uint8_t idx = settings.sleepIdx < 5 ? settings.sleepIdx : 0;
  if (!idx || hwKeepAwake || hwNetBusy || soundBusy || tPressed) { lastActivity = ms; return; }
  uint32_t limit = SLEEP_MINUTES[idx] * 60000UL;
  uint32_t idle = ms - lastActivity;
  if (idle >= limit) enterSleep();
  else if (!dimmed && idle + 15000 >= limit) { dimmed = true; lcd.setBrightness(8); }
}

Touch readTouch() {
  hwUpdate();
  Touch ev = { T_NONE, tLastX, tLastY, tStartX, tStartY, false, false };
  int16_t x, y;
  bool now = llTouchScreen(x, y);
  uint32_t ms = millis();
  if (now) lastActivity = ms;

  // 절전에서 깨운 손가락 / 어두운 화면을 밝힌 손가락은 뗄 때까지 무시
  if (swallow) {
    if (now) tMissCount = 0;
    else if (++tMissCount >= 2) { swallow = false; tPressed = false; tMissCount = 0; }
    return ev;
  }
  if (now && dimmed) {
    dimmed = false; settingsApply();
    swallow = true; tMissCount = 0;
    return ev;
  }
  if (!now) powerCheck(ms);

  if (now) {
    tMissCount = 0;
    if (!tPressed) {
      tPressed = true; tLongSent = false; tMoved = false;
      tStartX = tLastX = x; tStartY = tLastY = y; tStartMs = ms;
      ev.type = T_DOWN; ev.x = x; ev.y = y; ev.sx = x; ev.sy = y;
      return ev;
    }
    if (abs(x - tStartX) > 10 || abs(y - tStartY) > 10) tMoved = true;
    if (!tLongSent && !tMoved && ms - tStartMs > 450) {
      tLongSent = true;
      ev.type = T_LONG; ev.x = tStartX; ev.y = tStartY;
      return ev;
    }
    if (x != tLastX || y != tLastY) {
      tLastX = x; tLastY = y;
      ev.type = T_MOVE; ev.x = x; ev.y = y;
      return ev;
    }
    return ev;
  }

  // 저항막 터치는 순간적으로 끊겨 보일 때가 있어서 두 번 연속 '안 눌림'일 때 뗀 것으로 봄
  if (tPressed && ++tMissCount >= 2) {
    tPressed = false;
    ev.type = T_UP; ev.x = tLastX; ev.y = tLastY;
    ev.tap = !tMoved && !tLongSent;
    ev.longed = tLongSent;
    return ev;
  }
  return ev;
}

void waitRelease() {
  while (true) {
    Touch t = readTouch();
    if (!tPressed) break;
    (void)t;
    delay(5);
  }
}

// ---------------------------------------------------------------------
//  소리
// ---------------------------------------------------------------------
static uint16_t melody[64];
static int      melodyLen = 0, melodyPos = 0;
static uint32_t noteEndMs = 0;

static void startNote() {
  uint16_t f = melody[melodyPos * 2], d = melody[melodyPos * 2 + 1];
  if (f && settings.volume) llToneOn(f); else llToneOff();
  noteEndMs = millis() + d;
}

void playMelody(const uint16_t* notes, int count) {
  if (settings.volume == 0) return;
  if (count > 32) count = 32;
  for (int i = 0; i < count * 2; i++) melody[i] = notes[i];
  melodyLen = count; melodyPos = 0; soundBusy = true;
  startNote();
}

void beep(uint16_t freq, uint16_t ms) {
  uint16_t n[2] = { freq, ms };
  playMelody(n, 1);
}

void soundStop() { soundBusy = false; llToneOff(); }

void sfx(Sfx s) {
  static const uint16_t CLICK[] = { 1800, 15 };
  static const uint16_t OK[]    = { 1047, 70, 1568, 110 };
  static const uint16_t WRONG[] = { 330, 120, 0, 30, 247, 200 };
  static const uint16_t WIN[]   = { 523, 100, 659, 100, 784, 100, 1047, 250, 0, 60, 784, 100, 1047, 300 };
  static const uint16_t LOSE[]  = { 392, 150, 330, 150, 262, 150, 196, 400 };
  static const uint16_t FLAG[]  = { 1319, 40, 1760, 40 };
  static const uint16_t ALARM[] = { 1760, 150, 0, 80, 1760, 150, 0, 80, 1760, 150, 0, 400,
                                    1760, 150, 0, 80, 1760, 150, 0, 80, 1760, 150 };
  static const uint16_t TICK[]  = { 2400, 8 };
  switch (s) {
    case SFX_CLICK: playMelody(CLICK, 1); break;
    case SFX_OK:    playMelody(OK, 2); break;
    case SFX_WRONG: playMelody(WRONG, 3); break;
    case SFX_WIN:   playMelody(WIN, 7); break;
    case SFX_LOSE:  playMelody(LOSE, 4); break;
    case SFX_FLAG:  playMelody(FLAG, 2); break;
    case SFX_ALARM: playMelody(ALARM, 11); break;
    case SFX_TICK:  playMelody(TICK, 1); break;
  }
}

// ---------------------------------------------------------------------
//  LED
// ---------------------------------------------------------------------
static uint32_t ledOffMs = 0;
void led(bool r, bool g, bool b) { ledOffMs = 0; llLed(r, g, b); }
void ledFlash(bool r, bool g, bool b, uint16_t ms) { llLed(r, g, b); ledOffMs = millis() + ms; if (!ledOffMs) ledOffMs = 1; }

// ---------------------------------------------------------------------
void hwUpdate() {
  uint32_t now = millis();
  if (soundBusy && (int32_t)(now - noteEndMs) >= 0) {
    if (++melodyPos >= melodyLen) { soundBusy = false; llToneOff(); }
    else startNote();
  }
  if (ledOffMs && (int32_t)(now - ledOffMs) >= 0) { ledOffMs = 0; llLed(false, false, false); }
}

int batteryPercent() {
  int mv = batteryMilliVolts();
  // 리튬 폴리머 3.3V(0%) ~ 4.15V(100%) 정도로 대략 계산
  int p = (mv - 3300) * 100 / (4150 - 3300);
  if (p < 0) p = 0;
  if (p > 100) p = 100;
  return p;
}

void settingsSave() {
  kvSetInt("bright", settings.brightness);
  kvSetInt("volume", settings.volume);
  kvSetInt("invert", settings.invert);
  kvSetInt("flip", settings.flip);
  kvSetInt("sleep", settings.sleepIdx);
}

void settingsApply() {
  static const uint8_t LV[6] = { 0, 30, 70, 120, 180, 255 };
  if (settings.brightness < 1) settings.brightness = 1;
  if (settings.brightness > 5) settings.brightness = 5;
  lcd.setBrightness(LV[settings.brightness]);
  lcd.invertDisplay(settings.invert);
  lcd.setRotation(settings.flip ? 2 : 0);
}

static void settingsLoad() {
  settings.brightness = kvGetInt("bright", 3);
  settings.volume     = kvGetInt("volume", 2);
  settings.invert     = kvGetInt("invert", 0);
  settings.flip       = kvGetInt("flip", 0);
  settings.sleepIdx   = kvGetInt("sleep", 2);
}

void hwBegin() {
  llBegin();
  settingsLoad();
  lcd.init();
  settingsApply();
  lcd.fillScreen(TFT_BLACK);
  lastActivity = millis();
}

// =====================================================================
//  ↓↓↓ 여기부터는 ESP32 보드 전용 코드 ↓↓↓
// =====================================================================
#ifdef ARDUINO
#include <Preferences.h>
#include <LittleFS.h>
#include "esp_sleep.h"
#include "driver/gpio.h"

static Preferences prefs;
static bool fsReady = false;

// ---- 터치 보정값: 화면 x=0, x=239, y=0, y=319 에 해당하는 터치 원시값 ----
struct TouchCal { int16_t swap, x0, x1, y0, y1; };
static TouchCal cal = { 0, 3800, 300, 300, 3800 };

// XPT2046 를 소프트웨어 SPI 로 직접 읽기 (SD카드와 SPI 충돌을 피하려고)
static uint16_t xpt(uint8_t cmd) {
  for (int i = 7; i >= 0; i--) {
    digitalWrite(PIN_TP_MOSI, (cmd >> i) & 1);
    digitalWrite(PIN_TP_CLK, HIGH); delayMicroseconds(1);
    digitalWrite(PIN_TP_CLK, LOW);  delayMicroseconds(1);
  }
  digitalWrite(PIN_TP_MOSI, LOW);
  uint16_t r = 0;
  for (int i = 0; i < 16; i++) {
    digitalWrite(PIN_TP_CLK, HIGH); delayMicroseconds(1);
    r = (r << 1) | digitalRead(PIN_TP_MISO);
    digitalWrite(PIN_TP_CLK, LOW);  delayMicroseconds(1);
  }
  return (r >> 3) & 0x0FFF;   // 12비트 값 (0~4095)
}

// 터치 원시값 읽기. 눌려 있지 않으면 false
static bool xptRead(int16_t& rx, int16_t& ry) {
  digitalWrite(PIN_TP_CS, LOW);
  int z1 = xpt(0xB1), z2 = xpt(0xC1);
  int z = z1 + 4095 - z2;
  if (z < 450) { xpt(0xD0); digitalWrite(PIN_TP_CS, HIGH); return false; }
  int xs[5], ys[5];
  xpt(0x91);                                  // 첫 값은 버림
  for (int i = 0; i < 5; i++) { ys[i] = xpt(0x91); xs[i] = xpt(0xD1); }
  z1 = xpt(0xB1); z2 = xpt(0xC0);             // 마지막에 다시 확인 + 절전
  digitalWrite(PIN_TP_CS, HIGH);
  if (z1 + 4095 - z2 < 450) return false;
  // 정렬해서 가운데 3개 평균 (튀는 값 제거)
  for (int i = 0; i < 4; i++) for (int j = i + 1; j < 5; j++) {
    if (xs[j] < xs[i]) { int t = xs[i]; xs[i] = xs[j]; xs[j] = t; }
    if (ys[j] < ys[i]) { int t = ys[i]; ys[i] = ys[j]; ys[j] = t; }
  }
  if (xs[3] - xs[1] > 120 || ys[3] - ys[1] > 120) return false;   // 너무 흔들리면 무시
  rx = (xs[1] + xs[2] + xs[3]) / 3;
  ry = (ys[1] + ys[2] + ys[3]) / 3;
  return true;
}

bool llTouchScreen(int16_t& x, int16_t& y) {
  int16_t rx, ry;
  if (!xptRead(rx, ry)) return false;
  int16_t a = cal.swap ? ry : rx;
  int16_t b = cal.swap ? rx : ry;
  int32_t sx = (int32_t)(a - cal.x0) * 239 / (cal.x1 - cal.x0);
  int32_t sy = (int32_t)(b - cal.y0) * 319 / (cal.y1 - cal.y0);
  if (sx < 0) sx = 0;
  if (sx > 239) sx = 239;
  if (sy < 0) sy = 0;
  if (sy > 319) sy = 319;
  if (settings.flip) { sx = 239 - sx; sy = 319 - sy; }
  x = sx; y = sy;
  return true;
}

// 보정용: 손가락(펜)을 누르고 있는 동안 평균값을 구함
static void calSample(int px, int py, int16_t& rx, int16_t& ry) {
  lcd.fillScreen(TFT_WHITE);
  lcd.setTextColor(TFT_BLACK, TFT_WHITE);
  lcd.setFont(&fonts::efontKR_16);
  lcd.setTextDatum(middle_center);
  lcd.drawString("터치 보정", 120, 130);
  lcd.drawString("빨간 + 의 가운데를", 120, 160);
  lcd.drawString("펜으로 꾹 눌러 주세요", 120, 182);
  lcd.drawFastHLine(px - 12, py, 25, TFT_RED);
  lcd.drawFastVLine(px, py - 12, 25, TFT_RED);
  lcd.drawCircle(px, py, 6, TFT_RED);
  int16_t a, b;
  while (xptRead(a, b)) delay(10);        // 이전 터치 떼기
  delay(200);
  long sa = 0, sb = 0; int n = 0;
  while (n < 30) {
    if (xptRead(a, b)) { sa += a; sb += b; n++; }
    delay(10);
  }
  rx = sa / n; ry = sb / n;
  lcd.fillCircle(px, py, 6, TFT_GREEN);
  llToneOn(1500); delay(60); llToneOff();
  while (xptRead(a, b)) delay(10);
  delay(150);
}

void touchCalibrate() {
  lcd.setRotation(0);
  int16_t ax, ay, bx, by, cx, cy;
  calSample(20, 20, ax, ay);      // 왼쪽 위
  calSample(220, 20, bx, by);     // 오른쪽 위  (화면 x 만 바뀜)
  calSample(20, 300, cx, cy);     // 왼쪽 아래  (화면 y 만 바뀜)
  // 화면 x 가 바뀔 때 원시값 x, y 중 어느 쪽이 더 많이 변했는지로 축 뒤바뀜 판단
  cal.swap = abs(by - ay) > abs(bx - ax) ? 1 : 0;
  int16_t a1 = cal.swap ? ay : ax, a2 = cal.swap ? by : bx;   // x축 원시값
  int16_t b1 = cal.swap ? ax : ay, b3 = cal.swap ? cx : cy;   // y축 원시값
  // 20 -> 220 (200픽셀) 을 0 -> 239 로 늘리기
  cal.x0 = a1 - (int32_t)(a2 - a1) * 20 / 200;
  cal.x1 = a1 + (int32_t)(a2 - a1) * 219 / 200;
  cal.y0 = b1 - (int32_t)(b3 - b1) * 20 / 280;
  cal.y1 = b1 + (int32_t)(b3 - b1) * 299 / 280;
  if (cal.x1 == cal.x0) cal.x1 = cal.x0 + 1;
  if (cal.y1 == cal.y0) cal.y1 = cal.y0 + 1;
  kvSetBytes("tcal", &cal, sizeof(cal));
  settingsApply();
}

// ---- 소리: 스피커 핀에 PWM 으로 음을 냄 ----
static uint8_t volDuty() {
  static const uint8_t D[4] = { 0, 6, 24, 128 };   // 듀티가 작을수록 작은 소리
  return D[settings.volume & 3];
}
#if ESP_ARDUINO_VERSION_MAJOR >= 3
void llToneOn(uint16_t f)  { digitalWrite(PIN_AMP_EN, LOW); ledcWriteTone(PIN_SPK, f); ledcWrite(PIN_SPK, volDuty()); }
void llToneOff()           { ledcWriteTone(PIN_SPK, 0); ledcWrite(PIN_SPK, 0); digitalWrite(PIN_AMP_EN, HIGH); }
static void toneSetup()    { ledcAttach(PIN_SPK, 2000, 8); ledcWrite(PIN_SPK, 0); }
#else
#define SPK_CH 0
void llToneOn(uint16_t f)  { digitalWrite(PIN_AMP_EN, LOW); ledcWriteTone(SPK_CH, f); ledcWrite(SPK_CH, volDuty()); }
void llToneOff()           { ledcWriteTone(SPK_CH, 0); ledcWrite(SPK_CH, 0); digitalWrite(PIN_AMP_EN, HIGH); }
static void toneSetup()    { ledcSetup(SPK_CH, 2000, 8); ledcAttachPin(PIN_SPK, SPK_CH); ledcWrite(SPK_CH, 0); }
#endif

void llLed(bool r, bool g, bool b) {
  digitalWrite(PIN_LED_R, r ? LOW : HIGH);
  digitalWrite(PIN_LED_G, g ? LOW : HIGH);
  digitalWrite(PIN_LED_B, b ? LOW : HIGH);
}

// ---- 가벼운 절전: 화면 끄고 CPU 멈춤. 터치(IRQ) 또는 BOOT 버튼으로 깨어나 이어서 실행 ----
void llSleep() {
  static uint8_t spurious = 0;                 // 아무것도 안 눌렸는데 깨어난 횟수
  lcd.sleep();                                 // 백라이트 끄고 화면 칩 절전 (화면 내용은 유지)
  digitalWrite(PIN_AMP_EN, HIGH);
  while (true) {
    bool useTouch = spurious < 3 && digitalRead(PIN_TP_IRQ) == HIGH;
    if (useTouch) gpio_wakeup_enable((gpio_num_t)PIN_TP_IRQ, GPIO_INTR_LOW_LEVEL);
    gpio_wakeup_enable((gpio_num_t)PIN_BOOT, GPIO_INTR_LOW_LEVEL);
    esp_sleep_enable_gpio_wakeup();
    Serial.flush();
    esp_light_sleep_start();
    gpio_wakeup_disable((gpio_num_t)PIN_TP_IRQ);
    gpio_wakeup_disable((gpio_num_t)PIN_BOOT);
    delay(30);
    int16_t a, b;
    if (digitalRead(PIN_BOOT) == LOW || xptRead(a, b)) { spurious = 0; break; }
    spurious++;                                // 잘못 깨어남 → 다시 잠들기 (3번 넘으면 BOOT 로만 깨움)
  }
  lcd.wakeup();
}

// ---- 깊은 절전: BOOT 버튼(LOW)으로만 깨어남. 깨어나면 처음부터 다시 시작 ----
void llDeepSleep() {
  lcd.sleep();
  digitalWrite(PIN_AMP_EN, HIGH);
  llLed(false, false, false);
  while (digitalRead(PIN_BOOT) == LOW) delay(10);
  esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_BOOT, 0);
  esp_deep_sleep_start();
}

int batteryMilliVolts() {
  // 배터리 전압이 1/2 로 나뉘어 들어온다고 보고 2배 (보드마다 다를 수 있어요)
  uint32_t s = 0;
  for (int i = 0; i < 8; i++) s += analogReadMilliVolts(PIN_BAT);
  return s / 8 * 2;
}

void llBegin() {
  Serial.begin(115200);
  pinMode(PIN_TP_CLK, OUTPUT);  pinMode(PIN_TP_MOSI, OUTPUT);
  pinMode(PIN_TP_CS, OUTPUT);   pinMode(PIN_TP_MISO, INPUT);
  pinMode(PIN_TP_IRQ, INPUT);
  digitalWrite(PIN_TP_CS, HIGH); digitalWrite(PIN_TP_CLK, LOW);
  pinMode(PIN_LED_R, OUTPUT); pinMode(PIN_LED_G, OUTPUT); pinMode(PIN_LED_B, OUTPUT);
  llLed(false, false, false);
  pinMode(PIN_AMP_EN, OUTPUT); digitalWrite(PIN_AMP_EN, HIGH);
  pinMode(PIN_BOOT, INPUT_PULLUP);
  toneSetup();
  prefs.begin("studypad", false);
  fsReady = LittleFS.begin(true);       // 처음엔 자동 포맷
  if (prefs.getBytesLength("tcal") == sizeof(cal)) prefs.getBytes("tcal", &cal, sizeof(cal));
}

// ※ BOOT 버튼을 누른 채 전원을 켜면 ESP32 가 '업로드 대기 모드'로 들어가서 코드가 실행되지 않아요.
//   그래서 켜진 뒤 시작 화면('스터디패드' 글자)이 보일 때 BOOT 를 누르면 보정하도록 했어요.
bool bootButtonDown() { return digitalRead(PIN_BOOT) == LOW; }
bool touchNeedsCalibration() {
  return prefs.getBytesLength("tcal") != sizeof(cal) || bootButtonDown();
}

int32_t kvGetInt(const char* key, int32_t def) { return prefs.getInt(key, def); }
void    kvSetInt(const char* key, int32_t v)   { prefs.putInt(key, v); }
bool    kvGetBytes(const char* key, void* buf, size_t len) {
  if (prefs.getBytesLength(key) != len) return false;
  return prefs.getBytes(key, buf, len) == len;
}
void    kvSetBytes(const char* key, const void* buf, size_t len) { prefs.putBytes(key, buf, len); }
void    kvClearAll() {
  TouchCal keep = cal;
  prefs.clear();
  prefs.putBytes("tcal", &keep, sizeof(keep));
  settingsSave();
}

bool fileSave(const char* path, const void* buf, size_t len) {
  if (!fsReady) return false;
  File f = LittleFS.open(path, "w");
  if (!f) return false;
  size_t w = f.write((const uint8_t*)buf, len);
  f.close();
  return w == len;
}
bool fileLoad(const char* path, void* buf, size_t len) {
  if (!fsReady || !LittleFS.exists(path)) return false;
  File f = LittleFS.open(path, "r");
  if (!f) return false;
  size_t r = f.read((uint8_t*)buf, len);
  f.close();
  return r == len;
}
bool fileExists(const char* path) { return fsReady && LittleFS.exists(path); }
void fileRemove(const char* path) { if (fsReady && LittleFS.exists(path)) LittleFS.remove(path); }

#endif  // ARDUINO
