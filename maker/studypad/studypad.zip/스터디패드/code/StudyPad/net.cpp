// =====================================================================
//  net.cpp  -  와이파이 · 인터넷 시간 · 날씨 · 미세먼지 · 위치 (net.h 설명 참고)
//
//  날씨·미세먼지 : Open-Meteo (open-meteo.com, 비상업 무료 · 열쇠 필요 없음)
//  위치 찾기     : beaconDB (주변 와이파이) → 안 되면 ip-api.com (인터넷 주소, 대략)
//  미세먼지는 모델로 계산한 값이라 에어코리아 측정소 값과 조금 다를 수 있어요.
//
//  📁 이 파일은 고치지 않아도 됩니다.
// =====================================================================
#include "net.h"
#include <sys/time.h>

#ifdef ARDUINO
  #include <Preferences.h>
  #include <WiFi.h>
  #include <HTTPClient.h>
  #include <WiFiClientSecure.h>
  #include "esp_sntp.h"
  static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;   // 두 작업이 같이 쓰는 값 보호
  #define LOCK()   portENTER_CRITICAL(&mux)
  #define UNLOCK() portEXIT_CRITICAL(&mux)
  #define SIM_POLL()
#else
  #define LOCK()
  #define UNLOCK()
  namespace Net { static void simPoll(); }      // PC 시뮬레이터: 누르면 바로 결과
  #define SIM_POLL() Net::simPoll()
#endif

namespace Net {

const Place CITIES[CITY_N] = {
  {"서울", 37.5665f, 126.9780f}, {"인천", 37.4563f, 126.7052f}, {"수원", 37.2636f, 127.0286f},
  {"춘천", 37.8813f, 127.7298f}, {"강릉", 37.7519f, 128.8761f}, {"청주", 36.6424f, 127.4890f},
  {"대전", 36.3504f, 127.3845f}, {"천안", 36.8151f, 127.1139f}, {"전주", 35.8242f, 127.1480f},
  {"광주", 35.1595f, 126.8526f}, {"목포", 34.8118f, 126.3922f}, {"대구", 35.8714f, 128.6014f},
  {"포항", 36.0190f, 129.3435f}, {"울산", 35.5384f, 129.3114f}, {"부산", 35.1796f, 129.0756f},
  {"창원", 35.2280f, 128.6811f}, {"제주", 33.4996f, 126.5312f},
};

// ------------------------------ 상태 ------------------------------
static volatile State    st        = N_OFF;
static volatile uint32_t ver       = 0;
static const char* volatile msg    = "";
static volatile uint32_t lastOkMs  = 0;
static volatile bool     wantNow   = false;
static volatile bool     wantScan  = false;
static Weather           wx        = {false, 0, -1, -1, true, -1, -1, 0};

static Cred              creds[MAX_CRED];
static volatile uint8_t  nCred     = 0;
static char              lastSsid[33] = "";
static ScanItem          scanList[8];
static volatile uint8_t  scanN     = 0;
static volatile uint8_t  scanSt    = 0;

static volatile uint8_t  locM      = 0;
static volatile bool     autoFound = false;
static float             autoLat = 0, autoLon = 0;
static uint8_t           autoSrc   = 0;      // 1 = 주변 와이파이로, 2 = 인터넷 주소로
static char              autoSsid[33] = "";
static uint32_t          autoAtMs  = 0;

static void bump() { ver = ver + 1; }
static void setMsg(const char* m) { msg = m; bump(); }
static void saveCreds();
static void saveLoc();

State       state()     { SIM_POLL(); return st; }
uint32_t    version()   { SIM_POLL(); return ver; }
bool        busy()      { return st == N_BUSY; }
bool        ready()     { return nCred > 0; }
const char* lastMsg()   { return msg; }
static uint32_t refreshMs() { return (uint32_t)constrain(NET_REFRESH_MIN, 10, 120) * 60000UL; }
bool fresh() { return lastOkMs != 0 && millis() - lastOkMs < refreshMs() * 2 + 60000UL; }

Weather weather() { LOCK(); Weather w = wx; UNLOCK(); return w; }
void connectedSsid(char* out, size_t n) { LOCK(); strlcpy(out, lastSsid, n); UNLOCK(); }
void requestNow()  { wantNow = true; }
void requestScan() { scanSt = 1; wantScan = true; bump(); }

int  credCount() { return nCred; }
bool getCred(int i, Cred& out) {
  bool ok = false;
  LOCK(); if (i >= 0 && i < nCred) { out = creds[i]; ok = true; } UNLOCK();
  return ok;
}
bool isSaved(const char* ssid) {
  bool f = false;
  LOCK(); for (int i = 0; i < nCred; i++) if (strcmp(creds[i].ssid, ssid) == 0) f = true; UNLOCK();
  return f;
}
// 새로 넣은 와이파이는 맨 위로. 같은 이름이면 비밀번호만 바뀜. 4개째면 맨 아래 것이 빠짐.
void addCred(const char* ssid, const char* pass) {
  if (!ssid || !ssid[0]) return;
  Cred c = {};
  strlcpy(c.ssid, ssid, sizeof(c.ssid));
  strlcpy(c.pass, pass ? pass : "", sizeof(c.pass));
  LOCK();
  Cred t[MAX_CRED]; int k = 0;
  t[k++] = c;
  for (int i = 0; i < nCred && k < MAX_CRED; i++) if (strcmp(creds[i].ssid, ssid) != 0) t[k++] = creds[i];
  memcpy(creds, t, sizeof(Cred) * k);
  nCred = k;
  UNLOCK();
  saveCreds();
  wantNow = true;
  bump();
}
void removeCred(int idx) {
  LOCK();
  if (idx >= 0 && idx < nCred) {
    for (int i = idx; i < nCred - 1; i++) creds[i] = creds[i + 1];
    nCred = nCred - 1;
  }
  UNLOCK();
  saveCreds();
  bump();
}

uint8_t scanState() { SIM_POLL(); return scanSt; }
int     scanCount() { return scanN; }
bool getScan(int i, ScanItem& out) {
  bool ok = false;
  LOCK(); if (i >= 0 && i < scanN) { out = scanList[i]; ok = true; } UNLOCK();
  return ok;
}

// ------------------------------ 위치 ------------------------------
uint8_t locMode() { return locM; }
static void currentLoc(float& lat, float& lon) {
  uint8_t m = locM;
  if (m >= 1 && m <= CITY_N) { lat = CITIES[m - 1].lat; lon = CITIES[m - 1].lon; return; }
  if (autoFound)             { lat = autoLat; lon = autoLon; return; }
  lat = WEATHER_LAT; lon = WEATHER_LON;
}
static int nearestCity(float lat, float lon, float& km) {
  int best = 0; float bd = 1e9f;
  for (int i = 0; i < CITY_N; i++) {
    float dy = (lat - CITIES[i].lat) * 111.0f;
    float dx = (lon - CITIES[i].lon) * 111.0f * cosf(lat * 0.0174533f);
    float d = sqrtf(dx * dx + dy * dy);
    if (d < bd) { bd = d; best = i; }
  }
  km = bd;
  return best;
}
void placeName(char* out, size_t n, bool shortName) {
  uint8_t m = locM;
  if (m >= 1 && m <= CITY_N) { strlcpy(out, CITIES[m - 1].name, n); return; }
  float lat, lon, km;
  currentLoc(lat, lon);
  int i = nearestCity(lat, lon, km);
  if (km < 30 || (shortName && km < 100)) strlcpy(out, CITIES[i].name, n);
  else if (km < 100) snprintf(out, n, "%s 근처", CITIES[i].name);
  else strlcpy(out, "현재 위치", n);
}
const char* locDetail() {
  if (locM >= 1)  return "직접 고른 곳";
  if (!autoFound) return busy() ? "찾는 중..." : "아직 못 찾음 · 기본 위치";
  return autoSrc == 1 ? "주변 와이파이로 찾음" : "인터넷 주소로 찾음(대략)";
}
void setLocMode(uint8_t m) {
  if (m > CITY_N) m = 0;
  locM = m;
  if (m == 0) autoAtMs = 0;                      // 자동 → 바로 다시 찾기
  LOCK(); wx.has = false; UNLOCK();              // 다른 곳 날씨가 남아 있지 않게
  saveLoc();
  wantNow = true;
  bump();
}

}  // namespace Net

// =====================================================================
//                          보드 안 시계
// =====================================================================
namespace Clock {

static bool     restored = false;      // 저장해 둔 시간으로 되살림 → 확인 필요
static uint32_t lastSaveMs = 0;
static void useKoreaTime() {
  static bool done = false;
  if (!done) { setenv("TZ", "KST-9", 1); tzset(); done = true; }
}
#ifdef ARDUINO
time_t now() { useKoreaTime(); return time(nullptr); }
static void setSystem(time_t t) { timeval tv = {t, 0}; settimeofday(&tv, nullptr); }
#else
static time_t simBase = 0;             // PC 시뮬레이터: 가짜 시계
time_t now() { useKoreaTime(); return simBase ? simBase + millis() / 1000 : (time_t)(millis() / 1000); }
static void setSystem(time_t t) { simBase = t - millis() / 1000; }
#endif
bool   valid()      { return now() > 1735657200; }          // 2025-01-01 이후면 맞춘 시간
bool   needsCheck() { return restored; }
void   local(time_t t, struct tm& out) { useKoreaTime(); localtime_r(&t, &out); }
time_t make(struct tm& t) { useKoreaTime(); t.tm_isdst = 0; return mktime(&t); }

static void save() {
  if (!valid()) return;
#ifdef ARDUINO
  Preferences p; p.begin("clocktime", false);
  p.putUInt("t", (uint32_t)now());
  p.end();
#endif
  lastSaveMs = millis();
}
void set(time_t t) {
  setSystem(t);
  restored = false;
  save();
  Net::bump();
}
static void begin() {
  useKoreaTime();
  if (valid()) return;                         // 깊은 절전에서 깨어남 → 시간이 계속 흘렀음
#ifdef ARDUINO
  Preferences p; p.begin("clocktime", true);
  uint32_t saved = p.getUInt("t", 0);
  p.end();
  if (saved > 1735657200UL) { setSystem((time_t)saved); restored = true; }
#endif
}

}  // namespace Clock

#ifdef ARDUINO
// =====================================================================
//                 뒤에서 도는 부분 (보드에서만, 따로 된 작업)
// =====================================================================
namespace Net {

static void saveCreds() {
  Cred c[MAX_CRED]; int n;
  LOCK(); n = nCred; memcpy(c, creds, sizeof(creds)); UNLOCK();
  Preferences p; p.begin("netcfg", false);
  p.putUChar("n", n);
  for (int i = 0; i < MAX_CRED; i++) {
    char ks[4] = {'s', (char)('0' + i), 0}, kp[4] = {'p', (char)('0' + i), 0};
    if (i < n) { p.putString(ks, c[i].ssid); p.putString(kp, c[i].pass); }
    else       { p.remove(ks); p.remove(kp); }
  }
  p.end();
}
static void saveLoc() {
  Preferences p; p.begin("netcfg", false);
  p.putUChar("loc", locM);
  p.putBool("af", autoFound);
  p.putFloat("alat", autoLat);
  p.putFloat("alon", autoLon);
  p.putUChar("asrc", autoSrc);
  p.end();
}

static volatile bool ntpDone = false;
static void onNtp(struct timeval*) { ntpDone = true; }
static time_t   httpTime   = 0;                  // 날씨 서버가 알려 준 시각 (NTP 가 막혔을 때)
static uint32_t httpTimeMs = 0;

struct Ap { uint8_t mac[6]; int8_t rssi; };
static Ap       aps[12];
static int      nAps = 0;
static ScanItem seen[16];
static int      nSeen = 0;

// "Thu, 26 Nov 2026 07:17:00 GMT" → 1970년부터 센 초
static time_t parseHttpDate(const char* s) {
  const char* c = strchr(s, ',');
  if (!c) return 0;
  char mon[4] = {0};
  int d, y, h, mi, se;
  if (sscanf(c + 1, " %d %3s %d %d:%d:%d", &d, mon, &y, &h, &mi, &se) != 6) return 0;
  static const char* M = "JanFebMarAprMayJunJulAugSepOctNovDec";
  const char* p = strstr(M, mon);
  if (!p) return 0;
  int m = (int)(p - M) / 3 + 1;
  y -= (m <= 2);
  long era = (y >= 0 ? y : y - 399) / 400;
  long yoe = y - era * 400;
  long doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  long days = era * 146097L + doe - 719468L;
  return (time_t)days * 86400 + h * 3600 + mi * 60 + se;
}

static void doScan() {
  int n = WiFi.scanNetworks(false, true);
  if (n < 0) n = 0;
  nAps = 0; nSeen = 0;
  for (int i = 0; i < n; i++) {
    String s = WiFi.SSID(i);
    int r = WiFi.RSSI(i);
    if (nAps < 12 && !s.endsWith("_nomap")) {    // '_nomap' = 위치 찾기에 쓰지 말라는 표시
      memcpy(aps[nAps].mac, WiFi.BSSID(i), 6);
      aps[nAps].rssi = (int8_t)r;
      nAps++;
    }
    if (!s.length()) continue;                   // 숨긴 와이파이
    int k = -1;
    for (int j = 0; j < nSeen; j++) if (strcmp(seen[j].ssid, s.c_str()) == 0) k = j;
    if (k >= 0) { if (r > seen[k].rssi) seen[k].rssi = (int8_t)r; continue; }
    if (nSeen >= 16) continue;
    strlcpy(seen[nSeen].ssid, s.c_str(), sizeof(seen[0].ssid));
    seen[nSeen].rssi = (int8_t)r;
    seen[nSeen].open = (WiFi.encryptionType(i) == WIFI_AUTH_OPEN);
    nSeen++;
  }
  WiFi.scanDelete();
  for (int i = 1; i < nSeen; i++)                // 신호 센 것부터
    for (int j = i; j > 0 && seen[j].rssi > seen[j - 1].rssi; j--) { ScanItem t = seen[j]; seen[j] = seen[j - 1]; seen[j - 1] = t; }
  LOCK();
  int m = nSeen < 8 ? nSeen : 8;
  memcpy(scanList, seen, sizeof(ScanItem) * m);
  scanN = m;
  UNLOCK();
  scanSt = 2;
  wantScan = false;
  bump();
  Serial.printf("[인터넷] 와이파이 %d개 찾음\n", nSeen);
}

static bool connectTo(const char* ssid, const char* pass, uint32_t waitMs) {
  if (!ssid || !ssid[0]) return false;
  Serial.printf("[인터넷] 와이파이 '%s' 연결 중\n", ssid);
  WiFi.begin(ssid, pass);
  uint32_t t0 = millis();
  wl_status_t s = WL_IDLE_STATUS;
  while (millis() - t0 < waitMs) {
    s = WiFi.status();
    if (s == WL_CONNECTED) { Serial.printf("[인터넷] 연결됨 (%s)\n", WiFi.localIP().toString().c_str()); return true; }
    if (s == WL_CONNECT_FAILED && millis() - t0 > 3000) break;
    vTaskDelay(pdMS_TO_TICKS(200));
  }
  setMsg(s == WL_NO_SSID_AVAIL  ? "와이파이를 못 찾았어요" :
         s == WL_CONNECT_FAILED ? "와이파이 비밀번호 확인" : "와이파이 연결 안 됨");
  Serial.printf("[인터넷] '%s' 연결 실패 (상태 %d)\n", ssid, (int)s);
  WiFi.disconnect();
  vTaskDelay(pdMS_TO_TICKS(300));
  return false;
}

// 저장된 와이파이 중 주변에 보이는 것을 신호 센 순서로 (안 보이는 숨긴 와이파이는 맨 뒤)
static bool connectBest() {
  Cred c[MAX_CRED]; int n;
  LOCK(); n = nCred; memcpy(c, creds, sizeof(creds)); UNLOCK();
  int order[MAX_CRED], rs[MAX_CRED];
  bool anySeen = false;
  for (int i = 0; i < n; i++) {
    order[i] = i; rs[i] = -127;
    for (int j = 0; j < nSeen; j++) if (strcmp(seen[j].ssid, c[i].ssid) == 0) rs[i] = seen[j].rssi;
    if (rs[i] > -127) anySeen = true;
  }
  for (int i = 1; i < n; i++)
    for (int j = i; j > 0 && rs[order[j]] > rs[order[j - 1]]; j--) { int t = order[j]; order[j] = order[j - 1]; order[j - 1] = t; }
  for (int k = 0; k < n; k++) {
    int i = order[k];
    if (connectTo(c[i].ssid, c[i].pass, rs[i] > -127 ? 15000 : 8000)) {
      LOCK(); strlcpy(lastSsid, c[i].ssid, sizeof(lastSsid)); UNLOCK();
      return true;
    }
  }
  if (!anySeen && n > 0) setMsg("저장된 와이파이가 안 보여요");
  return false;
}

// 주소로 받아 오기: http 먼저, 안 되면 https
static bool httpGet(const char* hostPath, String& body) {
  const char* KEYS[] = {"Date"};
  for (int i = 0; i < 2; i++) {
    WiFiClient       plain;
    WiFiClientSecure secure;
    HTTPClient       http;
    String url = String(i == 0 ? "http://" : "https://") + hostPath;
    bool begun;
    if (i == 0) begun = http.begin(plain, url);
    else { secure.setInsecure(); begun = http.begin(secure, url); }   // 날씨라서 인증서 검사는 생략
    if (!begun) continue;
    http.setConnectTimeout(8000);
    http.setTimeout(8000);
    http.collectHeaders(KEYS, 1);
    int code = http.GET();
    if (code == 200) {
      body = http.getString();
      String d = http.header("Date");
      if (d.length()) {
        time_t t = parseHttpDate(d.c_str());
        if (t > 1735657200) { httpTime = t; httpTimeMs = millis(); }
      }
      http.end();
      if (body.length() > 0) return true;
      continue;
    }
    Serial.printf("[인터넷] %s → %d\n", url.c_str(), code);
    http.end();
  }
  return false;
}

// 받은 글(JSON)에서 "key": 숫자 찾기. section 을 주면 "section":{ ... } 안에서만
static bool findNum(const String& b, const char* section, const char* key, float& out) {
  int s = 0, e = -1;
  if (section) {
    s = b.indexOf(String("\"") + section + "\":");
    if (s < 0) return false;
    e = b.indexOf('}', s);
  }
  String k = String("\"") + key + "\":";
  int p = b.indexOf(k, s);
  if (p < 0 || (e > 0 && p > e)) return false;
  const char* c = b.c_str() + p + k.length();
  while (*c == ' ') c++;
  if (!(*c == '-' || *c == '.' || (*c >= '0' && *c <= '9'))) return false;
  out = atof(c);
  return true;
}

// 주변 와이파이로 위치 찾기 (beaconDB) — 공유기 주소(MAC)와 신호 세기만 보냄
static bool locateWifi(float& lat, float& lon, float& acc) {
  if (nAps < 2) return false;
  String body;
  body.reserve(48 + nAps * 64);
  body = "{\"considerIp\":true,\"wifiAccessPoints\":[";
  char e[80];
  for (int i = 0; i < nAps; i++) {
    const uint8_t* m = aps[i].mac;
    snprintf(e, sizeof(e), "%s{\"macAddress\":\"%02x:%02x:%02x:%02x:%02x:%02x\",\"signalStrength\":%d}",
             i ? "," : "", m[0], m[1], m[2], m[3], m[4], m[5], aps[i].rssi);
    body += e;
  }
  body += "]}";
  WiFiClientSecure sc;
  sc.setInsecure();
  HTTPClient http;
  if (!http.begin(sc, "https://api.beacondb.net/v1/geolocate")) return false;
  http.setConnectTimeout(8000);
  http.setTimeout(8000);
  http.setUserAgent("StudyPad/1.2 (ESP32 classroom clock)");
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  String r = (code == 200) ? http.getString() : String();
  http.end();
  if (code != 200) { Serial.printf("[위치] beaconDB → %d\n", code); return false; }
  if (!findNum(r, nullptr, "lat", lat) || !findNum(r, nullptr, "lng", lon)) return false;
  if (!findNum(r, nullptr, "accuracy", acc)) acc = 99999;
  return lat > -90 && lat < 90 && lon > -180 && lon < 180;
}
// 인터넷 주소로 대략 찾기 (ip-api.com, 비상업 무료)
static bool locateIp(float& lat, float& lon) {
  String b;
  if (!httpGet("ip-api.com/json/?fields=status,lat,lon", b)) return false;
  if (b.indexOf("success") < 0) return false;
  return findNum(b, nullptr, "lat", lat) && findNum(b, nullptr, "lon", lon);
}
static void maybeLocate() {
  if (locM != 0) return;
  char ss[33];
  connectedSsid(ss, sizeof(ss));
  bool need = !autoFound || autoAtMs == 0 || strcmp(ss, autoSsid) != 0 || millis() - autoAtMs > 24UL * 3600 * 1000;
  if (!need) return;
  float wl = 0, wo = 0, acc = 0, il = 0, io = 0;
  bool wOk = locateWifi(wl, wo, acc);
  bool good = wOk && acc <= 20000;               // 20km 안쪽이면 와이파이 위치를 믿음
  uint8_t src = 1;
  float lat = wl, lon = wo;
  if (!good) {
    if (locateIp(il, io)) { lat = il; lon = io; src = 2; good = true; }
    else if (wOk)         { src = 2; good = true; }
  }
  if (!good) { Serial.println("[위치] 못 찾음 → 지난 위치/기본 위치 사용"); return; }
  autoLat = lat; autoLon = lon; autoSrc = src; autoFound = true;
  autoAtMs = millis(); if (!autoAtMs) autoAtMs = 1;
  strlcpy(autoSsid, ss, sizeof(autoSsid));
  saveLoc();
  bump();
}

static bool fetchWeather() {
  float la, lo;
  currentLoc(la, lo);
  char path[240];
  String b;
  snprintf(path, sizeof(path),
           "api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
           "&current=temperature_2m,relative_humidity_2m,weather_code,is_day&timezone=Asia%%2FSeoul",
           (double)la, (double)lo);
  if (!httpGet(path, b)) return false;
  float t, h, c, d;
  if (!findNum(b, "current", "temperature_2m", t)) { Serial.println("[날씨] 기온을 못 읽음"); return false; }
  Weather w = weather();
  if (!w.has) { w.pm10 = -1; w.pm25 = -1; }
  w.temp = t;
  w.hum  = findNum(b, "current", "relative_humidity_2m", h) ? (int)(h + 0.5f) : -1;
  w.code = findNum(b, "current", "weather_code", c) ? (int)c : -1;
  w.day  = findNum(b, "current", "is_day", d) ? (d > 0.5f) : true;
  snprintf(path, sizeof(path),
           "air-quality-api.open-meteo.com/v1/air-quality?latitude=%.4f&longitude=%.4f"
           "&current=pm10,pm2_5&timezone=Asia%%2FSeoul",
           (double)la, (double)lo);
  if (httpGet(path, b)) {
    float p10, p25;
    w.pm10 = findNum(b, "current", "pm10", p10) ? p10 : -1;
    w.pm25 = findNum(b, "current", "pm2_5", p25) ? p25 : -1;
  }                                              // 미세먼지만 실패하면 지난 값을 그대로
  w.has = true;
  w.atMs = millis();
  LOCK(); wx = w; UNLOCK();
  Serial.printf("[날씨] %.1f도 습도 %d%% 날씨 %d · 미세 %.0f 초미세 %.0f\n", w.temp, w.hum, w.code, w.pm10, w.pm25);
  return true;
}

// 한 번: 찾기 → 연결 → 시간 → 위치 → 날씨 → 와이파이 끄기
static bool runOnce() {
  st = N_BUSY; msg = ""; bump();
  hwNetBusy = true;                              // 받는 동안은 자동 절전하지 않기
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  doScan();
  bool conn = connectBest();
  bool timeOk = false, wxOk = false;
  if (conn) {
    msg = "";
    httpTime = 0;
    ntpDone = false;
    configTzTime("KST-9", "time.kriss.re.kr", "pool.ntp.org", "time.google.com");
    uint32_t t0 = millis();
    while (!ntpDone && millis() - t0 < 8000) vTaskDelay(pdMS_TO_TICKS(100));
    timeOk = ntpDone;
    maybeLocate();
    wxOk = fetchWeather();
    if (!timeOk && httpTime) {                   // 학교망에서 NTP 가 막혔을 때: 날씨 서버 시각으로
      Clock::setSystem(httpTime + (time_t)((millis() - httpTimeMs) / 1000));
      timeOk = true;
    }
    if (timeOk) { Clock::restored = false; Clock::save(); }
    if (!timeOk && !wxOk) msg = "인터넷 응답 없음";
    else if (!wxOk)       msg = "날씨 서버 응답 없음";
  }
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);                           // 다 받으면 바로 끔
  bool ok = conn && timeOk && wxOk;
  if (ok) lastOkMs = millis();
  st = ok ? N_OK : N_FAIL;
  hwNetBusy = false;
  bump();
  return ok;
}

static void scanOnly() {
  hwNetBusy = true;
  WiFi.mode(WIFI_STA);
  doScan();
  WiFi.mode(WIFI_OFF);
  hwNetBusy = false;
}

static void task(void*) {
  uint32_t nextAt = millis() + 3000;             // 켜고 3초 뒤 처음
  uint8_t  fails = 0;
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(300));
    if (Clock::valid() && millis() - Clock::lastSaveMs > 30UL * 60 * 1000) Clock::save();   // 30분마다 적어 두기
    if (wantScan) { scanOnly(); continue; }
    if (nCred == 0) { if (st != N_OFF) { st = N_OFF; bump(); } wantNow = false; continue; }
    if (st == N_OFF) { st = N_WAIT; bump(); }
    if (wantNow) { wantNow = false; fails = 0; }
    else if ((int32_t)(millis() - nextAt) < 0) continue;
    if (runOnce()) { fails = 0; nextAt = millis() + refreshMs(); }
    else { if (fails < 5) fails++; nextAt = millis() + fails * 120000UL; }   // 2·4·6·8·10분 뒤 다시
  }
}

void begin() {
  Clock::begin();
  Preferences p;
  if (p.begin("netcfg", true)) {
    int n = p.getUChar("n", 0);
    if (n > MAX_CRED) n = MAX_CRED;
    int k = 0;
    for (int i = 0; i < n; i++) {
      char ks[4] = {'s', (char)('0' + i), 0}, kp[4] = {'p', (char)('0' + i), 0};
      Cred c = {};
      p.getString(ks, c.ssid, sizeof(c.ssid));
      p.getString(kp, c.pass, sizeof(c.pass));
      if (c.ssid[0]) creds[k++] = c;
    }
    nCred = k;
    locM      = p.getUChar("loc", 0);
    autoFound = p.getBool("af", false);
    autoLat   = p.getFloat("alat", 0);
    autoLon   = p.getFloat("alon", 0);
    autoSrc   = p.getUChar("asrc", 0);
    p.end();
  }
  if (locM > CITY_N) locM = 0;
  st = nCred ? N_WAIT : N_OFF;
  sntp_set_time_sync_notification_cb(onNtp);
  // 와이파이 일은 0번 코어에서 (화면·터치는 1번 코어라서 서로 방해하지 않아요)
  xTaskCreatePinnedToCore(task, "net", 12288, nullptr, 1, nullptr, 0);
}

}  // namespace Net

#else
// =====================================================================
//     PC 시뮬레이터용 가짜 (보드에서는 쓰지 않음). SIM_NET=1 이면 날씨가 있는 상태
// =====================================================================
#include <cstdlib>
namespace Net {
static void saveCreds() {}
static void saveLoc() {}
static void simFill() {
  wx = {true, 7.4f, 58, 2, true, 42, 18, millis()};
  st = N_OK; lastOkMs = millis() ? millis() : 1;
  strlcpy(lastSsid, creds[0].ssid, sizeof(lastSsid));
  autoFound = true; autoSrc = 1; autoLat = 35.16f; autoLon = 129.06f;
  struct tm t = {}; t.tm_year = 126; t.tm_mon = 10; t.tm_mday = 27; t.tm_hour = 9; t.tm_min = 41; t.tm_sec = 23;
  Clock::setSystem(Clock::make(t));
}
void begin() {
  Clock::begin();
  const char* e = getenv("SIM_NET");
  if (e && e[0] == '1') {
    Cred a = {"Haeyeon-Maker", "12345678"}, b = {"iPhone", "abcdefgh"};
    creds[0] = a; creds[1] = b; nCred = 2;
    simFill();
  }
  if (e && e[0] == '2') {                     // 꺼졌다 켜져서 저장된 시간부터 가는 상태
    struct tm t = {}; t.tm_year = 126; t.tm_mon = 10; t.tm_mday = 27; t.tm_hour = 8; t.tm_min = 5;
    Clock::setSystem(Clock::make(t)); Clock::restored = true;
  }
}
static void simPoll() {                        // 보드에서는 몇 초 걸리는 일을 바로 끝냄
  if (wantScan) {
    static const ScanItem L[] = {{"Haeyeon-Maker", -48, false}, {"Haeyeon-Guest", -55, true},
      {"iPhone", -61, false}, {"KT_GiGA_2G_7A31", -70, false}, {"U+Net5C2E", -79, false}};
    scanN = 5; memcpy(scanList, L, sizeof(L)); scanSt = 2; wantScan = false; bump();
  }
  if (wantNow && nCred) { wantNow = false; simFill(); bump(); }
}
}  // namespace Net
#endif
