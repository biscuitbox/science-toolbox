// =====================================================================
//  와이파이·날씨 설정  (설정 앱 · 탁상시계 메뉴에서 열려요)
//   ① 저장된 와이파이 3개까지 보기 / 지우기 (지우기는 두 번 눌러야 지워짐)
//   ② [+ 주변 와이파이 찾아서 추가] → 목록에서 고르기 → 화면 키보드로 비밀번호
//      · 목록에 없는 숨긴 와이파이는 [직접 입력] 으로 이름부터 써요
//   ③ 날씨 위치: [자동] (주변 와이파이 · 인터넷 주소로 찾음) 또는 도시 17곳 중 고르기
//   ④ [지금 연결해 보기] 로 바로 시험
//  저장된 와이파이 중 주변에 보이는 것을 신호가 센 순서로 붙어요 (net.cpp).
// =====================================================================
#include "apps.h"
#include "net.h"

namespace {

const uint16_t C_KEY  = UI_RGB(200, 205, 214);   // 특수 키
const uint16_t C_KBG  = UI_RGB(150, 156, 170);   // 키보드 바탕

enum Page : uint8_t { P_MAIN, P_SCAN, P_KEY, P_LOC };
Page     page = P_MAIN;
uint32_t lastVer = 0;
uint8_t  lastScan = 0;
int      delArmed = -1;          // '지우기'를 한 번 누른 줄
uint32_t delAt = 0;

// ------------------------------ 키보드 ------------------------------
char    kbuf[65];
int     klen = 0;
uint8_t layer = 0;               // 0 소문자 / 1 대문자·기호 / 2 기호
bool    forSsid = false;         // true = 와이파이 이름을 쓰는 중
char    pickSsid[33] = "";

enum : uint8_t { K_SHIFT = 1, K_BACK = 2, K_LAYER = 3, K_OK = 4 };
struct KeyDef { int16_t x, y, w, h; uint8_t code; };
KeyDef keys[44];
int    nKeys = 0;
int    pressedKey = -1;

const char* ROWS[3][4] = {
  {"1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"},
  {"!@#$%^&*()", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"},
  {"1234567890", "-_=+[]{}\\|", ";:'\",.<>/", "?`~.-_@"},
};
const int KEY_Y = 92;

void addKey(int x, int y, int w, int h, uint8_t code) {
  if (nKeys < 44) keys[nKeys++] = {(int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h, code};
}
void buildKeys() {
  nKeys = 0;
  for (int r = 0; r < 4; r++) {
    const char* s = ROWS[layer][r];
    int len = strlen(s), y = KEY_Y + r * 44;
    int x0 = (r == 2) ? 12 : (r == 3 ? 36 : 0);
    if (r == 3) addKey(0, y, 36, 40, K_SHIFT);
    for (int i = 0; i < len; i++) addKey(x0 + i * 24, y, 24, 40, (uint8_t)s[i]);
    if (r == 3) addKey(204, y, 36, 40, K_BACK);
  }
  addKey(0,   270, 58,  48, K_LAYER);
  addKey(58,  270, 116, 48, ' ');
  addKey(174, 270, 66,  48, K_OK);
}

void keyText(const char* s, int cx, int cy, uint16_t fg, uint16_t bg, bool ascii) {
  if (ascii) lcd.setFont(&fonts::FreeSansBold9pt7b); else uiFont(12);
  lcd.setTextSize(1);
  uiCenter(s, cx, cy, fg, bg);
}
void drawKey(int i, bool down) {
  if (i < 0 || i >= nKeys) return;
  const KeyDef& k = keys[i];
  bool special = (k.code < 32 || k.code == ' ');
  uint16_t face = down ? C_NET : (k.code == K_OK ? C_NET : (special ? C_KEY : TFT_WHITE));
  uint16_t ink  = (down || k.code == K_OK) ? TFT_WHITE : C_TEXT;
  lcd.fillRect(k.x, k.y, k.w, k.h, C_KBG);
  lcd.fillRoundRect(k.x + 1, k.y + 1, k.w - 2, k.h - 2, 5, face);
  int cx = k.x + k.w / 2, cy = k.y + k.h / 2;
  switch (k.code) {
    case K_SHIFT: keyText(layer == 0 ? "대문자" : (layer == 1 ? "소문자" : "abc"), cx, cy + 1, ink, face, layer == 2); break;
    case K_BACK:  keyText("지움", cx, cy + 1, ink, face, false); break;
    case K_LAYER: keyText(layer == 2 ? "abc" : "#+=", cx, cy, ink, face, true); break;
    case ' ':     keyText("띄어쓰기", cx, cy + 1, ink, face, false); break;
    case K_OK:    uiFont(16); uiCenter("확인", cx, cy + 1, ink, face); break;
    default: { char s[2] = {(char)k.code, 0}; keyText(s, cx, cy, ink, face, true); }
  }
}
void drawKeys() {
  lcd.fillRect(0, KEY_Y - 2, SCREEN_W, SCREEN_H - KEY_Y + 2, C_KBG);
  for (int i = 0; i < nKeys; i++) drawKey(i, false);
}
int keyAt(int x, int y) {
  for (int i = 0; i < nKeys; i++)
    if (x >= keys[i].x && x < keys[i].x + keys[i].w && y >= keys[i].y && y < keys[i].y + keys[i].h) return i;
  return -1;
}
void drawField() {
  lcd.fillRect(0, TOPBAR_H, SCREEN_W, KEY_Y - 2 - TOPBAR_H, C_BG);
  char lab[64];
  if (forSsid) strcpy(lab, "와이파이 이름 (대문자·소문자 그대로)");
  else snprintf(lab, sizeof(lab), "%s 의 비밀번호", pickSsid);
  uiFitText(lab, 120, 43, 228, C_SUB, C_BG, middle_center, 12);
  lcd.fillRoundRect(4, 53, 232, 34, 6, TFT_WHITE);
  lcd.drawRoundRect(4, 53, 232, 34, 6, C_LINE);
  lcd.setFont(&fonts::FreeMonoBold9pt7b);
  lcd.setTextSize(1);
  const char* show = kbuf;
  while (*show && lcd.textWidth(show) > 196) show++;   // 길면 끝부분만
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(C_SUB, TFT_WHITE);
  if (show != kbuf) lcd.drawString("<", 8, 70);
  lcd.setTextColor(C_TEXT, TFT_WHITE);
  lcd.drawString(show, 18, 70);
  int w = lcd.textWidth(show);
  lcd.fillRect(18 + w + 1, 61, 2, 18, C_NET);         // 커서
  char cnt[8]; snprintf(cnt, sizeof(cnt), "%d", klen);
  lcd.setFont(&fonts::Font0);
  lcd.setTextDatum(bottom_right);
  lcd.setTextColor(C_SUB, TFT_WHITE);
  lcd.drawString(cnt, 232, 85);
}

// ------------------------------ 큰 화면 ------------------------------
const Btn B_ADD   = {4, 180, 232, 34};
const Btn B_LOC   = {178, 238, 54, 32};
const Btn B_NOW   = {4, 284, 140, 32};
const Btn B_DONE  = {150, 284, 86, 32};

void drawStatus() {
  lcd.fillRect(0, TOPBAR_H, SCREEN_W, 28, C_BG);
  uint16_t dot = C_SUB;
  char b[64];
  const char* m;
  Net::State s = Net::state();
  if (Net::credCount() == 0)  { m = "와이파이를 추가해 주세요"; }
  else if (Net::busy())       { dot = C_WARN; m = "연결해 보는 중..."; }
  else if (s == Net::N_OK)    { char ss[33]; Net::connectedSsid(ss, sizeof(ss)); dot = C_OK; snprintf(b, sizeof(b), "연결 잘 됨 · %s", ss); m = b; }
  else if (s == Net::N_FAIL)  { dot = C_BAD; m = Net::lastMsg()[0] ? Net::lastMsg() : "연결 안 됨"; }
  else                        { m = "곧 연결해요"; }
  lcd.fillCircle(14, TOPBAR_H + 14, 5, dot);
  uiFitText(m, 26, TOPBAR_H + 14, 208, C_TEXT, C_BG, middle_left);
}

Btn delBtn(int i) { Btn b = {180, (int16_t)(78 + i * 34 + 3), 52, 24}; return b; }

void drawCredRows() {
  for (int i = 0; i < Net::MAX_CRED; i++) {
    int y = 78 + i * 34;
    lcd.fillRect(0, y, SCREEN_W, 32, C_BG);
    Net::Cred c;
    if (Net::getCred(i, c)) {
      lcd.fillRoundRect(4, y, 232, 30, 6, C_CARD);
      uiFitText(c.ssid, 12, y + 15, 160, C_TEXT, C_CARD, middle_left);
      bool armed = (delArmed == i);
      uiButton(delBtn(i), armed ? "정말?" : "지우기", armed ? C_BAD : C_LINE, armed ? TFT_WHITE : C_TEXT, 12);
    } else {
      lcd.drawRoundRect(4, y, 232, 30, 6, C_LINE);
      uiFont(12);
      uiCenter("비어 있음", 120, y + 15, C_SUB, C_BG);
    }
  }
}

void drawLocBox() {
  lcd.fillRect(0, 218, SCREEN_W, 62, C_BG);
  uiFont(12);
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(C_SUB, C_BG);
  lcd.drawString("날씨 위치", 8, 225);
  lcd.fillRoundRect(4, 234, 232, 42, 6, C_CARD);
  char nm[24], line[40];
  Net::placeName(nm, sizeof(nm));
  if (Net::locMode() == 0) snprintf(line, sizeof(line), "자동 · %s", nm);
  else strlcpy(line, nm, sizeof(line));
  uiFitText(line, 12, 246, 160, C_TEXT, C_CARD, middle_left);
  uiFitText(Net::locDetail(), 12, 265, 160, C_SUB, C_CARD, middle_left, 12);
  uiButton(B_LOC, "바꾸기", C_NET, TFT_WHITE, 12);
}

void drawMain() {
  lcd.fillScreen(C_BG);
  uiTopBar("와이파이 · 날씨", C_NET);
  drawStatus();
  uiFont(12);
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(C_SUB, C_BG);
  lcd.drawString("저장된 와이파이 (3개까지)", 8, 68);
  drawCredRows();
  uiButton(B_ADD, "+ 주변 와이파이 찾아서 추가", C_NET);
  drawLocBox();
  uiButton(B_NOW, "지금 연결해 보기", C_LINE, C_TEXT);
  uiButton(B_DONE, "다 했어요", C_OK);
}

void drawBars(int x, int y, int rssi) {               // 신호 막대 4칸 (x,y = 왼쪽 아래)
  int lv = rssi >= -55 ? 4 : rssi >= -65 ? 3 : rssi >= -75 ? 2 : 1;
  for (int i = 0; i < 4; i++) {
    int h = 4 + i * 3;
    lcd.fillRect(x + i * 5, y - h, 3, h, i < lv ? C_TEXT : C_LINE);
  }
}
void drawLock(int x, int y) {                          // 자물쇠 (x,y = 왼쪽 위)
  lcd.drawRoundRect(x + 2, y, 6, 8, 2, C_SUB);
  lcd.fillRoundRect(x, y + 5, 10, 8, 1, C_SUB);
}

const Btn B_RESCAN = {4, 284, 74, 32};
const Btn B_MANUAL = {82, 284, 76, 32};
const Btn B_CANCEL = {162, 284, 74, 32};

void drawScan() {
  lcd.fillScreen(C_BG);
  uiTopBar("와이파이 고르기", C_NET);
  if (Net::scanState() != 2) {
    uiFont(16); uiCenter("주변 와이파이를 찾는 중...", 120, 130, C_TEXT, C_BG);
    uiFont(12); uiCenter("몇 초 걸려요", 120, 154, C_SUB, C_BG);
  } else {
    int n = Net::scanCount();
    if (n == 0) { uiFont(16); uiCenter("찾은 와이파이가 없어요", 120, 130, C_TEXT, C_BG); }
    for (int i = 0; i < n && i < 6; i++) {
      Net::ScanItem s;
      if (!Net::getScan(i, s)) continue;
      int y = 38 + i * 36;
      lcd.fillRoundRect(4, y, 232, 32, 6, C_CARD);
      bool saved = Net::isSaved(s.ssid);
      uiFitText(s.ssid, 12, y + 16, saved ? 124 : 168, C_TEXT, C_CARD, middle_left);
      if (saved) { uiFont(12); lcd.setTextDatum(middle_right); lcd.setTextColor(C_NET, C_CARD); lcd.drawString("저장됨", 186, y + 16); }
      if (!s.open) drawLock(192, y + 9);
      drawBars(210, y + 24, s.rssi);
    }
  }
  uiFont(12);
  uiCenter("목록에 없는 숨긴 와이파이는 [직접 입력]", 120, 262, C_SUB, C_BG);
  uiCenter("5GHz 전용 와이파이는 쓸 수 없어요", 120, 276, C_SUB, C_BG);
  uiButton(B_RESCAN, "다시 찾기", C_LINE, C_TEXT, 12);
  uiButton(B_MANUAL, "직접 입력", C_LINE, C_TEXT, 12);
  uiButton(B_CANCEL, "취소", C_LINE, C_TEXT, 12);
}

void openKeyboard(bool ssidMode) {
  forSsid = ssidMode;
  memset(kbuf, 0, sizeof(kbuf)); klen = 0; layer = 0; pressedKey = -1;
  page = P_KEY;
  buildKeys();
  lcd.fillScreen(C_BG);
  uiTopBar(forSsid ? "와이파이 이름" : "비밀번호", C_NET);
  uiButton({176, 4, 60, 24}, "취소", UI_RGB(0, 96, 136), TFT_WHITE, 12);
  drawField();
  drawKeys();
}

Btn cityBtn(int i) { Btn b = {(int16_t)(4 + (i % 3) * 78), (int16_t)(38 + (i / 3) * 40), 74, 36}; return b; }
const Btn B_LOCBACK = {4, 290, 232, 28};

void drawLoc() {
  lcd.fillScreen(C_BG);
  uiTopBar("날씨 위치 고르기", C_NET);
  uint8_t m = Net::locMode();
  for (int i = 0; i <= Net::CITY_N; i++) {
    bool on = (i == m);
    uiButton(cityBtn(i), i == 0 ? "자동" : Net::CITIES[i - 1].name, on ? C_NET : C_CARD, on ? TFT_WHITE : C_TEXT);
  }
  uiFont(12);
  uiCenter("자동 = 와이파이·인터넷 주소로 찾기", 120, 280, C_SUB, C_BG);
  uiButton(B_LOCBACK, "돌아가기", C_LINE, C_TEXT);
}

void pressKey(uint8_t code) {
  switch (code) {
    case K_SHIFT: layer = (layer == 0) ? 1 : 0; buildKeys(); drawKeys(); sfx(SFX_CLICK); return;
    case K_LAYER: layer = (layer == 2) ? 0 : 2; buildKeys(); drawKeys(); sfx(SFX_CLICK); return;
    case K_BACK:
      if (klen > 0) kbuf[--klen] = 0;
      sfx(SFX_TICK); drawField(); return;
    case K_OK:
      if (forSsid) {
        if (klen == 0) { sfx(SFX_WRONG); return; }
        strlcpy(pickSsid, kbuf, sizeof(pickSsid));
        sfx(SFX_CLICK);
        openKeyboard(false);                     // 이름 다음은 비밀번호 (없으면 그냥 확인)
        return;
      }
      if (klen > 0 && klen < 8) {                // 와이파이 비밀번호는 8자 이상
        uiToast("비밀번호는 8자 이상이에요", C_BAD);
        drawField(); drawKeys();
        return;
      }
      Net::addCred(pickSsid, kbuf);              // 저장하고 바로 연결해 봄
      memset(kbuf, 0, sizeof(kbuf)); klen = 0;
      sfx(SFX_OK);
      page = P_MAIN; drawMain();
      return;
    default: {
      int maxLen = forSsid ? 32 : 63;
      if (klen < maxLen && code >= 32 && code < 127) { kbuf[klen++] = (char)code; kbuf[klen] = 0; sfx(SFX_TICK); }
      else sfx(SFX_WRONG);
      drawField();
    }
  }
}

}  // namespace

void appWifi() {
  page = P_MAIN; delArmed = -1; pressedKey = -1;
  lastVer = Net::version();
  drawMain();
  while (true) {
    Touch t = readTouch();

    // ---- 키보드: 누르는 동안 키를 파랗게, 뗄 때 입력 ----
    if (page == P_KEY) {
      if (t.type == T_DOWN || t.type == T_MOVE) {
        int k = keyAt(t.x, t.y);
        if (k != pressedKey) { drawKey(pressedKey, false); drawKey(k, true); pressedKey = k; }
      } else if (t.type == T_UP) {
        int k = pressedKey;
        pressedKey = -1;
        if (t.sy < TOPBAR_H && t.y < TOPBAR_H) {            // 제목줄: ◀ 또는 [취소]
          if (t.x >= 170 || t.x < 44) {
            sfx(SFX_CLICK);
            memset(kbuf, 0, sizeof(kbuf)); klen = 0;
            page = P_SCAN; lastScan = Net::scanState(); drawScan();
          }
        } else if (k >= 0) { drawKey(k, false); pressKey(keys[k].code); }
      }
      delay(5);
      continue;
    }

    if (uiHitHome(t)) {
      sfx(SFX_CLICK);
      if (page == P_MAIN) return;
      page = P_MAIN; lastVer = Net::version(); drawMain();
      continue;
    }

    if (page == P_MAIN) {
      bool hitRow = false;
      for (int i = 0; i < Net::credCount(); i++) {
        if (!delBtn(i).hit(t)) continue;
        hitRow = true;
        if (delArmed == i && millis() - delAt < 3000) { Net::removeCred(i); delArmed = -1; sfx(SFX_FLAG); }
        else { delArmed = i; delAt = millis(); sfx(SFX_CLICK); }
        drawCredRows(); drawStatus();
      }
      if (hitRow) {}
      else if (B_ADD.hit(t)) {
        sfx(SFX_CLICK);
        page = P_SCAN; Net::requestScan(); lastScan = Net::scanState(); drawScan();
      } else if (B_LOC.hit(t)) {
        sfx(SFX_CLICK); page = P_LOC; drawLoc();
      } else if (B_NOW.hit(t)) {
        if (Net::credCount() == 0) sfx(SFX_WRONG);
        else { sfx(SFX_CLICK); Net::requestNow(); }
      } else if (B_DONE.hit(t)) {
        sfx(SFX_CLICK); return;
      }
      if (page == P_MAIN && delArmed >= 0 && millis() - delAt > 3000) { delArmed = -1; drawCredRows(); }
      if (page == P_MAIN && Net::version() != lastVer) { lastVer = Net::version(); drawStatus(); drawLocBox(); }
    }

    else if (page == P_SCAN) {
      if (Net::scanState() != lastScan) { lastScan = Net::scanState(); drawScan(); }
      if (B_RESCAN.hit(t))      { sfx(SFX_CLICK); Net::requestScan(); lastScan = Net::scanState(); drawScan(); }
      else if (B_MANUAL.hit(t)) { sfx(SFX_CLICK); openKeyboard(true); }
      else if (B_CANCEL.hit(t)) { sfx(SFX_CLICK); page = P_MAIN; drawMain(); }
      else if (t.type == T_UP && t.tap && Net::scanState() == 2 && t.y >= 38 && t.y < 38 + 6 * 36) {
        int i = (t.y - 38) / 36;
        Net::ScanItem s;
        if (Net::getScan(i, s)) {
          sfx(SFX_CLICK);
          strlcpy(pickSsid, s.ssid, sizeof(pickSsid));
          if (s.open) { Net::addCred(pickSsid, ""); page = P_MAIN; drawMain(); }   // 비밀번호 없는 와이파이
          else openKeyboard(false);
        }
      }
    }

    else if (page == P_LOC) {
      if (B_LOCBACK.hit(t)) { sfx(SFX_CLICK); page = P_MAIN; drawMain(); }
      for (int i = 0; i <= Net::CITY_N; i++) {
        if (!cityBtn(i).hit(t)) continue;
        sfx(SFX_OK);
        Net::setLocMode(i);
        page = P_MAIN; drawMain();
        break;
      }
    }
    delay(5);
  }
}
