// =====================================================================
//  공부 타이머 (뽀모도로) + 스톱워치
//   - 집중 시간이 끝나면 알람이 울리고 자동으로 쉬는 시간이 시작돼요.
//   - ※ 이 화면을 나가면 타이머도 멈춰요.
// =====================================================================
#include "apps.h"

namespace {

const char* const TABS[2] = { "공부 타이머", "스톱워치" };
const int TAB_Y = TOPBAR_H;
int curTab = 0;

// ---------------- 공부 타이머 ----------------
int focusMin = 25, breakMin = 5;
bool onBreak = false, running = false;
uint32_t remainMs = 25 * 60000UL, lastTick = 0;
int doneCount = 0;

const Btn P1 = { 8, 236, 72, 30 }, P2 = { 84, 236, 72, 30 }, P3 = { 160, 236, 72, 30 };
const Btn MINUS = { 8, 72, 36, 36 }, PLUS = { 196, 72, 36, 36 };
const Btn START = { 8, 274, 140, 40 }, RESET = { 154, 274, 78, 40 };

void drawTime(uint32_t ms, int y, uint16_t fg) {
  char s[64];
  uint32_t sec = (ms + 999) / 1000;
  snprintf(s, sizeof(s), "%02u:%02u", (unsigned)(sec / 60), (unsigned)(sec % 60));
  lcd.setFont(&fonts::Font7);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(fg, C_BG);
  lcd.drawString(s, 120, y);
}

void drawTimerProgress() {
  uint32_t total = (onBreak ? breakMin : focusMin) * 60000UL;
  int w = total ? (int)((uint64_t)(total - remainMs) * 216 / total) : 0;
  lcd.fillRoundRect(12, 150, 216, 12, 6, C_LINE);
  if (w > 0) lcd.fillRoundRect(12, 150, w < 12 ? 12 : w, 12, 6, onBreak ? C_OK : C_TIMER);
}

void drawTimerScreen() {
  lcd.fillRect(0, TAB_Y + 30, SCREEN_W, SCREEN_H - TAB_Y - 30, C_BG);
  uiFont(16);
  uiCenter(onBreak ? "쉬는 시간" : "집중 시간", 120, 82, onBreak ? C_OK : C_TIMER, C_BG);
  if (!running) {
    uiButton(MINUS, "-", C_LINE, C_TEXT);
    uiButton(PLUS, "+", C_LINE, C_TEXT);
  }
  drawTime(remainMs, 122, C_TEXT);
  drawTimerProgress();
  char s[64];
  snprintf(s, sizeof(s), "집중 %d분 / 휴식 %d분 · 완료 %d회", focusMin, breakMin, doneCount);
  uiFont(12);
  uiCenter(s, 120, 180, C_SUB, C_BG);
  // 토마토 개수로 완료 횟수 표시
  for (int i = 0; i < doneCount && i < 8; i++) {
    int cx = 120 - (min(doneCount, 8) - 1) * 12 + i * 24;
    lcd.fillCircle(cx, 208, 8, C_BAD);
    lcd.fillRect(cx - 2, 198, 4, 4, C_OK);
  }
  uiButton(P1, "25/5", C_TIMER);
  uiButton(P2, "50/10", C_TIMER);
  uiButton(P3, "15/3", C_TIMER);
  uiButton(START, running ? "일시정지" : "시작", running ? C_WARN : C_OK);
  uiButton(RESET, "처음부터", C_SUB);
}

void setPreset(int f, int b) {
  focusMin = f; breakMin = b; onBreak = false; running = false;
  remainMs = focusMin * 60000UL;
}

void timerAlarm() {
  sfx(SFX_ALARM);
  for (int i = 0; i < 6; i++) {
    led(!onBreak, onBreak, false);   // 쉬는 시간 시작=초록, 집중 시작=빨강
    uint32_t u = millis() + 250;
    while ((int32_t)(millis() - u) < 0) { readTouch(); delay(5); }
    led(false, false, false);
    u = millis() + 150;
    while ((int32_t)(millis() - u) < 0) { readTouch(); delay(5); }
  }
}

// 돌려주는 값: true = 화면 전체 다시 그리기 필요
bool timerTouch(const Touch& t) {
  if (START.hit(t)) { running = !running; lastTick = millis(); sfx(SFX_CLICK); return true; }
  if (RESET.hit(t)) { onBreak = false; running = false; remainMs = focusMin * 60000UL; sfx(SFX_CLICK); return true; }
  if (P1.hit(t)) { setPreset(25, 5); sfx(SFX_CLICK); return true; }
  if (P2.hit(t)) { setPreset(50, 10); sfx(SFX_CLICK); return true; }
  if (P3.hit(t)) { setPreset(15, 3); sfx(SFX_CLICK); return true; }
  if (!running && (MINUS.hit(t) || PLUS.hit(t))) {
    int d = PLUS.hit(t) ? 1 : -1;
    if (onBreak) breakMin = constrain(breakMin + d, 1, 60);
    else         focusMin = constrain(focusMin + d, 1, 120);
    remainMs = (onBreak ? breakMin : focusMin) * 60000UL;
    sfx(SFX_TICK);
    return true;
  }
  return false;
}

void timerTick() {
  if (!running) return;
  uint32_t now = millis(), d = now - lastTick;
  if (d < 200) return;
  lastTick = now;
  uint32_t before = remainMs / 1000;
  remainMs = remainMs > d ? remainMs - d : 0;
  if (remainMs == 0) {
    if (!onBreak) doneCount++;
    onBreak = !onBreak;
    remainMs = (onBreak ? breakMin : focusMin) * 60000UL;
    if (curTab != 0) { curTab = 0; uiTabs(TABS, 2, 0, TAB_Y, C_TIMER); }
    drawTimerScreen();
    timerAlarm();
    lastTick = millis();
    return;
  }
  if (curTab == 0 && remainMs / 1000 != before) { drawTime(remainMs, 122, C_TEXT); drawTimerProgress(); }
}

// ---------------- 스톱워치 ----------------
bool swRun = false;
uint32_t swBase = 0, swAcc = 0;
uint32_t laps[5];
int lapCount = 0;
const Btn SW_START = { 8, 274, 110, 40 }, SW_LAP = { 122, 274, 110, 40 };

uint32_t swNow() { return swAcc + (swRun ? millis() - swBase : 0); }

void drawSwTime() {
  uint32_t ms = swNow();
  char s[64];
  snprintf(s, sizeof(s), "%02u:%02u.%u", (unsigned)(ms / 60000), (unsigned)(ms / 1000 % 60), (unsigned)(ms / 100 % 10));
  lcd.setFont(&fonts::Font7);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(C_TEXT, C_BG);
  lcd.drawString(s, 120, 110);
}

void drawSwScreen() {
  lcd.fillRect(0, TAB_Y + 30, SCREEN_W, SCREEN_H - TAB_Y - 30, C_BG);
  drawSwTime();
  uiFont(12);
  for (int i = 0; i < lapCount; i++) {
    uint32_t ms = laps[i];
    char s[64];
    snprintf(s, sizeof(s), "기록 %d   %02u:%02u.%u", i + 1, (unsigned)(ms / 60000), (unsigned)(ms / 1000 % 60), (unsigned)(ms / 100 % 10));
    uiCenter(s, 120, 158 + i * 22, C_SUB, C_BG);
  }
  uiButton(SW_START, swRun ? "멈춤" : "시작", swRun ? C_WARN : C_OK);
  uiButton(SW_LAP, swRun ? "기록" : "초기화", C_SUB);
}

bool swTouch(const Touch& t) {
  if (SW_START.hit(t)) {
    if (swRun) { swAcc += millis() - swBase; swRun = false; }
    else       { swBase = millis(); swRun = true; }
    sfx(SFX_CLICK);
    return true;
  }
  if (SW_LAP.hit(t)) {
    if (swRun) {
      if (lapCount < 5) laps[lapCount++] = swNow();
      else { memmove(laps, laps + 1, sizeof(uint32_t) * 4); laps[4] = swNow(); }
    } else { swAcc = 0; lapCount = 0; }
    sfx(SFX_CLICK);
    return true;
  }
  return false;
}

}  // namespace

void appTimer() {
  int& tab = curTab;
  tab = 0;
  remainMs = (onBreak ? breakMin : focusMin) * 60000UL;
  running = false;
  lcd.fillScreen(C_BG);
  uiTopBar("타이머", C_TIMER);
  uiTabs(TABS, 2, tab, TAB_Y, C_TIMER);
  drawTimerScreen();
  uint32_t lastSw = 0;
  while (true) {
    Touch t = readTouch();
    if (uiHitHome(t)) {
      if (!running || uiConfirm("타이머가 멈춰요. 나갈까요?")) { running = false; swRun = false; hwKeepAwake = false; return; }
      uiTabs(TABS, 2, tab, TAB_Y, C_TIMER);
      if (tab == 0) drawTimerScreen(); else drawSwScreen();
    }
    int th = uiTabHit(t, 2, TAB_Y);
    if (th >= 0 && th != tab) {
      tab = th; sfx(SFX_CLICK);
      uiTabs(TABS, 2, tab, TAB_Y, C_TIMER);
      if (tab == 0) drawTimerScreen(); else drawSwScreen();
    } else if (tab == 0) {
      if (timerTouch(t)) drawTimerScreen();
    } else {
      if (swTouch(t)) drawSwScreen();
    }
    timerTick();                                     // 다른 탭에서도 타이머는 계속 감
    hwKeepAwake = running || swRun;                  // 재는 중에는 자동 절전 안 함
    if (tab == 1 && swRun && millis() - lastSw > 100) { lastSw = millis(); drawSwTime(); }
    delay(5);
  }
}
