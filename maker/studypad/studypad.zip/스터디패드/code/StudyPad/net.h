// =====================================================================
//  net.h  -  와이파이로 시간·날씨·미세먼지 받아 오기 + 보드 안 시계
//            (교탁 도우미의 net.h · clock_time.h 를 스터디패드에 맞게 옮김)
//
//  와이파이는 [설정 → 와이파이·날씨] 화면에서 넣어요 (3개까지 보드 안에 기억).
//  켤 때 한 번 + 30분마다 한 번, 잠깐 와이파이에 붙어서
//    ① 인터넷 시간으로 시계를 맞추고
//    ② 지금 있는 곳을 찾고 (위치가 '자동'일 때 · 주변 와이파이 또는 인터넷 주소로)
//    ③ 그곳의 날씨·기온·습도·미세먼지·초미세먼지를 받은 뒤 (Open-Meteo)
//    ④ 바로 와이파이를 꺼요 (배터리를 아끼려고).
//  이 일은 뒤에서 따로 돌아서, 연결이 오래 걸려도 화면·터치가 멈추지 않아요.
//  인터넷이 끊겨도 시계는 보드 안 시계로 계속 가고, 날씨는 마지막 값이 남아요.
//
//  ※ 2.4GHz 와이파이만 돼요. 로그인 화면이 뜨는 와이파이(학교 손님망 등)는 안 돼요.
//  📁 이 파일과 net.cpp 는 고치지 않아도 됩니다.
// =====================================================================
#pragma once
#include "hw.h"
#include <time.h>

// 날씨 위치를 아직 못 찾았을 때 쓰는 곳 (위도, 경도) — 지금은 부산시청
#define WEATHER_LAT      35.1796f
#define WEATHER_LON      129.0756f
#define NET_REFRESH_MIN  30          // 몇 분마다 새로 받을지 (10 ~ 120)

namespace Net {

enum State : uint8_t { N_OFF, N_WAIT, N_BUSY, N_OK, N_FAIL };

struct Weather {
  bool     has;          // 한 번이라도 받았는지
  float    temp;         // 기온 (℃)
  int      hum;          // 습도 % (-1 = 모름)
  int      code;         // 날씨 번호 (WMO, -1 = 모름)
  bool     day;          // 낮이면 true (해 / 달 그림)
  float    pm10, pm25;   // 미세먼지·초미세먼지 ㎍/㎥ (-1 = 모름)
  uint32_t atMs;         // 받은 시각 (millis)
};
struct Cred     { char ssid[33]; char pass[65]; };
struct ScanItem { char ssid[33]; int8_t rssi; bool open; };
struct Place    { const char* name; float lat, lon; };

const int MAX_CRED = 3;
const int CITY_N   = 17;
extern const Place CITIES[CITY_N];

void begin();                 // setup() 에서 한 번 (hwBegin 다음)

// ---- 상태 ----
State       state();
uint32_t    version();        // 뭔가 바뀔 때마다 +1 → 화면 다시 그리기
bool        busy();           // 지금 연결해서 받는 중
bool        ready();          // 와이파이를 하나라도 넣었는지
bool        fresh();          // 최근에 잘 받았는지 (못 받은 지 오래면 false)
const char* lastMsg();        // 마지막 실패 이유 (화면에 보임)
void        connectedSsid(char* out, size_t n);
Weather     weather();
void        requestNow();     // '지금 연결해 보기'

// ---- 저장된 와이파이 ----
int  credCount();
bool getCred(int i, Cred& out);
bool isSaved(const char* ssid);
void addCred(const char* ssid, const char* pass);   // 맨 위에 넣고 바로 연결해 봄
void removeCred(int i);

// ---- 주변 와이파이 찾기 ----
void    requestScan();
uint8_t scanState();          // 0 아직 / 1 찾는 중 / 2 끝
int     scanCount();
bool    getScan(int i, ScanItem& out);

// ---- 날씨 위치 ----
uint8_t     locMode();        // 0 = 자동, 1~17 = CITIES 번호+1
void        setLocMode(uint8_t m);
void        placeName(char* out, size_t n, bool shortName = false);  // "부산" / "부산 근처"
const char* locDetail();      // "주변 와이파이로 찾음" 같은 설명

}  // namespace Net

// ---------------------------------------------------------------------
//  보드 안 시계 (한국 시간)
//   이 보드에는 시계 칩이 없어서, 꺼지면 시간이 멈춰요. 그래서
//   - 와이파이가 있으면 켤 때 · 30분마다 인터넷 시간으로 맞추고
//   - 30분마다 시간을 보드에 적어 둬서, 꺼졌다 켜지면 그 시간부터 다시 가요
//     (이때는 화면에 "시간 확인"이 떠요. 와이파이가 있으면 곧 저절로 맞춰져요)
// ---------------------------------------------------------------------
namespace Clock {
time_t now();
bool   valid();                          // 시간을 한 번이라도 맞췄는지
bool   needsCheck();                     // 꺼졌다 켜져서 저장해 둔 시간부터 가는 중
void   local(time_t t, struct tm& out);  // 한국 시간으로 풀기
time_t make(struct tm& t);               // 한국 시간 → 초
void   set(time_t t);                    // 손으로 맞추기 (저장까지)
}
