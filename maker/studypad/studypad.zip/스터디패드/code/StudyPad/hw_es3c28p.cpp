// =====================================================================
//  hw_es3c28p.cpp  -  2.8인치 ESP32-S3 보드(ES3C28P, 교탁 도우미 보드) 전용 부분
//    FT6336G 정전식 터치(보정 필요 없음) · ES8311 코덱으로 소리 · WS2812 LED · 절전
//  도구 → 보드 에서 "ESP32S3 Dev Module" 을 고르면 이 파일이 쓰여요. (ESP32 를 고르면 hw_e32r28t.cpp)
//  (교탁 도우미의 touch_ft6336.h · es8311.h 를 옮겨 왔어요)
// =====================================================================
#include "hw.h"
#if defined(ARDUINO) && HW_ES3C28P
#include <Wire.h>
#include <ESP_I2S.h>
#include "esp_sleep.h"
#include "driver/gpio.h"
#include "driver/rtc_io.h"

// ---------------------------------------------------------------------
//  FT6336G 정전식 터치 (I2C 주소 0x38)
// ---------------------------------------------------------------------
static const uint8_t FT_ADDR = 0x38;
static bool ftWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(FT_ADDR); Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}
static bool ftBegin() {
  pinMode(PIN_TP_INT, INPUT_PULLUP);
  pinMode(PIN_TP_RST, OUTPUT);
  digitalWrite(PIN_TP_RST, LOW);  delay(10);
  digitalWrite(PIN_TP_RST, HIGH); delay(300);
  return ftWrite(0xA4, 0x00);                  // 누르고 있는 동안 INT = LOW
}
// 패널 기준 좌표 (0~239, 0~319). 안 눌려 있으면 false
static bool ftRead(int16_t& x, int16_t& y) {
  Wire.beginTransmission(FT_ADDR);
  Wire.write(0x02);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(FT_ADDR, (uint8_t)5) != 5) return false;
  uint8_t n  = Wire.read() & 0x0F;
  uint8_t xh = Wire.read(), xl = Wire.read();
  uint8_t yh = Wire.read(), yl = Wire.read();
  if (n == 0 || n > 2) return false;
  int16_t rx = ((xh & 0x0F) << 8) | xl;
  int16_t ry = ((yh & 0x0F) << 8) | yl;
#if TOUCH_SWAP_XY
  int16_t t = rx; rx = ry; ry = t;
#endif
#if TOUCH_MIRROR_X
  rx = 239 - rx;
#endif
#if TOUCH_MIRROR_Y
  ry = 319 - ry;
#endif
  x = constrain(rx, 0, 239);
  y = constrain(ry, 0, 319);
  return true;
}

bool llTouchScreen(int16_t& x, int16_t& y) {
  int16_t sx, sy;
  if (!ftRead(sx, sy)) return false;
  if (settings.flip) { sx = 239 - sx; sy = 319 - sy; }
  x = sx; y = sy;
  return true;
}

// 정전식 터치는 보정이 필요 없어요 → 대신 '터치 점검' 화면 (누른 곳에 점이 찍힘)
bool touchNeedsCalibration() { return false; }
void touchCalibrate() {
  lcd.fillScreen(TFT_WHITE);
  lcd.setFont(&fonts::efontKR_16);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(TFT_BLACK, TFT_WHITE);
  lcd.drawString("터치 점검", 120, 120);
  lcd.setFont(&fonts::efontKR_12);
  lcd.setTextColor(0x632C, TFT_WHITE);
  lcd.drawString("이 보드는 보정이 필요 없어요", 120, 150);
  lcd.drawString("아무 곳이나 눌러 보세요", 120, 170);
  lcd.drawString("누른 곳에 빨간 점이 찍혀요", 120, 188);
  lcd.drawString("3초 동안 안 누르면 끝나요", 120, 206);
  uint32_t last = millis();
  while (millis() - last < 3000) {
    int16_t x, y;
    if (llTouchScreen(x, y)) { lcd.fillCircle(x, y, 3, TFT_RED); last = millis(); }
    delay(10);
  }
  settingsApply();
}

// ---------------------------------------------------------------------
//  ES8311 오디오 코덱 (I2C 0x18) — 슬레이브, MCLK = 256fs, 16비트 I2S
// ---------------------------------------------------------------------
static const uint8_t ES_ADDR = 0x18;
static void esWr(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(ES_ADDR); Wire.write(reg); Wire.write(val); Wire.endTransmission();
}
static bool esBegin() {
  Wire.beginTransmission(ES_ADDR);
  if (Wire.endTransmission() != 0) return false;
  esWr(0x00, 0x1F); delay(20);                 // 리셋
  esWr(0x00, 0x00); esWr(0x00, 0x80);          // 전원 ON, 슬레이브
  esWr(0x01, 0x3F); esWr(0x02, 0x00); esWr(0x03, 0x10); esWr(0x04, 0x10);
  esWr(0x05, 0x00); esWr(0x06, 0x03); esWr(0x07, 0x00); esWr(0x08, 0xFF);
  esWr(0x09, 0x0C); esWr(0x0A, 0x0C);          // I2S 16비트
  esWr(0x0B, 0x00); esWr(0x0C, 0x00); esWr(0x10, 0x1F); esWr(0x11, 0x7F);
  esWr(0x0D, 0x01); esWr(0x0E, 0x02); esWr(0x12, 0x00); esWr(0x13, 0x10);
  esWr(0x14, 0x1A); esWr(0x15, 0x40); esWr(0x16, 0x24); esWr(0x17, 0xBF);
  esWr(0x1B, 0x0A); esWr(0x1C, 0x6A); esWr(0x37, 0x08); esWr(0x45, 0x00);
  esWr(0x31, 0x00);                            // 음소거 해제
  esWr(0x32, 0xBF);                            // DAC 볼륨 0 dB
  return true;
}

// ---- 소리: 뒤에서 도는 작업이 지금 음 높이의 네모파를 계속 만들어 보냄 ----
static I2SClass i2s;
static bool     audioOk = false;
static volatile uint16_t toneHz = 0;
static volatile int16_t  toneAmp = 0;
static volatile uint32_t lastSoundMs = 0;
static volatile bool     ampOn = false;

static void ampSet(bool on) { ampOn = on; digitalWrite(PIN_AMP_EN, on ? LOW : HIGH); }

static void audioTask(void*) {
  const int N = 128;
  static int16_t buf[N * 2];
  uint32_t phase = 0;
  for (;;) {
    uint16_t f = toneHz;
    int16_t a = toneAmp;
    uint32_t step = f ? (uint32_t)((uint64_t)f * 4294967296ULL / AUDIO_RATE) : 0;
    for (int i = 0; i < N; i++) {
      int16_t v = f ? ((phase < 0x80000000u) ? a : (int16_t)-a) : 0;
      phase += step;
      buf[2 * i] = buf[2 * i + 1] = v;
    }
    if (!f) phase = 0;
    i2s.write((uint8_t*)buf, sizeof(buf));     // 보낼 자리가 날 때까지 기다림
    if (!f && ampOn && millis() - lastSoundMs > 500) ampSet(false);   // 조용하면 앰프 끄기
  }
}

void llToneOn(uint16_t f) {
  if (!audioOk) return;
  static const int16_t AMP[4] = { 0, 1200, 3500, 9000 };   // 소리 크기 0~3
  toneAmp = AMP[settings.volume & 3];
  if (!ampOn) ampSet(true);
  toneHz = f;
  lastSoundMs = millis();
}
void llToneOff() { toneHz = 0; lastSoundMs = millis(); }

// ---- LED: 보드 뒷면 WS2812 하나 (켜짐/꺼짐만, 너무 밝지 않게) ----
void llLed(bool r, bool g, bool b) { rgbLedWrite(PIN_WS2812, r ? 40 : 0, g ? 40 : 0, b ? 40 : 0); }

int batteryMilliVolts() {
  uint32_t s = 0;
  for (int i = 0; i < 8; i++) s += analogReadMilliVolts(PIN_BAT);
  return s / 8 * 2;                            // 1/2 로 나뉘어 들어옴
}

void llBegin() {
  Serial.begin(115200);
  gpio_hold_dis((gpio_num_t)PIN_LCD_BL);       // 깊은 절전에서 깨어났다면 핀 고정 풀기
  gpio_hold_dis((gpio_num_t)PIN_AMP_EN);
  gpio_hold_dis((gpio_num_t)PIN_TP_RST);
  gpio_deep_sleep_hold_dis();
  if (esp_sleep_get_wakeup_cause() == ESP_SLEEP_WAKEUP_EXT1) {
    rtc_gpio_deinit((gpio_num_t)PIN_TP_INT);
    rtc_gpio_deinit((gpio_num_t)PIN_BOOT);
  }
  pinMode(PIN_BOOT, INPUT_PULLUP);
  pinMode(PIN_AMP_EN, OUTPUT);
  ampSet(false);
  llLed(false, false, false);
  analogReadResolution(12);
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, 400000);
  if (!ftBegin()) Serial.println("[터치] FT6336 응답 없음");
  i2s.setPins(PIN_I2S_BCLK, PIN_I2S_LRCK, PIN_I2S_DOUT, -1, PIN_I2S_MCLK);
  if (i2s.begin(I2S_MODE_STD, AUDIO_RATE, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO)) {
    delay(5);                                  // MCLK 가 나온 뒤에 코덱 설정
    if (!esBegin()) Serial.println("[소리] ES8311 코덱 응답 없음");
    xTaskCreatePinnedToCore(audioTask, "tone", 3072, nullptr, 3, nullptr, 0);
    audioOk = true;
  } else {
    Serial.println("[소리] I2S 시작 실패");
  }
}

// ---- 가벼운 절전: 화면 끄고 CPU 멈춤. 화면 터치(INT) 또는 BOOT 로 깨어나 이어서 실행 ----
//  INT 선만 믿지 않고 0.2초마다 잠깐 깨어 터치 칩에 직접 물어봐요 (E32R28T 와 같은 방식).
void llSleep() {
  static uint8_t falseIrq = 0;
  toneHz = 0;
  ampSet(false);
  lcd.sleep();
  Serial.flush();
  while (true) {
    bool useIrq = falseIrq < 3 && digitalRead(PIN_TP_INT) == HIGH;
    if (useIrq) gpio_wakeup_enable((gpio_num_t)PIN_TP_INT, GPIO_INTR_LOW_LEVEL);
    gpio_wakeup_enable((gpio_num_t)PIN_BOOT, GPIO_INTR_LOW_LEVEL);
    esp_sleep_enable_gpio_wakeup();
    esp_sleep_enable_timer_wakeup(200000);
    esp_light_sleep_start();
    esp_sleep_wakeup_cause_t why = esp_sleep_get_wakeup_cause();
    gpio_wakeup_disable((gpio_num_t)PIN_TP_INT);
    gpio_wakeup_disable((gpio_num_t)PIN_BOOT);
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
    if (digitalRead(PIN_BOOT) == LOW) break;
    int16_t a, b;
    if (ftRead(a, b)) {                        // 조금 뒤 한 번 더 눌려 있으면 진짜 터치
      delay(8);
      if (ftRead(a, b)) break;
    }
    if (why == ESP_SLEEP_WAKEUP_GPIO && falseIrq < 3) falseIrq++;
  }
  lcd.wakeup();
}

// ---- 깊은 절전 (배터리 부족): 화면 터치 또는 BOOT 로 깨어나면 처음부터 다시 시작 ----
void llDeepSleep() {
  toneHz = 0;
  ampSet(false);
  llLed(false, false, false);
  lcd.sleep();
  uint32_t t = millis();
  int16_t x, y;
  while ((ftRead(x, y) || digitalRead(PIN_BOOT) == LOW) && millis() - t < 5000) delay(20);
  ftWrite(0x86, 0x01);                         // 터치 칩: 저전력 감시 모드 (누르면 INT)
  ftWrite(0xA5, 0x01);
  pinMode(PIN_LCD_BL, OUTPUT); digitalWrite(PIN_LCD_BL, LOW);
  gpio_hold_en((gpio_num_t)PIN_LCD_BL);
  gpio_hold_en((gpio_num_t)PIN_AMP_EN);
  gpio_hold_en((gpio_num_t)PIN_TP_RST);
  gpio_deep_sleep_hold_en();
  rtc_gpio_pullup_en((gpio_num_t)PIN_TP_INT);  rtc_gpio_pulldown_dis((gpio_num_t)PIN_TP_INT);
  rtc_gpio_pullup_en((gpio_num_t)PIN_BOOT);    rtc_gpio_pulldown_dis((gpio_num_t)PIN_BOOT);
  esp_sleep_pd_config(ESP_PD_DOMAIN_RTC_PERIPH, ESP_PD_OPTION_ON);
  esp_sleep_enable_ext1_wakeup_io((1ULL << PIN_TP_INT) | (1ULL << PIN_BOOT), ESP_EXT1_WAKEUP_ANY_LOW);
  Serial.flush();
  esp_deep_sleep_start();
}

#endif  // HW_ES3C28P
