// =====================================================================
//  그림판 + 손글씨 메모  (둘 다 같은 '그리기 엔진'을 써요)
//   - 그림은 3장, 메모는 5장까지 자동으로 저장돼요 (전원을 꺼도 남아요).
//   - 아래 도구: 색 / 굵기 / 지우개 / 되돌리기
//   - 위쪽 < > : 다른 장으로 이동,  새로 : 전부 지우기
// =====================================================================
#include "apps.h"

namespace {

const int CV_Y = TOPBAR_H;          // 캔버스 시작 y
const int CV_H = 248;               // 캔버스 높이 (32 ~ 280)
const int TB_Y = CV_Y + CV_H;       // 아래 도구 막대 y

enum { TOOL_COLOR, TOOL_SIZE, TOOL_ERASER, TOOL_UNDO };
struct Tool { uint8_t kind; uint8_t pal; };

struct PaintCfg {
  const char* title;
  uint16_t    color;
  const char* file;        // 저장 파일 이름 (번호가 붙음)
  int         slots;
  uint32_t    pal[16];     // 0번 = 바탕색 (0xRRGGBB)
  Tool        tools[10];
  int         toolCount;
};

const PaintCfg PAINT = {
  "그림", C_PAINT, "/draw", 3,
  { 0xFFFFFF, 0x202020, 0xE53935, 0xFB8C00, 0xFDD835, 0x43A047, 0x1E88E5, 0x8E24AA,
    0xF48FB1, 0x8D6E63, 0x80DEEA, 0x9E9E9E, 0, 0, 0, 0 },
  { {TOOL_COLOR,1}, {TOOL_COLOR,2}, {TOOL_COLOR,3}, {TOOL_COLOR,4}, {TOOL_COLOR,5},
    {TOOL_COLOR,6}, {TOOL_COLOR,7}, {TOOL_SIZE,0}, {TOOL_ERASER,0}, {TOOL_UNDO,0} },
  10
};

const PaintCfg MEMO = {
  "메모", C_MEMO, "/memo", 5,
  { 0xFFF8DC, 0x1A1A2E, 0x1565C0, 0xD32F2F, 0x2E7D32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
  { {TOOL_COLOR,1}, {TOOL_COLOR,2}, {TOOL_COLOR,3}, {TOOL_COLOR,4},
    {TOOL_SIZE,0}, {TOOL_ERASER,0}, {TOOL_UNDO,0} },
  7
};

const PaintCfg* cfg;
LGFX_Sprite canvas(&lcd);
uint8_t* undoBuf = nullptr;
size_t   bufLen = 0;
int slot = 0, curPal = 1, sizeIdx = 1;
bool eraser = false, dirty = false, hasUndo = false;
const uint8_t SIZES[3] = { 1, 3, 6 };

const Btn B_PREV = { 120, 2, 34, 28 }, B_NEXT = { 158, 2, 34, 28 }, B_NEW = { 196, 2, 42, 28 };

uint32_t palColor(int i) { return cfg->pal[i]; }

void filePath(char* out, int s) { sprintf(out, "%s%d.bin", cfg->file, s + 1); }

void save() {
  if (!dirty || !canvas.getBuffer()) return;
  char p[20]; filePath(p, slot);
  fileSave(p, canvas.getBuffer(), bufLen);
  dirty = false;
}

void load() {
  char p[20]; filePath(p, slot);
  if (!fileLoad(p, canvas.getBuffer(), bufLen)) canvas.fillScreen(0);
  hasUndo = false;
  canvas.pushSprite(0, CV_Y);
}

void drawTop() {
  lcd.fillRect(0, 0, SCREEN_W, TOPBAR_H, cfg->color);
  lcd.fillRoundRect(4, 4, 34, 24, 6, TFT_WHITE);
  lcd.fillTriangle(13, 16, 25, 9, 25, 23, cfg->color);
  char s[64];
  snprintf(s, sizeof(s), "%s %d/%d", cfg->title, slot + 1, cfg->slots);
  uiFont(16);
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(TFT_WHITE, cfg->color);
  lcd.drawString(s, 46, 17);
  uiButton(B_PREV, "<", TFT_WHITE, cfg->color);
  uiButton(B_NEXT, ">", TFT_WHITE, cfg->color);
  uiButton(B_NEW, "새로", TFT_WHITE, cfg->color, 12);
}

void drawTools() {
  int n = cfg->toolCount, w = SCREEN_W / n;
  lcd.fillRect(0, TB_Y, SCREEN_W, SCREEN_H - TB_Y, UI_RGB(60, 64, 76));
  for (int i = 0; i < n; i++) {
    const Tool& t = cfg->tools[i];
    int x = i * w, cx = x + w / 2, cy = TB_Y + 20;
    bool sel = (t.kind == TOOL_COLOR && !eraser && t.pal == curPal) || (t.kind == TOOL_ERASER && eraser);
    if (sel) lcd.fillRoundRect(x + 1, TB_Y + 3, w - 2, 34, 6, TFT_WHITE);
    switch (t.kind) {
      case TOOL_COLOR:
        lcd.fillCircle(cx, cy, 9, (uint32_t)palColor(t.pal));
        lcd.drawCircle(cx, cy, 9, sel ? TFT_BLACK : UI_RGB(200, 200, 200));
        break;
      case TOOL_SIZE: {
        int r = SIZES[sizeIdx] + 1;
        lcd.drawRoundRect(x + 2, TB_Y + 5, w - 4, 30, 5, UI_RGB(200, 200, 200));
        lcd.fillCircle(cx, cy, r, TFT_WHITE);
        break;
      }
      case TOOL_ERASER:
        lcd.fillRoundRect(cx - 8, cy - 6, 16, 12, 3, UI_RGB(255, 170, 190));
        lcd.fillRect(cx - 8, cy - 6, 6, 12, UI_RGB(120, 160, 255));
        break;
      case TOOL_UNDO:
        lcd.drawArc(cx + 1, cy + 2, 8, 6, 180, 360, hasUndo ? TFT_WHITE : UI_RGB(120, 120, 130));
        lcd.fillTriangle(cx - 12, cy + 1, cx - 2, cy + 1, cx - 7, cy + 8, hasUndo ? TFT_WHITE : UI_RGB(120, 120, 130));
        break;
    }
  }
}

void snapshot() {
  if (!undoBuf) return;
  memcpy(undoBuf, canvas.getBuffer(), bufLen);
  if (!hasUndo) { hasUndo = true; drawTools(); }
}

void undo() {
  if (!undoBuf || !hasUndo) return;
  memcpy(canvas.getBuffer(), undoBuf, bufLen);
  canvas.pushSprite(0, CV_Y);
  hasUndo = false; dirty = true;
  drawTools();
}

// 화면과 캔버스(저장용)에 같이 그림
void stroke(int x0, int y0, int x1, int y1) {
  int idx = eraser ? 0 : curPal;
  int r = eraser ? 9 : SIZES[sizeIdx];
  uint32_t c = palColor(idx);
  lcd.setClipRect(0, CV_Y, SCREEN_W, CV_H);
  uiThickLine(lcd, x0, y0, x1, y1, r, c);
  uiThickLine(canvas, x0, y0 - CV_Y, x1, y1 - CV_Y, r, idx);
  lcd.clearClipRect();
  dirty = true;
}

void run(const PaintCfg& c) {
  cfg = &c;
  canvas.setColorDepth(4);
  if (!canvas.createSprite(SCREEN_W, CV_H)) { uiToast("메모리가 부족해요", C_BAD); return; }
  canvas.createPalette();
  for (int i = 0; i < 16; i++) canvas.setPaletteColor(i, (uint32_t)cfg->pal[i]);
  bufLen = canvas.bufferLength();
  undoBuf = (uint8_t*)malloc(bufLen);
  slot = 0; curPal = 1; sizeIdx = 1; eraser = false; dirty = false;

  lcd.fillScreen(C_BG);
  drawTop();
  load();
  drawTools();

  bool drawing = false;
  int lx = 0, ly = 0;
  uint32_t lastDraw = 0;
  hwSetSaveHook(save);                     // 절전·배터리 부족 직전에 저장
  while (true) {
    Touch t = readTouch();
    if (drawing) lastDraw = millis();
    if (dirty && !drawing && millis() - lastDraw > 3000) save();   // 3초 동안 안 그리면 자동 저장
    bool inCanvas = t.y >= CV_Y && t.y < TB_Y;

    if (t.type == T_DOWN && inCanvas) {
      snapshot();
      drawing = true; lx = t.x; ly = t.y;
      stroke(lx, ly, lx, ly);
    } else if (t.type == T_MOVE && drawing) {
      if (abs(t.x - lx) > 60 || abs(t.y - ly) > 60) { lx = t.x; ly = t.y; }   // 튀는 값 무시
      stroke(lx, ly, t.x, t.y);
      lx = t.x; ly = t.y;
    } else if (t.type == T_UP) {
      bool wasDrawing = drawing;
      drawing = false;
      if (wasDrawing) { delay(2); continue; }
      if (uiHitHome(t)) break;
      if (B_PREV.hit(t) || B_NEXT.hit(t)) {
        save();
        slot = (slot + (B_NEXT.hit(t) ? 1 : cfg->slots - 1)) % cfg->slots;
        sfx(SFX_CLICK);
        drawTop(); load(); drawTools();
      } else if (B_NEW.hit(t)) {
        if (uiConfirm("이 장을 모두 지울까요?")) { snapshot(); canvas.fillScreen(0); dirty = true; }
        drawTop(); canvas.pushSprite(0, CV_Y); drawTools();
      } else if (t.y >= TB_Y && t.sy >= TB_Y) {
        int i = t.x / (SCREEN_W / cfg->toolCount);
        if (i >= 0 && i < cfg->toolCount) {
          const Tool& tl = cfg->tools[i];
          if (tl.kind == TOOL_COLOR)  { curPal = tl.pal; eraser = false; }
          if (tl.kind == TOOL_SIZE)   { sizeIdx = (sizeIdx + 1) % 3; }
          if (tl.kind == TOOL_ERASER) { eraser = !eraser; }
          if (tl.kind == TOOL_UNDO)   { undo(); }
          sfx(SFX_CLICK);
          drawTools();
        }
      }
    }
    delay(2);
  }
  save();
  hwSetSaveHook(nullptr);
  canvas.deleteSprite();
  free(undoBuf); undoBuf = nullptr;
}

}  // namespace

void appPaint() { run(PAINT); }
void appMemo()  { run(MEMO); }
