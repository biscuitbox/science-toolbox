// =====================================================================
//  ui.h  -  여러 앱이 같이 쓰는 화면 도구 (색, 버튼, 글자 줄바꿈, 대화상자)
// =====================================================================
#pragma once
#include "hw.h"

// ---- 색 (R, G, B) ----
#define UI_RGB(r, g, b) lgfx::color565(r, g, b)
static const uint16_t C_BG    = UI_RGB(244, 246, 250);
static const uint16_t C_CARD  = UI_RGB(255, 255, 255);
static const uint16_t C_TEXT  = UI_RGB(33, 37, 48);
static const uint16_t C_SUB   = UI_RGB(110, 116, 132);
static const uint16_t C_LINE  = UI_RGB(214, 218, 226);
static const uint16_t C_OK    = UI_RGB(39, 174, 96);
static const uint16_t C_BAD   = UI_RGB(231, 76, 60);
static const uint16_t C_WARN  = UI_RGB(243, 156, 18);

// 앱별 대표 색
static const uint16_t C_MINE  = UI_RGB(84, 98, 122);
static const uint16_t C_WORD  = UI_RGB(41, 128, 185);
static const uint16_t C_QUIZ  = UI_RGB(22, 160, 133);
static const uint16_t C_PAINT = UI_RGB(232, 67, 147);
static const uint16_t C_MEMO  = UI_RGB(230, 162, 20);
static const uint16_t C_TIMER = UI_RGB(142, 68, 173);
static const uint16_t C_CALC  = UI_RGB(52, 73, 94);
static const uint16_t C_RAND  = UI_RGB(230, 110, 30);
static const uint16_t C_SET   = UI_RGB(110, 120, 130);
static const uint16_t C_CLOCK = UI_RGB(26, 54, 93);
static const uint16_t C_NET   = UI_RGB(0, 132, 180);

#define TOPBAR_H 32

// 굵은 선 (원을 이어 찍어서 그림). 화면(lcd)과 스프라이트 모두 사용 가능
template <typename T>
void uiThickLine(lgfx::LGFXBase& g, int x0, int y0, int x1, int y1, int r, T color) {
  int dx = x1 - x0, dy = y1 - y0;
  int len = (int)sqrtf((float)(dx * dx + dy * dy));
  int step = r > 1 ? r / 2 : 1;
  if (r <= 0) { g.drawLine(x0, y0, x1, y1, color); return; }
  for (int i = 0; i <= len; i += step) {
    int x = len ? x0 + dx * i / len : x0, y = len ? y0 + dy * i / len : y0;
    g.fillCircle(x, y, r, color);
  }
  g.fillCircle(x1, y1, r, color);
}

// ---- 버튼 ----
struct Btn {
  int16_t x, y, w, h;
  bool in(int px, int py) const { return px >= x && px < x + w && py >= y && py < y + h; }
  // 버튼 안에서 눌렀다가 버튼 안에서 뗐으면 true
  bool hit(const Touch& t) const { return t.type == T_UP && !t.longed && in(t.sx, t.sy) && in(t.x, t.y); }
};

void uiFont(uint8_t px);                       // 12, 16, 24 (한글 글꼴 크기)
void uiTopBar(const char* title, uint16_t color);
bool uiHitHome(const Touch& t);                // 왼쪽 위 '◀' 를 눌렀나?
void uiButton(const Btn& b, const char* label, uint16_t bg, uint16_t fg = TFT_WHITE, uint8_t font = 16);
void uiCenter(const char* s, int cx, int cy, uint16_t fg, uint16_t bg);
// 칸 너비(maxW)에 맞춰 쓰기: 16px 로 안 들어가면 12px, 그래도 길면 뒤를 ..로 줄임
// datum: middle_left(왼쪽 맞춤) / middle_center(가운데) / middle_right(오른쪽)
void uiFitText(const char* s, int x, int y, int maxW, uint16_t fg, uint16_t bg,
               lgfx::textdatum_t datum = middle_left, uint8_t bigPx = 16);
int  uiWrap(const char* s, int x, int y, int w, int lineH, uint16_t fg, uint16_t bg,
            bool center = false, bool draw = true);   // 줄 수를 돌려줌
bool uiConfirm(const char* msg);               // 예 / 아니오 대화상자
void uiToast(const char* msg, uint16_t bg, uint16_t ms = 900);
void uiTabs(const char* const* labels, int n, int sel, int y, uint16_t color);
int  uiTabHit(const Touch& t, int n, int y);   // 몇 번째 탭을 눌렀는지 (-1 = 없음)
void uiBattery(int x, int y, uint16_t fg, uint16_t bg);
void uiShuffle(uint8_t* a, int n);             // 배열 섞기
void uiShuffle16(uint16_t* a, int n);          // 배열 섞기 (큰 번호용)
void uiChoice(const Btn& b, const char* text, uint16_t bg, uint16_t fg, uint16_t border);  // 보기 버튼 (길면 두 줄)
bool uiResult(const char* title, uint16_t color, int score, int total);  // 퀴즈 결과 (다시 하기 = true)
