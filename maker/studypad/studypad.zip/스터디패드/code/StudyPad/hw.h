// =====================================================================
//  hw.h  -  하드웨어(화면/터치/소리/LED/배터리/저장) 관련 공통 선언
//  보드: 2.8인치 ESP32-32E 디스플레이 (E32R28T, ST7789 + XPT2046 저항막 터치)
//  ※ 다른 파일들은 이 파일만 include 하면 하드웨어를 쓸 수 있어요.
// =====================================================================
#pragma once

#ifdef ARDUINO
  #include <Arduino.h>
#else
  #include "host_arduino.h"     // PC 시뮬레이터용 (보드에서는 사용 안 함)
#endif

#define LGFX_USE_V1
#include <LovyanGFX.hpp>

// ---------------------------------------------------------------------
//  [화면 설정]  색이 이상하게 나올 때 여기만 바꿔 보세요.
//   - 빨강/파랑이 서로 바뀌어 보이면 LCD_RGB_ORDER 를 true <-> false
//   - 색이 사진 필름처럼 반전돼 보이면 설정 앱의 '색 반전'을 누르세요.
// ---------------------------------------------------------------------
#define LCD_RGB_ORDER  false
#define LCD_INVERT     false

#define SCREEN_W 240
#define SCREEN_H 320

// ---------------------------------------------------------------------
//  핀 번호 (LCDWiki E32R28T 자료 기준)
// ---------------------------------------------------------------------
#define PIN_LCD_SCK   14
#define PIN_LCD_MOSI  13
#define PIN_LCD_MISO  12
#define PIN_LCD_CS    15
#define PIN_LCD_DC     2
#define PIN_LCD_BL    21

#define PIN_TP_CLK    25
#define PIN_TP_MOSI   32
#define PIN_TP_MISO   39
#define PIN_TP_CS     33
#define PIN_TP_IRQ    36

#define PIN_LED_R     22   // RGB LED (공통 양극: LOW = 켜짐)
#define PIN_LED_G     16
#define PIN_LED_B     17

#define PIN_SPK       26   // 스피커 (앰프 입력)
#define PIN_AMP_EN     4   // 앰프 켜기 (LOW = 켜짐)
#define PIN_BAT       34   // 배터리 전압 측정
#define PIN_BOOT       0   // BOOT 버튼

// ---------------------------------------------------------------------
//  화면 객체 (LovyanGFX)
// ---------------------------------------------------------------------
#ifdef ARDUINO
class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789 _panel;
  lgfx::Bus_SPI      _bus;
  lgfx::Light_PWM    _light;
public:
  LGFX() {
    {
      auto cfg = _bus.config();
      cfg.spi_host   = SPI2_HOST;      // HSPI
      cfg.spi_mode   = 0;
      cfg.freq_write = 40000000;
      cfg.freq_read  = 16000000;
      cfg.spi_3wire  = false;
      cfg.use_lock   = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO;
      cfg.pin_sclk = PIN_LCD_SCK;
      cfg.pin_mosi = PIN_LCD_MOSI;
      cfg.pin_miso = PIN_LCD_MISO;
      cfg.pin_dc   = PIN_LCD_DC;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg = _panel.config();
      cfg.pin_cs   = PIN_LCD_CS;
      cfg.pin_rst  = -1;               // 리셋은 EN 핀과 공유
      cfg.pin_busy = -1;
      cfg.panel_width  = 240;
      cfg.panel_height = 320;
      cfg.offset_x = 0;
      cfg.offset_y = 0;
      cfg.offset_rotation = 0;
      cfg.readable  = true;
      cfg.invert    = LCD_INVERT;
      cfg.rgb_order = LCD_RGB_ORDER;
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;
      _panel.config(cfg);
    }
    {
      auto cfg = _light.config();
      cfg.pin_bl = PIN_LCD_BL;
      cfg.invert = false;
      cfg.freq   = 12000;
      cfg.pwm_channel = 7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }
    setPanel(&_panel);
  }
};
#else
#include "host_lgfx.h"
#endif

extern LGFX lcd;

// ---------------------------------------------------------------------
//  터치
// ---------------------------------------------------------------------
enum TouchType : uint8_t {
  T_NONE = 0,   // 아무 일도 없음
  T_DOWN,       // 막 눌렀음
  T_MOVE,       // 누른 채로 움직이는 중
  T_UP,         // 손을 뗐음 (tap == true 이면 '짧게 톡' 누른 것)
  T_LONG        // 0.45초 이상 꾹 누르고 있음 (한 번만 발생)
};

struct Touch {
  TouchType type;
  int16_t x, y;      // 화면 좌표 (0~239, 0~319)
  int16_t sx, sy;    // 처음 누른 위치
  bool tap;          // T_UP 일 때: 짧게 눌렀다 뗐으면 true
  bool longed;       // T_UP 일 때: 꾹 누르기(T_LONG)가 이미 발생했으면 true
};

Touch readTouch();                       // 앱의 반복문 안에서 계속 불러 주세요
bool  touchRaw(int16_t& x, int16_t& y);  // 지금 눌려 있으면 좌표
void  waitRelease();                     // 손을 뗄 때까지 기다리기
void  touchCalibrate();                  // 터치 보정 화면
bool  touchNeedsCalibration();           // 처음 켰거나, 시작 화면에서 BOOT 버튼을 눌렀으면 true
bool  bootButtonDown();                  // BOOT 버튼이 지금 눌려 있나?

// ---------------------------------------------------------------------
//  소리 / LED
// ---------------------------------------------------------------------
enum Sfx : uint8_t { SFX_CLICK, SFX_OK, SFX_WRONG, SFX_WIN, SFX_LOSE, SFX_FLAG, SFX_ALARM, SFX_TICK };
void beep(uint16_t freq, uint16_t ms);
void playMelody(const uint16_t* notes, int count);  // {주파수, 길이ms, 주파수, 길이ms ...}
void sfx(Sfx s);
void soundStop();

void led(bool r, bool g, bool b);                 // RGB LED 켜기/끄기
void ledFlash(bool r, bool g, bool b, uint16_t ms); // 잠깐 켰다가 자동으로 끄기

// ---------------------------------------------------------------------
//  배터리
// ---------------------------------------------------------------------
int batteryMilliVolts();
int batteryPercent();      // 대략적인 값 (0~100)

// ---------------------------------------------------------------------
//  설정 / 저장
// ---------------------------------------------------------------------
struct Settings {
  uint8_t brightness;   // 1~5
  uint8_t volume;       // 0~3 (0 = 음소거)
  uint8_t invert;       // 0/1 색 반전
  uint8_t flip;         // 0/1 화면 180도 회전
  uint8_t sleepIdx;     // 자동 절전: 0 = 끄기, 1~4 = SLEEP_MINUTES[] 분
};
static const uint8_t SLEEP_MINUTES[5] = { 0, 1, 3, 5, 10 };
extern Settings settings;
void settingsSave();
void settingsApply();

int32_t kvGetInt(const char* key, int32_t def);
void    kvSetInt(const char* key, int32_t value);
bool    kvGetBytes(const char* key, void* buf, size_t len);
void    kvSetBytes(const char* key, const void* buf, size_t len);
void    kvClearAll();

bool fileSave(const char* path, const void* buf, size_t len);
bool fileLoad(const char* path, void* buf, size_t len);
bool fileExists(const char* path);
void fileRemove(const char* path);

// ---------------------------------------------------------------------
//  절전 / 배터리 보호
//   - 아무것도 안 누르고 정해진 시간이 지나면: 15초 전에 화면이 어두워지고 → 절전
//   - 절전 중에는 화면을 누르거나 BOOT 버튼을 누르면 하던 화면 그대로 깨어나요.
//   - 배터리가 부족하면 저장 후 빨간 LED 깜빡임, 아주 부족하면 저장 후 전원 차단
//     (충전한 뒤 BOOT 버튼을 누르면 다시 켜져요)
// ---------------------------------------------------------------------
extern bool hwKeepAwake;              // true 이면 자동 절전 안 함 (타이머 작동 중 등)
extern volatile bool hwNetBusy;       // 와이파이로 시간·날씨를 받는 중 (이때도 절전 안 함, net.cpp)
extern bool hwLowBattery;             // 배터리 부족 상태
void hwSetSaveHook(void (*fn)());     // 절전·배터리 부족 직전에 부를 '저장 함수' 등록 (nullptr = 해제)
void hwSaveNow();                     // 등록된 저장 함수를 지금 부르기

// ---------------------------------------------------------------------
void hwBegin();     // setup()에서 한 번
void hwUpdate();    // 소리/LED 타이머 처리 (readTouch 가 알아서 불러 줌)
