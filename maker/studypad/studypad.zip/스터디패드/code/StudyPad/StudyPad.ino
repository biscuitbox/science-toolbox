// =====================================================================
//   스터디패드 (StudyPad)  -  2.8인치 ESP32 터치 디스플레이용 공부 단말기
//
//   보드  : 2.8inch ESP32-32E Display (E32R28T, ST7789, 저항막 터치)
//   필요한 라이브러리 : LovyanGFX  (라이브러리 매니저에서 설치)
//   보드 설정 : ESP32 Dev Module
//               Partition Scheme -> "Huge APP (3MB No OTA/1MB SPIFFS)"  ← 꼭!
//
//   파일 안내
//     hw.h / hw.cpp        화면·터치·소리·LED·저장 (하드웨어)
//     ui.h / ui.cpp        버튼, 글자 줄바꿈 같은 공통 화면 도구
//     app_*.cpp            앱 하나당 파일 하나
//     data_words.h         영어 단어장   ← 학생들이 고치기 좋은 곳
//     data_quiz.h          상식 퀴즈     ← 학생들이 고치기 좋은 곳
// =====================================================================
#include "apps.h"
#include "net.h"

// ---------------------------------------------------------------------
//  홈 화면 아이콘 그리기 (cx, cy = 아이콘 가운데)
// ---------------------------------------------------------------------
static void iconMine(int cx, int cy) {
  for (int i = 0; i < 4; i++) {
    float a = i * 3.14159f / 4;
    int dx = cos(a) * 17, dy = sin(a) * 17;
    uiThickLine(lcd, cx - dx, cy - dy, cx + dx, cy + dy, 1, TFT_BLACK);
  }
  lcd.fillCircle(cx, cy, 12, TFT_BLACK);
  lcd.fillCircle(cx - 4, cy - 4, 3, TFT_WHITE);
}
static void iconWord(int cx, int cy) {
  lcd.fillRoundRect(cx - 20, cy - 16, 40, 32, 5, TFT_WHITE);
  lcd.setFont(&fonts::FreeSansBold12pt7b);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(C_WORD);
  lcd.drawString("Aa", cx, cy + 1);
}
static void iconQuiz(int cx, int cy) {        // 말풍선 + 물음표
  lcd.fillRoundRect(cx - 20, cy - 18, 40, 30, 10, TFT_WHITE);
  lcd.fillTriangle(cx - 8, cy + 10, cx + 2, cy + 10, cx - 10, cy + 19, TFT_WHITE);
  lcd.setFont(&fonts::FreeSansBold12pt7b);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(C_QUIZ);
  lcd.drawString("?", cx, cy - 2);
}
static void iconPaint(int cx, int cy) {
  lcd.fillEllipse(cx, cy, 20, 16, TFT_WHITE);
  lcd.fillCircle(cx + 9, cy + 6, 4, C_PAINT);
  lcd.fillCircle(cx - 10, cy - 4, 4, TFT_RED);
  lcd.fillCircle(cx - 1, cy - 8, 4, TFT_BLUE);
  lcd.fillCircle(cx + 9, cy - 5, 4, UI_RGB(255, 200, 0));
  lcd.fillCircle(cx - 8, cy + 7, 4, TFT_GREEN);
}
static void iconMemo(int cx, int cy) {
  lcd.fillRoundRect(cx - 15, cy - 19, 30, 38, 4, TFT_WHITE);
  for (int i = 0; i < 4; i++) lcd.drawFastHLine(cx - 10, cy - 9 + i * 7, 20, C_MEMO);
  uiThickLine(lcd, cx + 2, cy + 14, cx + 18, cy - 6, 1, C_TEXT);
}
static void iconTimer(int cx, int cy) {
  lcd.fillCircle(cx, cy + 2, 18, TFT_WHITE);
  lcd.fillRect(cx - 4, cy - 21, 8, 5, TFT_WHITE);
  uiThickLine(lcd, cx, cy + 2, cx, cy - 10, 1, C_TIMER);
  uiThickLine(lcd, cx, cy + 2, cx + 8, cy + 7, 1, C_TIMER);
}
static void iconCalc(int cx, int cy) {
  lcd.fillRoundRect(cx - 16, cy - 20, 32, 40, 4, TFT_WHITE);
  lcd.fillRect(cx - 12, cy - 16, 24, 9, C_CALC);
  for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++)
    lcd.fillRect(cx - 12 + c * 9, cy - 3 + r * 7, 6, 5, (c == 2 && r == 2) ? C_RAND : C_CALC);
}
static void iconRand(int cx, int cy) {
  lcd.fillRoundRect(cx - 17, cy - 17, 34, 34, 7, TFT_WHITE);
  int d = 9;
  lcd.fillCircle(cx - d, cy - d, 3, C_RAND); lcd.fillCircle(cx + d, cy + d, 3, C_RAND);
  lcd.fillCircle(cx, cy, 3, C_RAND);
  lcd.fillCircle(cx + d, cy - d, 3, C_RAND); lcd.fillCircle(cx - d, cy + d, 3, C_RAND);
}
static void iconReact(int cx, int cy) {
  lcd.fillCircle(cx, cy, 18, TFT_WHITE);
  lcd.fillTriangle(cx + 2, cy - 14, cx - 8, cy + 3, cx + 1, cy + 2, C_BAD);
  lcd.fillTriangle(cx - 2, cy + 14, cx + 8, cy - 3, cx - 1, cy - 2, C_BAD);
}
static void iconClock(int cx, int cy) {
  lcd.fillCircle(cx, cy, 19, TFT_WHITE);
  for (int i = 0; i < 12; i += 3) {
    float a = i * 3.14159f / 6;
    lcd.fillCircle(cx + sin(a) * 14, cy - cos(a) * 14, 2, C_CLOCK);
  }
  uiThickLine(lcd, cx, cy, cx, cy - 11, 1, C_CLOCK);
  uiThickLine(lcd, cx, cy, cx + 8, cy + 3, 1, C_CLOCK);
  lcd.fillCircle(cx, cy, 2, C_BAD);
}
static void iconSet(int cx, int cy) {
  for (int i = 0; i < 8; i++) {
    float a = i * 3.14159f / 4;
    uiThickLine(lcd, cx, cy, cx + cos(a) * 18, cy + sin(a) * 18, 2, TFT_WHITE);
  }
  lcd.fillCircle(cx, cy, 13, TFT_WHITE);
  lcd.fillCircle(cx, cy, 6, C_SET);
}

// ---------------------------------------------------------------------
//  앱 표 : { 이름, 색, 아이콘 그리는 함수, 실행 함수 }
//  새 앱을 넣으려면 한 줄 추가! (한 쪽에 9개, 넘치면 다음 쪽으로 넘어가요)
// ---------------------------------------------------------------------
struct AppInfo {
  const char* name;
  uint16_t color;
  void (*icon)(int, int);
  void (*run)();
};

static const AppInfo APPS[] = {
  { "지뢰찾기", C_MINE,  iconMine,  appMinesweeper },
  { "영어 단어", C_WORD,  iconWord,  appWords },
  { "상식 퀴즈", C_QUIZ,  iconQuiz,  appQuiz },
  { "그림판",   C_PAINT, iconPaint, appPaint },
  { "손글씨 메모", C_MEMO, iconMemo, appMemo },
  { "공부 타이머", C_TIMER, iconTimer, appTimer },
  { "계산기",   C_CALC,  iconCalc,  appCalc },
  { "주사위·뽑기", C_RAND, iconRand, appRandom },
  { "설정",     C_SET,   iconSet,   appSettings },
  // ---- 2쪽 ----
  { "탁상시계", C_CLOCK, iconClock, appClock },    // 와이파이로 시간·날씨·미세먼지
  // ---- 학생들이 만든 앱을 여기에 추가해요 ----
  { "반응 속도", C_BAD,   iconReact, appReaction },
};
static const int APP_COUNT = sizeof(APPS) / sizeof(APPS[0]);

static const int PAGES = (APP_COUNT + 8) / 9;
static int page = 0;
static const Btn B_PAGE = { 112, 2, 70, 32 };   // 위쪽 '1/2 ▶' 버튼

static Btn tileRect(int i) {
  i %= 9;
  Btn b = { (int16_t)(6 + (i % 3) * 78), (int16_t)(44 + (i / 3) * 92), 72, 86 };
  return b;
}

static void drawHome() {
  lcd.fillScreen(C_BG);
  lcd.fillRect(0, 0, SCREEN_W, 36, C_TEXT);
  uiFont(16);
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(TFT_WHITE, C_TEXT);
  lcd.drawString("스터디패드", 10, 18);
  uiBattery(188, 11, TFT_WHITE, C_TEXT);
  if (PAGES > 1) {
    char s[32];
    snprintf(s, sizeof(s), "%d/%d ▶", page + 1, PAGES);
    lcd.fillRoundRect(B_PAGE.x, B_PAGE.y + 4, B_PAGE.w, B_PAGE.h - 8, 8, UI_RGB(70, 76, 92));
    uiFont(12);
    uiCenter(s, B_PAGE.x + B_PAGE.w / 2, B_PAGE.y + B_PAGE.h / 2, TFT_WHITE, UI_RGB(70, 76, 92));
  }
  for (int i = page * 9; i < APP_COUNT && i < page * 9 + 9; i++) {
    Btn b = tileRect(i);
    lcd.fillRoundRect(b.x, b.y, b.w, b.h, 12, APPS[i].color);
    APPS[i].icon(b.x + b.w / 2, b.y + 32);
    uiFont(12);
    uiCenter(APPS[i].name, b.x + b.w / 2, b.y + 70, TFT_WHITE, APPS[i].color);
  }
}

static bool calRequested = false;   // 시작 화면에서 BOOT 를 누르면 터치 보정

static void splash() {
  lcd.fillScreen(C_TEXT);
  uiFont(24);
  uiCenter("스터디패드", 120, 140, TFT_WHITE, C_TEXT);
  uiFont(12);
  uiCenter("공부도 놀이도 한 손에", 120, 172, UI_RGB(180, 190, 210), C_TEXT);
  uiCenter("터치 보정: 지금 BOOT 버튼 누르기", 120, 300, UI_RGB(110, 118, 140), C_TEXT);
  led(false, false, true);
  static const uint16_t HELLO[] = { 784, 80, 1047, 80, 1319, 120 };
  playMelody(HELLO, 3);
  uint32_t end = millis() + 1500;
  while ((int32_t)(millis() - end) < 0) {
    readTouch();
    if (bootButtonDown()) calRequested = true;
    delay(5);
  }
  led(false, false, false);
}

void setup() {
  hwBegin();
  Net::begin();              // 와이파이 · 시간 · 날씨 (뒤에서 따로 돌아요)
  splash();
  if (calRequested || touchNeedsCalibration()) touchCalibrate();
  drawHome();
}

void loop() {
  static uint32_t lastBat = 0;
  Touch t = readTouch();
  // 쪽 넘기기: 위쪽 버튼을 누르거나, 옆으로 쓸기
  bool swipe = t.type == T_UP && abs(t.x - t.sx) > 70 && abs(t.y - t.sy) < 50;
  if (PAGES > 1 && (B_PAGE.hit(t) || swipe)) {
    page = (swipe && t.x > t.sx) ? (page + PAGES - 1) % PAGES : (page + 1) % PAGES;
    sfx(SFX_CLICK);
    drawHome();
    return;
  }
  for (int i = page * 9; i < APP_COUNT && i < page * 9 + 9; i++) {
    Btn b = tileRect(i);
    if (b.hit(t)) {
      sfx(SFX_CLICK);
      waitRelease();
      APPS[i].run();          // 앱 실행 (앱에서 ◀ 를 누르면 여기로 돌아옴)
      soundStop();
      led(false, false, false);
      waitRelease();
      drawHome();
      return;
    }
  }
  if (millis() - lastBat > 10000) { lastBat = millis(); uiBattery(188, 11, TFT_WHITE, C_TEXT); }
  delay(5);
}
