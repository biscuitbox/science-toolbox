// =====================================================================
//  hw_e32r28t.cpp  -  2.8인치 ESP32-32E 보드(E32R28T) 전용 부분
//    XPT2046 저항막 터치(보정 필요) · 스피커 PWM · RGB LED 3개 핀 · 절전(터치·BOOT 로 깨우기)
//  도구 → 보드 에서 "ESP32 Dev Module" 을 고르면 이 파일이 쓰여요. (S3 를 고르면 hw_es3c28p.cpp)
// =====================================================================
#include "hw.h"
#if defined(ARDUINO) && HW_E32R28T
#include "esp_sleep.h"
#include "driver/gpio.h"

// ---- 터치 보정값: 화면 x=0, x=239, y=0, y=319 에 해당하는 터치 원시값 ----
struct TouchCal { int16_t swap, x0, x1, y0, y1; };
static TouchCal cal = { 0, 3800, 300, 300, 3800 };

// XPT2046 를 소프트웨어 SPI 로 직접 읽기 (SD카드와 SPI 충돌을 피하려고)
static uint16_t xpt(uint8_t cmd) {
  for (int i = 7; i >= 0; i--) {
    digitalWrite(PIN_TP_MOSI, (cmd >> i) & 1);
    digitalWrite(PIN_TP_CLK, HIGH); delayMicroseconds(1);
    digitalWrite(PIN_TP_CLK, LOW);  delayMicroseconds(1);
  }
  digitalWrite(PIN_TP_MOSI, LOW);
  uint16_t r = 0;
  for (int i = 0; i < 16; i++) {
    digitalWrite(PIN_TP_CLK, HIGH); delayMicroseconds(1);
    r = (r << 1) | digitalRead(PIN_TP_MISO);
    digitalWrite(PIN_TP_CLK, LOW);  delayMicroseconds(1);
  }
  return (r >> 3) & 0x0FFF;   // 12비트 값 (0~4095)
}

// 터치 원시값 읽기. 눌려 있지 않으면 false
static bool xptRead(int16_t& rx, int16_t& ry) {
  digitalWrite(PIN_TP_CS, LOW);
  int z1 = xpt(0xB1), z2 = xpt(0xC1);
  int z = z1 + 4095 - z2;
  if (z < 450) { xpt(0xD0); digitalWrite(PIN_TP_CS, HIGH); return false; }
  int xs[5], ys[5];
  xpt(0x91);                                  // 첫 값은 버림
  for (int i = 0; i < 5; i++) { ys[i] = xpt(0x91); xs[i] = xpt(0xD1); }
  z1 = xpt(0xB1); z2 = xpt(0xC0);             // 마지막에 다시 확인 + 절전
  digitalWrite(PIN_TP_CS, HIGH);
  if (z1 + 4095 - z2 < 450) return false;
  // 정렬해서 가운데 3개 평균 (튀는 값 제거)
  for (int i = 0; i < 4; i++) for (int j = i + 1; j < 5; j++) {
    if (xs[j] < xs[i]) { int t = xs[i]; xs[i] = xs[j]; xs[j] = t; }
    if (ys[j] < ys[i]) { int t = ys[i]; ys[i] = ys[j]; ys[j] = t; }
  }
  if (xs[3] - xs[1] > 120 || ys[3] - ys[1] > 120) return false;   // 너무 흔들리면 무시
  rx = (xs[1] + xs[2] + xs[3]) / 3;
  ry = (ys[1] + ys[2] + ys[3]) / 3;
  return true;
}

bool llTouchScreen(int16_t& x, int16_t& y) {
  int16_t rx, ry;
  if (!xptRead(rx, ry)) return false;
  int16_t a = cal.swap ? ry : rx;
  int16_t b = cal.swap ? rx : ry;
  int32_t sx = (int32_t)(a - cal.x0) * 239 / (cal.x1 - cal.x0);
  int32_t sy = (int32_t)(b - cal.y0) * 319 / (cal.y1 - cal.y0);
  if (sx < 0) sx = 0;
  if (sx > 239) sx = 239;
  if (sy < 0) sy = 0;
  if (sy > 319) sy = 319;
  if (settings.flip) { sx = 239 - sx; sy = 319 - sy; }
  x = sx; y = sy;
  return true;
}

// 보정용: 손가락(펜)을 누르고 있는 동안 평균값을 구함
static void calSample(int px, int py, int16_t& rx, int16_t& ry) {
  lcd.fillScreen(TFT_WHITE);
  lcd.setTextColor(TFT_BLACK, TFT_WHITE);
  lcd.setFont(&fonts::efontKR_16);
  lcd.setTextDatum(middle_center);
  lcd.drawString("터치 보정", 120, 130);
  lcd.drawString("빨간 + 의 가운데를", 120, 160);
  lcd.drawString("펜으로 꾹 눌러 주세요", 120, 182);
  lcd.drawFastHLine(px - 12, py, 25, TFT_RED);
  lcd.drawFastVLine(px, py - 12, 25, TFT_RED);
  lcd.drawCircle(px, py, 6, TFT_RED);
  int16_t a, b;
  while (xptRead(a, b)) delay(10);        // 이전 터치 떼기
  delay(200);
  long sa = 0, sb = 0; int n = 0;
  while (n < 30) {
    if (xptRead(a, b)) { sa += a; sb += b; n++; }
    delay(10);
  }
  rx = sa / n; ry = sb / n;
  lcd.fillCircle(px, py, 6, TFT_GREEN);
  llToneOn(1500); delay(60); llToneOff();
  while (xptRead(a, b)) delay(10);
  delay(150);
}

void touchCalibrate() {
  lcd.setRotation(0);
  int16_t ax, ay, bx, by, cx, cy;
  calSample(20, 20, ax, ay);      // 왼쪽 위
  calSample(220, 20, bx, by);     // 오른쪽 위  (화면 x 만 바뀜)
  calSample(20, 300, cx, cy);     // 왼쪽 아래  (화면 y 만 바뀜)
  // 화면 x 가 바뀔 때 원시값 x, y 중 어느 쪽이 더 많이 변했는지로 축 뒤바뀜 판단
  cal.swap = abs(by - ay) > abs(bx - ax) ? 1 : 0;
  int16_t a1 = cal.swap ? ay : ax, a2 = cal.swap ? by : bx;   // x축 원시값
  int16_t b1 = cal.swap ? ax : ay, b3 = cal.swap ? cx : cy;   // y축 원시값
  // 20 -> 220 (200픽셀) 을 0 -> 239 로 늘리기
  cal.x0 = a1 - (int32_t)(a2 - a1) * 20 / 200;
  cal.x1 = a1 + (int32_t)(a2 - a1) * 219 / 200;
  cal.y0 = b1 - (int32_t)(b3 - b1) * 20 / 280;
  cal.y1 = b1 + (int32_t)(b3 - b1) * 299 / 280;
  if (cal.x1 == cal.x0) cal.x1 = cal.x0 + 1;
  if (cal.y1 == cal.y0) cal.y1 = cal.y0 + 1;
  kvSetBytes("tcal", &cal, sizeof(cal));
  settingsApply();
}

// ---- 소리: 스피커 핀에 PWM 으로 음을 냄 ----
static uint8_t volDuty() {
  static const uint8_t D[4] = { 0, 6, 24, 128 };   // 듀티가 작을수록 작은 소리
  return D[settings.volume & 3];
}
#if ESP_ARDUINO_VERSION_MAJOR >= 3
void llToneOn(uint16_t f)  { digitalWrite(PIN_AMP_EN, LOW); ledcWriteTone(PIN_SPK, f); ledcWrite(PIN_SPK, volDuty()); }
void llToneOff()           { ledcWriteTone(PIN_SPK, 0); ledcWrite(PIN_SPK, 0); digitalWrite(PIN_AMP_EN, HIGH); }
static void toneSetup()    { ledcAttach(PIN_SPK, 2000, 8); ledcWrite(PIN_SPK, 0); }
#else
#define SPK_CH 0
void llToneOn(uint16_t f)  { digitalWrite(PIN_AMP_EN, LOW); ledcWriteTone(SPK_CH, f); ledcWrite(SPK_CH, volDuty()); }
void llToneOff()           { ledcWriteTone(SPK_CH, 0); ledcWrite(SPK_CH, 0); digitalWrite(PIN_AMP_EN, HIGH); }
static void toneSetup()    { ledcSetup(SPK_CH, 2000, 8); ledcAttachPin(PIN_SPK, SPK_CH); ledcWrite(SPK_CH, 0); }
#endif

void llLed(bool r, bool g, bool b) {
  digitalWrite(PIN_LED_R, r ? LOW : HIGH);
  digitalWrite(PIN_LED_G, g ? LOW : HIGH);
  digitalWrite(PIN_LED_B, b ? LOW : HIGH);
}

// 절전 중 빠른 확인: 지금 화면이 눌려 있나? (압력만 재고, 끝나면 터치 칩을 IRQ 켜진 대기 상태로)
static bool xptPressedQuick() {
  digitalWrite(PIN_TP_CS, LOW);
  int z1 = xpt(0xB1), z2 = xpt(0xC1);
  xpt(0xD0);                                   // PD=00 → 대기 + 누르면 IRQ 가 LOW
  digitalWrite(PIN_TP_CS, HIGH);
  return z1 + 4095 - z2 >= 450;
}

// ---- 가벼운 절전: 화면 끄고 CPU 멈춤. 화면 터치 또는 BOOT 버튼으로 깨어나 이어서 실행 ----
//  터치 칩의 IRQ 선만 믿지 않고, 0.2초마다 아주 잠깐 깨어나 화면이 눌렸는지 직접 확인해요.
//  (보드에 따라 IRQ 선(GPIO36)이 떠 있거나 신호가 약하면 IRQ 로는 안 깨어나는 일이 있어서)
//  잠깐 깨어 확인하는 데 1ms 정도라 배터리는 거의 더 들지 않아요.
void llSleep() {
  static uint8_t falseIrq = 0;                 // IRQ 가 울렸는데 눌린 게 아니었던 횟수
  lcd.sleep();                                 // 백라이트 끄고 화면 칩 절전 (화면 내용은 유지)
  digitalWrite(PIN_AMP_EN, HIGH);
  Serial.flush();
  while (true) {
    xptPressedQuick();                         // 터치 칩을 IRQ 켜진 상태로 맞춰 두기
    bool useIrq = falseIrq < 3 && digitalRead(PIN_TP_IRQ) == HIGH;
    if (useIrq) gpio_wakeup_enable((gpio_num_t)PIN_TP_IRQ, GPIO_INTR_LOW_LEVEL);
    gpio_wakeup_enable((gpio_num_t)PIN_BOOT, GPIO_INTR_LOW_LEVEL);
    esp_sleep_enable_gpio_wakeup();
    esp_sleep_enable_timer_wakeup(200000);     // 0.2초마다 잠깐 깨어 확인
    esp_light_sleep_start();
    esp_sleep_wakeup_cause_t why = esp_sleep_get_wakeup_cause();
    gpio_wakeup_disable((gpio_num_t)PIN_TP_IRQ);
    gpio_wakeup_disable((gpio_num_t)PIN_BOOT);
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
    if (digitalRead(PIN_BOOT) == LOW) break;
    if (xptPressedQuick()) {                   // 조금 뒤 한 번 더 눌려 있으면 진짜 터치
      delay(8);
      if (xptPressedQuick()) break;
    }
    if (why == ESP_SLEEP_WAKEUP_GPIO && falseIrq < 3) falseIrq++;   // IRQ 잡음 → 3번 넘으면 IRQ 는 안 씀
  }
  lcd.wakeup();
}

// ---- 깊은 절전: BOOT 버튼(LOW)으로만 깨어남. 깨어나면 처음부터 다시 시작 ----
void llDeepSleep() {
  lcd.sleep();
  digitalWrite(PIN_AMP_EN, HIGH);
  llLed(false, false, false);
  while (digitalRead(PIN_BOOT) == LOW) delay(10);
  esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_BOOT, 0);
  esp_deep_sleep_start();
}

int batteryMilliVolts() {
  // 배터리 전압이 1/2 로 나뉘어 들어온다고 보고 2배 (보드마다 다를 수 있어요)
  uint32_t s = 0;
  for (int i = 0; i < 8; i++) s += analogReadMilliVolts(PIN_BAT);
  return s / 8 * 2;
}

void llBegin() {
  Serial.begin(115200);
  pinMode(PIN_TP_CLK, OUTPUT);  pinMode(PIN_TP_MOSI, OUTPUT);
  pinMode(PIN_TP_CS, OUTPUT);   pinMode(PIN_TP_MISO, INPUT);
  pinMode(PIN_TP_IRQ, INPUT);
  digitalWrite(PIN_TP_CS, HIGH); digitalWrite(PIN_TP_CLK, LOW);
  pinMode(PIN_LED_R, OUTPUT); pinMode(PIN_LED_G, OUTPUT); pinMode(PIN_LED_B, OUTPUT);
  llLed(false, false, false);
  pinMode(PIN_AMP_EN, OUTPUT); digitalWrite(PIN_AMP_EN, HIGH);
  pinMode(PIN_BOOT, INPUT_PULLUP);
  toneSetup();
  kvGetBytes("tcal", &cal, sizeof(cal));   // 저장된 터치 보정값
}

// ※ BOOT 버튼을 누른 채 전원을 켜면 ESP32 가 '업로드 대기 모드'로 들어가서 코드가 실행되지 않아요.
//   그래서 켜진 뒤 시작 화면('스터디패드' 글자)이 보일 때 BOOT 를 누르면 보정하도록 했어요.
bool touchNeedsCalibration() {
  TouchCal t;
  return !kvGetBytes("tcal", &t, sizeof(t)) || bootButtonDown();
}

#endif  // HW_E32R28T
