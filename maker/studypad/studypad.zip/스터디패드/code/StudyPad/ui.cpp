#include "ui.h"

void uiFont(uint8_t px) {
  if (px <= 12)      lcd.setFont(&fonts::efontKR_12);
  else if (px <= 16) lcd.setFont(&fonts::efontKR_16);
  else               lcd.setFont(&fonts::efontKR_24);
  lcd.setTextSize(1);
}

void uiTopBar(const char* title, uint16_t color) {
  lcd.fillRect(0, 0, SCREEN_W, TOPBAR_H, color);
  // 홈(뒤로) 버튼
  lcd.fillRoundRect(4, 4, 34, 24, 6, lcd.color565(255, 255, 255));
  lcd.fillTriangle(13, 16, 25, 9, 25, 23, color);
  uiFont(16);
  lcd.setTextDatum(middle_left);
  lcd.setTextColor(TFT_WHITE, color);
  lcd.drawString(title, 46, 17);
}

bool uiHitHome(const Touch& t) {
  static const Btn home = { 0, 0, 44, TOPBAR_H };
  return home.hit(t);
}

void uiButton(const Btn& b, const char* label, uint16_t bg, uint16_t fg, uint8_t font) {
  lcd.fillRoundRect(b.x, b.y, b.w, b.h, 8, bg);
  uiFont(font);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(fg, bg);
  lcd.drawString(label, b.x + b.w / 2, b.y + b.h / 2 + 1);
}

void uiCenter(const char* s, int cx, int cy, uint16_t fg, uint16_t bg) {
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(fg, bg);
  lcd.drawString(s, cx, cy);
}

void uiFitText(const char* s, int x, int y, int maxW, uint16_t fg, uint16_t bg,
               lgfx::textdatum_t datum, uint8_t bigPx) {
  char buf[80];
  strlcpy(buf, s, sizeof(buf));
  uiFont(bigPx);
  if (lcd.textWidth(buf) > maxW) uiFont(12);
  if (lcd.textWidth(buf) > maxW) {              // 그래도 길면 뒤를 빼고 '..'
    char t[84] = "..";
    int n = strlen(buf);
    while (n > 0) {
      do { n--; } while (n > 0 && (buf[n] & 0xC0) == 0x80);   // 한글(3바이트) 중간에서 자르지 않게
      memcpy(t, buf, n); strcpy(t + n, "..");
      if (lcd.textWidth(t) <= maxW) break;
    }
    strlcpy(buf, t, sizeof(buf));
  }
  lcd.setTextDatum(datum);
  lcd.setTextColor(fg, bg);
  lcd.drawString(buf, x, y);
}

static int utf8Len(uint8_t c) {
  if (c < 0x80) return 1;
  if ((c & 0xE0) == 0xC0) return 2;
  if ((c & 0xF0) == 0xE0) return 3;
  if ((c & 0xF8) == 0xF0) return 4;
  return 1;
}

int uiWrap(const char* s, int x, int y, int w, int lineH, uint16_t fg, uint16_t bg, bool center, bool draw) {
  char line[200];
  int lines = 0;
  const char* p = s;
  lcd.setTextColor(fg, bg);
  lcd.setTextDatum(center ? top_center : top_left);
  while (*p) {
    while (*p == ' ') p++;
    if (!*p) break;
    int len = 0, lastSpace = -1;
    const char* q = p;
    const char* afterSpace = nullptr;
    while (*q && *q != '\n') {
      int cl = utf8Len((uint8_t)*q);
      if (len + cl >= (int)sizeof(line) - 1) break;
      memcpy(line + len, q, cl);
      line[len + cl] = 0;
      if (len > 0 && lcd.textWidth(line) > w) { line[len] = 0; break; }
      if (*q == ' ') { lastSpace = len; afterSpace = q + 1; }
      len += cl; q += cl;
    }
    line[len] = 0;
    if (*q && *q != '\n' && lastSpace > 0) { line[lastSpace] = 0; q = afterSpace; }
    if (draw) lcd.drawString(line, center ? x + w / 2 : x, y);
    lines++;
    y += lineH;
    p = q;
    if (*p == '\n') p++;
  }
  return lines;
}

bool uiConfirm(const char* msg) {
  waitRelease();
  lcd.fillRoundRect(16, 96, 208, 128, 12, C_TEXT);
  lcd.fillRoundRect(18, 98, 204, 124, 11, C_CARD);
  uiFont(16);
  int n = uiWrap(msg, 26, 0, 188, 20, C_TEXT, C_CARD, true, false);
  uiWrap(msg, 26, 140 - n * 10, 188, 20, C_TEXT, C_CARD, true, true);
  Btn no = { 30, 176, 84, 36 }, yes = { 126, 176, 84, 36 };
  uiButton(no, "아니오", C_LINE, C_TEXT);
  uiButton(yes, "예", C_BAD, TFT_WHITE);
  while (true) {
    Touch t = readTouch();
    if (yes.hit(t)) { sfx(SFX_CLICK); return true; }
    if (no.hit(t))  { sfx(SFX_CLICK); return false; }
    delay(5);
  }
}

void uiToast(const char* msg, uint16_t bg, uint16_t ms) {
  uiFont(16);
  int w = lcd.textWidth(msg) + 32;
  if (w > 230) w = 230;
  int x = (SCREEN_W - w) / 2;
  lcd.fillRoundRect(x, 140, w, 40, 10, bg);
  uiCenter(msg, SCREEN_W / 2, 161, TFT_WHITE, bg);
  uint32_t end = millis() + ms;
  while ((int32_t)(millis() - end) < 0) { readTouch(); delay(5); }
}

void uiTabs(const char* const* labels, int n, int sel, int y, uint16_t color) {
  int w = SCREEN_W / n;
  uiFont(16);
  for (int i = 0; i < n; i++) {
    bool on = (i == sel);
    uint16_t bg = on ? C_CARD : C_BG;
    lcd.fillRect(i * w, y, w, 30, bg);
    lcd.fillRect(i * w, y + 27, w, 3, on ? color : C_LINE);
    uiCenter(labels[i], i * w + w / 2, y + 14, on ? color : C_SUB, bg);
  }
}

int uiTabHit(const Touch& t, int n, int y) {
  if (t.type != T_UP || t.longed) return -1;
  if (t.y < y || t.y >= y + 30 || t.sy < y || t.sy >= y + 30) return -1;
  return t.x / (SCREEN_W / n);
}

void uiBattery(int x, int y, uint16_t fg, uint16_t bg) {
  int p = batteryPercent();
  lcd.fillRect(x, y, 44, 14, bg);
  lcd.drawRect(x + 20, y + 2, 20, 10, fg);
  lcd.fillRect(x + 40, y + 5, 2, 4, fg);
  int w = 16 * p / 100;
  lcd.fillRect(x + 22, y + 4, w, 6, p < 20 ? C_BAD : fg);
  char s[6];
  snprintf(s, sizeof(s), "%d", p);
  lcd.setFont(&fonts::Font0);
  lcd.setTextDatum(middle_right);
  lcd.setTextColor(fg, bg);
  lcd.drawString(s, x + 18, y + 7);
}

void uiShuffle16(uint16_t* a, int n) {
  for (int i = n - 1; i > 0; i--) {
    int j = random(i + 1);
    uint16_t t = a[i]; a[i] = a[j]; a[j] = t;
  }
}

void uiShuffle(uint8_t* a, int n) {
  for (int i = n - 1; i > 0; i--) {
    int j = random(i + 1);
    uint8_t t = a[i]; a[i] = a[j]; a[j] = t;
  }
}

// ---------------------------------------------------------------------
//  퀴즈 결과 화면 (다시 하기 = true)
// ---------------------------------------------------------------------
bool uiResult(const char* title, uint16_t color, int score, int total) {
  lcd.fillScreen(C_BG);
  uiTopBar(title, color);
  lcd.fillRoundRect(20, 50, 200, 160, 16, C_CARD);
  uiFont(16);
  uiCenter("결과", 120, 74, C_SUB, C_CARD);
  char s[64];
  snprintf(s, sizeof(s), "%d / %d", score, total);
  lcd.setFont(&fonts::FreeSansBold24pt7b);
  uiCenter(s, 120, 120, C_TEXT, C_CARD);
  int stars = total ? (score * 3 + total - 1) / total : 0;   // 0~3개
  if (score == 0) stars = 0;
  for (int i = 0; i < 3; i++) {
    int cx = 84 + i * 36;
    uint16_t c = i < stars ? UI_RGB(255, 196, 0) : C_LINE;
    lcd.fillTriangle(cx, 150, cx - 13, 180, cx + 13, 180, c);
    lcd.fillTriangle(cx - 14, 160, cx + 14, 160, cx, 188, c);
  }
  uiFont(16);
  const char* msg = score == total ? "완벽해요!" : (score * 2 >= total ? "잘했어요!" : "조금만 더 힘내요!");
  uiCenter(msg, 120, 198, color, C_CARD);
  if (score == total) { sfx(SFX_WIN); ledFlash(false, true, false, 1500); }
  Btn again = { 20, 228, 96, 44 }, menu = { 124, 228, 96, 44 };
  uiButton(again, "다시 하기", color);
  uiButton(menu, "메뉴로", C_SUB);
  while (true) {
    Touch t = readTouch();
    if (again.hit(t)) { sfx(SFX_CLICK); return true; }
    if (menu.hit(t) || uiHitHome(t)) { sfx(SFX_CLICK); return false; }
    delay(5);
  }
}


// 보기 버튼: 글자가 길면 작은 글꼴로 두 줄
void uiChoice(const Btn& b, const char* text, uint16_t bg, uint16_t fg, uint16_t border) {
  lcd.fillRoundRect(b.x, b.y, b.w, b.h, 8, bg);
  if (border != bg) lcd.drawRoundRect(b.x, b.y, b.w, b.h, 8, border);
  uiFont(16);
  if (lcd.textWidth(text) <= b.w - 16) {
    uiCenter(text, b.x + b.w / 2, b.y + b.h / 2 + 1, fg, bg);
  } else {
    uiFont(12);
    int lines = uiWrap(text, b.x + 6, 0, b.w - 12, 14, fg, bg, true, false);
    uiWrap(text, b.x + 6, b.y + b.h / 2 - lines * 7 + 1, b.w - 12, 14, fg, bg, true);
  }
}

