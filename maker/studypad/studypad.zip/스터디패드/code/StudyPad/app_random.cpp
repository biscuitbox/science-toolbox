// =====================================================================
//  주사위 · 번호 뽑기 · 동전
//   - 번호 뽑기: 1 ~ N 중에서 뽑기 (발표 순서 정할 때!)
//     '중복 없이'를 켜면 한 번 나온 번호는 다시 안 나와요.
// =====================================================================
#include "apps.h"

namespace {

const char* const TABS[3] = { "주사위", "번호 뽑기", "동전" };
const int TAB_Y = TOPBAR_H;
const int AREA_Y = TAB_Y + 30;

// ---------------- 주사위 ----------------
int diceCount = 1, dice[2] = { 1, 1 };
const Btn D1 = { 8, 74, 110, 32 }, D2 = { 122, 74, 110, 32 }, ROLL = { 30, 266, 180, 46 };

void drawDie(int cx, int cy, int v, uint16_t color) {
  const int s = 76, h = s / 2;
  lcd.fillRoundRect(cx - h, cy - h, s, s, 14, TFT_WHITE);
  lcd.drawRoundRect(cx - h, cy - h, s, s, 14, C_LINE);
  int d = 20, r = 7;
  bool p[7] = { false };   // 0:가운데 1:왼위 2:오아래 3:오위 4:왼아래 5:왼가운데 6:오가운데
  if (v % 2) p[0] = true;
  if (v >= 2) p[1] = p[2] = true;
  if (v >= 4) p[3] = p[4] = true;
  if (v == 6) p[5] = p[6] = true;
  uint16_t pc = (v == 1) ? C_BAD : color;
  if (p[0]) lcd.fillCircle(cx, cy, v == 1 ? 10 : r, pc);
  if (p[1]) lcd.fillCircle(cx - d, cy - d, r, pc);
  if (p[2]) lcd.fillCircle(cx + d, cy + d, r, pc);
  if (p[3]) lcd.fillCircle(cx + d, cy - d, r, pc);
  if (p[4]) lcd.fillCircle(cx - d, cy + d, r, pc);
  if (p[5]) lcd.fillCircle(cx - d, cy, r, pc);
  if (p[6]) lcd.fillCircle(cx + d, cy, r, pc);
}

void drawDiceFaces() {
  lcd.fillRect(0, 116, SCREEN_W, 146, C_BG);
  if (diceCount == 1) drawDie(120, 176, dice[0], C_TEXT);
  else { drawDie(64, 176, dice[0], C_TEXT); drawDie(176, 176, dice[1], C_TEXT); }
}

void drawDiceSum() {
  if (diceCount == 2) {
    char s[64];
    snprintf(s, sizeof(s), "합계 %d", dice[0] + dice[1]);
    uiFont(16);
    lcd.fillRect(0, 226, SCREEN_W, 30, C_BG);
    uiCenter(s, 120, 240, C_RAND, C_BG);
  }
}

void drawDice() {
  lcd.fillRect(0, AREA_Y, SCREEN_W, SCREEN_H - AREA_Y, C_BG);
  uiButton(D1, "1개", diceCount == 1 ? C_RAND : C_LINE, diceCount == 1 ? TFT_WHITE : C_TEXT);
  uiButton(D2, "2개", diceCount == 2 ? C_RAND : C_LINE, diceCount == 2 ? TFT_WHITE : C_TEXT);
  drawDiceFaces();
  drawDiceSum();
  uiButton(ROLL, "굴리기!", C_RAND, TFT_WHITE, 24);
}

void rollDice() {
  for (int i = 0; i < 12; i++) {
    dice[0] = random(1, 7); dice[1] = random(1, 7);
    drawDiceFaces();
    sfx(SFX_TICK);
    uint32_t u = millis() + 40 + i * 12;
    while ((int32_t)(millis() - u) < 0) { readTouch(); delay(2); }
  }
  drawDiceSum();
  sfx(SFX_OK);
  ledFlash(false, false, true, 300);
}

// ---------------- 번호 뽑기 ----------------
int maxN = 30;
bool noRepeat = true;
uint8_t used[13];            // 1~100 사용 표시
int history[8], histN = 0, lastPick = 0;
const Btn NM = { 8, 70, 40, 34 }, NP = { 192, 70, 40, 34 }, NOREP = { 8, 112, 224, 30 };
const Btn PICK = { 8, 266, 150, 46 }, CLR = { 164, 266, 68, 46 };

bool isUsed(int n) { return used[n >> 3] & (1 << (n & 7)); }
int usedCount() { int c = 0; for (int i = 1; i <= maxN; i++) if (isUsed(i)) c++; return c; }

void drawBigNumber(int n, uint16_t color) {
  lcd.fillRect(0, 148, SCREEN_W, 74, C_BG);
  if (n <= 0) return;
  char s[64];
  snprintf(s, sizeof(s), "%d", n);
  lcd.setFont(&fonts::Font7);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(color, C_BG);
  lcd.drawString(s, 120, 186);
}

void drawPickInfo() {
  char s[48];
  lcd.fillRect(0, 222, SCREEN_W, 40, C_BG);
  uiFont(12);
  if (noRepeat) snprintf(s, sizeof(s), "남은 번호 %d개", maxN - usedCount());
  else          snprintf(s, sizeof(s), "같은 번호가 또 나올 수 있어요");
  uiCenter(s, 120, 230, C_SUB, C_BG);
  char h[64] = "";
  for (int i = 0; i < histN; i++) {
    char b[8]; snprintf(b, sizeof(b), i ? ", %d" : "%d", history[i]);
    strcat(h, b);
  }
  if (histN) uiCenter(h, 120, 250, C_TEXT, C_BG);
}

void drawPicker() {
  lcd.fillRect(0, AREA_Y, SCREEN_W, SCREEN_H - AREA_Y, C_BG);
  char s[64];
  snprintf(s, sizeof(s), "1 ~ %d 번", maxN);
  uiFont(24);
  lcd.fillRect(50, 70, 140, 34, C_BG);
  uiCenter(s, 120, 88, C_TEXT, C_BG);
  uiButton(NM, "-", C_LINE, C_TEXT, 24);
  uiButton(NP, "+", C_LINE, C_TEXT, 24);
  uiButton(NOREP, noRepeat ? "중복 없이 뽑기: 켜짐" : "중복 없이 뽑기: 꺼짐", noRepeat ? C_OK : C_LINE, noRepeat ? TFT_WHITE : C_TEXT, 12);
  drawBigNumber(lastPick, C_RAND);
  drawPickInfo();
  uiButton(PICK, "뽑기!", C_RAND, TFT_WHITE, 24);
  uiButton(CLR, "처음부터", C_SUB, TFT_WHITE, 12);
}

void resetPicker() { memset(used, 0, sizeof(used)); histN = 0; lastPick = 0; }

void pick() {
  int left = maxN - (noRepeat ? usedCount() : 0);
  if (left <= 0) { uiToast("번호를 다 뽑았어요", C_RAND); drawPicker(); return; }
  int n;
  do { n = random(1, maxN + 1); } while (noRepeat && isUsed(n));
  for (int i = 0; i < 14; i++) {                 // 두근두근 연출
    drawBigNumber(random(1, maxN + 1), C_LINE);
    sfx(SFX_TICK);
    uint32_t u = millis() + 40 + i * 10;
    while ((int32_t)(millis() - u) < 0) { readTouch(); delay(2); }
  }
  lastPick = n;
  if (noRepeat) used[n >> 3] |= 1 << (n & 7);
  if (histN == 8) { memmove(history, history + 1, sizeof(int) * 7); histN = 7; }
  history[histN++] = n;
  drawBigNumber(n, C_RAND);
  drawPickInfo();
  sfx(SFX_OK);
  ledFlash(true, true, false, 400);
}

// ---------------- 동전 ----------------
int coin = 0;   // 0 = 없음, 1 = 앞, 2 = 뒤
const Btn FLIP = { 30, 266, 180, 46 };

void drawCoinFace(int w) {     // w = 보이는 폭 (회전 연출)
  lcd.fillRect(0, 90, SCREEN_W, 160, C_BG);
  if (coin == 0) return;
  uint16_t c = coin == 1 ? UI_RGB(240, 190, 40) : UI_RGB(190, 195, 205);
  lcd.fillEllipse(120, 160, w, 66, c);
  lcd.drawEllipse(120, 160, w, 66, C_SUB);
  if (w > 40) {
    uiFont(24);
    uiCenter(coin == 1 ? "앞" : "뒤", 120, 160, C_TEXT, c);
  }
}

void drawCoin() {
  lcd.fillRect(0, AREA_Y, SCREEN_W, SCREEN_H - AREA_Y, C_BG);
  drawCoinFace(66);
  if (coin == 0) { uiFont(16); uiCenter("동전을 던져 보세요", 120, 160, C_SUB, C_BG); }
  uiButton(FLIP, "던지기!", C_RAND, TFT_WHITE, 24);
}

void flipCoin() {
  int result = random(1, 3);
  for (int i = 0; i < 10; i++) {
    coin = (i % 2) + 1;
    for (int w = 66; w > 6; w -= 20) { drawCoinFace(w); delay(8); readTouch(); }
    for (int w = 6; w <= 66; w += 20) { drawCoinFace(w); delay(8); readTouch(); }
    sfx(SFX_TICK);
  }
  coin = result;
  drawCoinFace(66);
  sfx(SFX_OK);
}

}  // namespace

void appRandom() {
  int tab = 0;
  maxN = kvGetInt("pick_max", 30);
  lcd.fillScreen(C_BG);
  uiTopBar("주사위 · 뽑기", C_RAND);
  uiTabs(TABS, 3, tab, TAB_Y, C_RAND);
  drawDice();
  while (true) {
    Touch t = readTouch();
    if (uiHitHome(t)) { kvSetInt("pick_max", maxN); return; }
    int th = uiTabHit(t, 3, TAB_Y);
    if (th >= 0 && th != tab) {
      tab = th; sfx(SFX_CLICK);
      uiTabs(TABS, 3, tab, TAB_Y, C_RAND);
      if (tab == 0) drawDice(); else if (tab == 1) drawPicker(); else drawCoin();
      continue;
    }
    if (tab == 0) {
      if (D1.hit(t)) { diceCount = 1; sfx(SFX_CLICK); drawDice(); }
      if (D2.hit(t)) { diceCount = 2; sfx(SFX_CLICK); drawDice(); }
      if (ROLL.hit(t)) rollDice();
    } else if (tab == 1) {
      if (NM.hit(t) || NP.hit(t)) {
        maxN = constrain(maxN + (NP.hit(t) ? 1 : -1), 2, 100);
        resetPicker(); sfx(SFX_TICK); drawPicker();
      }
      if (t.type == T_LONG && (NM.in(t.x, t.y) || NP.in(t.x, t.y))) {   // 꾹 누르면 5씩
        maxN = constrain(maxN + (NP.in(t.x, t.y) ? 5 : -5), 2, 100);
        resetPicker(); sfx(SFX_TICK); drawPicker();
      }
      if (NOREP.hit(t)) { noRepeat = !noRepeat; resetPicker(); sfx(SFX_CLICK); drawPicker(); }
      if (PICK.hit(t)) pick();
      if (CLR.hit(t)) { resetPicker(); sfx(SFX_CLICK); drawPicker(); }
    } else {
      if (FLIP.hit(t)) flipCoin();
    }
    delay(5);
  }
}
