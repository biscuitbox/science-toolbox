// =====================================================================
//  상식 퀴즈 - 분야를 골라 10문제! 답을 고르면 해설이 나와요.
//  문제와 분야 이름은 data_quiz.h 에서 추가/수정할 수 있어요.
// =====================================================================
#include "apps.h"
#include "data_quiz.h"

static_assert(QUIZ_COUNT <= QUIZ_MAX, "data_quiz.h 문제가 너무 많아요 (QUIZ_MAX 확인)");

namespace {

uint16_t qpool[QUIZ_MAX];

const uint16_t CAT_COLOR[QUIZ_CAT_COUNT] = {
  UI_RGB(52, 152, 219), UI_RGB(192, 57, 43), UI_RGB(39, 174, 96),
  UI_RGB(155, 89, 182), UI_RGB(211, 120, 40), UI_RGB(233, 30, 99),
};

int countCat(int cat) {
  int n = 0;
  for (int i = 0; i < QUIZ_COUNT; i++) if (cat < 0 || QUIZ[i].cat == cat) n++;
  return n;
}

bool runQuiz(int cat) {
  int n = 0;
  for (int i = 0; i < QUIZ_COUNT; i++)
    if (cat < 0 || QUIZ[i].cat == cat) qpool[n++] = i;
  if (n == 0) { uiToast("문제가 없어요", C_BAD); return false; }
  uiShuffle16(qpool, n);
  int qn = n < 10 ? n : 10, score = 0;
  const char* title = cat < 0 ? "상식 퀴즈 - 전체" : QUIZ_CATS[cat];
  uint16_t color = cat < 0 ? C_QUIZ : CAT_COLOR[cat];

  for (int q = 0; q < qn; q++) {
    const QuizQ& Q = QUIZ[qpool[q]];
    uint8_t order[4] = { 0, 1, 2, 3 };
    uiShuffle(order, 4);

    lcd.fillScreen(C_BG);
    char s[64];
    if (cat < 0) snprintf(s, sizeof(s), "전체 · %s", QUIZ_CATS[Q.cat]);   // 전체 모드: 분야 표시
    uiTopBar(cat < 0 ? s : title, cat < 0 ? CAT_COLOR[Q.cat] : color);
    snprintf(s, sizeof(s), "%d / %d", q + 1, qn);
    uiFont(12);
    lcd.setTextDatum(middle_right);
    lcd.setTextColor(TFT_WHITE, cat < 0 ? CAT_COLOR[Q.cat] : color);
    lcd.drawString(s, 234, 17);
    lcd.fillRect(0, TOPBAR_H, SCREEN_W * q / qn, 3, C_WARN);

    lcd.fillRoundRect(8, 42, 224, 98, 12, C_CARD);
    uiFont(16);
    int lines = uiWrap(Q.q, 16, 0, 208, 21, C_TEXT, C_CARD, false, false);
    uiWrap(Q.q, 16, 42 + (98 - lines * 21) / 2 + 2, 208, 21, C_TEXT, C_CARD);

    Btn b[4];
    for (int k = 0; k < 4; k++) {
      b[k] = { 8, (int16_t)(148 + k * 43), 224, 38 };
      uiChoice(b[k], Q.a[order[k]], C_CARD, C_TEXT, C_LINE);
    }
    int picked = -1;
    while (picked < 0) {
      Touch t = readTouch();
      if (uiHitHome(t)) return false;
      for (int k = 0; k < 4; k++) if (b[k].hit(t)) picked = k;
      delay(5);
    }
    bool ok = order[picked] == 0;
    for (int k = 0; k < 4; k++) {
      if (order[k] == 0) uiChoice(b[k], Q.a[0], C_OK, TFT_WHITE, C_OK);
      else if (k == picked) uiChoice(b[k], Q.a[order[k]], C_BAD, TFT_WHITE, C_BAD);
    }
    if (ok) { score++; sfx(SFX_OK); ledFlash(false, true, false, 300); }
    else    { sfx(SFX_WRONG); ledFlash(true, false, false, 300); }
    uint32_t until = millis() + 700;
    while ((int32_t)(millis() - until) < 0) { readTouch(); delay(5); }

    // 해설 화면
    uint16_t exBg = ok ? UI_RGB(226, 247, 235) : UI_RGB(253, 232, 230);
    lcd.fillRoundRect(8, 146, 224, 170, 12, exBg);
    uiFont(16);
    lcd.setTextDatum(top_left);
    lcd.setTextColor(ok ? C_OK : C_BAD);
    lcd.drawString(ok ? "정답이에요!" : "아쉬워요!", 18, 154);
    uiFont(12);
    char ans[128];
    snprintf(ans, sizeof(ans), "정답: %s", Q.a[0]);
    int al = uiWrap(ans, 18, 178, 204, 16, C_TEXT, exBg);
    uiWrap(Q.ex, 18, 182 + al * 16, 204, 16, C_SUB, exBg);
    Btn next = { 140, 274, 84, 34 };
    uiButton(next, q + 1 < qn ? "다음 ▶" : "결과 ▶", color);
    while (true) {
      Touch t = readTouch();
      if (uiHitHome(t)) return false;
      if (next.hit(t)) { sfx(SFX_CLICK); break; }
      delay(5);
    }
  }
  // 분야별 최고 점수 저장
  char key[12];
  snprintf(key, sizeof(key), "qz_best%d", cat + 1);
  if (score > kvGetInt(key, 0)) kvSetInt(key, score);
  return uiResult(title, color, score, qn);
}

}  // namespace

void appQuiz() {
  // 0 = 전체, 1~6 = 분야
  Btn B[QUIZ_CAT_COUNT + 1];
  B[0] = { 8, 40, 224, 42 };
  for (int i = 0; i < QUIZ_CAT_COUNT; i++)
    B[i + 1] = { (int16_t)(8 + (i % 2) * 116), (int16_t)(90 + (i / 2) * 64), 108, 58 };
  bool redraw = true;
  while (true) {
    if (redraw) {
      redraw = false;
      lcd.fillScreen(C_BG);
      uiTopBar("상식 퀴즈", C_QUIZ);
      char key[12], s[64];
      snprintf(key, sizeof(key), "qz_best0");
      lcd.fillRoundRect(B[0].x, B[0].y, B[0].w, B[0].h, 10, C_QUIZ);
      uiFont(16);
      uiCenter("전체 섞어서 풀기", 120, B[0].y + 14, TFT_WHITE, C_QUIZ);
      snprintf(s, sizeof(s), "%d문제 · 최고 %d점", QUIZ_COUNT, (int)kvGetInt(key, 0));
      uiFont(12);
      uiCenter(s, 120, B[0].y + 32, TFT_WHITE, C_QUIZ);
      for (int i = 0; i < QUIZ_CAT_COUNT; i++) {
        const Btn& b = B[i + 1];
        uint16_t c = CAT_COLOR[i];
        lcd.fillRoundRect(b.x, b.y, b.w, b.h, 10, c);
        uiFont(16);
        uiCenter(QUIZ_CATS[i], b.x + b.w / 2, b.y + 17, TFT_WHITE, c);
        snprintf(key, sizeof(key), "qz_best%d", i + 1);
        snprintf(s, sizeof(s), "%d문제", countCat(i));
        uiFont(12);
        uiCenter(s, b.x + b.w / 2, b.y + 36, TFT_WHITE, c);
        snprintf(s, sizeof(s), "최고 %d점", (int)kvGetInt(key, 0));
        uiCenter(s, b.x + b.w / 2, b.y + 50, TFT_WHITE, c);
      }
      uiFont(12);
      uiCenter("문제는 data_quiz.h 에서 추가해요", 120, 300, C_SUB, C_BG);
    }
    Touch t = readTouch();
    if (uiHitHome(t)) return;
    for (int i = 0; i <= QUIZ_CAT_COUNT; i++) {
      if (!B[i].hit(t)) continue;
      sfx(SFX_CLICK);
      waitRelease();
      while (runQuiz(i - 1)) {}
      redraw = true;
    }
    delay(5);
  }
}
