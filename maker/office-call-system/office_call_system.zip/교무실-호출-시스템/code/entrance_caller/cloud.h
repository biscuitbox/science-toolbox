// ============================================================
//  클라우드 중계 (Firebase 실시간 DB) + 선생님 명단 관리
//  - 별도 작업(태스크)에서 돌아가므로 화면이 멈추지 않음
//  - 입구 호출기와 공통 단말이 같은 파일을 씀
// ============================================================
#pragma once
#include <Arduino.h>

#define MAX_TEACHERS 64

struct Teacher {
  char id[12];
  char name[32];      // 한글 10글자까지
  char subject[32];
};

// 현재 선생님 명단 (화면 쪽에서만 읽기. 바꾸는 것은 teachersApplyPending())
extern Teacher TEACHERS[MAX_TEACHERS];
extern int TEACHER_COUNT;

struct CloudSettings {
  int alertSeconds;        // 공통 단말 알림 시간
  int flashSeconds;        // 처음 깜빡임 시간
  int repeatBlockSeconds;  // 같은 선생님 재호출 제한
  int soundLevel;          // 공통 단말 효과음 크기 1~10
};
extern CloudSettings cloudSettings;

void teachersInit();              // 저장된 명단(없으면 teachers.h) 불러오기. setup()에서 먼저 호출
bool teachersApplyPending();      // loop()에서 호출: 새 명단을 받았으면 적용하고 true
int findTeacherById(const char *id);

// ---------- 공통 ----------
enum CloudRole { ROLE_ENTRANCE, ROLE_TERMINAL };
void cloudBegin(CloudRole role);  // Wi-Fi 시작 후 호출
bool cloudEnabled();              // config.h 에 Firebase 정보가 있는지
bool cloudOk();                   // 지금 클라우드와 통신 중인지
const char *cloudStatusText();    // 화면 표시용 한 줄 상태
const char *cloudDeviceId();
bool serverTimeKnown();
int64_t serverNowMs();            // 서버 기준 현재 시각(ms). 모르면 0

// ---------- 입구 호출기 ----------
void cloudSendCall(const char *callId, const Teacher &t);
bool cloudCallDelivered(const char *callId);   // 어느 단말이든 받았으면 true
bool cloudTeacherOnline(const char *tid);      // 그 선생님을 맡은 단말이 켜져 있는지

// ---------- 공통 단말 ----------
struct IncomingCall {
  char id[40];
  char tid[12];
  char name[32];
  char subject[32];
};
bool cloudPopCall(IncomingCall &c);            // 새 호출이 있으면 true
void cloudAckCall(const char *callId);         // 받았다고 표시
void cloudSetCoverage(const String &covers);   // "*" 또는 "T01,T02"
