// 입구 호출기 프로그램 본체 (설정은 config.h, 명단은 teachers.h 탭에서 바꾸세요)
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <U8g2lib.h>              // 반드시 Arduino_GFX보다 먼저! (한글 폰트 기능 활성화)
#include <Arduino_GFX_Library.h>

#include "config.h"
#include "cloud.h"              // 클라우드 중계 + 선생님 명단
#include "wifi_ui.h"            // 화면에서 Wi-Fi 바꾸기

#ifndef ADMIN_PIN
#define ADMIN_PIN "0000"        // 관리 메뉴 비밀번호 (config.h 에 #define ADMIN_PIN "숫자" 로 바꾸세요)
#endif
#include "gt911_touch.h"
#include "fonts.h"            // 한글 폰트 (데이터는 fonts.cpp)

// ---------------- 하드웨어 설정 ----------------
#define PIN_BL 1                 // 백라이트
#define DISPLAY_ROTATION 0       // 화면이 거꾸로 보이면 2 로 바꾸세요
#define TOUCH_MIRROR_X false     // 터치 위치가 좌우로 반대면 바꾸세요
#define TOUCH_MIRROR_Y false     // 터치 위치가 위아래로 반대면 바꾸세요
#define TOUCH_DEBUG false        // true: 터치한 곳에 빨간 점 표시 (보정용)

static const int W = 480, H = 272;

Arduino_DataBus *bus = new Arduino_ESP32QSPI(45 /*CS*/, 47 /*SCK*/, 21 /*D0*/, 48 /*D1*/, 40 /*D2*/, 39 /*D3*/);
Arduino_GFX *panel = new Arduino_NV3041A(bus, GFX_NOT_DEFINED, DISPLAY_ROTATION, true /*IPS*/);
Arduino_Canvas *gfx = new Arduino_Canvas(W, H, panel);   // PSRAM 화면 버퍼 → 깜빡임 없이 그리기
GT911Touch touch(8 /*SDA*/, 4 /*SCL*/, 3 /*INT*/, 38 /*RST*/);
WiFiUDP udp;

// ---------------- 색상 ----------------
static inline uint16_t RGB(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}
const uint16_t COL_BG = RGB(244, 246, 249);
const uint16_t COL_BAR = RGB(30, 58, 95);
const uint16_t COL_TEXT = RGB(30, 33, 38);
const uint16_t COL_SUB = RGB(95, 105, 118);
const uint16_t COL_BTN = RGB(255, 255, 255);
const uint16_t COL_BORDER = RGB(196, 205, 216);
const uint16_t COL_PRIMARY = RGB(37, 99, 235);
const uint16_t COL_OK = RGB(22, 150, 70);
const uint16_t COL_WARN = RGB(225, 125, 0);
const uint16_t COL_BAD = RGB(210, 40, 40);
const uint16_t COL_GREY = RGB(150, 156, 163);
const uint16_t COL_WHITE = 0xFFFF;

// ---------------- 화면 상태 ----------------
enum Screen { SCR_HOME, SCR_TEACHERS, SCR_CONFIRM, SCR_CALLING, SCR_DONE, SCR_FAIL, SCR_PIN, SCR_ADMIN, SCR_WIFI };
Screen screen = SCR_HOME;
bool needRedraw = true;
uint32_t screenSince = 0, lastTouchMs = 0;

const char *subjects[32];
int subjectCount = 0;
int selSubject = -1, page = 0;
Teacher selT;                        // 고른 선생님 (명단이 바뀌어도 유지되도록 복사해 둠)

// 호출 상태
String callId;
int sendCount = 0;
uint32_t callStart = 0, lastSend = 0;
bool repeatNotice = false;           // 방금 호출한 선생님을 또 누른 경우
uint32_t lastDelivered[MAX_TEACHERS];    // 선생님별 마지막 전달 시각 (중복 호출 방지, 제한 시간은 구글 시트 [설정])

// 이 선생님 호출을 받는 교무실 단말이 켜져 있는지 (HB 수신 시각)
uint32_t lastSeen[MAX_TEACHERS];
uint32_t onlineSignature = 0;
bool udpStarted = false;
int netState = -1;                   // 위쪽 상태 표시가 바뀌었는지 확인용

// ---------------- 버튼 ----------------
enum { BTN_BACK = 1, BTN_PREV, BTN_NEXT, BTN_CALL, BTN_HOME, BTN_RETRY, BTN_WIFI,
       BTN_SUBJECT = 100, BTN_TEACHER = 200 };
struct Button { int16_t x, y, w, h; int id; };
Button buttons[20];
int buttonCount = 0;

// ============================================================
//  그리기 도우미
// ============================================================
void textAt(const char *s, int x, int cy, const uint8_t *font, uint16_t color, int align /*0왼 1가운데 2오른*/) {
  gfx->setFont(font);
  gfx->setTextColor(color);
  int16_t x1, y1;
  uint16_t w, h;
  gfx->getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  int sx = (align == 0) ? x - x1 : (align == 1) ? x - x1 - w / 2 : x - x1 - w;
  gfx->setCursor(sx, cy - y1 - h / 2);
  gfx->print(s);
}
void textCenter(const char *s, int cx, int cy, const uint8_t *font, uint16_t color) { textAt(s, cx, cy, font, color, 1); }
void textCenter(const String &s, int cx, int cy, const uint8_t *font, uint16_t color) { textAt(s.c_str(), cx, cy, font, color, 1); }

void addButton(int x, int y, int w, int h, int id, const char *label, const uint8_t *font,
               uint16_t bg, uint16_t fg, bool border = true) {
  gfx->fillRoundRect(x, y, w, h, 10, bg);
  if (border) gfx->drawRoundRect(x, y, w, h, 10, COL_BORDER);
  if (label) textCenter(label, x + w / 2, y + h / 2, font, fg);
  if (buttonCount < 20) buttons[buttonCount++] = {(int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h, id};
}

int hitTest(int x, int y) {
  for (int i = buttonCount - 1; i >= 0; i--) {
    const Button &b = buttons[i];
    if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) return b.id;
  }
  return 0;
}

bool isOnline(int t) {                // 그 선생님을 맡은 공통 단말이 켜져 있는지 (직접 통신 또는 클라우드)
  if (t < 0) return false;
  return (lastSeen[t] != 0 && millis() - lastSeen[t] < 12000) || cloudTeacherOnline(TEACHERS[t].id);
}

// 0: Wi-Fi 연결 중, 1: 클라우드 연결됨, 2: 직접 통신만 (클라우드 안 됨/사용 안 함)
int currentNetState() {
  if (WiFi.status() != WL_CONNECTED) return 0;
  return cloudOk() ? 1 : 2;
}

void drawTopBar(const char *title) {
  gfx->fillRect(0, 0, W, 40, COL_BAR);
  textAt(title, 14, 20, font_kr26, COL_WHITE, 0);
  int st = currentNetState();
  const char *label = st == 1 ? "● 연결됨" : (st == 2 ? (cloudEnabled() ? "● 직접 통신" : "● 연결됨") : "● 연결 중");
  uint16_t col = st == 1 || (st == 2 && !cloudEnabled()) ? RGB(120, 220, 140) : (st == 2 ? RGB(255, 200, 90) : RGB(255, 140, 140));
  textAt(label, W - 12, 20, font_kr18, col, 2);
}

// 격자 버튼 6개(3x2) + 페이지 이동
static const int GRID_COLS = 3, GRID_ROWS = 2, PER_PAGE = GRID_COLS * GRID_ROWS;
static const int BW = 140, BH = 62, GAP = 12, GX = (W - (GRID_COLS * BW + (GRID_COLS - 1) * GAP)) / 2, GY = 78;
void gridCell(int slot, int &x, int &y) {
  x = GX + (slot % GRID_COLS) * (BW + GAP);
  y = GY + (slot / GRID_COLS) * (BH + 10);
}
void drawPager(int total) {
  int pages = (total + PER_PAGE - 1) / PER_PAGE;
  if (pages <= 1) return;
  if (page > 0) addButton(W - 230, 222, 105, 42, BTN_PREV, "← 이전", font_kr18, COL_BTN, COL_TEXT);
  if (page < pages - 1) addButton(W - 117, 222, 105, 42, BTN_NEXT, "다음 →", font_kr18, COL_BTN, COL_TEXT);
}

// ============================================================
//  화면별 그리기
// ============================================================
void drawHome() {
  gfx->fillScreen(COL_BG);
  drawTopBar("교무실 선생님 호출");
  textCenter("찾는 선생님의 교과를 고르세요", W / 2, 60, font_kr18, COL_SUB);
  for (int i = page * PER_PAGE; i < subjectCount && i < (page + 1) * PER_PAGE; i++) {
    int x, y;
    gridCell(i - page * PER_PAGE, x, y);
    addButton(x, y, BW, BH, BTN_SUBJECT + i, subjects[i], font_kr26, COL_BTN, COL_TEXT);
  }
  if (subjectCount > PER_PAGE) drawPager(subjectCount);
  else textCenter("교무실 안으로 들어가지 말고 여기서 기다려요", W / 2, 243, font_kr18, COL_SUB);
}

int teachersOfSubject(int *out) {
  int n = 0;
  for (int t = 0; t < TEACHER_COUNT; t++)
    if (strcmp(TEACHERS[t].subject, subjects[selSubject]) == 0) out[n++] = t;
  return n;
}

void drawTeachers() {
  gfx->fillScreen(COL_BG);
  String title = String(subjects[selSubject]) + " 선생님";
  drawTopBar(title.c_str());
  textCenter("호출할 선생님을 누르세요", W / 2, 60, font_kr18, COL_SUB);
  int list[MAX_TEACHERS];
  int n = teachersOfSubject(list);
  for (int i = page * PER_PAGE; i < n && i < (page + 1) * PER_PAGE; i++) {
    int t = list[i], x, y;
    gridCell(i - page * PER_PAGE, x, y);
    addButton(x, y, BW, BH, BTN_TEACHER + t, nullptr, font_kr26, COL_BTN, COL_TEXT);
    textCenter(TEACHERS[t].name, x + BW / 2, y + 23, font_kr26, COL_TEXT);
    bool on = isOnline(t);
    textCenter(on ? "● 켜짐" : "○ 꺼짐", x + BW / 2, y + 48, font_kr18, on ? COL_OK : COL_GREY);
  }
  addButton(12, 222, 130, 42, BTN_BACK, "← 처음으로", font_kr18, COL_BTN, COL_TEXT);
  drawPager(n);
}

void drawConfirm() {
  gfx->fillScreen(COL_BG);
  drawTopBar("호출 확인");
  textCenter(String(selT.name) + " 선생님을", W / 2, 88, font_kr36, COL_TEXT);
  textCenter("호출할까요?", W / 2, 134, font_kr26, COL_TEXT);
  if (!isOnline(findTeacherById(selT.id)))
    textCenter("교무실 호출 단말이 꺼져 있을 수 있어요", W / 2, 172, font_kr18, COL_WARN);
  addButton(40, 196, 180, 62, BTN_BACK, "취소", font_kr26, COL_BTN, COL_TEXT);
  addButton(260, 196, 180, 62, BTN_CALL, "호출하기", font_kr26, COL_PRIMARY, COL_WHITE, false);
}

void drawCalling() {
  gfx->fillScreen(COL_BG);
  drawTopBar("호출 중");
  textCenter(String(selT.name) + " 선생님께", W / 2, 105, font_kr36, COL_TEXT);
  textCenter("알림을 보내는 중...", W / 2, 160, font_kr26, COL_PRIMARY);
}

void drawDone() {
  gfx->fillScreen(COL_OK);
  textCenter(String(selT.name) + " 선생님께", W / 2, 40, font_kr26, COL_WHITE);
  if (!repeatNotice) {
    textCenter("알렸어요!", W / 2, 88, font_kr36, COL_WHITE);
    textCenter("교무실 화면에 이름이 떴어요", W / 2, 136, font_kr26, COL_WHITE);
  } else {
    textCenter("조금 전에 이미 알렸어요", W / 2, 88, font_kr36, COL_WHITE);
    textCenter("조금만 더 기다려 주세요", W / 2, 136, font_kr26, COL_WHITE);
  }
  textCenter("입구에서 기다려 주세요", W / 2, 172, font_kr26, COL_WHITE);
  addButton(150, 206, 180, 54, BTN_HOME, "처음으로", font_kr26, COL_WHITE, COL_OK, false);
}

void drawFail() {
  gfx->fillScreen(COL_BG);
  drawTopBar("안내");
  textCenter("교무실 단말에 연결되지 않았어요", W / 2, 92, font_kr26, COL_BAD);
  textCenter("단말이 꺼져 있거나 Wi-Fi 문제일 수 있어요", W / 2, 132, font_kr18, COL_SUB);
  addButton(40, 186, 180, 62, BTN_RETRY, "다시 호출", font_kr26, COL_PRIMARY, COL_WHITE, false);
  addButton(260, 186, 180, 62, BTN_HOME, "처음으로", font_kr26, COL_BTN, COL_TEXT);
}

// 관리 메뉴 (위쪽 파란 띠를 5초 누르고 비밀번호 입력)
void drawAdmin() {
  gfx->fillScreen(COL_BG);
  drawTopBar("관리 메뉴");
  bool ok = WiFi.status() == WL_CONNECTED;
  String w1 = String("Wi-Fi: ") + wifiCurrentSsid() + (ok ? String(" (") + WiFi.localIP().toString() + ")" : String(" (연결 안 됨)"));
  String w2 = String("클라우드: ") + cloudStatusText();
  String w3 = String("기기 ID: ") + cloudDeviceId();
  textAt(w1.c_str(), 14, 66, font_kr18, ok ? COL_TEXT : COL_BAD, 0);
  textAt(w2.c_str(), 14, 96, font_kr18, cloudOk() ? COL_TEXT : COL_WARN, 0);
  textAt(w3.c_str(), 14, 126, font_kr18, COL_SUB, 0);
  addButton(40, 170, 190, 70, BTN_WIFI, "Wi-Fi 바꾸기", font_kr26, COL_PRIMARY, COL_WHITE, false);
  addButton(250, 170, 190, 70, BTN_HOME, "나가기", font_kr26, COL_BTN, COL_TEXT);
}

void redraw() {
  buttonCount = 0;
  switch (screen) {
    case SCR_HOME: drawHome(); break;
    case SCR_TEACHERS: drawTeachers(); break;
    case SCR_CONFIRM: drawConfirm(); break;
    case SCR_CALLING: drawCalling(); break;
    case SCR_DONE: drawDone(); break;
    case SCR_FAIL: drawFail(); break;
    case SCR_ADMIN: drawAdmin(); break;
    case SCR_PIN:
    case SCR_WIFI: buttonCount = 0; uiDraw(); break;
  }
  gfx->flush();
  needRedraw = false;
}

void goScreen(Screen s) {
  screen = s;
  screenSince = millis();
  needRedraw = true;
}

// ============================================================
//  네트워크 (UDP 브로드캐스트)
//  메시지 형식: TAG|종류|호출ID|선생님ID
//   입구 → CALL (전달 확인 올 때까지 0.8초마다 반복)
//   단말 → RECV (받았음), HB (3초마다 생존 신호)
// ============================================================
void sendMsg(const char *type, const Teacher &t) {
  if (WiFi.status() != WL_CONNECTED || !udpStarted) return;
  char buf[160];
  snprintf(buf, sizeof(buf), "%s|%s|%s|%s|%s|%s", SYSTEM_TAG, type, callId.c_str(), t.id, t.name, t.subject);
  udp.beginPacket(WiFi.broadcastIP(), CALL_PORT);
  udp.print(buf);
  udp.endPacket();
}


void markDelivered() {
  int t = findTeacherById(selT.id);
  if (t >= 0) lastDelivered[t] = millis();
  goScreen(SCR_DONE);
}

void processMessage(char *msg) {
  char *f[6] = {0};
  int n = 0;
  char *save;
  for (char *p = strtok_r(msg, "|", &save); p && n < 6; p = strtok_r(NULL, "|", &save)) f[n++] = p;
  if (n < 3 || strcmp(f[0], SYSTEM_TAG) != 0) return;

  if (strcmp(f[1], "HB") == 0) {                       // 교무실 단말 생존 신호: CALL|HB|T01,T02|IDLE
    char *save2;
    for (char *id = strtok_r(f[2], ",", &save2); id; id = strtok_r(NULL, ",", &save2)) {
      if (strcmp(id, "*") == 0) { for (int t = 0; t < TEACHER_COUNT; t++) lastSeen[t] = millis(); continue; }
      int t = findTeacherById(id);
      if (t >= 0) lastSeen[t] = millis();
    }
    return;
  }
  if (n < 4 || callId.length() == 0 || callId != f[2]) return;   // 현재 호출과 관계없는 메시지
  if (strcmp(f[1], "RECV") == 0 && screen == SCR_CALLING) {          // 교무실 단말이 받음
    repeatNotice = false;
    markDelivered();
  }
}

void handleNetwork() {
  int st = currentNetState();
  if (st != netState) {                                  // 연결 상태가 바뀌면 위쪽 표시 갱신
    if (netState <= 0 && st > 0) {
      Serial.printf("Wi-Fi 연결됨: %s\n", WiFi.localIP().toString().c_str());
      if (!udpStarted) udpStarted = udp.begin(CALL_PORT);
    }
    netState = st;
    needRedraw = true;
  }
  if (!udpStarted) return;
  int len;
  while ((len = udp.parsePacket()) > 0) {
    char buf[512];
    int r = udp.read(buf, sizeof(buf) - 1);
    if (r <= 0) continue;
    buf[r] = 0;
    processMessage(buf);
  }
}

// ============================================================
//  호출 동작
// ============================================================
void startCall() {
  int t = findTeacherById(selT.id);
  uint32_t last = t >= 0 ? lastDelivered[t] : 0;
  if (last && millis() - last < (uint32_t)cloudSettings.repeatBlockSeconds * 1000) {   // 방금 알린 선생님 → 다시 보내지 않음
    repeatNotice = true;
    goScreen(SCR_DONE);
    return;
  }
  char id[40];                                         // 호출 ID: 서버 시각 + 임의 값 (두 경로 공통)
  snprintf(id, sizeof(id), "%lld-%04lx", (long long)(serverTimeKnown() ? serverNowMs() : millis()), (unsigned long)(esp_random() & 0xFFFF));
  callId = id;
  cloudSendCall(id, selT);                             // 클라우드로 올림 (백그라운드)
  sendCount = 0;
  lastSend = 0;
  callStart = millis();
  goScreen(SCR_CALLING);
}

void handleTimers() {
  uint32_t now = millis();
  switch (screen) {
    case SCR_CALLING:
      if (cloudCallDelivered(callId.c_str())) { repeatNotice = false; markDelivered(); break; }
      if (now - lastSend > 800) {                      // 같은 Wi-Fi 직접 통신도 함께 (최대 약 12초)
        if (sendCount >= 15) { goScreen(SCR_FAIL); break; }
        sendMsg("CALL", selT);
        sendCount++;
        lastSend = now;
      }
      break;
    case SCR_DONE:
      if (now - screenSince > 8000) { page = 0; goScreen(SCR_HOME); }
      break;
    case SCR_PIN:
    case SCR_ADMIN:
      if (now - lastTouchMs > 60000 && now - screenSince > 60000) { page = 0; goScreen(SCR_HOME); }   // 1분 동안 안 쓰면 닫기
      break;
    case SCR_FAIL:
      if (now - screenSince > 20000) { page = 0; goScreen(SCR_HOME); }
      break;
    case SCR_TEACHERS:
    case SCR_CONFIRM: {
      if (now - lastTouchMs > 30000 && now - screenSince > 30000) { page = 0; goScreen(SCR_HOME); break; }
      uint32_t sig = 0;                                 // 켜짐/꺼짐이 바뀌면 다시 그림
      for (int t = 0; t < TEACHER_COUNT && t < 32; t++) if (isOnline(t)) sig |= (1UL << t);
      if (sig != onlineSignature) { onlineSignature = sig; needRedraw = true; }
      break;
    }
    default: break;
  }
}

// ============================================================
//  터치
// ============================================================
bool getTouchPoint(int &x, int &y) {
  uint16_t rx, ry;
  if (!touch.read(rx, ry)) return false;
  int mx = touch.maxX() ? touch.maxX() : W, my = touch.maxY() ? touch.maxY() : H;
  int tx = (int32_t)rx * W / mx, ty = (int32_t)ry * H / my;
  bool fx = TOUCH_MIRROR_X, fy = TOUCH_MIRROR_Y;
  if (DISPLAY_ROTATION == 2) { fx = !fx; fy = !fy; }
  if (fx) tx = W - 1 - tx;
  if (fy) ty = H - 1 - ty;
  x = constrain(tx, 0, W - 1);
  y = constrain(ty, 0, H - 1);
  if (TOUCH_DEBUG) Serial.printf("터치 원래값 (%u,%u) → 화면 (%d,%d)\n", rx, ry, x, y);
  return true;
}

void onButton(int id) {
  if (id >= BTN_TEACHER) {
    selT = TEACHERS[id - BTN_TEACHER];
    goScreen(SCR_CONFIRM);
  } else if (id >= BTN_SUBJECT) {
    selSubject = id - BTN_SUBJECT;
    page = 0;
    goScreen(SCR_TEACHERS);
  } else switch (id) {
    case BTN_PREV: page--; needRedraw = true; break;
    case BTN_NEXT: page++; needRedraw = true; break;
    case BTN_BACK:
      if (screen == SCR_CONFIRM) { goScreen(SCR_TEACHERS); }
      else { page = 0; goScreen(SCR_HOME); }
      break;
    case BTN_CALL:
    case BTN_RETRY: startCall(); break;
    case BTN_HOME: page = 0; goScreen(SCR_HOME); break;
    case BTN_WIFI: wifiUiStart(); goScreen(SCR_WIFI); break;
  }
}

void handleTouch() {
  static bool wasDown = false, longFired = false;
  static uint32_t lastPoll = 0, downSince = 0;
  if (millis() - lastPoll < 20) return;
  lastPoll = millis();
  int x, y;
  bool down = getTouchPoint(x, y);
  if (down && !wasDown) {
    lastTouchMs = millis();
    downSince = millis();
    longFired = false;
    if (TOUCH_DEBUG) { gfx->fillCircle(x, y, 6, COL_BAD); gfx->flush(); }
    if (millis() - screenSince > 300) {                  // 화면 바뀐 직후 연속 터치 방지
      if (screen == SCR_PIN || screen == SCR_WIFI) {      // 화면 키보드 / Wi-Fi 설정
        UiResult r = uiTap(x, y);
        needRedraw = true;
        if (screen == SCR_PIN && r == UI_DONE) {
          if (textInputValue() == ADMIN_PIN) goScreen(SCR_ADMIN);
          else { page = 0; goScreen(SCR_HOME); }
        } else if (screen == SCR_PIN && r == UI_CANCEL) {
          page = 0; goScreen(SCR_HOME);
        } else if (screen == SCR_WIFI && r != UI_NONE) {
          goScreen(SCR_ADMIN);
        }
      } else {
        int id = hitTest(x, y);
        if (id) onButton(id);
      }
    }
  }
  // 처음 화면 위쪽 파란 띠를 5초 누르면 관리 메뉴 (비밀번호 필요)
  if (down && wasDown && !longFired && y < 40 && screen == SCR_HOME && millis() - downSince > 5000) {
    longFired = true;
    textInputStart("관리자 비밀번호", "", true);
    goScreen(SCR_PIN);
  }
  wasDown = down;
}

// 명단에서 교과 목록 만들기 (중복 제거, 순서 유지)
void rebuildSubjects() {
  subjectCount = 0;
  for (int t = 0; t < TEACHER_COUNT; t++) {
    lastSeen[t] = 0;
    lastDelivered[t] = 0;
    bool found = false;
    for (int s = 0; s < subjectCount; s++) if (strcmp(subjects[s], TEACHERS[t].subject) == 0) found = true;
    if (!found && subjectCount < 32) subjects[subjectCount++] = TEACHERS[t].subject;
  }
}

// ============================================================
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\n교무실 입구 호출기 시작");

  teachersInit();                                           // 저장된 명단(없으면 teachers.h)
  rebuildSubjects();

  if (!gfx->begin()) Serial.println("화면 초기화 실패! (PSRAM: OPI PSRAM 설정 확인)");
  uiSetup(gfx, W, H, font_kr18, font_kr26);
  gfx->setUTF8Print(true);
  gfx->fillScreen(COL_BG);
  gfx->flush();
  ledcAttach(PIN_BL, 5000, 8);
  ledcWrite(PIN_BL, 255);

  if (touch.begin()) Serial.printf("터치 OK (주소 0x%02X, 해상도 %ux%u)\n", touch.address(), touch.maxX(), touch.maxY());
  else Serial.println("터치 칩을 찾지 못했습니다");

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);                                     // 절전 끄기: 브로드캐스트를 놓치지 않도록
  WiFi.setAutoReconnect(true);
  String ssid, pass;
  wifiLoadCreds(ssid, pass);                                // 화면에서 바꾼 Wi-Fi가 있으면 그것, 없으면 config.h
  WiFi.begin(ssid.c_str(), pass.c_str());
  cloudBegin(ROLE_ENTRANCE);                                // 클라우드 중계 시작 (백그라운드)

  goScreen(SCR_HOME);
}

void loop() {
  if (teachersApplyPending()) {                              // 구글 시트에서 새 명단이 옴
    rebuildSubjects();
    if (screen == SCR_HOME || screen == SCR_TEACHERS || screen == SCR_CONFIRM) { page = 0; goScreen(SCR_HOME); }
  }
  handleNetwork();
  handleTouch();
  if (screen == SCR_WIFI && uiLoop()) needRedraw = true;
  handleTimers();
  if (needRedraw) redraw();
  delay(5);
}
