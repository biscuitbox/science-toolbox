// 한글 폰트 데이터: 이 파일은 프로그램을 고쳐도 다시 컴파일되지 않아 업로드가 빨라짐
#include "fonts.h"
#include "font_kr18.h"
#include "font_kr26.h"
#include "font_kr36.h"
