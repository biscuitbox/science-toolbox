// 최소 GT911 정전식 터치 드라이버 (JC4827W543C용, 외부 라이브러리 불필요)
#pragma once
#include <Wire.h>

class GT911Touch {
public:
  GT911Touch(int sda, int scl, int intPin, int rstPin)
    : _sda(sda), _scl(scl), _int(intPin), _rst(rstPin) {}

  bool begin() {
    // 리셋 중 INT를 LOW로 유지하면 I2C 주소가 0x5D로 정해짐
    if (_rst >= 0 && _int >= 0) {
      pinMode(_int, OUTPUT);
      pinMode(_rst, OUTPUT);
      digitalWrite(_int, LOW);
      digitalWrite(_rst, LOW);
      delay(10);
      digitalWrite(_rst, HIGH);
      delay(10);
      pinMode(_int, INPUT);
      delay(60);
    }
    Wire.begin(_sda, _scl, 400000);
    const uint8_t candidates[2] = {0x5D, 0x14};
    for (uint8_t a : candidates) {
      Wire.beginTransmission(a);
      if (Wire.endTransmission() == 0) { _addr = a; break; }
    }
    if (!_addr) return false;
    uint8_t buf[4];
    if (readReg(0x8048, buf, 4)) {          // 터치 패널에 설정된 해상도
      _maxX = buf[0] | (buf[1] << 8);
      _maxY = buf[2] | (buf[3] << 8);
    }
    return true;
  }

  // 터치 중이면 true, x/y에는 터치 칩 원래 좌표가 들어감
  bool read(uint16_t &x, uint16_t &y) {
    if (!_addr) return false;
    uint8_t status;
    if (!readReg(0x814E, &status, 1)) return false;
    bool touched = false;
    if (status & 0x80) {
      uint8_t n = status & 0x0F;
      if (n > 0) {
        uint8_t p[6];
        if (readReg(0x8150, p, 6)) {
          x = p[0] | (p[1] << 8);
          y = p[2] | (p[3] << 8);
          touched = true;
          _lastX = x; _lastY = y;
        }
      }
      uint8_t zero = 0;
      writeReg(0x814E, &zero, 1);           // 읽음 표시
      _lastTouched = touched;
      return touched;
    }
    // 새 데이터가 없으면 직전 상태 유지 (손가락을 계속 대고 있는 경우)
    if (_lastTouched) { x = _lastX; y = _lastY; }
    return _lastTouched;
  }

  uint16_t maxX() const { return _maxX; }
  uint16_t maxY() const { return _maxY; }
  uint8_t address() const { return _addr; }

private:
  bool readReg(uint16_t reg, uint8_t *buf, uint8_t len) {
    Wire.beginTransmission(_addr);
    Wire.write(reg >> 8);
    Wire.write(reg & 0xFF);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom((int)_addr, (int)len) != len) return false;
    for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
    return true;
  }
  bool writeReg(uint16_t reg, const uint8_t *buf, uint8_t len) {
    Wire.beginTransmission(_addr);
    Wire.write(reg >> 8);
    Wire.write(reg & 0xFF);
    for (uint8_t i = 0; i < len; i++) Wire.write(buf[i]);
    return Wire.endTransmission() == 0;
  }

  int _sda, _scl, _int, _rst;
  uint8_t _addr = 0;
  uint16_t _maxX = 480, _maxY = 272;
  uint16_t _lastX = 0, _lastY = 0;
  bool _lastTouched = false;
};
