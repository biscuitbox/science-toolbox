// ============================================================
//  단말 화면에서 Wi-Fi 바꾸기 + 글자 입력(화면 키보드)
//  - 입구 호출기(480x272)와 공통 단말(1280x800 / 800x1280)이 같은 파일을 씀
//  - 바꾼 Wi-Fi는 기기에 저장되어 다음에 켤 때도 그대로 씀 (없으면 config.h 값)
// ============================================================
#pragma once
#include <Arduino.h>
#include <Arduino_GFX_Library.h>

// 저장된 Wi-Fi 정보 (없으면 config.h 의 WIFI_SSID / WIFI_PASS)
void wifiLoadCreds(String &ssid, String &pass);
String wifiCurrentSsid();

enum UiResult { UI_NONE, UI_DONE, UI_CANCEL };

// 화면 준비: 그릴 대상, 화면 크기, 작은 글꼴, 중간 글꼴
void uiSetup(Arduino_GFX *g, int w, int h, const uint8_t *fontSmall, const uint8_t *fontMid);

// ---- 글자 입력 (예: 관리자 비밀번호) ----
void textInputStart(const char *title, const String &initial, bool masked);
String textInputValue();

// ---- Wi-Fi 바꾸기 (검색 → 고르기 → 비밀번호 → 접속 확인 → 저장) ----
void wifiUiStart();

// 공통: 화면에 그리기 / 터치 처리 / 주기적 호출
void uiDraw();                    // 호출한 쪽에서 flush()
UiResult uiTap(int x, int y);     // UI_DONE 또는 UI_CANCEL 이면 끝
bool uiLoop();                    // 다시 그려야 하면 true (검색·접속 진행 상황)
