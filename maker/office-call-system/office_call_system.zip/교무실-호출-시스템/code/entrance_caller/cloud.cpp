// ============================================================
//  클라우드 중계 (Firebase 실시간 DB) + 선생님 명단 관리
//  데이터 구조
//    /config   : { teachers:[{id,name,subject}], settings:{...} }   ← 구글 시트가 씀
//    /calls/ID : { tid, name, subject, ts, from, recv:{단말ID:시각} } ← 입구가 쓰고 단말이 recv 표시
//    /devices/ID : { type, covers, ip, lastSeen }                   ← 각 기기가 주기적으로 씀
// ============================================================
#include "cloud.h"
#include "config.h"
#include "teachers.h"
#include <WiFi.h>
#include <NetworkClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <sys/time.h>
#include "esp_timer.h"

Teacher TEACHERS[MAX_TEACHERS];
int TEACHER_COUNT = 0;
CloudSettings cloudSettings = {10, 3, 30, 4};

static SemaphoreHandle_t mtx = NULL;
static void lock() { xSemaphoreTake(mtx, portMAX_DELAY); }
static void unlock() { xSemaphoreGive(mtx); }
static void ensureMutex() { if (!mtx) mtx = xSemaphoreCreateMutex(); }

// 새로 받은 명단 (화면 쪽 loop()에서 적용)
static Teacher pendingT[MAX_TEACHERS];
static int pendingCount = 0;
static CloudSettings pendingS;
static bool pendingFlag = false;

static CloudRole role = ROLE_ENTRANCE;
static bool started = false;
static volatile bool okFlag = false;
static char statusText[64] = "클라우드 사용 안 함";
static char deviceId[32] = "";
static String idToken;
static uint32_t tokenAt = 0;
static volatile int64_t serverOffsetMs = 0;
static volatile bool serverKnown = false;

static int64_t uptimeMs() { return esp_timer_get_time() / 1000; }

// ============================================================
//  명단 / 설정
// ============================================================
static bool parseConfig(const String &json, Teacher *out, int &count, CloudSettings &s) {
  JsonDocument doc;
  if (deserializeJson(doc, json)) return false;
  count = 0;
  auto addOne = [&](JsonObjectConst o) {
    const char *name = o["name"] | "";
    if (!name[0] || count >= MAX_TEACHERS) return;
    strlcpy(out[count].id, o["id"] | "", sizeof(out[count].id));
    strlcpy(out[count].name, name, sizeof(out[count].name));
    strlcpy(out[count].subject, o["subject"] | "기타", sizeof(out[count].subject));
    if (!out[count].id[0]) snprintf(out[count].id, sizeof(out[count].id), "X%02d", count + 1);
    count++;
  };
  JsonVariantConst t = doc["teachers"];
  if (t.is<JsonArrayConst>()) for (JsonObjectConst o : t.as<JsonArrayConst>()) addOne(o);
  else if (t.is<JsonObjectConst>()) for (JsonPairConst kv : t.as<JsonObjectConst>()) addOne(kv.value().as<JsonObjectConst>());
  s.alertSeconds = constrain((int)(doc["settings"]["alertSeconds"] | 10), 3, 120);
  s.flashSeconds = constrain((int)(doc["settings"]["flashSeconds"] | 3), 0, 30);
  s.repeatBlockSeconds = constrain((int)(doc["settings"]["repeatBlockSeconds"] | 30), 0, 600);
  s.soundLevel = constrain((int)(doc["settings"]["soundLevel"] | 4), 1, 10);
  return true;
}

void teachersInit() {
  ensureMutex();
  Preferences p;
  p.begin("callcfg", true);
  String json = p.getString("json", "");
  p.end();
  int n = 0;
  CloudSettings s = cloudSettings;
  if (json.length() && parseConfig(json, TEACHERS, n, s) && n > 0) {
    TEACHER_COUNT = n;
    cloudSettings = s;
    Serial.printf("저장된 명단 %d명 불러옴\n", n);
    return;
  }
  TEACHER_COUNT = 0;
  for (const DefaultTeacher &d : DEFAULT_TEACHERS) {
    if (TEACHER_COUNT >= MAX_TEACHERS) break;
    strlcpy(TEACHERS[TEACHER_COUNT].id, d.id, sizeof(TEACHERS[0].id));
    strlcpy(TEACHERS[TEACHER_COUNT].name, d.name, sizeof(TEACHERS[0].name));
    strlcpy(TEACHERS[TEACHER_COUNT].subject, d.subject, sizeof(TEACHERS[0].subject));
    TEACHER_COUNT++;
  }
  Serial.printf("기본 명단(teachers.h) %d명 사용\n", TEACHER_COUNT);
}

bool teachersApplyPending() {
  if (!mtx) return false;
  bool changed = false;
  lock();
  if (pendingFlag) {
    memcpy(TEACHERS, pendingT, sizeof(Teacher) * pendingCount);
    TEACHER_COUNT = pendingCount;
    cloudSettings = pendingS;
    pendingFlag = false;
    changed = true;
  }
  unlock();
  if (changed) Serial.printf("새 명단 적용: %d명\n", TEACHER_COUNT);
  return changed;
}

int findTeacherById(const char *id) {
  for (int t = 0; t < TEACHER_COUNT; t++)
    if (strcmp(TEACHERS[t].id, id) == 0) return t;
  return -1;
}

// ============================================================
//  서버 시각 (HTTP 응답의 Date 헤더로 맞춤 → NTP가 막혀 있어도 동작)
// ============================================================
static int64_t daysFromCivil(int y, unsigned m, unsigned d) {
  y -= m <= 2;
  const int era = (y >= 0 ? y : y - 399) / 400;
  const unsigned yoe = (unsigned)(y - era * 400);
  const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return (int64_t)era * 146097 + (int64_t)doe - 719468;
}

static void noteHttpDate(const String &date) {   // 예: "Tue, 24 Nov 2026 01:23:45 GMT"
  char wd[4], mon[4];
  int d, y, h, mi, s;
  if (sscanf(date.c_str(), "%3s, %d %3s %d %d:%d:%d", wd, &d, mon, &y, &h, &mi, &s) != 7) return;
  static const char *M = "JanFebMarAprMayJunJulAugSepOctNovDec";
  const char *p = strstr(M, mon);
  if (!p) return;
  int m = (p - M) / 3 + 1;
  int64_t sec = daysFromCivil(y, m, d) * 86400 + h * 3600 + mi * 60 + s;
  int64_t off = sec * 1000 + 500 - uptimeMs();
  if (!serverKnown || llabs(off - serverOffsetMs) > 1500) serverOffsetMs = off;
  serverKnown = true;
  if (time(nullptr) < 1700000000) {              // 시계가 안 맞춰져 있으면 서버 시각으로 맞춤
    setenv("TZ", "KST-9", 1);
    tzset();
    struct timeval tv = {(time_t)sec, 0};
    settimeofday(&tv, nullptr);
  }
}

bool serverTimeKnown() { return serverKnown; }
int64_t serverNowMs() { return serverKnown ? uptimeMs() + serverOffsetMs : 0; }

// ============================================================
//  HTTP 도우미
// ============================================================
static NetworkClientSecure dbTls;
static HTTPClient dbHttp;

static void setStatus(bool ok, const char *text) {
  okFlag = ok;
  if (strcmp(statusText, text) != 0) {
    strlcpy(statusText, text, sizeof(statusText));
    Serial.printf("[클라우드] %s\n", text);
  }
}

static String dbBase() {                          // 끝의 "/" 제거
  String b = FIREBASE_DB_URL;
  while (b.endsWith("/")) b.remove(b.length() - 1);
  return b;
}

// path 예: "/config", query 예: "&shallow=true"
static int dbRequest(const char *method, const String &path, const String &body, String *out, const String &query = "") {
  String url = dbBase() + path + ".json?auth=" + idToken + query;
  dbHttp.setReuse(true);
  dbHttp.setTimeout(8000);
  if (!dbHttp.begin(dbTls, url)) return -1;
  const char *hdrs[] = {"Date"};
  dbHttp.collectHeaders(hdrs, 1);
  int code;
  if (strcmp(method, "GET") == 0) code = dbHttp.GET();
  else {
    dbHttp.addHeader("Content-Type", "application/json");
    code = dbHttp.sendRequest(method, body);
  }
  if (code > 0) {
    String d = dbHttp.header("Date");
    if (d.length()) noteHttpDate(d);
    if (out) *out = dbHttp.getString();
  }
  dbHttp.end();
  if (code == 401) idToken = "";                 // 로그인 만료 → 다시 로그인
  if (code < 0) dbTls.stop();
  return code;
}

static bool signIn() {
  NetworkClientSecure tls;
  tls.useBuiltinCACertBundle();
  HTTPClient h;
  String url = String("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=") + FIREBASE_API_KEY;
  if (!h.begin(tls, url)) return false;
  h.addHeader("Content-Type", "application/json");
  JsonDocument req;
  req["email"] = DEVICE_EMAIL;
  req["password"] = DEVICE_PASSWORD;
  req["returnSecureToken"] = true;
  String body;
  serializeJson(req, body);
  int code = h.POST(body);
  String r = h.getString();
  h.end();
  if (code != 200) {
    Serial.printf("[클라우드] 로그인 실패 %d: %s\n", code, r.c_str());
    setStatus(false, code == 400 ? "클라우드 로그인 실패 (계정/API 키 확인)" : "클라우드 서버에 연결 안 됨");
    return false;
  }
  JsonDocument d;
  if (deserializeJson(d, r)) return false;
  idToken = d["idToken"].as<String>();
  tokenAt = millis();
  return idToken.length() > 0;
}

static void fetchConfig() {
  static String lastJson;
  String r;
  int code = dbRequest("GET", "/config", "", &r);
  if (code != 200) {
    setStatus(false, code == 401 ? "클라우드 권한 없음 (규칙 확인)" : "클라우드 응답 없음");
    return;
  }
  setStatus(true, "클라우드 연결됨");
  if (r == "null" || r == lastJson) return;
  Teacher tmp[MAX_TEACHERS];
  int n = 0;
  CloudSettings s = cloudSettings;
  if (!parseConfig(r, tmp, n, s) || n == 0) return;
  lastJson = r;
  lock();
  memcpy(pendingT, tmp, sizeof(Teacher) * n);
  pendingCount = n;
  pendingS = s;
  pendingFlag = true;
  unlock();
  Preferences p;                                 // 다음에 인터넷 없이 켜져도 쓰도록 저장
  p.begin("callcfg", false);
  p.putString("json", r);
  p.end();
}

static String coverStr = "*";

static void heartbeat() {
  JsonDocument d;
  d["type"] = role == ROLE_TERMINAL ? "terminal" : "entrance";
  lock();
  if (role == ROLE_TERMINAL) d["covers"] = coverStr;
  unlock();
  d["ip"] = WiFi.localIP().toString();
  d["lastSeen"][".sv"] = "timestamp";
  String body;
  serializeJson(d, body);
  dbRequest("PUT", String("/devices/") + deviceId, body, nullptr);
}

// ============================================================
//  입구 호출기: 호출 올리기, 전달 확인, 단말 켜짐 상태
// ============================================================
struct OutCall { char id[40]; Teacher t; };
static QueueHandle_t outQ = NULL;
static char deliveredId[40] = "";
static String onlineSet = ",";
static bool onlineAll = false;

void cloudSendCall(const char *callId, const Teacher &t) {
  if (!outQ) return;
  OutCall oc;
  strlcpy(oc.id, callId, sizeof(oc.id));
  oc.t = t;
  xQueueSend(outQ, &oc, 0);
}

bool cloudCallDelivered(const char *callId) {
  if (!mtx) return false;
  lock();
  bool r = strcmp(deliveredId, callId) == 0;
  unlock();
  return r;
}

bool cloudTeacherOnline(const char *tid) {
  if (!mtx) return false;
  lock();
  bool r = onlineAll || onlineSet.indexOf(String(",") + tid + ",") >= 0;
  unlock();
  return r;
}

static void processOutgoing() {
  OutCall oc;
  if (xQueueReceive(outQ, &oc, 0) != pdTRUE) return;
  JsonDocument d;
  d["tid"] = oc.t.id;
  d["name"] = oc.t.name;
  d["subject"] = oc.t.subject;
  d["from"] = deviceId;
  d["ts"][".sv"] = "timestamp";
  String body;
  serializeJson(d, body);
  String path = String("/calls/") + oc.id;
  int code = dbRequest("PUT", path, body, nullptr);
  Serial.printf("[클라우드] 호출 올림 %s → %d\n", oc.id, code);
  if (code != 200) return;
  uint32_t start = millis();
  while (millis() - start < 12000) {             // 단말이 받았는지 확인
    String r;
    int c = dbRequest("GET", path + "/recv", "", &r, "&shallow=true");
    if (c == 200 && r.length() && r != "null") {
      lock();
      strlcpy(deliveredId, oc.id, sizeof(deliveredId));
      unlock();
      Serial.println("[클라우드] 단말이 받음");
      break;
    }
    if (uxQueueMessagesWaiting(outQ)) break;     // 새 호출이 들어옴
    vTaskDelay(pdMS_TO_TICKS(400));
  }
}

static void fetchDevices() {
  String r;
  if (dbRequest("GET", "/devices", "", &r) != 200) return;
  JsonDocument d;
  if (deserializeJson(d, r)) return;
  int64_t now = serverNowMs();
  String set = ",";
  bool all = false;
  if (d.is<JsonObject>()) {
    for (JsonPair kv : d.as<JsonObject>()) {
      JsonObject o = kv.value().as<JsonObject>();
      if (strcmp(o["type"] | "", "terminal") != 0) continue;
      int64_t seen = o["lastSeen"] | (int64_t)0;
      if (!now || now - seen > 90000) continue;
      String c = o["covers"] | "";
      if (c == "*") all = true;
      else set += c + ",";
    }
  }
  lock();
  onlineSet = set;
  onlineAll = all;
  unlock();
}

// ============================================================
//  공통 단말: 실시간 스트림(SSE)으로 호출 받기
// ============================================================
static QueueHandle_t inQ = NULL, ackQ = NULL;
static NetworkClientSecure sTls;
static bool sConn = false, sChunked = false;
static uint32_t sLastData = 0, sLastTry = 0;
static int chunkState = 0;
static long chunkLeft = 0;
static String chunkLine, lineBuf, evName, evData;

bool cloudPopCall(IncomingCall &c) { return inQ && xQueueReceive(inQ, &c, 0) == pdTRUE; }

void cloudAckCall(const char *callId) {
  if (!ackQ) return;
  char id[40];
  strlcpy(id, callId, sizeof(id));
  xQueueSend(ackQ, id, 0);
}

void cloudSetCoverage(const String &covers) {
  ensureMutex();
  lock();
  coverStr = covers;
  unlock();
}

static void closeStream() {
  sTls.stop();
  sConn = false;
}

static bool readLine(String &out, uint32_t timeoutMs) {
  out = "";
  uint32_t t = millis();
  while (millis() - t < timeoutMs) {
    while (sTls.available()) {
      char ch = sTls.read();
      if (ch == '\n') return true;
      if (ch != '\r') out += ch;
    }
    if (!sTls.connected()) return false;
    vTaskDelay(pdMS_TO_TICKS(5));
  }
  return false;
}

static void onCallObject(const char *id, JsonObjectConst o) {
  if (!o["tid"].is<const char *>()) return;
  int64_t ts = o["ts"] | (int64_t)0;
  if (serverKnown && ts > 0 && serverNowMs() - ts > 20000) return;   // 오래된 호출은 무시
  if (!o["recv"][deviceId].isNull()) return;                          // 이미 받은 호출
  IncomingCall c;
  strlcpy(c.id, id, sizeof(c.id));
  strlcpy(c.tid, o["tid"] | "", sizeof(c.tid));
  strlcpy(c.name, o["name"] | "", sizeof(c.name));
  strlcpy(c.subject, o["subject"] | "", sizeof(c.subject));
  xQueueSend(inQ, &c, 0);
}

static void handleEvent() {
  if (evName == "keep-alive" || evName.isEmpty()) return;
  if (evName == "cancel" || evName == "auth_revoked") {
    Serial.printf("[클라우드] 스트림 종료: %s\n", evName.c_str());
    closeStream();
    if (evName == "auth_revoked") idToken = "";
    return;
  }
  if (evName != "put" && evName != "patch") return;
  JsonDocument doc;
  if (deserializeJson(doc, evData)) return;
  const char *path = doc["path"] | "";
  JsonVariantConst d = doc["data"];
  if (strcmp(path, "/") == 0) {
    if (d.is<JsonObjectConst>())
      for (JsonPairConst kv : d.as<JsonObjectConst>())
        if (kv.value().is<JsonObjectConst>()) onCallObject(kv.key().c_str(), kv.value().as<JsonObjectConst>());
  } else if (path[0] == '/' && !strchr(path + 1, '/') && d.is<JsonObjectConst>()) {
    onCallObject(path + 1, d.as<JsonObjectConst>());
  }
}

static void onStreamChar(char c) {
  if (c == '\n') {
    if (lineBuf.isEmpty()) {                      // 빈 줄 = 이벤트 하나 끝
      handleEvent();
      evName = "";
      evData = "";
    } else if (lineBuf.startsWith("event:")) {
      evName = lineBuf.substring(6);
      evName.trim();
    } else if (lineBuf.startsWith("data:")) {
      String part = lineBuf.substring(5);
      part.trim();
      evData += part;
    }
    lineBuf = "";
  } else if (c != '\r') {
    lineBuf += c;
  }
}

static void feedByte(char c) {
  if (!sChunked) { onStreamChar(c); return; }
  switch (chunkState) {                           // Transfer-Encoding: chunked 풀기
    case 0:                                        // 크기 줄
      if (c == '\n') {
        chunkLeft = strtol(chunkLine.c_str(), nullptr, 16);
        chunkLine = "";
        chunkState = chunkLeft > 0 ? 1 : 2;
      } else if (c != '\r') chunkLine += c;
      break;
    case 1:                                        // 데이터
      onStreamChar(c);
      if (--chunkLeft == 0) chunkState = 2;
      break;
    case 2:                                        // 데이터 뒤 CRLF
      if (c == '\n') chunkState = 0;
      break;
  }
}

static bool streamConnect() {
  String url = dbBase();
  String host = url.substring(url.indexOf("://") + 3);
  if (host.indexOf('/') >= 0) host = host.substring(0, host.indexOf('/'));
  String path = "/calls.json?auth=" + idToken + "&orderBy=%22ts%22";
  if (serverKnown) path += "&startAt=" + String((long long)(serverNowMs() - 20000));

  for (int hop = 0; hop < 3; hop++) {
    sTls.stop();
    if (!sTls.connect(host.c_str(), 443)) {
      setStatus(false, "클라우드 스트림 연결 실패");
      return false;
    }
    sTls.print(String("GET ") + path + " HTTP/1.1\r\nHost: " + host +
               "\r\nAccept: text/event-stream\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\n\r\n");
    String line;
    if (!readLine(line, 10000)) { closeStream(); return false; }
    int code = line.length() > 12 ? line.substring(9, 12).toInt() : 0;
    String location;
    bool chunked = false;
    while (readLine(line, 5000) && line.length()) {
      String low = line;
      low.toLowerCase();
      if (low.startsWith("location:")) { location = line.substring(9); location.trim(); }
      else if (low.startsWith("transfer-encoding:") && low.indexOf("chunked") > 0) chunked = true;
      else if (low.startsWith("date:")) { String d = line.substring(5); d.trim(); noteHttpDate(d); }
    }
    if ((code == 307 || code == 302 || code == 301) && location.length()) {   // 다른 서버로 안내됨
      String rest = location.substring(location.indexOf("://") + 3);
      host = rest.substring(0, rest.indexOf('/'));
      path = rest.substring(rest.indexOf('/'));
      continue;
    }
    if (code != 200) {
      Serial.printf("[클라우드] 스트림 응답 %d\n", code);
      if (code == 401) idToken = "";
      closeStream();
      setStatus(false, code == 401 ? "클라우드 권한 없음 (규칙 확인)" : "클라우드 스트림 오류");
      return false;
    }
    sChunked = chunked;
    chunkState = 0;
    chunkLeft = 0;
    chunkLine = lineBuf = evName = evData = "";
    sConn = true;
    sLastData = millis();
    setStatus(true, "클라우드 연결됨");
    Serial.println("[클라우드] 실시간 스트림 연결");
    return true;
  }
  closeStream();
  return false;
}

static void streamPoll() {
  int n = 0;
  while (sTls.available() && n++ < 4096) {
    feedByte((char)sTls.read());
    sLastData = millis();
  }
  if (!sTls.connected() && !sTls.available()) {
    Serial.println("[클라우드] 스트림 끊김 → 다시 연결");
    closeStream();
  } else if (millis() - sLastData > 90000) {      // 30초마다 오는 keep-alive가 끊긴 경우
    Serial.println("[클라우드] 스트림 응답 없음 → 다시 연결");
    closeStream();
  }
}

static void processAcks() {
  char id[40];
  while (xQueueReceive(ackQ, id, 0) == pdTRUE) {
    String body = String("{\"") + deviceId + "\":{\".sv\":\"timestamp\"}}";
    dbRequest("PATCH", String("/calls/") + id + "/recv", body, nullptr);
  }
}

// ============================================================
//  백그라운드 작업
// ============================================================
static void cloudTask(void *) {
  uint32_t lastConfig = 0, lastHB = 0, lastDevices = 0;
  bool first = true;
  dbTls.useBuiltinCACertBundle();
  sTls.useBuiltinCACertBundle();
  for (;;) {
    if (WiFi.status() != WL_CONNECTED) {
      setStatus(false, "Wi-Fi 연결 대기");
      if (sConn) closeStream();
      first = true;
      vTaskDelay(pdMS_TO_TICKS(1000));
      continue;
    }
    if (idToken.isEmpty() || millis() - tokenAt > 50UL * 60 * 1000) {   // 로그인 (50분마다 새로)
      if (sConn) closeStream();
      setStatus(false, "클라우드 로그인 중...");
      if (!signIn()) { vTaskDelay(pdMS_TO_TICKS(15000)); continue; }
      first = true;
    }
    uint32_t now = millis();
    if (first || now - lastConfig > 60000) { fetchConfig(); lastConfig = now; }

    if (role == ROLE_TERMINAL) {
      if (!sConn) {
        if (first || now - sLastTry > 5000) { sLastTry = now; streamConnect(); }
      } else {
        streamPoll();
      }
      processAcks();
      if (first || now - lastHB > 30000) { heartbeat(); lastHB = now; }
    } else {
      processOutgoing();
      if (first || now - lastDevices > 20000) { fetchDevices(); lastDevices = now; }
      if (first || now - lastHB > 60000) { heartbeat(); lastHB = now; }
    }
    first = false;
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

bool cloudEnabled() {
  return strlen(FIREBASE_DB_URL) > 8 && strstr(FIREBASE_DB_URL, "여기에") == nullptr &&
         strstr(FIREBASE_API_KEY, "여기에") == nullptr;
}
bool cloudOk() { return okFlag; }
const char *cloudStatusText() { return statusText; }
const char *cloudDeviceId() { return deviceId; }

void cloudBegin(CloudRole r) {
  ensureMutex();
  role = r;
  uint64_t mac = ESP.getEfuseMac();
  snprintf(deviceId, sizeof(deviceId), "%s-%02X%02X%02X", r == ROLE_TERMINAL ? "terminal" : "entrance",
           (uint8_t)(mac >> 24), (uint8_t)(mac >> 32), (uint8_t)(mac >> 40));
  if (!cloudEnabled()) {
    setStatus(false, "클라우드 사용 안 함 (직접 통신만)");
    return;
  }
  if (started) return;
  started = true;
  outQ = xQueueCreate(4, sizeof(OutCall));
  inQ = xQueueCreate(8, sizeof(IncomingCall));
  ackQ = xQueueCreate(8, 40);
  setStatus(false, "클라우드 준비 중...");
  xTaskCreate(cloudTask, "cloud", 16384, NULL, 1, NULL);
  Serial.printf("[클라우드] 시작 (단말 ID %s)\n", deviceId);
}
