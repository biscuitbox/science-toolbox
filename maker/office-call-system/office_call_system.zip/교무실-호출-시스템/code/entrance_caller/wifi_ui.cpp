// ============================================================
//  단말 화면에서 Wi-Fi 바꾸기 + 글자 입력(화면 키보드)
// ============================================================
#include "wifi_ui.h"
#include "config.h"
#include <WiFi.h>
#include <Preferences.h>

static inline uint16_t C565(uint8_t r, uint8_t g, uint8_t b) { return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3); }
static const uint16_t U_BG = C565(244, 246, 249), U_BAR = C565(30, 58, 95), U_CARD = 0xFFFF, U_BORDER = C565(196, 205, 216);
static const uint16_t U_TEXT = C565(30, 33, 38), U_SUB = C565(95, 105, 118), U_PRIMARY = C565(37, 99, 235);
static const uint16_t U_SELECT = C565(225, 236, 252), U_OK = C565(22, 150, 70), U_BAD = C565(210, 40, 40), U_KEY = C565(226, 231, 238);

static Arduino_GFX *g = nullptr;
static int W = 480, H = 272;
static const uint8_t *fS = nullptr, *fM = nullptr;
static bool small() { return H < 400 || W < 600; }

enum Mode { M_NONE, M_TEXT, M_LIST, M_PASS, M_SSID, M_CONNECT, M_RESULT };
static Mode mode = M_NONE;

// 글자 입력
static String tiTitle, tiValue;
static bool tiMasked = false, kbShift = false, kbSym = false;

// Wi-Fi 목록
struct Net { String ssid; int rssi; bool open; };
static Net nets[24];
static int netCount = 0, listPage = 0;
static bool scanning = false, scanRetried = false;

// 접속
static String newSsid, newPass, oldSsid, oldPass;
static uint32_t connStart = 0, lastTick = 0;
static bool connOk = false;

// 버튼
enum { B_RESCAN = 1, B_MANUAL, B_PREV, B_NEXT, B_CANCEL, B_OK, B_RETRY, B_SHIFT, B_SYM, B_DEL, B_SPACE,
       B_NET = 100, B_CHAR = 1000 };
struct UBtn { int16_t x, y, w, h; int id; };
static UBtn ub[72];
static int ubn = 0;

// ------------------------------------------------------------
void wifiLoadCreds(String &ssid, String &pass) {
  Preferences p;
  p.begin("wificfg", true);
  ssid = p.getString("ssid", "");
  pass = p.getString("pass", "");
  p.end();
  if (ssid.isEmpty()) { ssid = WIFI_SSID; pass = WIFI_PASS; }
}

static void wifiSaveCreds(const String &ssid, const String &pass) {
  Preferences p;
  p.begin("wificfg", false);
  p.putString("ssid", ssid);
  p.putString("pass", pass);
  p.end();
}

String wifiCurrentSsid() {
  if (WiFi.status() == WL_CONNECTED) return WiFi.SSID();
  String s, p;
  wifiLoadCreds(s, p);
  return s;
}

static void restoreWifi() {                       // 설정을 그만뒀을 때 원래 Wi-Fi로 다시 접속
  if (WiFi.status() == WL_CONNECTED) return;
  String s, p;
  wifiLoadCreds(s, p);
  WiFi.begin(s.c_str(), p.c_str());
}

void uiSetup(Arduino_GFX *gfx, int w, int h, const uint8_t *fontSmall, const uint8_t *fontMid) {
  g = gfx; W = w; H = h; fS = fontSmall; fM = fontMid;
}

// ------------------------------------------------------------
//  그리기 도우미
// ------------------------------------------------------------
static void dropFirstChar(String &s) {           // UTF-8 글자 단위로 앞에서 하나 지우기
  unsigned i = 1;
  while (i < s.length() && ((uint8_t)s[i] & 0xC0) == 0x80) i++;
  s = s.substring(i);
}
static void dropLastChar(String &s) {
  int i = s.length() - 1;
  while (i > 0 && ((uint8_t)s[i] & 0xC0) == 0x80) i--;
  s.remove(i);
}
static void txt(const String &s, int x, int cy, const uint8_t *font, uint16_t color, int align) {
  g->setFont(font);
  g->setTextColor(color);
  int16_t x1, y1;
  uint16_t w, h;
  g->getTextBounds(s.c_str(), 0, 0, &x1, &y1, &w, &h);
  int sx = align == 0 ? x - x1 : (align == 1 ? x - x1 - w / 2 : x - x1 - w);
  g->setCursor(sx, cy - y1 - h / 2);
  g->print(s);
}
static int txtW(const String &s, const uint8_t *font) {
  g->setFont(font);
  int16_t x1, y1;
  uint16_t w, h;
  g->getTextBounds(s.c_str(), 0, 0, &x1, &y1, &w, &h);
  return w;
}
static void btn(int x, int y, int w, int h, int id, const String &label, uint16_t bg, uint16_t fg, const uint8_t *font) {
  int r = small() ? 6 : 14;
  g->fillRoundRect(x, y, w, h, r, bg);
  if (bg == U_CARD || bg == U_KEY) g->drawRoundRect(x, y, w, h, r, U_BORDER);
  if (label.length()) txt(label, x + w / 2, y + h / 2, font, fg, 1);
  if (ubn < 72) ub[ubn++] = {(int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h, id};
}
static int titleBar(const String &title, const String &right = "") {
  int tb = small() ? 36 : 90;
  g->fillRect(0, 0, W, tb, U_BAR);
  String t = title;
  int maxW = W - (small() ? 20 : 80) - (right.length() ? txtW(right, fS) + 20 : 0);
  while (t.length() > 1 && txtW(t, fM) > maxW) dropLastChar(t);   // 길면 자르기
  txt(t, small() ? 10 : 40, tb / 2, fM, 0xFFFF, 0);
  if (right.length()) txt(right, W - (small() ? 10 : 40), tb / 2, fS, C565(170, 200, 235), 2);
  return tb;
}

// ------------------------------------------------------------
//  화면 키보드
// ------------------------------------------------------------
static const char *rowsLower[4] = {"1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"};
static const char *rowsUpper[4] = {"1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"};
static const char *rowsSym[4] = {"1234567890", "!@#$%^&*()", "-_=+[]{};:", "'\",./?\\"};
static const char *rowsSym2[4] = {"1234567890", "!@#$%^&*()", "-_=+[]{};:", "|~`<>"};

static void drawTextInput() {
  int tb = titleBar(tiTitle);
  int m = small() ? 6 : 40;
  int fh = small() ? 34 : 80;
  int fy = tb + (small() ? 4 : 20);
  g->fillRoundRect(m, fy, W - 2 * m, fh, small() ? 6 : 12, U_CARD);
  g->drawRoundRect(m, fy, W - 2 * m, fh, small() ? 6 : 12, U_PRIMARY);
  String shown = tiMasked ? String("") : tiValue;
  if (tiMasked) for (unsigned i = 0; i < tiValue.length(); i++) shown += '*';
  shown += "_";
  int maxW = W - 2 * m - 20;
  while (shown.length() > 1 && txtW(shown, fM) > maxW) dropFirstChar(shown);   // 길면 뒷부분만
  txt(shown, m + 10, fy + fh / 2, fM, U_TEXT, 0);

  // 자판
  int top = fy + fh + (small() ? 4 : 24);
  int gap = small() ? 3 : 10;
  int rowH = (H - top - (small() ? 2 : 20) - gap * 4) / 5;
  float unit = (float)(W - 2 * (small() ? 2 : 30)) / 10.0f;
  int x0 = small() ? 2 : 30;
  const char **rows = kbSym ? (kbShift ? rowsSym2 : rowsSym) : (kbShift ? rowsUpper : rowsLower);
  for (int r = 0; r < 4; r++) {
    int y = top + r * (rowH + gap);
    const char *keys = rows[r];
    int n = strlen(keys);
    float start = x0;
    if (r == 2) start = x0 + unit * (10 - n) / 2.0f;
    if (r == 3) {                                   // 대/소 + 글자 + 지우기
      btn(x0, y, (int)(unit * 1.5f) - gap, rowH, B_SHIFT, kbSym ? "더보기" : "대/소", kbShift ? U_SELECT : U_KEY, kbShift ? U_PRIMARY : U_TEXT, fS);
      start = x0 + unit * 1.5f + unit * (7 - n) / 2.0f;
      btn(x0 + (int)(unit * 8.5f), y, (int)(unit * 1.5f) - gap, rowH, B_DEL, "지우기", U_KEY, U_TEXT, fS);
    }
    for (int i = 0; i < n; i++) {
      char ch[2] = {keys[i], 0};
      btn((int)(start + unit * i), y, (int)unit - gap, rowH, B_CHAR + (uint8_t)keys[i], ch, U_CARD, U_TEXT, fM);
    }
  }
  int y = top + 4 * (rowH + gap);
  btn(x0, y, (int)(unit * 2) - gap, rowH, B_SYM, kbSym ? "abc" : "기호", U_KEY, U_TEXT, fS);
  btn(x0 + (int)(unit * 2), y, (int)(unit * 4) - gap, rowH, B_SPACE, "띄어쓰기", U_KEY, U_TEXT, fS);
  btn(x0 + (int)(unit * 6), y, (int)(unit * 2) - gap, rowH, B_CANCEL, "취소", U_KEY, U_TEXT, fS);
  btn(x0 + (int)(unit * 8), y, (int)(unit * 2) - gap, rowH, B_OK, "완료", U_PRIMARY, 0xFFFF, fS);
}

void textInputStart(const char *title, const String &initial, bool masked) {
  tiTitle = title;
  tiValue = initial;
  tiMasked = masked;
  kbShift = kbSym = false;
  mode = M_TEXT;
}
String textInputValue() { return tiValue; }

// ------------------------------------------------------------
//  Wi-Fi 목록
// ------------------------------------------------------------
static void startScan() {
  netCount = 0;
  listPage = 0;
  scanning = true;
  scanRetried = false;
  WiFi.scanDelete();
  WiFi.scanNetworks(true);
}

static const char *strength(int rssi) { return rssi > -60 ? "강함" : (rssi > -75 ? "보통" : "약함"); }

static void drawList() {
  String cur = wifiCurrentSsid();
  int tb = titleBar("Wi-Fi 바꾸기", String("현재: ") + cur);
  int m = small() ? 6 : 40, gap = small() ? 4 : 10;
  int barH = small() ? 40 : 90;
  int barY = H - barH - (small() ? 4 : 20);
  int rowH = small() ? 40 : 80;
  int areaTop = tb + gap, areaH = barY - gap - areaTop;
  int per = max(1, areaH / (rowH + gap));
  if (scanning) {
    txt("주변 Wi-Fi를 찾는 중...", W / 2, areaTop + areaH / 2, fM, U_SUB, 1);
  } else if (netCount == 0) {
    txt("찾은 Wi-Fi가 없어요. [다시 검색]을 눌러 보세요", W / 2, areaTop + areaH / 2, fS, U_SUB, 1);
  } else {
    for (int i = listPage * per; i < netCount && i < (listPage + 1) * per; i++) {
      int y = areaTop + (i - listPage * per) * (rowH + gap);
      bool isCur = nets[i].ssid == cur;
      btn(m, y, W - 2 * m, rowH, B_NET + i, "", isCur ? U_SELECT : U_CARD, U_TEXT, fM);
      String name = nets[i].ssid;
      int maxW = W - 2 * m - (small() ? 130 : 300);
      while (name.length() > 1 && txtW(name, fM) > maxW) dropLastChar(name);
      txt(name, m + (small() ? 8 : 24), y + rowH / 2, fM, isCur ? U_PRIMARY : U_TEXT, 0);
      String info = String(strength(nets[i].rssi)) + (nets[i].open ? " · 개방" : " · 암호") + (isCur ? " · 사용 중" : "");
      txt(info, W - m - (small() ? 8 : 24), y + rowH / 2, fS, U_SUB, 2);
    }
  }
  int pages = (netCount + per - 1) / per;
  int bw = (W - 2 * m - gap * 4) / 5;
  btn(m, barY, bw, barH, B_RESCAN, "다시 검색", U_CARD, U_TEXT, fS);
  btn(m + (bw + gap), barY, bw, barH, B_MANUAL, "직접 입력", U_CARD, U_TEXT, fS);
  if (listPage > 0) btn(m + (bw + gap) * 2, barY, bw, barH, B_PREV, "← 이전", U_CARD, U_TEXT, fS);
  if (listPage < pages - 1) btn(m + (bw + gap) * 3, barY, bw, barH, B_NEXT, "다음 →", U_CARD, U_TEXT, fS);
  btn(m + (bw + gap) * 4, barY, bw, barH, B_CANCEL, "닫기", U_KEY, U_TEXT, fS);
}

static int perPage() {
  int tb = small() ? 36 : 90, gap = small() ? 4 : 10, barH = small() ? 40 : 90;
  int barY = H - barH - (small() ? 4 : 20);
  int rowH = small() ? 40 : 80;
  return max(1, (barY - gap - (tb + gap)) / (rowH + gap));
}

void wifiUiStart() {
  wifiLoadCreds(oldSsid, oldPass);
  mode = M_LIST;
  startScan();
}

// ------------------------------------------------------------
//  접속 확인
// ------------------------------------------------------------
static void startConnect() {
  wifiLoadCreds(oldSsid, oldPass);
  WiFi.disconnect();
  delay(100);
  WiFi.begin(newSsid.c_str(), newPass.c_str());
  connStart = millis();
  mode = M_CONNECT;
  Serial.printf("[Wi-Fi] %s 에 접속 시도\n", newSsid.c_str());
}

static void drawConnect() {
  titleBar("Wi-Fi 연결 중");
  uint32_t sec = (millis() - connStart) / 1000;
  txt(String("\"") + newSsid + "\" 에 연결하는 중...", W / 2, H / 2 - (small() ? 15 : 40), fM, U_TEXT, 1);
  txt(String(sec) + "초 (최대 15초)", W / 2, H / 2 + (small() ? 20 : 40), fS, U_SUB, 1);
}

static void drawResult() {
  titleBar(connOk ? "Wi-Fi 연결됨" : "Wi-Fi 연결 실패");
  int cy = H / 2 - (small() ? 40 : 100);
  int step = small() ? 30 : 70;
  if (connOk) {
    txt(String("\"") + newSsid + "\" 에 연결되었어요", W / 2, cy, fM, U_OK, 1);
    txt(String("IP ") + WiFi.localIP().toString() + " · 다음에 켤 때도 이 Wi-Fi를 써요", W / 2, cy + step, fS, U_SUB, 1);
  } else {
    txt(String("\"") + newSsid + "\" 에 연결하지 못했어요", W / 2, cy, fM, U_BAD, 1);
    txt("비밀번호를 확인해 주세요", W / 2, cy + step, fS, U_SUB, 1);
    txt(String("원래 Wi-Fi(") + oldSsid + ")로 돌아갑니다", W / 2, cy + step * 2, fS, U_SUB, 1);
  }
  int bw = small() ? 140 : 300, bh = small() ? 44 : 100, by = H - bh - (small() ? 12 : 40);
  if (connOk) {
    btn((W - bw) / 2, by, bw, bh, B_OK, "완료", U_PRIMARY, 0xFFFF, fM);
  } else {
    btn(W / 2 - bw - 10, by, bw, bh, B_RETRY, "다시 입력", U_PRIMARY, 0xFFFF, fM);
    btn(W / 2 + 10, by, bw, bh, B_CANCEL, "닫기", U_CARD, U_TEXT, fM);
  }
}

// ------------------------------------------------------------
void uiDraw() {
  ubn = 0;
  g->fillScreen(U_BG);
  switch (mode) {
    case M_TEXT: case M_PASS: case M_SSID: drawTextInput(); break;
    case M_LIST: drawList(); break;
    case M_CONNECT: drawConnect(); break;
    case M_RESULT: drawResult(); break;
    default: break;
  }
}

bool uiLoop() {
  if (mode == M_LIST && scanning) {
    int n = WiFi.scanComplete();
    if (n == WIFI_SCAN_FAILED && !scanRetried) {     // 접속 시도 중이면 검색이 실패할 수 있어 한 번 더
      scanRetried = true;
      WiFi.disconnect();
      delay(100);
      WiFi.scanNetworks(true);
      return false;
    }
    if (n >= 0 || n == WIFI_SCAN_FAILED) {
      netCount = 0;
      for (int i = 0; i < n && netCount < 24; i++) {
        String s = WiFi.SSID(i);
        if (s.isEmpty()) continue;
        bool dup = false;
        for (int k = 0; k < netCount; k++) if (nets[k].ssid == s) dup = true;   // 같은 이름은 가장 센 것만
        if (dup) continue;
        nets[netCount++] = {s, (int)WiFi.RSSI(i), WiFi.encryptionType(i) == WIFI_AUTH_OPEN};
      }
      WiFi.scanDelete();
      scanning = false;
      if (WiFi.status() != WL_CONNECTED) restoreWifi();
      return true;
    }
    return false;
  }
  if (mode == M_CONNECT) {
    if (WiFi.status() == WL_CONNECTED) {
      connOk = true;
      wifiSaveCreds(newSsid, newPass);
      Serial.printf("[Wi-Fi] 접속 성공, 저장함: %s\n", newSsid.c_str());
      mode = M_RESULT;
      return true;
    }
    if (millis() - connStart > 15000) {
      connOk = false;
      Serial.println("[Wi-Fi] 접속 실패 → 원래 Wi-Fi로");
      WiFi.disconnect();
      delay(100);
      WiFi.begin(oldSsid.c_str(), oldPass.c_str());
      mode = M_RESULT;
      return true;
    }
    if (millis() - lastTick > 1000) { lastTick = millis(); return true; }
  }
  return false;
}

UiResult uiTap(int x, int y) {
  int id = 0;
  for (int i = ubn - 1; i >= 0; i--)
    if (x >= ub[i].x && x < ub[i].x + ub[i].w && y >= ub[i].y && y < ub[i].y + ub[i].h) { id = ub[i].id; break; }
  if (!id) return UI_NONE;

  if (mode == M_TEXT || mode == M_PASS || mode == M_SSID) {
    if (id >= B_CHAR) { if (tiValue.length() < 63) tiValue += (char)(id - B_CHAR); return UI_NONE; }
    switch (id) {
      case B_SHIFT: kbShift = !kbShift; return UI_NONE;
      case B_SYM: kbSym = !kbSym; kbShift = false; return UI_NONE;
      case B_DEL: if (tiValue.length()) dropLastChar(tiValue); return UI_NONE;
      case B_SPACE: if (tiValue.length() < 63) tiValue += ' '; return UI_NONE;
      case B_CANCEL:
        if (mode == M_TEXT) { mode = M_NONE; return UI_CANCEL; }
        mode = M_LIST;
        return UI_NONE;
      case B_OK:
        if (mode == M_TEXT) { mode = M_NONE; return UI_DONE; }
        if (mode == M_SSID) {
          if (tiValue.isEmpty()) return UI_NONE;
          newSsid = tiValue;
          textInputStart("비밀번호 (없으면 그냥 완료)", "", false);
          mode = M_PASS;
          return UI_NONE;
        }
        newPass = tiValue;                            // M_PASS
        startConnect();
        return UI_NONE;
    }
    return UI_NONE;
  }

  if (mode == M_LIST) {
    if (id >= B_NET && id < B_NET + 24) {
      const Net &n = nets[id - B_NET];
      newSsid = n.ssid;
      if (n.open) { newPass = ""; startConnect(); return UI_NONE; }
      textInputStart((String(newSsid) + " 비밀번호").c_str(), "", false);
      mode = M_PASS;
      return UI_NONE;
    }
    switch (id) {
      case B_RESCAN: startScan(); return UI_NONE;
      case B_MANUAL: textInputStart("Wi-Fi 이름(SSID) 직접 입력", "", false); mode = M_SSID; return UI_NONE;
      case B_PREV: if (listPage > 0) listPage--; return UI_NONE;
      case B_NEXT: if ((listPage + 1) * perPage() < netCount) listPage++; return UI_NONE;
      case B_CANCEL: mode = M_NONE; restoreWifi(); return UI_CANCEL;
    }
    return UI_NONE;
  }

  if (mode == M_RESULT) {
    if (id == B_OK) { mode = M_NONE; return UI_DONE; }
    if (id == B_RETRY) {
      textInputStart((String(newSsid) + " 비밀번호").c_str(), newPass, false);
      mode = M_PASS;
      return UI_NONE;
    }
    if (id == B_CANCEL) { mode = M_NONE; restoreWifi(); return UI_CANCEL; }
  }
  return UI_NONE;
}
