/*
 * ============================================================
 *  교무실 입구 호출기 (학생용)
 *  보드 : Guition JC4827W543C (ESP32-S3, 4.3" 480x272, 정전식 터치)
 *  통신 : Firebase 클라우드 중계 + 같은 Wi-Fi 직접 통신(비상용) 동시 사용
 * ------------------------------------------------------------
 *  Arduino IDE 보드 설정
 *   - 보드 : ESP32S3 Dev Module
 *   - Flash Size : 4MB
 *   - PSRAM : OPI PSRAM
 *   - Partition Scheme : Huge APP (3MB No OTA/1MB SPIFFS)
 *  필요한 라이브러리 : GFX Library for Arduino, U8g2, ArduinoJson(7.x)
 * ============================================================
 */
//  ▶ Wi-Fi·Firebase 정보 : config.h 탭 (공통 단말과 같게)
//  ▶ 선생님 명단·설정    : 구글 시트에서 관리 (teachers.h 는 처음 켤 때만 쓰는 기본값)
//  ▶ 프로그램 본체       : caller_app.cpp 탭, 클라우드 통신은 cloud.cpp 탭
//  (setup()과 loop()는 caller_app.cpp 안에 있습니다)
