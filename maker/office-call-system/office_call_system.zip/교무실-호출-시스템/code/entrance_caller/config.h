// ============================================================
//  교무실 호출 시스템 - 공통 설정 (입구 호출기와 공통 단말 모두 같은 값으로!)
// ============================================================
#pragma once

// ---------- Wi-Fi (2.4GHz) ----------
// 처음 접속할 Wi-Fi. 설치 후에는 단말 화면에서 바꿀 수 있음 (바꾼 값이 우선)
#define WIFI_SSID "여기에_와이파이_이름"
#define WIFI_PASS "여기에_비밀번호"

// ---------- Firebase (클라우드 중계) ----------
// 비워 두면("") 클라우드 없이 같은 Wi-Fi 안 직접 통신만 사용
#define FIREBASE_DB_URL  "https://여기에-프로젝트-ID-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_API_KEY "여기에_웹_API_키"
#define DEVICE_EMAIL     "device@callsys.local"   // Firebase Authentication 에 만든 단말용 계정
#define DEVICE_PASSWORD  "여기에_단말_계정_비밀번호"

// ---------- 입구 호출기 관리 메뉴 비밀번호 (위쪽 파란 띠 5초 누르기) ----------
#define ADMIN_PIN "0000"

// ---------- 같은 Wi-Fi 안 직접 통신 (인터넷이 끊겨도 동작하는 비상 경로) ----------
#define CALL_PORT 47800
#define SYSTEM_TAG "CALL"
