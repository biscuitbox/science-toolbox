/**
 * 교무실 호출 시스템 - 구글 시트 관리 스크립트
 *
 * 하는 일
 *  - [선생님 명단], [설정] 시트를 고치면 Firebase로 자동 반영 → 단말들이 1분 안에 받아 감
 *  - 5분마다 [호출 기록], [단말 상태] 시트를 새로 채움
 *
 * 처음 한 번
 *  1) 아래 FIREBASE_URL 을 내 Firebase 실시간 DB 주소로 바꾸고 저장
 *  2) 위쪽 함수 목록에서 setup 을 고르고 [실행] → 권한 허용
 *  3) 시트를 새로고침하면 메뉴에 [호출 시스템]이 생김
 */
const FIREBASE_URL = 'https://여기에-프로젝트-ID-default-rtdb.asia-southeast1.firebasedatabase.app';

const SHEET_TEACHERS = '선생님 명단';
const SHEET_SETTINGS = '설정';
const SHEET_LOG = '호출 기록';
const SHEET_DEVICES = '단말 상태';
const KEEP_DAYS_IN_FIREBASE = 1;      // Firebase에서는 하루 지난 호출을 지움 (시트 기록은 계속 남음)
const MAX_NAME_CHARS = 10;            // 단말에 저장할 수 있는 이름 길이

// [항목 이름, 저장 키, 기본값, 설명]
const SETTINGS = [
  ['알림 표시 시간(초)', 'alertSeconds', 10, '공통 단말에 이름을 띄우는 시간'],
  ['처음 깜빡임 시간(초)', 'flashSeconds', 3, '알림 처음 몇 초 동안 노랑/검정을 번갈아 깜빡일지'],
  ['같은 선생님 재호출 제한(초)', 'repeatBlockSeconds', 30, '이 시간 안에 같은 선생님을 다시 누르면 보내지 않음'],
  ['효과음 크기(1~10)', 'soundLevel', 4, '공통 단말 효과음 크기. 1이 가장 작음'],
];

// ------------------------------------------------------------
function onOpen() {
  SpreadsheetApp.getUi().createMenu('호출 시스템')
    .addItem('단말에 반영하기', 'syncConfig')
    .addItem('호출 기록·단말 상태 새로고침', 'pullStatus')
    .addSeparator()
    .addItem('처음 설정 (한 번만)', 'setup')
    .addToUi();
}

function setup() {
  checkUrl_();
  const ss = SpreadsheetApp.getActive();
  const header = (sh, values) => {
    sh.getRange(1, 1, 1, values.length).setValues([values])
      .setFontWeight('bold').setBackground('#1e3a5f').setFontColor('#ffffff');
    sh.setFrozenRows(1);
  };

  let t = ss.getSheetByName(SHEET_TEACHERS);
  if (!t) {
    t = ss.insertSheet(SHEET_TEACHERS, 0);
    header(t, ['ID', '이름', '교과', '사용']);
    t.getRange(2, 1, 2, 4).setValues([['T01', '홍길동', '국어과', true], ['T02', '김영희', '국어과', true]]);
    t.getRange('D2:D200').insertCheckboxes();
    t.setColumnWidth(1, 70).setColumnWidth(2, 120).setColumnWidth(3, 120).setColumnWidth(4, 60);
    t.getRange('F1').setValue('· ID는 비워 두면 자동으로 붙어요.  · 행 순서가 입구 화면의 순서예요.  · [사용]을 끄면 입구 화면에서 숨겨져요.');
  }
  let s = ss.getSheetByName(SHEET_SETTINGS);
  if (!s) {
    s = ss.insertSheet(SHEET_SETTINGS);
    header(s, ['항목', '값', '설명']);
    s.getRange(2, 1, SETTINGS.length, 3).setValues(SETTINGS.map(r => [r[0], r[2], r[3]]));
    s.setColumnWidth(1, 200).setColumnWidth(3, 380);
  }
  let l = ss.getSheetByName(SHEET_LOG);
  if (!l) {
    l = ss.insertSheet(SHEET_LOG);
    header(l, ['호출 시각', '선생님', '교과', '받은 단말 수', '호출 ID']);
    l.setColumnWidth(1, 160);
  }
  let d = ss.getSheetByName(SHEET_DEVICES);
  if (!d) {
    d = ss.insertSheet(SHEET_DEVICES);
    header(d, ['단말 ID', '종류', '받는 선생님', '마지막 신호', '상태']);
    d.setColumnWidth(1, 170).setColumnWidth(4, 160);
  }
  ['시트1', 'Sheet1'].forEach(n => {                       // 빈 기본 시트 정리
    const sh = ss.getSheetByName(n);
    if (sh && sh.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(sh);
  });

  ScriptApp.getProjectTriggers().forEach(tr => ScriptApp.deleteTrigger(tr));
  ScriptApp.newTrigger('onEditSync').forSpreadsheet(ss).onEdit().create();
  ScriptApp.newTrigger('pullStatus').timeBased().everyMinutes(5).create();

  syncConfig();
  pullStatus();
  ss.toast('설정을 마쳤어요. 이제 명단을 고치면 자동으로 단말에 반영돼요.', '호출 시스템', 8);
}

// 명단·설정 시트를 고치면 자동 실행 (설치형 트리거)
function onEditSync(e) {
  if (!e || !e.range) return;
  const name = e.range.getSheet().getName();
  if (name !== SHEET_TEACHERS && name !== SHEET_SETTINGS) return;
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) return;
  try {
    syncConfig();
  } finally {
    lock.releaseLock();
  }
}

// ------------------------------------------------------------
// 명단·설정 → Firebase /config
function syncConfig() {
  checkUrl_();
  const ss = SpreadsheetApp.getActive();
  const sh = ss.getSheetByName(SHEET_TEACHERS);
  const teachers = [];
  const problems = [];
  const last = sh.getLastRow();
  if (last >= 2) {
    const vals = sh.getRange(2, 1, last - 1, 4).getValues();
    const used = new Set(vals.map(r => String(r[0]).trim()).filter(x => x));
    const seenIds = new Set();
    let n = 1;
    const nextId = () => {
      let id;
      do { id = 'T' + String(n++).padStart(2, '0'); } while (used.has(id));
      used.add(id);
      return id;
    };
    const ok = supportedChars_();
    let idsChanged = false;

    vals.forEach((r, i) => {
      const name = String(r[1]).trim();
      const subject = String(r[2]).trim() || '기타';
      if (!name) return;
      if (!String(r[0]).trim() || seenIds.has(String(r[0]).trim())) { r[0] = nextId(); idsChanged = true; }
      const id = String(r[0]).trim();
      seenIds.add(id);

      const bad = [...(name + subject)].filter(ch => !ok.has(ch));
      const notes = [];
      if (bad.length) notes.push('화면에 표시할 수 없는 글자: ' + bad.join(' '));
      if ([...name].length > MAX_NAME_CHARS || [...subject].length > MAX_NAME_CHARS) notes.push(MAX_NAME_CHARS + '글자를 넘으면 잘려요');
      const cell = sh.getRange(i + 2, 2, 1, 2);
      if (notes.length) {
        cell.setBackground('#ffd6d6').setNote(notes.join('\n'));
        problems.push(name);
      } else {
        cell.setBackground(null).clearNote();
      }
      if (r[3] !== false) teachers.push({ id: id, name: name, subject: subject });
    });
    if (idsChanged) sh.getRange(2, 1, vals.length, 1).setValues(vals.map(r => [r[0]]));
  }

  const settings = {};
  SETTINGS.forEach(r => { settings[r[1]] = r[2]; });
  const st = ss.getSheetByName(SHEET_SETTINGS);
  if (st) {                                                   // 새로 생긴 설정 항목은 시트에 자동 추가
    const labels = st.getLastRow() >= 2 ? st.getRange(2, 1, st.getLastRow() - 1, 1).getValues().map(r => String(r[0]).trim()) : [];
    SETTINGS.filter(r => labels.indexOf(r[0]) < 0).forEach(r => st.appendRow([r[0], r[2], r[3]]));
  }
  if (st && st.getLastRow() >= 2) {
    st.getRange(2, 1, st.getLastRow() - 1, 2).getValues().forEach(r => {
      const def = SETTINGS.find(x => x[0] === String(r[0]).trim());
      const v = Number(r[1]);
      if (def && v > 0) settings[def[1]] = Math.round(v);
    });
  }

  fb_('put', '/config', { teachers: teachers, settings: settings, updatedAt: new Date().toISOString() });
  let msg = '선생님 ' + teachers.length + '명을 단말에 반영했어요 (1분 안에 적용).';
  if (problems.length) msg += ' 확인 필요: ' + problems.join(', ');
  ss.toast(msg, '호출 시스템', 6);
}

// ------------------------------------------------------------
// Firebase → 호출 기록 / 단말 상태 시트 (5분마다 자동)
function pullStatus() {
  checkUrl_();
  const ss = SpreadsheetApp.getActive();
  const props = PropertiesService.getScriptProperties();
  const now = Date.now();

  // 1) 새 호출을 기록 시트에 추가 (30초 지난 것만: 받은 단말 수가 확정된 뒤)
  const lastTs = Number(props.getProperty('lastTs') || 0);
  const q = '&orderBy=' + encodeURIComponent('"ts"') + '&startAt=' + (lastTs + 1) + '&endAt=' + (now - 30000);
  const calls = fb_('get', '/calls', undefined, q) || {};
  const rows = Object.keys(calls).map(id => Object.assign({ id: id }, calls[id]))
    .filter(c => c.ts).sort((a, b) => a.ts - b.ts);
  const log = ss.getSheetByName(SHEET_LOG);
  if (log && rows.length) {
    const start = log.getLastRow() + 1;
    log.getRange(start, 1, rows.length, 5).setValues(rows.map(c => [
      new Date(c.ts), c.name || '', c.subject || '', c.recv ? Object.keys(c.recv).length : 0, c.id]));
    log.getRange(start, 1, rows.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
    props.setProperty('lastTs', String(rows[rows.length - 1].ts));
  }

  // 2) 오래된 호출은 Firebase에서 지움
  const oldQ = '&orderBy=' + encodeURIComponent('"ts"') + '&endAt=' + (now - KEEP_DAYS_IN_FIREBASE * 86400000);
  const old = fb_('get', '/calls', undefined, oldQ) || {};
  const del = {};
  Object.keys(old).forEach(id => { del[id] = null; });
  if (Object.keys(del).length) fb_('patch', '/calls', del);

  // 3) 단말 상태
  const devs = fb_('get', '/devices') || {};
  const dsh = ss.getSheetByName(SHEET_DEVICES);
  if (dsh) {
    if (dsh.getLastRow() > 1) dsh.getRange(2, 1, dsh.getLastRow() - 1, 5).clearContent();
    const list = Object.keys(devs).sort().map(id => {
      const v = devs[id] || {};
      const online = v.lastSeen && now - v.lastSeen < 120000;
      return [id, v.type === 'terminal' ? '공통 단말' : (v.type === 'entrance' ? '입구 호출기' : (v.type || '')),
        v.covers === '*' ? '전체' : (v.covers || ''), v.lastSeen ? new Date(v.lastSeen) : '', online ? '● 켜짐' : '○ 꺼짐'];
    });
    if (list.length) {
      dsh.getRange(2, 1, list.length, 5).setValues(list);
      dsh.getRange(2, 4, list.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
    }
  }
}

// ------------------------------------------------------------
function fb_(method, path, payload, query) {
  const url = FIREBASE_URL.replace(/\/+$/, '') + path + '.json?access_token=' + ScriptApp.getOAuthToken() + (query || '');
  const opt = { method: method, muteHttpExceptions: true, contentType: 'application/json' };
  if (payload !== undefined) opt.payload = JSON.stringify(payload);
  const res = UrlFetchApp.fetch(url, opt);
  const code = res.getResponseCode();
  if (code >= 300) throw new Error('Firebase 오류 ' + code + ': ' + res.getContentText());
  const text = res.getContentText();
  return text ? JSON.parse(text) : null;
}

function checkUrl_() {
  if (FIREBASE_URL.indexOf('여기에') >= 0) throw new Error('Code.gs 맨 위의 FIREBASE_URL 을 내 Firebase 주소로 바꿔 주세요.');
}

// 단말 폰트에 있는 글자: 한글 2,350자(KS X 1001) + 영문·숫자·기호 일부
function supportedChars_() {
  const cache = CacheService.getScriptCache();
  let s = cache.get('ksx1001');
  if (!s) {
    const bytes = [];
    for (let b1 = 0xB0; b1 <= 0xC8; b1++)
      for (let b2 = 0xA1; b2 <= 0xFE; b2++) bytes.push(b1 - 256, b2 - 256);
    s = Utilities.newBlob(bytes).getDataAsString('EUC-KR');
    cache.put('ksx1001', s, 21600);
  }
  const set = new Set([...s]);
  for (let c = 32; c < 127; c++) set.add(String.fromCharCode(c));
  set.add('·');
  return set;
}
