#include <Arduino.h>
#include <Arduino_GFX_Library.h>

#define LCD_PANEL_V2 1      // 1: 새 패널(V2), 0: 이전 패널 → 둘 다 시험해 보기
#define PIN_BL 23

#if LCD_PANEL_V2
#include "lcd_panel_v2.h"
Arduino_ESP32DSIPanel *dsipanel = new Arduino_ESP32DSIPanel(20, 20, 40, 4, 10, 20, 70000000, 1500);
#define PANEL_INIT jc8012_v2_init_operations
#else
#include "lcd_panel_v1.h"
Arduino_ESP32DSIPanel *dsipanel = new Arduino_ESP32DSIPanel(20, 20, 40, 4, 8, 20, 60000000);
#define PANEL_INIT jc8012_v1_init_operations
#endif
Arduino_DSI_Display *gfx = new Arduino_DSI_Display(800, 1280, dsipanel, 0, true, 27, PANEL_INIT,
                                                   sizeof(PANEL_INIT) / sizeof(lcd_init_cmd_t));

void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.println("\n===== 10.1\" 화면 점검 =====");
  Serial.printf("1) 칩 리비전: v%d.%d\n", ESP.getChipRevision() / 100, ESP.getChipRevision() % 100);
  Serial.printf("   PSRAM 크기: %u 바이트 (0이면 Tools > PSRAM 을 Enabled 로)\n", ESP.getPsramSize());
  Serial.printf("   패널 설정: %s\n", LCD_PANEL_V2 ? "새 패널(V2)" : "이전 패널(V1)");

  Serial.println("2) 백라이트 켜기 (GPIO23)");
  pinMode(PIN_BL, OUTPUT);
  digitalWrite(PIN_BL, HIGH);
  Serial.println("   → 지금 화면 뒤에서 빛이 나야 함 (검은 화면이라도 약간 밝게 보임)");
  delay(2000);

  Serial.println("3) 화면 초기화 시작 (여기서 멈추거나 재부팅되면 이 단계 문제)");
  if (!gfx->begin()) {
    Serial.println("   → 화면 초기화 실패");
    return;
  }
  Serial.println("4) 화면 초기화 성공, 색 바꾸기 시작");
}

void loop() {
  const uint16_t colors[] = {0xF800, 0x07E0, 0x001F, 0xFFFF};
  const char *names[] = {"빨강", "초록", "파랑", "흰색"};
  for (int i = 0; i < 4; i++) {
    gfx->fillScreen(colors[i]);
    Serial.printf("   화면: %s\n", names[i]);
    delay(1500);
  }
  gfx->fillScreen(0x0000);
  gfx->setTextColor(0xFFFF);
  gfx->setTextSize(6);
  gfx->setCursor(60, 600);
  gfx->print("DISPLAY OK");
  Serial.println("   화면: DISPLAY OK 글자");
  delay(3000);
}
