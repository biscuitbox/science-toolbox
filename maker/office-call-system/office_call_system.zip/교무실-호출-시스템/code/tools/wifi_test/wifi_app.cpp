#include <Arduino.h>
#include <WiFi.h>

#define TEST_SSID "여기에_와이파이_이름"
#define TEST_PASS "여기에_비밀번호"

static volatile int lastReason = -1;

static const char *encName(wifi_auth_mode_t e) {
  switch (e) {
    case WIFI_AUTH_OPEN: return "개방";
    case WIFI_AUTH_WEP: return "WEP";
    case WIFI_AUTH_WPA_PSK: return "WPA";
    case WIFI_AUTH_WPA2_PSK: return "WPA2";
    case WIFI_AUTH_WPA_WPA2_PSK: return "WPA/WPA2";
    case WIFI_AUTH_WPA2_ENTERPRISE: return "WPA2-기업용";
    case WIFI_AUTH_WPA3_PSK: return "WPA3";
    case WIFI_AUTH_WPA2_WPA3_PSK: return "WPA2/WPA3";
    default: return "기타";
  }
}

void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.println("\n===== Wi-Fi 점검 =====");

  WiFi.onEvent([](arduino_event_id_t ev, arduino_event_info_t info) {
    if (ev == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) lastReason = info.wifi_sta_disconnected.reason;
  });

  WiFi.mode(WIFI_STA);
  delay(500);
#if CONFIG_IDF_TARGET_ESP32P4
  uint32_t a, b, c, x, y, z;
  hostedGetHostVersion(&a, &b, &c);
  hostedGetSlaveVersion(&x, &y, &z);
  Serial.printf("1) 보조칩(C6) 통신: %s\n", hostedIsInitialized() ? "정상" : "실패 (보조칩과 연결 안 됨)");
  Serial.printf("   본체 쪽 버전 %u.%u.%u / 보조칩 펌웨어 %u.%u.%u (%s)\n", a, b, c, x, y, z, hostedGetSlaveTargetName());
  if (hostedHasUpdate()) Serial.println("   ※ 보조칩 펌웨어가 오래됨 → 파일 > 예제 > ESP_HostedOTA 로 업데이트 권장");
#endif
  Serial.printf("   MAC 주소: %s\n", WiFi.macAddress().c_str());

  Serial.println("2) 주변 Wi-Fi 검색 중...");
  int n = WiFi.scanNetworks();
  bool found = false;
  if (n <= 0) Serial.println("   → 하나도 안 보임 (보조칩 또는 안테나 문제 가능)");
  for (int i = 0; i < n && i < 20; i++) {
    bool me = WiFi.SSID(i) == TEST_SSID;
    if (me) found = true;
    Serial.printf("   %s %-28s 채널 %2ld  신호 %4ld  %s\n", me ? "▶" : " ", WiFi.SSID(i).c_str(),
                  (long)WiFi.channel(i), (long)WiFi.RSSI(i), encName(WiFi.encryptionType(i)));
    if (me && WiFi.channel(i) >= 12) Serial.println("     ※ 12~13번 채널: 공유기 설정에서 1~11번 채널로 바꿔 보세요");
    if (me && WiFi.RSSI(i) < -80) Serial.println("     ※ 신호가 약함: 공유기 가까이에서 시험해 보세요");
    if (me && WiFi.encryptionType(i) == WIFI_AUTH_WPA2_ENTERPRISE) Serial.println("     ※ 기업용(아이디+비번) 인증 Wi-Fi는 지금 코드로 접속 불가");
  }
  if (n > 0 && !found) {
    Serial.printf("   → \"%s\" 가 목록에 없음\n", TEST_SSID);
    Serial.println("     · 이름의 대소문자/띄어쓰기 확인");
    Serial.println("     · 5GHz 전용이 아닌지 (아이폰 핫스팟은 '호환성 최대화' 켜기)");
    Serial.println("     · 숨김 Wi-Fi가 아닌지");
  }

  Serial.printf("3) \"%s\" 에 접속 시도...\n", TEST_SSID);
  WiFi.begin(TEST_SSID, TEST_PASS);
  for (int i = 0; i < 20 && WiFi.status() != WL_CONNECTED; i++) {
    delay(1000);
    Serial.printf("   %2d초: 상태 %d", i + 1, WiFi.status());
    if (lastReason >= 0) Serial.printf("  끊김 이유 %d (%s)", lastReason, WiFi.disconnectReasonName((wifi_err_reason_t)lastReason));
    Serial.println();
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("   → 접속 성공! IP %s, 게이트웨이 %s\n", WiFi.localIP().toString().c_str(), WiFi.gatewayIP().toString().c_str());
  } else {
    Serial.println("   → 접속 실패. 위의 '끊김 이유'를 알려 주세요");
    Serial.println("     (AUTH_FAIL/HANDSHAKE_TIMEOUT 계열 = 비밀번호, NO_AP_FOUND = 이름/채널/5GHz)");
  }
}

void loop() { delay(1000); }
