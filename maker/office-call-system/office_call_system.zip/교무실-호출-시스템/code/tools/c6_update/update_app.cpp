#include <Arduino.h>
#include <WiFi.h>

extern const uint8_t c6_firmware[];
extern const size_t c6_firmware_len;

static void printVersions() {
  uint32_t a, b, c, x, y, z;
  hostedGetHostVersion(&a, &b, &c);
  hostedGetSlaveVersion(&x, &y, &z);
  Serial.printf("   본체 쪽 버전 %u.%u.%u / 보조칩 펌웨어 %u.%u.%u\n", a, b, c, x, y, z);
}

void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.println("\n===== Wi-Fi 보조칩(C6) 펌웨어 업데이트 =====");

  WiFi.STA.begin();                       // 보조칩과 통신 시작
  delay(500);
  if (!hostedIsInitialized()) {
    Serial.println("보조칩과 통신이 안 됩니다. 보드 설정을 확인하세요.");
    return;
  }
  printVersions();
  if (!hostedHasUpdate()) {
    Serial.println("→ 보조칩 펌웨어가 이미 최신입니다. 이제 본 프로그램을 올리세요.");
    return;
  }

  Serial.printf("1) 업데이트 시작 (%u 바이트). 전원을 끄지 마세요!\n", (unsigned)c6_firmware_len);
  if (!hostedBeginUpdate()) {
    Serial.println("   → 시작 실패");
    return;
  }
  static uint8_t buf[2048];
  size_t done = 0;
  int lastPct = -1;
  while (done < c6_firmware_len) {
    size_t n = min((size_t)sizeof(buf), c6_firmware_len - done);
    memcpy(buf, c6_firmware + done, n);
    if (!hostedWriteUpdate(buf, n)) {
      Serial.printf("\n   → 쓰기 실패 (%u 바이트 지점). RESET 후 다시 시도하세요.\n", (unsigned)done);
      return;
    }
    done += n;
    int pct = done * 100 / c6_firmware_len;
    if (pct / 10 != lastPct / 10) Serial.printf("   %d%%\n", pct);
    lastPct = pct;
  }
  Serial.println("2) 마무리 중...");
  if (!hostedEndUpdate()) {
    Serial.println("   → 마무리 실패. RESET 후 다시 시도하세요.");
    return;
  }
  Serial.println("3) 새 펌웨어 적용 중...");
  if (!hostedActivateUpdate()) {
    Serial.println("   → 적용 실패. RESET 후 다시 시도하세요.");
    return;
  }
  Serial.println("===== 업데이트 완료! 5초 뒤 다시 시작해서 버전을 확인합니다 =====");
  delay(5000);
  ESP.restart();
}

void loop() { delay(1000); }
