// GSL3680 터치 래퍼 (JC8012P4A1C용)
// 원본: CelliesProjects/JC8012P4A1-Arduino_GFX — 새 I2C 마스터 드라이버를 쓰도록 수정
#pragma once
#include <stdint.h>
#include "driver/i2c_master.h"

// 터치와 같은 I2C 버스(SDA7/SCL8)를 오디오 코덱(ES8311)도 함께 씀
i2c_master_bus_handle_t gsl3680_i2c_bus();

class gsl3680_touch {
public:
  gsl3680_touch(int8_t sda_pin, int8_t scl_pin, int8_t rst_pin = -1, int8_t int_pin = -1);
  bool begin();
  bool getTouch(uint16_t *x, uint16_t *y);
  void set_rotation(uint8_t r);

private:
  int8_t _sda, _scl, _rst, _int;
  bool _ok = false;
};
