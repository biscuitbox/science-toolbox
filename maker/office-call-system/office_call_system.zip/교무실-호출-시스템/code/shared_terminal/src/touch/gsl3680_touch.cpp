// GSL3680 터치 래퍼 (JC8012P4A1C용)
// 원본: CelliesProjects/JC8012P4A1-Arduino_GFX — 새 I2C 마스터 드라이버(i2c_master)를 쓰도록 수정
#include "esp_err.h"
#include "esp_log.h"
#include "driver/i2c_master.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_touch.h"
#include "esp_lcd_gsl3680.h"
#include "gsl3680_touch.h"

#define TOUCH_HRES 800
#define TOUCH_VRES 1280

static const char *TAG = "gsl3680";
static esp_lcd_touch_handle_t tp = NULL;
static esp_lcd_panel_io_handle_t tp_io_handle = NULL;
static i2c_master_bus_handle_t i2c_bus = NULL;

i2c_master_bus_handle_t gsl3680_i2c_bus() { return i2c_bus; }

gsl3680_touch::gsl3680_touch(int8_t sda_pin, int8_t scl_pin, int8_t rst_pin, int8_t int_pin)
    : _sda(sda_pin), _scl(scl_pin), _rst(rst_pin), _int(int_pin) {}

bool gsl3680_touch::begin() {
  i2c_master_bus_config_t bus_cfg = {};
  bus_cfg.i2c_port = I2C_NUM_0;
  bus_cfg.sda_io_num = (gpio_num_t)_sda;
  bus_cfg.scl_io_num = (gpio_num_t)_scl;
  bus_cfg.clk_source = I2C_CLK_SRC_DEFAULT;
  bus_cfg.glitch_ignore_cnt = 7;
  bus_cfg.flags.enable_internal_pullup = true;
  if (i2c_new_master_bus(&bus_cfg, &i2c_bus) != ESP_OK) {
    ESP_LOGE(TAG, "I2C bus init failed");
    return false;
  }

  esp_lcd_panel_io_i2c_config_t tp_io_config = ESP_LCD_TOUCH_IO_I2C_GSL3680_CONFIG();
  tp_io_config.scl_speed_hz = 400000;
  if (esp_lcd_new_panel_io_i2c_v2(i2c_bus, &tp_io_config, &tp_io_handle) != ESP_OK) {
    ESP_LOGE(TAG, "touch panel IO init failed");
    return false;
  }

  esp_lcd_touch_config_t tp_cfg = {};
  tp_cfg.x_max = TOUCH_HRES;
  tp_cfg.y_max = TOUCH_VRES;
  tp_cfg.rst_gpio_num = (gpio_num_t)_rst;
  tp_cfg.int_gpio_num = (gpio_num_t)_int;
  tp_cfg.levels.reset = 0;
  tp_cfg.levels.interrupt = 0;
  if (esp_lcd_touch_new_i2c_gsl3680(tp_io_handle, &tp_cfg, &tp) != ESP_OK) {
    ESP_LOGE(TAG, "gsl3680 init failed");
    return false;
  }
  _ok = true;
  return true;
}

bool gsl3680_touch::getTouch(uint16_t *x, uint16_t *y) {
  if (!_ok) return false;
  static uint16_t strength[1];
  uint8_t cnt = 0;
  esp_lcd_touch_read_data(tp);
  return esp_lcd_touch_get_coordinates(tp, x, y, strength, &cnt, 1);
}

void gsl3680_touch::set_rotation(uint8_t r) {
  if (!_ok) return;
  switch (r) {
    case 0: esp_lcd_touch_set_swap_xy(tp, false); esp_lcd_touch_set_mirror_x(tp, true);  esp_lcd_touch_set_mirror_y(tp, false); break;
    case 1: esp_lcd_touch_set_swap_xy(tp, true);  esp_lcd_touch_set_mirror_x(tp, false); esp_lcd_touch_set_mirror_y(tp, false); break;
    case 2: esp_lcd_touch_set_swap_xy(tp, false); esp_lcd_touch_set_mirror_x(tp, false); esp_lcd_touch_set_mirror_y(tp, true);  break;
    case 3: esp_lcd_touch_set_swap_xy(tp, true);  esp_lcd_touch_set_mirror_x(tp, true);  esp_lcd_touch_set_mirror_y(tp, true);  break;
  }
}
