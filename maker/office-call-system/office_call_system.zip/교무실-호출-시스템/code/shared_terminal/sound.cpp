// 효과음 (ES8311 코덱 + NS4150 앰프, JC8012P4A1C 내장 스피커)
// 핀: MCLK 13, BCLK 12, WS 10, DOUT 9, 코덱 I2C 0x18 (SDA 7 / SCL 8, 터치와 공유), 앰프 켜기 GPIO20
#include "sound.h"
#include <ESP_I2S.h>
#include <math.h>
#include "driver/i2c_master.h"
#include "src/touch/gsl3680_touch.h"

#define PIN_I2S_MCLK 13
#define PIN_I2S_BCLK 12
#define PIN_I2S_WS 10
#define PIN_I2S_DOUT 9
#define PIN_PA 20                 // 스피커 앰프 켜기 핀. 재생할 때만 켬 (켜 두면 잡음)
#define PA_ON_LEVEL HIGH          // 앰프가 켜지는 신호 (소리가 전혀 안 나면 LOW 로 바꿔 시험)
#define ES8311_ADDR 0x18
#define SAMPLE_RATE 16000

// 효과음 크기 기본값 (1~10). 구글 시트 [설정]의 "효과음 크기(1~10)"가 있으면 그 값을 씀
#define SOUND_LEVEL_DEFAULT 4
static uint8_t levelToReg(int level) {          // ES8311 DAC 볼륨: 191 = 0dB, 1 = 0.5dB
  level = constrain(level, 1, 10);
  return 150 + level * 6;                       // 1 → -17.5dB ... 4 → -8.5dB ... 10 → +9.5dB
}

static I2SClass i2s;
static i2c_master_dev_handle_t codec = NULL;
static QueueHandle_t soundQueue = NULL;
static bool ready = false;
static const char *statusText = "준비 안 됨";

static bool cw(uint8_t reg, uint8_t val) {
  uint8_t b[2] = {reg, val};
  return i2c_master_transmit(codec, b, 2, 100) == ESP_OK;
}
static int cr(uint8_t reg) {
  uint8_t v = 0;
  if (i2c_master_transmit_receive(codec, &reg, 1, &v, 1, 100) != ESP_OK) return -1;
  return v;
}

static bool codecInit() {
  i2c_master_bus_handle_t bus = gsl3680_i2c_bus();
  if (!bus) { statusText = "I2C 버스 없음"; return false; }

  Serial.print("[소리] I2C 장치 찾기:");                 // 코덱 0x18, 터치 0x40 등이 보여야 함
  for (uint8_t a = 0x08; a < 0x78; a++)
    if (i2c_master_probe(bus, a, 50) == ESP_OK) Serial.printf(" 0x%02X", a);
  Serial.println();

  i2c_device_config_t dc = {};
  dc.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  dc.device_address = ES8311_ADDR;
  dc.scl_speed_hz = 100000;
  if (i2c_master_bus_add_device(bus, &dc, &codec) != ESP_OK) { statusText = "코덱 등록 실패"; return false; }
  int id1 = cr(0xFD), id2 = cr(0xFE);
  Serial.printf("[소리] 코덱 ID: %02X %02X (정상: 83 11)\n", id1 & 0xFF, id2 & 0xFF);
  if (id1 < 0) { statusText = "코덱(ES8311) 응답 없음"; return false; }

  // ESPHome es8311 드라이버와 같은 순서 (MCLK 4.096MHz = 256fs, 16kHz, 16비트, 슬레이브)
  bool ok = true;
  ok &= cw(0x00, 0x1F); delay(20);           // 리셋
  ok &= cw(0x00, 0x00);
  ok &= cw(0x01, 0x3F);                      // 모든 클럭 켜기, MCLK 핀 사용
  ok &= cw(0x02, 0x00);                      // pre_div 1, pre_mult 1
  ok &= cw(0x03, 0x10);                      // ADC OSR
  ok &= cw(0x04, 0x20);                      // DAC OSR
  ok &= cw(0x05, 0x00);                      // ADC/DAC 분주 1
  ok &= cw(0x06, 0x03);                      // BCLK 분주
  ok &= cw(0x07, 0x00);
  ok &= cw(0x08, 0xFF);                      // LRCK = MCLK/256
  ok &= cw(0x09, 0x0C);                      // 입력: I2S 16비트
  ok &= cw(0x0A, 0x0C);                      // 출력: I2S 16비트
  ok &= cw(0x14, 0x1A);
  ok &= cw(0x16, 0x04);
  ok &= cw(0x17, 0xC8);
  ok &= cw(0x32, levelToReg(SOUND_LEVEL_DEFAULT));   // 음량
  ok &= cw(0x0D, 0x01);                      // 아날로그 전원 켜기
  ok &= cw(0x0E, 0x02);
  ok &= cw(0x12, 0x00);                      // DAC 전원 켜기
  ok &= cw(0x13, 0x10);                      // 출력단 켜기
  ok &= cw(0x1C, 0x6A);
  ok &= cw(0x37, 0x08);
  ok &= cw(0x31, 0x00);                      // 음소거 해제
  ok &= cw(0x00, 0x80);                      // 동작 시작 (슬레이브 모드)
  Serial.printf("[소리] 코덱 설정 %s (0x00=%02X 0x01=%02X 0x32=%02X)\n", ok ? "완료" : "중 오류",
                cr(0x00) & 0xFF, cr(0x01) & 0xFF, cr(0x32) & 0xFF);
  if (!ok) statusText = "코덱 설정 실패";
  return ok;
}

// ---------------- 소리 만들기 ----------------
struct Note { float freq; int ms; };

static void playNotes(const Note *notes, int count, float amp) {
  const int FR = 256;                        // 한 번에 보내는 프레임 수
  static int16_t buf[FR * 2];
  for (int n = 0; n < count; n++) {
    int total = SAMPLE_RATE * notes[n].ms / 1000;
    float f = notes[n].freq;
    for (int i = 0; i < total; i += FR) {
      int len = min(FR, total - i);
      for (int k = 0; k < len; k++) {
        float t = (float)(i + k) / SAMPLE_RATE;
        float v = 0;
        if (f > 0) {
          // 부드러운 소리: 천천히 시작(15ms) + 길게 사라짐, 배음을 거의 넣지 않은 맑은 음
          float env = (t < 0.015f ? t / 0.015f : 1.0f) * expf(-t / 0.45f);
          float tail = (total - (i + k)) < 400 ? (total - (i + k)) / 400.0f : 1.0f;   // 끝을 부드럽게
          v = env * tail * (sinf(2 * PI * f * t) + 0.12f * sinf(4 * PI * f * t)) / 1.12f;
        }
        int16_t s = (int16_t)(v * amp * 32767);
        buf[k * 2] = s;
        buf[k * 2 + 1] = s;
      }
      i2s.write((uint8_t *)buf, len * 4);
    }
  }
  memset(buf, 0, sizeof(buf));               // 끝에 무음 조금
  for (int i = 0; i < 4; i++) i2s.write((uint8_t *)buf, sizeof(buf));
}

static void soundTask(void *) {
  // "띵-동" 한 번 (부드러운 초인종 소리). 소리 시험도 같은 소리를 냄
  static const Note callChime[] = {{784, 650}, {659, 1000}};
  static const Note onBeep[] = {{880, 250}};
  int req;
  for (;;) {
    if (xQueueReceive(soundQueue, &req, portMAX_DELAY) != pdTRUE) continue;
    digitalWrite(PIN_PA, PA_ON_LEVEL);
    delay(60);
    if (req == SOUND_ON) playNotes(onBeep, 1, 0.3f);
    else playNotes(callChime, sizeof(callChime) / sizeof(Note), 0.4f);
    delay(60);
    if (uxQueueMessagesWaiting(soundQueue) == 0) digitalWrite(PIN_PA, !PA_ON_LEVEL);
  }
}

bool soundBegin() {
  pinMode(PIN_PA, OUTPUT);
  digitalWrite(PIN_PA, !PA_ON_LEVEL);
  i2s.setPins(PIN_I2S_BCLK, PIN_I2S_WS, PIN_I2S_DOUT, -1, PIN_I2S_MCLK);
  if (!i2s.begin(I2S_MODE_STD, SAMPLE_RATE, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO)) {
    Serial.println("[소리] I2S 시작 실패");
    statusText = "I2S 시작 실패";
    return false;
  }
  delay(10);
  if (!codecInit()) {
    Serial.printf("[소리] %s\n", statusText);
    return false;
  }
  soundQueue = xQueueCreate(4, sizeof(int));
  xTaskCreate(soundTask, "sound", 4096, NULL, 3, NULL);
  ready = true;
  statusText = "준비됨";
  Serial.println("[소리] 효과음 준비 완료");
  return true;
}

void soundPlay(SoundType type) {
  if (!ready) return;
  int req = type;
  xQueueSend(soundQueue, &req, 0);
}

bool soundReady() { return ready; }

static int currentLevel = SOUND_LEVEL_DEFAULT;
void soundSetLevel(int level) {
  level = constrain(level, 1, 10);
  if (!ready || level == currentLevel) return;
  currentLevel = level;
  cw(0x32, levelToReg(level));
  Serial.printf("[소리] 크기 %d\n", level);
}
const char *soundStatusText() { return statusText; }
