// 효과음 (ES8311 코덱 + NS4150 앰프, JC8012P4A1C 내장 스피커)
#pragma once
#include <Arduino.h>

enum SoundType { SOUND_CALL, SOUND_TEST, SOUND_ON };

bool soundBegin();               // 터치 초기화(touch.begin) 다음에 호출 (같은 I2C 버스 사용)
void soundPlay(SoundType type);  // 바로 반환, 소리는 별도 작업에서 재생
bool soundReady();
const char *soundStatusText();
void soundSetLevel(int level);    // 효과음 크기 1~10   // 화면 표시용 상태 ("준비됨", "코덱 응답 없음" 등)
