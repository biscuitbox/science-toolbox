// 공통 호출 단말 프로그램 본체 (Wi-Fi·Firebase는 config.h, 명단·알림 시간은 구글 시트에서)
// 동작: 입구에서 호출이 오면 10초 동안 선생님 이름을 크게 띄우고 효과음을 냄
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <Preferences.h>
#include <time.h>
#include <U8g2lib.h>              // 반드시 Arduino_GFX보다 먼저! (한글 폰트 기능 활성화)
#include <Arduino_GFX_Library.h>

#include "config.h"
#include "cloud.h"              // 클라우드 중계 + 선생님 명단
#include "sound.h"
#include "wifi_ui.h"            // 화면에서 Wi-Fi 바꾸기
#include "src/touch/gsl3680_touch.h"
#include "fonts.h"            // 한글 폰트 (데이터는 fonts.cpp)

// ================= 설정 =================
#define LCD_PANEL_V2 1           // 1: 2026년 출하 새 패널(V2)  0: 이전 패널 → 화면이 안 나오면 바꾸세요
// 알림 시간·깜빡임 시간은 구글 시트 [설정]에서 바꿈 (cloudSettings)
#define DEFAULT_ROTATION 1       // 처음 화면 방향: 0 세로, 1 가로, 2 세로(반대), 3 가로(반대)
                                 // → 설치 후에는 설정 화면(맨 위 파란 영역 3초)에서 바꿀 수 있음
#define TOUCH_ROTATION 0         // (세로 기준) 터치 위치가 어긋나면 0~3 중에서 바꿔 보세요
#define TOUCH_DEBUG false        // true: 터치한 곳에 빨간 점 표시 (보정용)
#define PIN_BL 23                // 백라이트
#define PIN_BOOT_BTN 35          // 보드의 BOOT 버튼: 누르면 효과음 켜기/끄기

static const int PW = 800, PH = 1280;   // 패널 원래 크기 (세로)
int W = PW, H = PH;                      // 지금 화면 방향 기준 크기 (가로면 1280x800)

#if LCD_PANEL_V2
#include "lcd_panel_v2.h"
Arduino_ESP32DSIPanel *dsipanel = new Arduino_ESP32DSIPanel(
    20, 20, 40,    // hsync pulse / back porch / front porch
    4, 10, 20,     // vsync pulse / back porch / front porch
    70000000, 1500);
#define PANEL_INIT jc8012_v2_init_operations
#else
#include "lcd_panel_v1.h"
Arduino_ESP32DSIPanel *dsipanel = new Arduino_ESP32DSIPanel(
    20, 20, 40,
    4, 8, 20,
    60000000);
#define PANEL_INIT jc8012_v1_init_operations
#endif
Arduino_DSI_Display *dsi = new Arduino_DSI_Display(
    PW, PH, dsipanel, 0 /* rotation */, false /* auto_flush: 다 그린 뒤 flush() */,
    27 /* RST */, PANEL_INIT, sizeof(PANEL_INIT) / sizeof(lcd_init_cmd_t));
// 화면 깜빡임 방지: 보이지 않는 메모리(캔버스)에 먼저 다 그린 뒤 한 번에 화면으로 옮김
Arduino_Canvas *gfx = new Arduino_Canvas(PW, PH, dsi);
void present() {
  gfx->flush();      // 캔버스 → 화면 메모리
  dsi->flush();      // 화면 메모리 → 패널
}

gsl3680_touch touch(7 /*SDA*/, 8 /*SCL*/, 22 /*RST*/, 21 /*INT*/);
WiFiUDP udp;
Preferences prefs;

// ---------------- 색상 ----------------
static inline uint16_t RGB(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}
const uint16_t COL_BG = RGB(238, 241, 245);
const uint16_t COL_BAR = RGB(30, 58, 95);
const uint16_t COL_CARD = RGB(255, 255, 255);
const uint16_t COL_BORDER = RGB(205, 212, 222);
const uint16_t COL_TEXT = RGB(30, 33, 38);
const uint16_t COL_SUB = RGB(100, 110, 122);
const uint16_t COL_PRIMARY = RGB(37, 99, 235);
const uint16_t COL_SELECT = RGB(225, 236, 252);
const uint16_t COL_OK = RGB(22, 150, 70);
const uint16_t COL_BAD = RGB(210, 40, 40);
const uint16_t COL_OFF = RGB(120, 128, 138);
const uint16_t COL_LIGHT = RGB(170, 200, 235);
const uint16_t COL_YELLOW = RGB(255, 214, 0);    // 알림 배경 (멀리서도 잘 보이는 노랑)
const uint16_t COL_INK = RGB(18, 18, 18);        // 알림 글자 (검정에 가까운 색)
const uint16_t COL_AMBER = RGB(255, 160, 0);     // 부드러운 효과에서 노랑과 오가는 주황
const uint16_t COL_WHITE = 0xFFFF;

// ---------------- 상태 ----------------
enum Screen { SCR_SETUP, SCR_IDLE, SCR_ALERT, SCR_WIFI };
Screen screen = SCR_IDLE;
bool needRedraw = true;
uint32_t screenSince = 0;

String coverStr = "*";            // 받는 선생님: "*"(전체) 또는 "T01,T02"
bool covered[MAX_TEACHERS];       // 명단 순서대로 받는지 여부 (coverStr에서 계산)
bool editCovered[MAX_TEACHERS];
int setupPage = 0;
bool soundOn = true;
int fxMode = 0;                   // 알림 효과: 0 없음(화면 고정), 1 깜빡임(1초 간격), 2 부드럽게(색이 천천히 바뀜)
uint16_t alertBg = 0, alertFg = 0; // 지금 알림 화면의 배경/글자 색
int alertBarY = 0;
int blinkPhase = -1;
uint32_t lastBreath = 0, lastBar = 0;
int soundLevel = 4;               // 효과음 크기 1~10 (단말에서 바꾸거나 시트에서 바꾼 값)
int lastSheetLevel = -1;          // 마지막으로 받은 시트 값 (시트가 바뀌면 그 값을 따름)
uint8_t screenRot = DEFAULT_ROTATION;

struct Call { String id; String tid; String name; uint32_t start; char time[8]; };
const int MAX_ACTIVE = 4;
Call active[MAX_ACTIVE];          // 지금 화면에 띄우는 호출
int activeCount = 0;
uint32_t lastNewCall = 0;

String seen[16];                  // 이미 받은 호출 ID (입구가 같은 호출을 여러 번 보내도 한 번만 알림)
int seenPos = 0;

struct LogItem { char time[8]; char name[32]; };
LogItem recent[4];
int recentCount = 0;

uint32_t lastHB = 0;
int lastMinute = -1;
bool udpStarted = false, ntpStarted = false;
int netState = -1;
char lastCloudText[64] = "";

// ---------------- 버튼 ----------------
enum { BTN_SOUND = 1, BTN_TEST, BTN_FX, BTN_ROTATE, BTN_WIFI, BTN_VOLDN, BTN_VOLUP, BTN_ALL, BTN_NONE, BTN_SAVE, BTN_PREV, BTN_NEXT, BTN_TOGGLE = 100 };
struct Button { int16_t x, y, w, h; int id; };
Button buttons[24];
int buttonCount = 0;

// ============================================================
//  글자 그리기
// ============================================================
void textAt(const char *s, int x, int cy, const uint8_t *font, uint16_t color, int align /*0왼 1가운데 2오른*/) {
  gfx->setFont(font);
  gfx->setTextColor(color);
  int16_t x1, y1;
  uint16_t w, h;
  gfx->getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  int sx = (align == 0) ? x - x1 : (align == 1) ? x - x1 - w / 2 : x - x1 - w;
  gfx->setCursor(sx, cy - y1 - h / 2);
  gfx->print(s);
}
void textAt(const String &s, int x, int cy, const uint8_t *font, uint16_t color, int align) {
  textAt(s.c_str(), x, cy, font, color, align);
}

// 큰 글씨용: 48px 글자를 메모리에 그린 뒤 부드럽게 확대해서 찍음 (계단 현상 줄임)
class MaskCanvas : public Arduino_GFX {
public:
  MaskCanvas(int16_t w, int16_t h, uint8_t *buf) : Arduino_GFX(w, h), _buf(buf), _w(w), _h(h) {}
  bool begin(int32_t) override { return true; }
  void writePixelPreclipped(int16_t x, int16_t y, uint16_t) override {
    if (x >= 0 && y >= 0 && x < _w && y < _h) _buf[y * _w + x] = 255;
  }
private:
  uint8_t *_buf;
  int16_t _w, _h;
};

static inline uint16_t blend565(uint16_t fg, uint16_t bg, uint8_t a) {
  uint32_t fr = fg >> 11, fgc = (fg >> 5) & 0x3F, fb = fg & 0x1F;
  uint32_t br = bg >> 11, bgc = (bg >> 5) & 0x3F, bb = bg & 0x1F;
  uint32_t r = (fr * a + br * (255 - a)) / 255;
  uint32_t g = (fgc * a + bgc * (255 - a)) / 255;
  uint32_t b = (fb * a + bb * (255 - a)) / 255;
  return (r << 11) | (g << 5) | b;
}

int textWidth(const char *s, const uint8_t *font) {
  gfx->setFont(font);
  int16_t x1, y1;
  uint16_t w, h;
  gfx->getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  return w;
}
void trimLastChar(String &s) {                             // UTF-8 글자 하나 지우기 (한글이 깨지지 않게)
  int i = s.length() - 1;
  while (i > 0 && ((uint8_t)s[i] & 0xC0) == 0x80) i--;
  s.remove(i);
}

// 48px 기준 글자 폭
int textWidth48(const char *s) {
  gfx->setFont(font_kr48);
  int16_t x1, y1;
  uint16_t w, h;
  gfx->getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  return w;
}

// (cx, cy)를 가운데로 scale배 크기의 글씨를 그림. maxW를 넘으면 자동으로 줄임
void bigText(const String &str, int cx, int cy, float scale, uint16_t fg, uint16_t bg, int maxW = 0) {
  if (maxW <= 0) maxW = W - 60;
  const char *s = str.c_str();
  gfx->setFont(font_kr48);
  int16_t x1, y1;
  uint16_t w, h;
  gfx->getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  if (w == 0) return;
  if (w * scale > maxW) scale = (float)maxW / w;
  const int pad = 2;
  int mw = w + pad * 2, mh = h + pad * 2;
  uint8_t *m = (uint8_t *)heap_caps_calloc(mw * mh, 1, MALLOC_CAP_SPIRAM);
  if (!m) return;
  MaskCanvas mc(mw, mh, m);
  mc.setTextWrap(false);
  mc.setUTF8Print(true);
  mc.setFont(font_kr48);
  mc.setTextColor(1);
  mc.setCursor(pad - x1, pad - y1);
  mc.print(s);

  // 1비트 글자를 살짝 흐리게(3x3) 한 뒤 확대하면 계단 모양이 매끈해짐
  uint8_t *tmp = (uint8_t *)heap_caps_malloc(mw * mh, MALLOC_CAP_SPIRAM);
  if (tmp) {
    for (int y = 0; y < mh; y++)
      for (int x = 0; x < mw; x++) {
        int l = x > 0 ? m[y * mw + x - 1] : 0, r = x < mw - 1 ? m[y * mw + x + 1] : 0;
        tmp[y * mw + x] = (l + 2 * m[y * mw + x] + r) >> 2;
      }
    for (int y = 0; y < mh; y++)
      for (int x = 0; x < mw; x++) {
        int u = y > 0 ? tmp[(y - 1) * mw + x] : 0, d = y < mh - 1 ? tmp[(y + 1) * mw + x] : 0;
        m[y * mw + x] = (u + 2 * tmp[y * mw + x] + d) >> 2;
      }
    free(tmp);
  }

  int ow = mw * scale, oh = mh * scale;
  int ox = cx - ow / 2, oy = cy - oh / 2;
  float inv = 1.0f / scale;
  gfx->startWrite();
  for (int ty = 0; ty < oh; ty++) {
    int py = oy + ty;
    if (py < 0 || py >= H) continue;
    float sy = (ty + 0.5f) * inv - 0.5f;
    int y0 = (int)floorf(sy);
    float fy = sy - y0;
    for (int tx = 0; tx < ow; tx++) {
      int px = ox + tx;
      if (px < 0 || px >= W) continue;
      float sx = (tx + 0.5f) * inv - 0.5f;
      int x0 = (int)floorf(sx);
      float fx = sx - x0;
      auto at = [&](int x, int y) -> float {
        return (x < 0 || y < 0 || x >= mw || y >= mh) ? 0.0f : (float)m[y * mw + x];
      };
      float v = (at(x0, y0) * (1 - fx) + at(x0 + 1, y0) * fx) * (1 - fy) +
                (at(x0, y0 + 1) * (1 - fx) + at(x0 + 1, y0 + 1) * fx) * fy;
      float a = (v - 128.0f) * 3.0f + 128.0f;            // 가장자리를 또렷하게
      if (a <= 0) continue;
      if (a >= 255) gfx->writePixel(px, py, fg);
      else gfx->writePixel(px, py, blend565(fg, bg, (uint8_t)a));
    }
  }
  gfx->endWrite();
  free(m);
}

// ============================================================
//  도우미
// ============================================================
void addButton(int x, int y, int w, int h, int id, const char *label, const uint8_t *font,
               uint16_t bg, uint16_t fg, uint16_t border) {
  gfx->fillRoundRect(x, y, w, h, 24, bg);
  if (border != bg) {
    gfx->drawRoundRect(x, y, w, h, 24, border);
    gfx->drawRoundRect(x + 1, y + 1, w - 2, h - 2, 23, border);
  }
  if (label) textAt(label, x + w / 2, y + h / 2, font, fg, 1);
  if (buttonCount < 24) buttons[buttonCount++] = {(int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h, id};
}

int hitTest(int x, int y) {
  for (int i = buttonCount - 1; i >= 0; i--) {
    const Button &b = buttons[i];
    if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) return b.id;
  }
  return 0;
}


bool nowTime(struct tm &t) {
  if (!ntpStarted) return false;
  return getLocalTime(&t, 0) && t.tm_year > (2024 - 1900);
}

void card(int x, int y, int w, int h) {
  gfx->fillRoundRect(x, y, w, h, 24, COL_CARD);
  gfx->drawRoundRect(x, y, w, h, 24, COL_BORDER);
}
bool landscape() { return W > H; }
int headerH() { return landscape() ? 150 : 180; }

// 화면 방향 바꾸기 (0 세로, 1 가로, 2 세로 반대, 3 가로 반대)
void applyRotation(uint8_t r) {
  screenRot = r & 3;
  gfx->setRotation(screenRot);
  W = gfx->width();
  H = gfx->height();
  uiSetup(gfx, W, H, font_kr26, font_kr36);                // Wi-Fi 설정 화면도 같은 방향으로
  needRedraw = true;
}

// 터치 칩 좌표(패널 세로 기준) → 지금 화면 방향 좌표
void touchToScreen(int nx, int ny, int &x, int &y) {
  switch (screenRot) {
    case 1: x = ny; y = PW - 1 - nx; break;
    case 2: x = PW - 1 - nx; y = PH - 1 - ny; break;
    case 3: x = PH - 1 - ny; y = nx; break;
    default: x = nx; y = ny; break;
  }
}

String coverageTitle() {
  int n = 0;
  for (int t = 0; t < TEACHER_COUNT; t++) if (covered[t]) n++;
  if (n == TEACHER_COUNT) return "교무실 전체";
  String s;
  int shown = 0, subjCount = 0;
  for (int t = 0; t < TEACHER_COUNT; t++) {
    if (!covered[t]) continue;
    bool dup = false;
    for (int u = 0; u < t; u++) if (covered[u] && strcmp(TEACHERS[u].subject, TEACHERS[t].subject) == 0) dup = true;
    if (dup) continue;
    subjCount++;
    if (shown < 2) { if (shown) s += " · "; s += TEACHERS[t].subject; shown++; }
  }
  if (subjCount > 2) s += " 외";
  return s;
}

String coveredNames(int maxW) {
  String s;
  int total = 0, shown = 0;
  for (int t = 0; t < TEACHER_COUNT; t++) if (covered[t]) total++;
  gfx->setFont(font_kr26);
  for (int t = 0; t < TEACHER_COUNT; t++) {
    if (!covered[t]) continue;
    String next = s + (shown ? ", " : "") + TEACHERS[t].name;
    int16_t x1, y1;
    uint16_t w, h;
    gfx->getTextBounds((next + " 외 00명").c_str(), 0, 0, &x1, &y1, &w, &h);
    if (w > maxW && shown < total - 1) return s + " 외 " + (total - shown) + "명";
    s = next;
    shown++;
  }
  return s;
}

// ---------------- 설정 저장 ----------------
void applyCoverage() {                     // coverStr → covered[] (명단이 바뀔 때도 호출)
  for (int t = 0; t < TEACHER_COUNT; t++)
    covered[t] = coverStr == "*" || ("," + coverStr + ",").indexOf(String(",") + TEACHERS[t].id + ",") >= 0;
  cloudSetCoverage(coverStr);
}
bool isCoveredTid(const char *tid) {
  return coverStr == "*" || ("," + coverStr + ",").indexOf(String(",") + tid + ",") >= 0;
}
void loadSettings() {
  coverStr = prefs.getString("cover", "*");
  applyCoverage();
  soundOn = prefs.getBool("sound", true);
  fxMode = constrain(prefs.getInt("fx", 0), 0, 2);
  screenRot = prefs.getUChar("rot", DEFAULT_ROTATION) & 3;
  soundLevel = prefs.getInt("vol", cloudSettings.soundLevel);
  lastSheetLevel = prefs.getInt("svol", -1);
}

// 효과음 크기: 단말에서 바꾸면 그 값, 시트 값이 새로 바뀌면 시트 값을 따름 (나중에 바꾼 쪽이 적용)
void setSoundLevel(int level, bool preview) {
  soundLevel = constrain(level, 1, 10);
  prefs.putInt("vol", soundLevel);
  soundSetLevel(soundLevel);
  if (preview && soundOn) soundPlay(SOUND_TEST);
  needRedraw = true;
}
void syncSheetLevel() {
  if (cloudSettings.soundLevel != lastSheetLevel) {
    lastSheetLevel = cloudSettings.soundLevel;
    prefs.putInt("svol", lastSheetLevel);
    setSoundLevel(lastSheetLevel, false);
  }
}
void saveCoverage() {                      // covered[] → coverStr 저장
  String s;
  bool all = true;
  for (int t = 0; t < TEACHER_COUNT; t++) {
    if (covered[t]) { if (s.length()) s += ","; s += TEACHERS[t].id; }
    else all = false;
  }
  coverStr = all ? "*" : s;
  prefs.putString("cover", coverStr);
  applyCoverage();
}
const char *fxName(int m) { return m == 1 ? "깜빡임" : (m == 2 ? "부드럽게" : "없음"); }
void setFx(int m) {
  fxMode = m % 3;
  prefs.putInt("fx", fxMode);
  if (screen == SCR_IDLE) needRedraw = true;
}
void setSound(bool on) {
  soundOn = on;
  prefs.putBool("sound", on);
  if (on) soundPlay(SOUND_ON);
  Serial.printf("효과음 %s\n", on ? "켜짐" : "꺼짐");
  if (screen == SCR_IDLE) needRedraw = true;
}

// ============================================================
//  화면
// ============================================================
// 작은 켜기/끄기 버튼 (켜짐: 초록, 꺼짐: 회색)
void toggleButton(int x, int y, int w, int h, int id, const char *label, bool on) {
  uint16_t bg = on ? COL_OK : COL_OFF;
  addButton(x, y, w, h, id, nullptr, font_kr26, bg, COL_WHITE, bg);
  textAt(String(label) + (on ? " 켜짐" : " 꺼짐"), x + w / 2, y + h / 2, font_kr26, COL_WHITE, 1);
}

void drawHeaderBar() {
  int hh = headerH();
  gfx->fillRect(0, 0, W, hh, COL_BAR);
  textAt("교무실 공통 호출 단말", 40, landscape() ? 42 : 52, font_kr26, COL_LIGHT, 0);
  textAt(coverageTitle(), 40, landscape() ? 102 : 115, font_kr48, COL_WHITE, 0);
  struct tm t;
  if (nowTime(t)) {
    static const char *wd[7] = {"일", "월", "화", "수", "목", "금", "토"};
    char clock[8], date[32];
    snprintf(clock, sizeof(clock), "%02d:%02d", t.tm_hour, t.tm_min);
    snprintf(date, sizeof(date), "%d월 %d일 (%s)", t.tm_mon + 1, t.tm_mday, wd[t.tm_wday]);
    textAt(clock, W - 40, landscape() ? 55 : 65, font_kr48, COL_WHITE, 2);
    textAt(date, W - 40, landscape() ? 112 : 128, font_kr26, COL_LIGHT, 2);
  }
}

void drawStatusCard(int x, int y, int w, int h) {
  card(x, y, w, h);
  bool ok = WiFi.status() == WL_CONNECTED;
  int cy = y + h / 2 - 28;
  gfx->fillCircle(x + 60, cy, 20, ok ? COL_OK : COL_BAD);
  textAt(ok ? "호출 대기 중" : "Wi-Fi 연결 중...", x + 100, cy, font_kr48, COL_TEXT, 0);
  char sub[80];
  snprintf(sub, sizeof(sub), "호출이 오면 %d초 동안 이름을 크게 보여 드려요", cloudSettings.alertSeconds);
  textAt(sub, x + 40, cy + 70, font_kr26, COL_SUB, 0);
}

void drawRecentCard(int x, int y, int w, int h) {
  card(x, y, w, h);
  textAt("최근 호출", x + 40, y + 45, font_kr36, COL_TEXT, 0);
  if (recentCount == 0) textAt("아직 호출이 없어요", x + 40, y + 120, font_kr26, COL_SUB, 0);
  for (int i = 0; i < recentCount; i++) {
    int ry = y + 115 + i * 60;
    if (ry > y + h - 25) break;
    uint16_t c = i == 0 ? COL_TEXT : COL_SUB;
    textAt(recent[i].time, x + 40, ry, font_kr36, c, 0);
    textAt(String(recent[i].name) + " 선생님", x + 180, ry, font_kr36, c, 0);
  }
}

void drawCoverageCard(int x, int y, int w, int h) {
  card(x, y, w, h);
  textAt("받는 선생님", x + 30, y + 32, font_kr26, COL_SUB, 0);
  textAt(coveredNames(w - 60), x + 30, y + 75, font_kr26, COL_TEXT, 0);
}

void drawFooterLines(int y1, int y2, int y3, bool hintRight) {
  bool ok = WiFi.status() == WL_CONNECTED;
  String s = ok ? String("● Wi-Fi ") + WiFi.SSID() + " · " + WiFi.localIP().toString() : String("● Wi-Fi 연결 중... (") + wifiCurrentSsid() + ")";
  textAt(s, 40, y1, font_kr26, ok ? COL_OK : COL_BAD, 0);
  textAt(String("● ") + cloudStatusText(), 40, y2, font_kr26, cloudOk() ? COL_OK : (cloudEnabled() ? RGB(200, 120, 0) : COL_SUB), 0);
  if (hintRight) textAt("설정: 맨 위 파란 영역 3초 누르기", W - 40, y2, font_kr26, COL_SUB, 2);
  else textAt("설정: 맨 위 파란 영역을 3초간 누르기", 40, y3, font_kr26, COL_SUB, 0);
}

void drawIdle() {
  gfx->fillScreen(COL_BG);
  drawHeaderBar();
  if (landscape()) {                                       // ---- 가로 (1280x800)
    drawStatusCard(40, 175, 780, 170);
    drawRecentCard(40, 365, 780, 330);
    int bx = 850, bw = W - 40 - bx;
    toggleButton(bx, 175, bw, 80, BTN_SOUND, "효과음", soundOn);
    addButton(bx, 270, bw, 80, BTN_FX, nullptr, font_kr26, fxMode ? COL_OK : COL_OFF, COL_WHITE, fxMode ? COL_OK : COL_OFF);
    textAt(String("알림 효과: ") + fxName(fxMode), bx + bw / 2, 310, font_kr26, COL_WHITE, 1);
    addButton(bx, 365, bw, 80, BTN_TEST, "소리 시험", font_kr26, COL_CARD, COL_TEXT, COL_BORDER);
    if (!soundReady()) textAt(String("소리: ") + soundStatusText(), bx + bw / 2, 470, font_kr26, COL_BAD, 1);
    drawCoverageCard(bx, 500, bw, 195);
    drawFooterLines(730, 768, 0, true);
  } else {                                                 // ---- 세로 (800x1280)
    drawStatusCard(40, 210, 720, 200);
    drawRecentCard(40, 440, 720, 360);
    int bw = (720 - 30) / 3;
    toggleButton(40, 830, bw, 80, BTN_SOUND, "효과음", soundOn);
    addButton(40 + bw + 15, 830, bw, 80, BTN_FX, nullptr, font_kr26, fxMode ? COL_OK : COL_OFF, COL_WHITE, fxMode ? COL_OK : COL_OFF);
    textAt(String("효과: ") + fxName(fxMode), 40 + bw + 15 + bw / 2, 870, font_kr26, COL_WHITE, 1);
    addButton(40 + (bw + 15) * 2, 830, bw, 80, BTN_TEST, "소리 시험", font_kr26, COL_CARD, COL_TEXT, COL_BORDER);
    if (!soundReady()) textAt(String("소리 안 됨: ") + soundStatusText() + " (화면 알림은 동작)", 40, 945, font_kr26, COL_BAD, 0);
    drawCoverageCard(40, 985, 720, 125);
    drawFooterLines(1178, 1213, 1252, false);
  }
}

int currentBlinkPhase() {                                  // 0: 노랑, 1: 검정 (깜빡임 효과일 때만)
  uint32_t el = millis() - lastNewCall;
  if (fxMode != 1 || el >= (uint32_t)cloudSettings.flashSeconds * 1000UL) return 0;
  return (el / 1000) % 2;
}

// 남은 시간 막대만 다시 그리기 (화면 전체를 다시 그리지 않아 깜빡이지 않음)
void drawAlertBar() {
  if (activeCount == 0) return;
  float remain = 1.0f - (float)(millis() - active[activeCount - 1].start) / (cloudSettings.alertSeconds * 1000.0f);
  if (remain < 0) remain = 0;
  gfx->fillRect(60, alertBarY, W - 120, 30, alertBg);
  gfx->drawRoundRect(60, alertBarY, W - 120, 30, 15, alertFg);
  int bw = (int)((W - 128) * remain);
  if (bw > 0) gfx->fillRoundRect(64, alertBarY + 4, bw, 22, 11, alertFg);
}

// 부드럽게 효과: 배경색만 노랑 ↔ 주황으로 천천히 바꿈 (글자는 그대로)
void breathe() {
  float ph = (float)((millis() - lastNewCall) % 2400) / 2400.0f;
  float k = 0.5f - 0.5f * cosf(2 * PI * ph);
  uint16_t nb = blend565(COL_AMBER, COL_YELLOW, (uint8_t)(k * 255));
  if (nb == alertBg) return;
  uint16_t *fb = gfx->getFramebuffer();
  const int n = PW * PH;
  for (int i = 0; i < n; i++) if (fb[i] == alertBg) fb[i] = nb;
  alertBg = nb;
}

void drawAlert() {
  uint32_t now = millis();
  // 깜빡임 효과: 처음 몇 초 동안 1초마다 노랑/검정을 번갈아 → 이후 노랑 고정
  bool inverted = fxMode == 1 && currentBlinkPhase() == 1;
  uint16_t bg = inverted ? COL_INK : COL_YELLOW;
  uint16_t fg = inverted ? COL_YELLOW : COL_INK;
  alertBg = bg;
  alertFg = fg;
  gfx->fillScreen(bg);
  bool land = landscape();
  const Call &newest = active[activeCount - 1];

  bigText("교무실 입구 호출", W / 2, land ? 70 : 110, land ? 1.2f : 1.3f, fg, bg);
  gfx->fillRect(60, land ? 125 : 185, W - 120, 8, fg);
  int lineY, msgY;
  if (activeCount == 1) {
    const Call &c = active[0];
    if (land) {
      bigText(c.name, W / 2, 320, 4.5f, fg, bg);
      bigText("선생님", W / 2, 520, 2.2f, fg, bg);
      lineY = 600; msgY = 665;
    } else {
      bigText(c.name, W / 2, 440, 4.2f, fg, bg);
      bigText("선생님", W / 2, 660, 2.2f, fg, bg);
      lineY = 765; msgY = 0;
    }
  } else {                                                 // 여러 선생님: 최신 호출이 맨 위
    int gap = land ? 120 : 165, mid = land ? 365 : 575;
    for (int i = 0; i < activeCount; i++) {
      const Call &c = active[activeCount - 1 - i];
      bigText(c.name + " 선생님", W / 2, mid - (activeCount - 1) * gap / 2 + i * gap, land ? 1.8f : 2.2f, fg, bg);
    }
    lineY = land ? 600 : 960; msgY = land ? 665 : 1045;
  }
  gfx->fillRect(60, lineY, W - 120, 8, fg);
  if (land || activeCount > 1) {
    bigText("학생이 입구에서 기다리고 있어요", W / 2, msgY, land ? 1.1f : 1.0f, fg, bg);
  } else {
    bigText("학생이 입구에서", W / 2, 865, 1.3f, fg, bg);
    bigText("기다리고 있어요", W / 2, 955, 1.3f, fg, bg);
    bigText(String(newest.time) + " 호출", W / 2, 1050, 1.0f, fg, bg);
  }

  alertBarY = land ? 718 : 1140;
  if (fxMode != 0) {                                        // 효과가 있을 때만 줄어드는 시간 막대
    drawAlertBar();
    if (land) textAt(String(newest.time) + " 호출 · 화면을 누르면 바로 닫혀요", W / 2, 775, font_kr26, fg, 1);
    else textAt("화면을 누르면 바로 닫혀요", W / 2, 1230, font_kr36, fg, 1);
  } else {                                                  // 효과 없음: 화면을 한 번 그리고 닫힐 때까지 그대로
    String t = String(newest.time) + " 호출 · " + cloudSettings.alertSeconds + "초 뒤 닫혀요 · 누르면 바로 닫기";
    textAt(t, W / 2, land ? 740 : 1180, land ? font_kr26 : font_kr36, fg, 1);
  }
}

const char *rotationName(uint8_t r) {
  static const char *n[4] = {"세로", "가로", "세로(반대)", "가로(반대)"};
  return n[r & 3];
}

void drawSetup() {
  gfx->fillScreen(COL_BG);
  bool land = landscape();
  int hh = headerH();
  gfx->fillRect(0, 0, W, hh, COL_BAR);
  textAt("단말 설정", 40, land ? 45 : 55, font_kr26, COL_LIGHT, 0);
  textAt("이 단말에서 호출을 받을 선생님", 40, land ? 100 : 115, font_kr36, COL_WHITE, 0);

  int rowY = hh + 25, bw3 = (W - 80 - 30) / 3;
  addButton(40, rowY, bw3, 80, BTN_ALL, "전체 선택", font_kr26, COL_CARD, COL_TEXT, COL_BORDER);
  addButton(40 + bw3 + 15, rowY, bw3, 80, BTN_NONE, "모두 해제", font_kr26, COL_CARD, COL_TEXT, COL_BORDER);
  addButton(40 + (bw3 + 15) * 2, rowY, bw3, 80, BTN_ROTATE, nullptr, font_kr26, COL_SELECT, COL_PRIMARY, COL_PRIMARY);
  textAt(String("화면: ") + rotationName(screenRot), 40 + (bw3 + 15) * 2 + bw3 / 2, rowY + 40, font_kr26, COL_PRIMARY, 1);

  // 기기 설정 줄: Wi-Fi 바꾸기 / 효과음 크기
  int r2 = rowY + 95, ww = (W - 80) * 45 / 100, sw3 = (W - 80 - ww - 45) / 3;
  addButton(40, r2, ww, 80, BTN_WIFI, nullptr, font_kr26, COL_CARD, COL_TEXT, COL_BORDER);
  String wl = String("Wi-Fi: ") + wifiCurrentSsid();
  while (wl.length() > 8 && textWidth(wl.c_str(), font_kr26) > ww - 30) trimLastChar(wl);
  textAt(wl, 40 + ww / 2, r2 + 40, font_kr26, COL_TEXT, 1);
  int vx = 40 + ww + 15;
  addButton(vx, r2, sw3, 80, BTN_VOLDN, "소리 -", font_kr26, COL_CARD, COL_TEXT, COL_BORDER);
  textAt(String("크기 ") + soundLevel, vx + sw3 + 15 + sw3 / 2, r2 + 40, font_kr26, COL_TEXT, 1);
  addButton(vx + (sw3 + 15) * 2, r2, sw3, 80, BTN_VOLUP, "소리 +", font_kr26, COL_CARD, COL_TEXT, COL_BORDER);

  const int cols = land ? 3 : 2, rows = land ? 3 : 6;
  const int perPage = cols * rows;
  int cw = (W - 80 - (cols - 1) * 20) / cols, ch = 80, gy = rowY + 200;
  for (int i = setupPage * perPage; i < TEACHER_COUNT && i < (setupPage + 1) * perPage; i++) {
    int k = i - setupPage * perPage;
    int x = 40 + (k % cols) * (cw + 20), y = gy + (k / cols) * (ch + 15);
    String label = String(editCovered[i] ? "● " : "○ ") + TEACHERS[i].subject + " " + TEACHERS[i].name;
    addButton(x, y, cw, ch, BTN_TOGGLE + i, label.c_str(), font_kr36,
              editCovered[i] ? COL_SELECT : COL_CARD, editCovered[i] ? COL_PRIMARY : COL_SUB,
              editCovered[i] ? COL_PRIMARY : COL_BORDER);
  }
  int pages = (TEACHER_COUNT + perPage - 1) / perPage;
  int by = H - 120;
  if (pages > 1) {
    if (setupPage > 0) addButton(40, by, 180, 90, BTN_PREV, "← 이전", font_kr36, COL_CARD, COL_TEXT, COL_BORDER);
    if (setupPage < pages - 1) addButton(W - 220, by, 180, 90, BTN_NEXT, "다음 →", font_kr36, COL_CARD, COL_TEXT, COL_BORDER);
  }
  int n = 0;
  for (int t = 0; t < TEACHER_COUNT; t++) if (editCovered[t]) n++;
  int sw = W - 520;
  if (n > 0) addButton((W - sw) / 2, by, sw, 90, BTN_SAVE, "저장하고 닫기", font_kr36, COL_PRIMARY, COL_WHITE, COL_PRIMARY);
  else textAt("한 명 이상 골라 주세요", W / 2, by + 45, font_kr36, COL_BAD, 1);
}

void redraw() {
  buttonCount = 0;
  switch (screen) {
    case SCR_SETUP: drawSetup(); break;
    case SCR_WIFI: uiDraw(); break;
    case SCR_IDLE: drawIdle(); break;
    case SCR_ALERT: drawAlert(); break;
  }
  present();
  needRedraw = false;
}

void goScreen(Screen s) {
  screen = s;
  screenSince = millis();
  needRedraw = true;
}

// ============================================================
//  네트워크 (UDP 브로드캐스트)
//  메시지 형식: TAG|종류|호출ID|선생님ID
// ============================================================
void sendRaw(const char *buf) {
  if (WiFi.status() != WL_CONNECTED || !udpStarted) return;
  udp.beginPacket(WiFi.broadcastIP(), CALL_PORT);
  udp.print(buf);
  udp.endPacket();
}

void sendHeartbeat() {                                     // 예: CALL|HB|T01,T02|IDLE
  char buf[512];
  int n = snprintf(buf, sizeof(buf), "%s|HB|", SYSTEM_TAG);
  bool first = true;
  if (coverStr == "*") { n += snprintf(buf + n, sizeof(buf) - n, "*"); first = false; }
  else for (int t = 0; t < TEACHER_COUNT && n < (int)sizeof(buf) - 16; t++) {
    if (!covered[t]) continue;
    n += snprintf(buf + n, sizeof(buf) - n, "%s%s", first ? "" : ",", TEACHERS[t].id);
    first = false;
  }
  if (first) return;
  snprintf(buf + n, sizeof(buf) - n, "|%s", screen == SCR_ALERT ? "ALERT" : "IDLE");
  sendRaw(buf);
}

bool wasSeen(const char *id) {
  for (int i = 0; i < 16; i++) if (seen[i] == id) return true;
  return false;
}

// 호출 받음 (클라우드 또는 같은 Wi-Fi 직접 통신, 어느 쪽으로 와도 한 번만 알림)
void onCall(const char *id, const char *tid, const char *name) {
  char buf[96];
  snprintf(buf, sizeof(buf), "%s|RECV|%s|%s|", SYSTEM_TAG, id, tid);
  sendRaw(buf);                                            // 받았다고 입구에 알림 (직접 통신)
  if (wasSeen(id)) return;                                 // 같은 호출을 다시 받은 경우
  seen[seenPos] = id;
  seenPos = (seenPos + 1) % 16;
  cloudAckCall(id);                                        // 받았다고 클라우드에 표시

  if (activeCount == MAX_ACTIVE) {                         // 꽉 차면 가장 오래된 것 빼기
    for (int i = 0; i < MAX_ACTIVE - 1; i++) active[i] = active[i + 1];
    activeCount--;
  }
  for (int i = 0; i < activeCount; i++)                    // 같은 선생님이 이미 떠 있으면 교체
    if (active[i].tid == tid) {
      for (int k = i; k < activeCount - 1; k++) active[k] = active[k + 1];
      activeCount--;
      break;
    }
  Call &c = active[activeCount++];
  c.id = id;
  c.tid = tid;
  c.name = name;
  c.start = millis();
  struct tm tm;
  if (nowTime(tm)) snprintf(c.time, sizeof(c.time), "%02d:%02d", tm.tm_hour, tm.tm_min);
  else strcpy(c.time, "방금");

  for (int i = 3; i > 0; i--) recent[i] = recent[i - 1];  // 최근 호출 기록
  strcpy(recent[0].time, c.time);
  strlcpy(recent[0].name, name, sizeof(recent[0].name));
  if (recentCount < 4) recentCount++;

  lastNewCall = millis();
  if (soundOn) soundPlay(SOUND_CALL);
  Serial.printf("호출: %s 선생님 (%s)\n", name, id);
  if (screen != SCR_WIFI) goScreen(SCR_ALERT);             // Wi-Fi 입력 중에는 소리만 (입력 내용 보호)
}

// 이 단말이 맡은 선생님인지 확인 후 알림
void acceptCall(const char *id, const char *tid, const char *name) {
  if (!isCoveredTid(tid)) return;
  if (!name || !name[0]) {                                 // 이름이 없으면 명단에서 찾기
    int t = findTeacherById(tid);
    if (t < 0) return;
    name = TEACHERS[t].name;
  }
  onCall(id, tid, name);
}

void processMessage(char *msg) {
  char *f[6] = {0};
  int n = 0;
  char *save;
  for (char *p = strtok_r(msg, "|", &save); p && n < 6; p = strtok_r(NULL, "|", &save)) f[n++] = p;
  if (n < 4 || strcmp(f[0], SYSTEM_TAG) != 0) return;
  if (strcmp(f[1], "CALL") != 0) return;                  // CALL|CALL|호출ID|선생님ID|이름|교과
  acceptCall(f[2], f[3], n >= 5 ? f[4] : "");
}

void handleNetwork() {
  bool ok = WiFi.status() == WL_CONNECTED;
  int st = ok ? (cloudOk() ? 2 : 1) : 0;
  if (st != netState || strcmp(lastCloudText, cloudStatusText()) != 0) {   // 상태 표시가 바뀌면 다시 그림
    bool wasOk = netState > 0;
    netState = st;
    strlcpy(lastCloudText, cloudStatusText(), sizeof(lastCloudText));
    if (screen == SCR_IDLE) needRedraw = true;
    if (ok && !wasOk) {
      Serial.printf("Wi-Fi 연결됨: %s\n", WiFi.localIP().toString().c_str());
      if (!udpStarted) udpStarted = udp.begin(CALL_PORT);
      if (!ntpStarted) {                                   // 인터넷이 되면 시계 맞추기 (안 돼도 호출은 동작)
        configTzTime("KST-9", "pool.ntp.org", "time.google.com");
        ntpStarted = true;
      }
    }
  }
  if (!udpStarted) return;
  int len;
  while ((len = udp.parsePacket()) > 0) {
    char buf[512];
    int r = udp.read(buf, sizeof(buf) - 1);
    if (r <= 0) continue;
    buf[r] = 0;
    processMessage(buf);
  }
  IncomingCall ic;                                         // 클라우드로 온 호출
  while (cloudPopCall(ic)) acceptCall(ic.id, ic.tid, ic.name);
}

// ============================================================
//  타이머 / 버튼 / 터치
// ============================================================
void handleTimers() {
  uint32_t now = millis();
  if (now - lastHB > 3000) { lastHB = now; sendHeartbeat(); }

  if (activeCount > 0) {                                   // 10초 지난 호출은 내림
    int k = 0;
    for (int i = 0; i < activeCount; i++)
      if (now - active[i].start < (uint32_t)cloudSettings.alertSeconds * 1000UL) active[k++] = active[i];
    if (k != activeCount) { activeCount = k; needRedraw = true; }
  }

  switch (screen) {
    case SCR_ALERT: {
      if (activeCount == 0) { goScreen(SCR_IDLE); break; }
      bool changed = false;
      if (fxMode == 1) {                                    // 깜빡임: 1초마다 색을 바꿔 다시 그림
        int ph = currentBlinkPhase();
        if (ph != blinkPhase) { blinkPhase = ph; needRedraw = true; break; }
      } else if (fxMode == 2 && now - lastBreath >= 100) {  // 부드럽게: 0.1초마다 배경색만 조금씩
        lastBreath = now;
        breathe();
        changed = true;
      }
      if (fxMode != 0 && now - lastBar >= 250) { lastBar = now; drawAlertBar(); changed = true; }
      if (changed && !needRedraw) present();
      break;
    }
    case SCR_IDLE: {
      struct tm t;                                          // 1분마다 시계 갱신
      if (nowTime(t) && t.tm_min != lastMinute) { lastMinute = t.tm_min; needRedraw = true; }
      break;
    }
    default: break;
  }
}

void handleBootButton() {                                  // BOOT 버튼으로 효과음 켜기/끄기
  static bool last = HIGH;
  static uint32_t lastChange = 0;
  bool v = digitalRead(PIN_BOOT_BTN);
  if (v != last && millis() - lastChange > 50) {
    lastChange = millis();
    last = v;
    if (v == LOW) setSound(!soundOn);
  }
}

void onButton(int id) {
  if (id >= BTN_TOGGLE) {
    editCovered[id - BTN_TOGGLE] = !editCovered[id - BTN_TOGGLE];
    needRedraw = true;
    return;
  }
  switch (id) {
    case BTN_SOUND: setSound(!soundOn); break;
    case BTN_TEST: soundPlay(SOUND_TEST); break;
    case BTN_FX: setFx(fxMode + 1); break;
    case BTN_WIFI: wifiUiStart(); goScreen(SCR_WIFI); break;
    case BTN_VOLDN: setSoundLevel(soundLevel - 1, true); break;
    case BTN_VOLUP: setSoundLevel(soundLevel + 1, true); break;
    case BTN_ROTATE:                                        // 화면 방향 바꾸기 (바로 저장)
      applyRotation((screenRot + 1) & 3);
      prefs.putUChar("rot", screenRot);
      break;
    case BTN_ALL: for (int t = 0; t < TEACHER_COUNT; t++) editCovered[t] = true; needRedraw = true; break;
    case BTN_NONE: for (int t = 0; t < TEACHER_COUNT; t++) editCovered[t] = false; needRedraw = true; break;
    case BTN_PREV: setupPage--; needRedraw = true; break;
    case BTN_NEXT: setupPage++; needRedraw = true; break;
    case BTN_SAVE:
      for (int t = 0; t < TEACHER_COUNT; t++) covered[t] = editCovered[t];
      saveCoverage();
      goScreen(SCR_IDLE);
      break;
  }
}

void handleTouch() {
  static bool wasDown = false, longFired = false;
  static uint32_t downSince = 0, lastPoll = 0;
  if (millis() - lastPoll < 20) return;
  lastPoll = millis();

  uint16_t ux, uy;
  bool down = touch.getTouch(&ux, &uy);
  int x, y;
  touchToScreen(ux, uy, x, y);                             // 화면 방향에 맞게 좌표 변환
  if (down && !wasDown) {
    downSince = millis();
    longFired = false;
    if (TOUCH_DEBUG) {
      Serial.printf("터치 원래 (%u,%u) → 화면 (%d,%d)\n", ux, uy, x, y);
      gfx->fillCircle(x, y, 12, COL_BAD);
      present();
    }
    if (millis() - screenSince > 600) {                    // 화면 바뀐 직후 연속 터치 방지
      if (screen == SCR_WIFI) {                            // Wi-Fi 설정 화면
        UiResult r = uiTap(x, y);
        needRedraw = true;
        if (r != UI_NONE) goScreen(SCR_SETUP);
      } else if (screen == SCR_ALERT) {                    // 알림 화면: 아무 곳이나 누르면 닫기
        activeCount = 0;
        goScreen(SCR_IDLE);
      } else {
        int id = hitTest(x, y);
        if (id) onButton(id);
      }
    }
  }
  // 대기 화면 맨 위 파란 영역을 3초 누르면 설정 화면
  if (down && wasDown && !longFired && y < headerH() && screen == SCR_IDLE && millis() - downSince > 3000) {
    longFired = true;
    for (int t = 0; t < TEACHER_COUNT; t++) editCovered[t] = covered[t];
    setupPage = 0;
    goScreen(SCR_SETUP);
  }
  wasDown = down;
}

// ============================================================
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n교무실 공통 호출 단말 시작");

  if (!gfx->begin()) Serial.println("화면 초기화 실패! (PSRAM: Enabled 확인)");
  gfx->setUTF8Print(true);
  gfx->fillScreen(COL_BG);
  present();
  ledcAttach(PIN_BL, 5000, 8);
  ledcWrite(PIN_BL, 255);                                   // 최대 밝기

  if (touch.begin()) { touch.set_rotation(TOUCH_ROTATION); Serial.println("터치 OK"); }
  else Serial.println("터치 초기화 실패");
  soundBegin();                                             // 터치와 같은 I2C 버스를 쓰므로 터치 다음에
  pinMode(PIN_BOOT_BTN, INPUT_PULLUP);

  teachersInit();                                           // 저장된 명단(없으면 teachers.h)
  prefs.begin("callsys", false);
  loadSettings();
  applyRotation(screenRot);                                 // 저장된 화면 방향
  syncSheetLevel();                                         // 시트 값이 바뀌었으면 반영
  soundSetLevel(soundLevel);                                // 저장된 효과음 크기
  goScreen(SCR_IDLE);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);                                     // 절전 끄기: 브로드캐스트를 놓치지 않도록
  WiFi.setAutoReconnect(true);
  String ssid, pass;
  wifiLoadCreds(ssid, pass);                                // 화면에서 바꾼 Wi-Fi가 있으면 그것, 없으면 config.h
  WiFi.begin(ssid.c_str(), pass.c_str());
  cloudBegin(ROLE_TERMINAL);                                // 클라우드 중계 시작 (백그라운드)
}

void loop() {
  if (teachersApplyPending()) {                              // 구글 시트에서 새 명단·설정이 옴
    applyCoverage();
    syncSheetLevel();
    if (screen == SCR_SETUP) goScreen(SCR_IDLE);
    else if (screen == SCR_IDLE) needRedraw = true;
  }
  handleNetwork();
  handleTouch();
  handleBootButton();
  handleTimers();
  if (screen == SCR_WIFI && uiLoop()) needRedraw = true;   // 검색·접속 진행 상황
  if (needRedraw) redraw();
  delay(5);
}
