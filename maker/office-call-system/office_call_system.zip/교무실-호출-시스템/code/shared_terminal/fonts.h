// 한글 폰트 선언 (실제 데이터는 fonts.cpp 에서 한 번만 컴파일됨)
#pragma once
#include <stdint.h>
extern const uint8_t font_kr26[];
extern const uint8_t font_kr36[];
extern const uint8_t font_kr48[];
