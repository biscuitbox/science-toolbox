# 코드 안내

| 폴더 | 대상 | 여는 파일 |
|---|---|---|
| `entrance_caller/` | 입구 호출기 (JC4827W543C) | `entrance_caller.ino` |
| `shared_terminal/` | 공통 단말 (JC8012P4A1C) | `shared_terminal.ino` |
| `google_sheet/` | 구글 시트 Apps Script | `Code.gs`, `appsscript.json` |
| `firebase/` | Firebase 보안 규칙 | `database.rules.json` |
| `tools/display_test/` | 10.1" 화면 점검 | `display_test.ino` |
| `tools/wifi_test/` | Wi-Fi 점검 (두 보드 공용) | `wifi_test.ino` |
| `tools/c6_update/` | 10.1" Wi-Fi 보조칩 펌웨어 업데이트 | `c6_update.ino` |

- 두 스케치의 `config.h`에 Wi-Fi와 Firebase 정보를 **같게** 넣습니다. 자세한 방법은 `../docs/03_펌웨어_올리기.md`에 있습니다.
- `.ino` 파일에는 설명만 있고, 프로그램 본체는 `caller_app.cpp`와 `terminal_app.cpp`에 있습니다(Arduino IDE에서 탭으로 보입니다).
- 컴파일 확인 환경: Arduino ESP32 core 3.3.13, GFX Library for Arduino 1.6.9 (1.6.8에서도 확인), U8g2 2.37, ArduinoJson 7.4.
