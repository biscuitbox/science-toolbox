# 사용한 외부 자료와 라이선스

이 프로젝트를 공개하거나 배포할 때 아래 자료의 라이선스를 함께 지켜 주세요.

| 자료 | 사용한 곳 | 출처 | 라이선스 |
|---|---|---|---|
| 나눔고딕 ExtraBold | `font_kr*.h` (한글 2,350자 + 영문을 u8g2 비트맵으로 변환) | 네이버 / Google Fonts | SIL Open Font License 1.1 |
| GSL3680 터치 드라이버 | `code/shared_terminal/src/touch/` | Guition 제공 코드 기반, [CelliesProjects/JC8012P4A1-Arduino_GFX](https://github.com/CelliesProjects/JC8012P4A1-Arduino_GFX) | `esp_lcd_touch.*`: Apache-2.0, `gsl_point_id.c`: GPL v2. 나머지는 원 출처의 조건을 따릅니다. |
| 10.1" 새 패널(V2) 초기화 값, 오디오 핀 정보 | `lcd_panel_v2.h`, `sound.cpp` | [chickymonkey/guition-10.1-inch-esp32-p4](https://github.com/chickymonkey/guition-10.1-inch-esp32-p4) | MIT |
| 10.1" 이전 패널(V1) 초기화 값 | `lcd_panel_v1.h` | [Arduino_GFX](https://github.com/moononournation/Arduino_GFX) | Arduino_GFX 라이선스를 따름 |
| ESP-Hosted 보조칩 펌웨어 v2.12.13 | `code/tools/c6_update/c6_firmware.cpp` | Espressif (arduino-esp32 배포본) | Apache-2.0 |
| ES8311 초기화 순서 | `sound.cpp` | ESPHome es8311 컴포넌트 참고 | (참고 구현) |

## 이 프로젝트의 코드

나머지 코드(입구 호출기, 공통 단말 본체, 클라우드 모듈, Wi-Fi 설정 화면, 구글 시트 스크립트)의 라이선스는 만든 사람이 정해 주세요(예: MIT).

`gsl_point_id.c`가 GPL v2이므로, 공통 단말(`shared_terminal`) 펌웨어를 바이너리로 배포할 때는 GPL 조건(소스 공개)을 함께 지켜야 합니다.
